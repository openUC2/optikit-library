"""The vendor catalog row — BOMB's ``CatalogPart`` shape, field for field.

A row is a *search-index candidate*, never a library record: ``specs`` keeps
the vendor's cells with their unit and source, ``normalized`` is the typed
summary the picker ranks on (keyed by ``kind``), ``files`` are the vendor's
downloads (zmx · zar · step · pdf · dxf …) by role, and ``confidence`` says
whether a ``.zmx`` was parsed (``exact``) or only the table (``derived``).
JSON is camelCase, as in the snapshot; Python attributes are snake_case.
"""

from __future__ import annotations

import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

#: The Thorlabs "complete Zemax catalog" landing page — a hint, not a file.
GENERIC_ZEMAX_PAGE = "https://www.thorlabs.com/software-pages/zemax"


class CatalogModel(BaseModel):
    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True, extra="allow")

    def to_json(self) -> dict[str, Any]:
        return self.model_dump(by_alias=True, exclude_none=True)


class CatalogValue(CatalogModel):
    value: float | int | str | bool
    unit: str | None = None
    source: str = "vendorPage"


class CatalogFile(CatalogModel):
    kind: str
    role: str | None = None
    url: str
    local_path: str | None = None
    sha256: str | None = None


class CatalogPrice(CatalogModel):
    amount: float
    currency: str = "USD"
    quantity: int = 1
    region: str = ""
    checked_at: str = ""
    source_url: str = ""


class CatalogProvenance(CatalogModel):
    source: str = "vendorPage"
    url: str | None = None
    note: str = ""
    retrieved_at: str | None = None


Confidence = Literal["exact", "derived", "approximate"]


class CatalogPart(CatalogModel):
    id: str
    vendor: str
    sku: str
    title: str
    product_url: str = ""
    category_path: list[str] = Field(default_factory=list)
    component_type: str = "unknown"
    specs: dict[str, CatalogValue] = Field(default_factory=dict)
    normalized: dict[str, Any] = Field(default_factory=lambda: {"kind": "unknown"})
    files: list[CatalogFile] = Field(default_factory=list)
    price: CatalogPrice | None = None
    provenance: list[CatalogProvenance] = Field(default_factory=list)
    confidence: Confidence = "derived"
    last_indexed: str = ""

    @property
    def kind(self) -> str:
        return str(self.normalized.get("kind") or self.component_type)

    def spec(self, key: str) -> float | int | str | bool | None:
        v = self.specs.get(key)
        return None if v is None else v.value

    def is_cased(self) -> bool:
        """Mounted (in a cell/housing) vs bare glass — BOMB's ``isCasedCatalogPart``."""
        mounting = str(self.spec("mounting") or "").strip().lower()
        if mounting == "mounted":
            return True
        if mounting == "unmounted":
            return False
        if "threading" in self.specs:
            return True
        text = f"{self.title} {' '.join(self.category_path)}"
        if re.search(r"\bunmounted\b", text, re.I):
            return False
        return bool(re.search(r"\b(mounted|mount|housing|housed|cased|threaded)\b", text, re.I))

    def prescription_file(self) -> CatalogFile | None:
        """The product-level Zemax file, if the row names one (``.zmx`` before ``.zar``)."""
        candidates = [
            f
            for f in self.files
            if f.role == "opticalPrescription" and f.url and f.url != GENERIC_ZEMAX_PAGE
        ]
        for ext in (".zmx", ".zar", ".zip"):
            for f in candidates:
                if f.url.split("?")[0].lower().endswith(ext):
                    return f
        return None

    def to_compact(self) -> dict[str, Any]:
        """What a ranked list needs: identity, kind, the normalized numbers, price, cased."""
        return {
            "id": self.id, "sku": self.sku, "title": self.title, "kind": self.kind,
            "productUrl": self.product_url, "normalized": self.normalized,
            "confidence": self.confidence, "cased": self.is_cased(),
            "price": self.price.to_json() if self.price else None,
            "hasZmx": self.prescription_file() is not None,
        }

    def mechanical_files(self) -> list[CatalogFile]:
        return [f for f in self.files if f.role == "mechanicalModel"]
