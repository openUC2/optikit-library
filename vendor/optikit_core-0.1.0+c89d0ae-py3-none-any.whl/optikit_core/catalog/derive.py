"""Row-derived prescriptions (WP-255): a catalog row → a component record, no ``.zmx``.

Complete from the vendor table: spherical singlets, cemented doublets, and
plates (mirrors, curved mirrors, beamsplitters, dichroics, filters). Refused
by name: aspheres (the row has no conic/polynomial terms — fetch the zmx),
cylinders (WP-210), objectives (WP-220b), prisms.

Frames follow ``importers/thorlabs.py``: ``optical`` at the first vertex,
``exit`` at the last, ``mount`` at the edge mid-plane from the sag. Bands are
µm on the coated surface (WP-74); a ``transmit-ratio`` is the REFLECTED
fraction, as ``response.transmitted_fraction`` reads it.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any

from ..importers.thorlabs import _sag_mm, _slug
from ..schema.library import ComponentRecord
from .types import CatalogPart

INITIAL_VERSION = "0.1.0"

#: Vendor spellings → what optiland's database resolves (with the note the record carries).
_GLASS_ALIASES: dict[str, tuple[str, str | None]] = {
    "uv fused silica": ("LITHOSIL-Q", "fused silica modelled as Schott LITHOSIL-Q (n_d 1.4585)"),
    "fused silica": ("LITHOSIL-Q", "fused silica modelled as Schott LITHOSIL-Q (n_d 1.4585)"),
    "uvfs": ("LITHOSIL-Q", "fused silica modelled as Schott LITHOSIL-Q (n_d 1.4585)"),
    "bk7": ("N-BK7", None),
    "n-bk7": ("N-BK7", None),
    "optical glass": ("N-BK7", "vendor says 'Optical Glass' — modelled as N-BK7"),
}

_RANGE_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*(nm|µm|um)?\s*(?:-|–|to)\s*(\d+(?:\.\d+)?)\s*(nm|µm|um)", re.I
)


class CatalogDeriveError(Exception):
    """A row this road cannot turn into a record, with the code the API returns."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass
class DeriveResult:
    component: dict[str, Any]
    review: list[str] = field(default_factory=list)
    efl_mm: float | None = None
    part_id: str = ""
    sku: str = ""

    @property
    def record(self) -> ComponentRecord:
        return ComponentRecord.model_validate(self.component)


# --- small helpers ------------------------------------------------------------------------


def _radius(value: Any) -> float:
    """A row radius → float; ``None``/``'Infinity'``/≥1e8 mean flat."""
    if value is None or isinstance(value, str):
        return math.inf
    r = float(value)
    return math.inf if abs(r) >= 1e8 else r


def _num(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _um(nm: float) -> float:
    return round(nm / 1000.0, 4)


def ranges_um(text: str | None) -> list[list[float]]:
    """``'400 - 725 nm, 980 - 1700 nm'`` → ``[[0.4, 0.725], [0.98, 1.7]]``."""
    if not text:
        return []
    out: list[list[float]] = []
    for lo, unit_lo, hi, unit_hi in _RANGE_RE.findall(str(text)):
        unit = (unit_lo or unit_hi).lower()
        scale = 1.0 if unit == "nm" else 1000.0
        out.append([_um(float(lo) * scale), _um(float(hi) * scale)])
    return out


def paraxial_efl(stack: list[tuple[float, float, float]]) -> float | None:
    """Paraxial EFL of ``[(radius, thickness_after, n_after), …]`` starting in air."""
    y, u, n = 1.0, 0.0, 1.0
    for radius, thickness, n_next in stack:
        power = 0.0 if not math.isfinite(radius) or radius == 0 else (n_next - n) / radius
        u = (n * u - y * power) / n_next
        y += u * thickness
        n = n_next
    if abs(u) < 1e-12:
        return None
    return -1.0 / u


def glass_material(
    name: str | None, ior: float | None, review: list[str]
) -> tuple[dict | None, float]:
    """``material_post`` for a vendor glass name, plus an index for the paraxial check."""
    raw = (name or "").strip()
    if not raw:
        review.append(
            "glass unknown on the row — surfaces carry no material; add one before tracing"
        )
        return None, ior or 1.5168
    canonical, note = _GLASS_ALIASES.get(raw.lower(), (raw, None))
    if note:
        review.append(f"glass {raw!r}: {note}")
    try:
        from ..canvas.materials import resolve_glass

        glass, findings = resolve_glass(canonical, "row")
    except ImportError:
        glass, findings = None, []
        review.append(f"glass {canonical!r} unverified (optiland not installed)")
    if glass is None and findings:
        review.append(
            f"glass {canonical!r} is not bakeable by the canvas materializer "
            "(not in optiland's Sellmeier database) — the record validates, the trace will refuse"
        )
    elif glass is not None and glass.name != canonical:
        review.append(f"glass {canonical!r} normalized to database name {glass.name!r}")
        canonical = glass.name
    index = float(glass.index(0.5876)) if glass is not None else (ior or 1.5168)
    return {"type": "Material", "name": canonical}, index


def _surface(
    radius: float,
    *,
    thickness: float | None = None,
    material: dict | None = None,
    semi: float | None = None,
    reflective: bool = False,
    response: dict | None = None,
    rect: tuple[float, float] | None = None,
) -> dict[str, Any]:
    s: dict[str, Any] = {
        "type": "standard",
        "geometry": {"type": "StandardGeometry", "radius": radius, "conic": 0.0},
    }
    if thickness is not None:
        s["thickness"] = float(thickness)
    if material is not None:
        s["material_post"] = material
    if semi is not None:
        s["semi_aperture"] = float(semi)
    if rect is not None:
        w, h = rect
        s["aperture"] = {
            "type": "RectangularAperture",
            "x_min": -w / 2,
            "x_max": w / 2,
            "y_min": -h / 2,
            "y_max": h / 2,
        }
    if reflective:
        s["interaction_model"] = {"type": "refractive_reflective", "is_reflective": True}
    if response is not None:
        s["response"] = response
    return s


def _frames(surfaces: list[dict], review: list[str]) -> dict[str, Any]:
    ct = sum(float(s.get("thickness", 0.0)) for s in surfaces)
    semi = max((s["semi_aperture"] for s in surfaces if "semi_aperture" in s), default=0.0)
    mount = ct / 2.0
    if semi > 0:
        try:
            front = _sag_mm(surfaces[0], semi)
            back = _sag_mm(surfaces[-1], semi)
            mount = (front + (ct + back)) / 2.0
        except ValueError:
            review.append(
                "mount frame set to the centre-thickness mid-plane (semi-diameter exceeds a radius)"
            )
    return {
        "optical": {"z-mm": 0.0},
        "exit": {"z-mm": round(ct, 9)},
        "mount": {"z-mm": round(mount, 6)},
    }


def _dims(n: dict[str, Any]) -> tuple[float | None, tuple[float, float] | None]:
    """(semi-aperture, rect) from a plate row's diameter or width×height."""
    d = _num(n.get("diameterMm"))
    w, h = _num(n.get("widthMm")), _num(n.get("heightMm"))
    if d:
        return d / 2.0, None
    if w and h:
        return max(w, h) / 2.0, (w, h)
    if w or h:
        return (w or h) / 2.0, None
    return None, None


# --- families -----------------------------------------------------------------------------


def _lens(part: CatalogPart, n: dict, review: list[str]) -> tuple[list[dict], float | None]:
    ct = _num(n.get("thicknessMm"))
    semi = _num(n.get("apertureRadiusMm")) or (_num(part.spec("diameter")) or 0) / 2 or None
    if ct is None or semi is None:
        raise CatalogDeriveError(
            "E_CATALOG_INCOMPLETE", f"{part.sku}: row lacks centre thickness or diameter"
        )
    material, index = glass_material(n.get("material"), _num(n.get("ior")), review)
    r1, r2 = _radius(n.get("r1Mm")), _radius(n.get("r2Mm"))
    surfaces = [
        _surface(r1, thickness=ct, material=material, semi=semi),
        _surface(r2, semi=semi),
    ]
    return surfaces, paraxial_efl([(r1, ct, index), (r2, 0.0, 1.0)])


def _achromat(part: CatalogPart, n: dict, review: list[str]) -> tuple[list[dict], float | None]:
    vals = [_num(n.get(k)) for k in ("r1Mm", "r2Mm", "r3Mm", "t1Mm", "t2Mm")]
    if any(v is None for v in vals[3:]) or all(v is None for v in vals[:3]):
        raise CatalogDeriveError(
            "E_CATALOG_INCOMPLETE", f"{part.sku}: row lacks the doublet radii/thicknesses"
        )
    r1, r2, r3 = (_radius(n.get(k)) for k in ("r1Mm", "r2Mm", "r3Mm"))
    t1, t2 = float(vals[3]), float(vals[4])
    semi = _num(n.get("apertureRadiusMm")) or (_num(part.spec("diameter")) or 0) / 2
    if not semi:
        raise CatalogDeriveError("E_CATALOG_INCOMPLETE", f"{part.sku}: row lacks a diameter")
    m1, n1 = glass_material(n.get("glass1"), _num(n.get("ior1")), review)
    m2, n2 = glass_material(n.get("glass2"), _num(n.get("ior2")), review)
    # Cemented: no air gap between the elements (the WP-252 rule).
    surfaces = [
        _surface(r1, thickness=t1, material=m1, semi=semi),
        _surface(r2, thickness=t2, material=m2, semi=semi),
        _surface(r3, semi=semi),
    ]
    return surfaces, paraxial_efl([(r1, t1, n1), (r2, t2, n2), (r3, 0.0, 1.0)])


def _plate(
    part: CatalogPart, n: dict, review: list[str], *, kind: str
) -> tuple[list[dict], dict[str, Any], float | None]:
    """Mirror / curved mirror / beamsplitter / dichroic / filter as a coated plate."""
    semi, rect = _dims(n)
    if semi is None and kind == "polarizingBeamSplitter":
        # Thorlabs PBSnnx cubes carry their edge in the SKU (PBS251 = 25.4 mm).
        m = re.match(r"PBS(10|12|20|25)", part.sku, re.I)
        if m:
            edge = {"10": 10.0, "12": 12.7, "20": 20.0, "25": 25.4}[m.group(1)]
            semi, n = edge / 2.0, {**n, "shape": "cube", "widthMm": edge, "heightMm": edge}
    if semi is None:
        raise CatalogDeriveError(
            "E_CATALOG_INCOMPLETE", f"{part.sku}: row lacks a diameter or width×height"
        )
    t = _num(n.get("thicknessMm")) or 2.0
    substrate, _ = glass_material(n.get("substrate") or n.get("material") or "N-BK7", None, review)
    efl: float | None = None
    response: dict[str, Any] | None = None
    reflective = kind != "filter"
    radius = math.inf
    ports: dict[str, Any] = {"front": {"frame": "optical", "direction": "-z"}}

    if kind == "mirror":
        response = {"kind": "mirror"}
        bands = ranges_um(str(n.get("coating") or part.spec("wavelengthRange") or ""))
        if bands:
            response["reflect-bands-um"] = bands
        else:
            review.append("mirror coating band not on the row — reflects everything (broadband)")
        ports["reflected"] = {"frame": "optical", "direction": "-x", "after-surface": 0}
    elif kind == "curvedMirror":
        roc = _num(n.get("radiusOfCurvatureMm"))
        if not roc:
            raise CatalogDeriveError(
                "E_CATALOG_INCOMPLETE", f"{part.sku}: curved mirror without a radius of curvature"
            )
        radius = -abs(roc)  # concave toward the beam
        efl = abs(roc) / 2.0
        response = {"kind": "mirror"}
        ports["reflected"] = {"frame": "optical", "direction": "-x", "after-surface": 0}
    elif kind == "beamSplitter":
        ratio = _num(n.get("splitRatio"))
        if ratio is None:
            ratio = 0.5
            review.append("split ratio not on the row — 50:50 assumed")
        response = {"kind": "sampler", "transmit-ratio": round(ratio, 4)}
        ports["transmitted"] = {"frame": "optical", "direction": "+z", "after-surface": 1}
        ports["reflected"] = {"frame": "optical", "direction": "-x", "after-surface": 0}
    elif kind == "polarizingBeamSplitter":
        response = {"kind": "polarizing"}
        review.append(
            "polarization axis is not on the row — declare polarization-deg before a BB84-class use"
        )
        ports["transmitted"] = {"frame": "optical", "direction": "+z", "after-surface": 1}
        ports["reflected"] = {"frame": "optical", "direction": "-x", "after-surface": 0}
    elif kind == "dichroic":
        response = {"kind": "dichroic"}
        fk = str(n.get("filterKind") or "longpass")
        cut = _num(n.get("cutoffWavelengthNm"))
        if fk == "longpass" and cut:
            response["reflect-bands-um"] = [[None, _um(cut)]]
        elif fk == "shortpass" and cut:
            response["reflect-bands-um"] = [[_um(cut), None]]
        elif fk == "bandpass":
            passed = ranges_um(str(n.get("transmissionBand") or ""))
            if passed:
                lo, hi = passed[0]
                response["reflect-bands-um"] = [[None, lo], [hi, None]]
            else:
                review.append(
                    "bandpass dichroic: transmission band not parseable — no bands declared"
                )
        else:
            review.append("dichroic cut-on not on the row — no bands declared (wavelength-blind)")
        ports["transmitted"] = {"frame": "optical", "direction": "+z", "after-surface": 1}
        ports["reflected"] = {"frame": "optical", "direction": "-x", "after-surface": 0}
    elif kind == "filter":
        response = {"kind": "absorptive"}
        fk = str(n.get("filterKind") or "bandpass")
        centre, width, cut = (
            _num(n.get(k)) for k in ("centerWavelengthNm", "bandwidthNm", "cutoffWavelengthNm")
        )
        if fk == "bandpass" and centre and width:
            response["transmit-bands-um"] = [[_um(centre - width / 2), _um(centre + width / 2)]]
        elif fk == "longpass" and cut:
            response["transmit-bands-um"] = [[_um(cut), None]]
        elif fk == "shortpass" and cut:
            response["transmit-bands-um"] = [[None, _um(cut)]]
        elif fk == "multiband" and ranges_um(str(n.get("transmissionBand") or "")):
            response["transmit-bands-um"] = ranges_um(str(n.get("transmissionBand") or ""))
        else:
            review.append(f"{fk} filter: centre/width or cut-on not on the row — no bands declared")
        ports["back"] = {"frame": "exit", "direction": "+z", "after-surface": 1}

    cube = str(n.get("shape") or "") == "cube"
    if cube:
        # One reflective interface, like openuc2.beamsplitter.cube_5050: the cube's own
        # glass path is not modelled; ports leave after surface 0.
        surfaces = [_surface(radius, semi=semi, reflective=True, response=response)]
        for p in ("transmitted", "reflected"):
            if p in ports:
                ports[p]["after-surface"] = 0
                ports[p]["frame"] = "optical"
        review.append(
            "cube spelled as its diagonal interface only (no glass path), as the shipped cube_5050"
        )
    else:
        surfaces = [
            _surface(
                radius,
                thickness=t,
                material=substrate,
                semi=semi,
                reflective=reflective,
                response=response,
                rect=rect,
            ),
            _surface(math.inf, semi=semi, rect=rect),
        ]
    return surfaces, ports, efl


_CATEGORY = {
    "sphericalLens": "lens",
    "achromatDoublet": "lens",
    "mirror": "mirror",
    "curvedMirror": "mirror",
    "beamSplitter": "beamsplitter",
    "polarizingBeamSplitter": "beamsplitter",
    "dichroic": "dichroic",
    "filter": "filter",
}

_REFUSALS = {
    "asphericLens": (
        "E_CATALOG_ZMX_ONLY",
        "the table has no conic/polynomial terms — fetch the vendor zmx "
        "(catalog fetch) and import that",
    ),
    "cylindricalLens": (
        "E_CATALOG_UNSUPPORTED",
        "cylindrical lenses wait for the dialect's cylinder entry (WP-210)",
    ),
    "objective": (
        "E_CATALOG_UNSUPPORTED",
        "objectives wait for the aplanatic facts block (WP-220b)",
    ),
    "prism": ("E_CATALOG_UNSUPPORTED", "prisms have no dialect entry"),
}


def derive_component(
    part: CatalogPart,
    *,
    namespace: str = "thorlabs",
    vendor_name: str = "",
    snapshot_version: str = "",
) -> DeriveResult:
    """One catalog row → the proposed ``optical_component`` (validated), or a named refusal."""
    kind = part.kind
    if kind in _REFUSALS:
        code, why = _REFUSALS[kind]
        raise CatalogDeriveError(code, f"{part.sku} ({kind}): {why}")
    category = _CATEGORY.get(kind)
    if category is None:
        raise CatalogDeriveError(
            "E_CATALOG_UNSUPPORTED", f"{part.sku}: no derivation for kind {kind!r}"
        )

    n = part.normalized
    review: list[str] = [
        f"prescription derived from the catalog row (confidence {part.confidence}), "
        "not from a vendor .zmx"
    ]
    efl_row = _num(n.get("focalLengthMm"))
    if kind == "sphericalLens":
        surfaces, efl_calc = _lens(part, n, review)
        ports = {
            "front": {"frame": "optical", "direction": "-z"},
            "back": {"frame": "exit", "direction": "+z", "after-surface": 1},
        }
    elif kind == "achromatDoublet":
        surfaces, efl_calc = _achromat(part, n, review)
        ports = {
            "front": {"frame": "optical", "direction": "-z"},
            "back": {"frame": "exit", "direction": "+z", "after-surface": 2},
        }
    else:
        surfaces, ports, efl_calc = _plate(part, n, review, kind=kind)

    efl = efl_row if efl_row is not None else efl_calc
    if (
        efl_row is not None
        and efl_calc is not None
        and abs(efl_calc - efl_row) > 0.02 * abs(efl_row)
    ):
        review.append(
            f"paraxial EFL from the row's radii is {efl_calc:.2f} mm, "
            f"the vendor says {efl_row:.2f} mm — check the glass"
        )

    vendor = vendor_name or part.vendor.capitalize()
    tags = ["imported", "catalog"] + ([f"catalog/{snapshot_version}"] if snapshot_version else [])
    component: dict[str, Any] = {
        "kind": "optical_component",
        "id": f"{namespace}.{category}.{_slug(part.sku)}",
        "version": INITIAL_VERSION,
        "category": category,
        "description": part.title,
        "tags": tags,
        "vendor": {
            "name": vendor, "mpn": part.sku, "url": part.product_url,
            **({"price": part.price.amount, "currency": part.price.currency} if part.price else {}),
        },
        "optics": {
            "fragment": {"surfaces": surfaces},
            "frames": _frames(surfaces, review),
            "ports": ports,
        },
        "review": review,
    }
    if efl is not None:
        component["effective_focal_length_mm"] = round(float(efl), 6)
    result = DeriveResult(
        component=component, review=review, efl_mm=efl, part_id=part.id, sku=part.sku
    )
    _ = result.record  # validate eagerly — an unwritable record fails here
    return result
