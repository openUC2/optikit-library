"""Library records → a catalog snapshot: openUC2's own primitives as rows.

The reverse of ``derive.py``: the curated components ARE the vendor table for
openUC2's parts, so the snapshot is derived from them rather than maintained
by hand — re-running after a record change is the update. Rows use the same
``CatalogPart`` shape (and the picker's exact ``normalized`` key spellings) as
the converted BOMB crawl, so both rank in one picker.
"""

from __future__ import annotations

from typing import Any

from ..library.build import Library
from ..schema.library import ComponentRecord
from .snapshot import Snapshot, today
from .types import CatalogPart, CatalogPrice, CatalogProvenance, CatalogValue

#: Component categories that become rows, → the picker's row kind.
ROW_KINDS = {
    "lens": "lens",
    "mirror": "mirror",
    "beamsplitter": "beamSplitter",
    "dichroic": "dichroic",
    "filter": "filter",
    "objective": "objective",
    "detector": "detector",
}


def _spec(value: Any, unit: str | None = None) -> CatalogValue:
    return CatalogValue(value=value, unit=unit, source="libraryRecord")


def _semi_aperture_mm(record: ComponentRecord) -> float | None:
    """The largest declared surface semi-aperture (the row's face radius)."""
    if record.optics.fragment is None:
        return None
    values = [
        float(s["semi_aperture"])
        for s in record.optics.fragment.surfaces
        if isinstance(s.get("semi_aperture"), int | float)
    ]
    return max(values) if values else None


def _band_view(record: ComponentRecord) -> dict[str, Any]:
    """Filter facts off the first transmit band: bandpass, or an open edge.

    An upper limit past 5 µm reads as a longpass, a lower limit under 0.2 µm
    as a shortpass — the band model's way of spelling an open edge.
    """
    if record.optics.fragment is None:
        return {}
    for surface in record.optics.fragment.surfaces:
        response = surface.get("response") or {}
        bands = response.get("transmit-bands-um") or []
        if not bands:
            continue
        lo_um, hi_um = float(bands[0][0]), float(bands[0][1])
        if hi_um >= 5.0:
            return {"filterKind": "longpass", "cutoffWavelengthNm": lo_um * 1000}
        if lo_um <= 0.2:
            return {"filterKind": "shortpass", "cutoffWavelengthNm": hi_um * 1000}
        return {
            "filterKind": "bandpass",
            "centerWavelengthNm": (lo_um + hi_um) / 2 * 1000,
            "bandwidthNm": (hi_um - lo_um) * 1000,
        }
    return {}


def _normalized(record: ComponentRecord, kind: str) -> dict[str, Any]:
    semi = _semi_aperture_mm(record)
    if kind == "objective" and record.objective is not None:
        o = record.objective
        return {
            "kind": kind,
            "magnification": o.magnification,
            "numericalAperture": o.numerical_aperture,
            "workingDistanceMm": o.working_distance_mm,
            "tubeLensFocalMm": o.tube_lens_f_mm,
        }
    if kind == "detector" and record.detector is not None:
        d = record.detector
        return {
            "kind": kind,
            "sensor": d.sensor,
            "pixelPitchUm": d.pixel_pitch_um,
            "resolutionPx": list(d.resolution) if d.resolution else None,
            "quantumEfficiency": d.quantum_efficiency,
        }
    if kind == "lens":
        return {
            "kind": kind,
            "focalLengthMm": record.effective_focal_length_mm,
            "apertureRadiusMm": semi,
            **({"diameterMm": 2 * semi} if semi is not None else {}),
        }
    if kind in ("filter", "dichroic"):
        return {"kind": kind, **({"diameterMm": 2 * semi} if semi else {}), **_band_view(record)}
    # mirror / beamSplitter: the face size is the one honest number.
    return {"kind": kind, **({"diameterMm": 2 * semi} if semi else {})}


def library_rows(library: Library, namespace: str = "openuc2") -> list[CatalogPart]:
    """One row per latest-version component in ``namespace`` with a row kind."""
    latest: dict[str, ComponentRecord] = {}
    for loaded in library.by_kind("optical_component"):
        record = loaded.record
        assert isinstance(record, ComponentRecord)
        if record.namespace != namespace or record.category not in ROW_KINDS:
            continue
        held = latest.get(record.id)
        if held is None or record.version > held.version:
            latest[record.id] = record

    rows: list[CatalogPart] = []
    for record in sorted(latest.values(), key=lambda r: r.id):
        kind = ROW_KINDS[record.category]
        name = record.id.rsplit(".", 1)[-1]
        specs: dict[str, CatalogValue] = {}
        if record.objective is not None:
            o = record.objective
            for key, value, unit in (
                ("immersion", o.immersion, None), ("thread", o.thread, None),
                ("parfocalDistance", o.parfocal_distance_mm, "mm"),
                ("fieldNumber", o.field_number_mm, "mm"), ("correction", o.correction, None),
            ):
                if value not in (None, ""):
                    specs[key] = _spec(value, unit)
        if record.detector is not None:
            d = record.detector
            for key, value, unit in (
                ("sensorSize", "x".join(str(v) for v in d.sensor_size_mm or []) or None, "mm"),
                ("bitDepth", d.bit_depth, "bit"), ("fpsMax", d.fps_max, "fps"),
                ("mount", d.mount or None, None),
            ):
                if value is not None:
                    specs[key] = _spec(value, unit)
        rows.append(CatalogPart(
            id=f"{namespace}:{name}",
            vendor=record.vendor.name or "openUC2",
            sku=record.vendor.mpn or name,
            title=record.description or name,
            product_url=record.vendor.url or (record.docs[0] if record.docs else ""),
            category_path=[namespace, record.category],
            component_type=kind,
            specs=specs,
            normalized=_normalized(record, kind),
            price=CatalogPrice(
                amount=float(record.vendor.price), currency=record.vendor.currency or "EUR",
                checked_at=today(), source_url=record.vendor.url,
            ) if record.vendor.price is not None else None,
            provenance=[CatalogProvenance(
                source="libraryRecord", note=f"{record.id}@{record.version}",
                retrieved_at=today(),
            )],
            confidence="derived",
            last_indexed=today(),
        ))
    return rows


def merged_snapshot(rows: list[CatalogPart], base: Snapshot | None, version: str) -> Snapshot:
    """``rows`` over ``base``: same-id rows replaced, everything else kept.

    The service reads only the LATEST snapshot, so a standalone openUC2 file
    would SHADOW the vendor rows — merging is the deployable default.
    """
    ours = {row.id for row in rows}
    kept = [p for p in (base.parts if base else []) if p.id not in ours]
    source = f"library+{base.source}" if base and base.source else "library"
    return Snapshot(version=version, source=source, retrieved_at=today(), parts=kept + rows)
