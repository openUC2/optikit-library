"""The Thorlabs crawler (WP-225b): their content API, our robots policy, a page cache.

Policy (plan §7.1): one request per ``delay_s`` to www.thorlabs.com — its
``robots.txt`` says ``Crawl-delay: 30`` — pages cached on disk by slug so a
re-run costs nothing, a client that names itself, and never a STEP/DXF.
Family pages are BFS-crawled from a slug list; product assets (the per-SKU
zmx URL) are looked up lazily, one SKU at a time, by ``catalog fetch``.
"""

from __future__ import annotations

import json
import re
import time
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .fetch import USER_AGENT
from .snapshot import Snapshot, today
from .thorlabs import linked_slugs, parse_family_page, should_crawl
from .types import CatalogFile, CatalogPart

GRAPHQL = "https://www.thorlabs.com/graphql"
STORE = {
    "storeId": "Thorlabs-Website",
    "cultureName": "en-US",
    "userId": "Anonymous",
    "country": "USA",
}

SLUG_INFO_QUERY = (
    "query SlugInfo($slug:String,$storeId:String,$userId:String,"
    "$cultureName:String,$country:String){"
    " slugInfo(slug:$slug,storeId:$storeId,userId:$userId,"
    "cultureName:$cultureName,country:$country){"
    " entityInfo { objectId objectType semanticUrl } } }"
)
PAGE_QUERY = (
    "query Page($id:String!,$cultureName:String,$storeId:String!){"
    " page(id:$id,cultureName:$cultureName,storeId:$storeId){ id name content permalink } }"
)
ASSETS_QUERY = (
    "query ProductAssets($storeId:String!,$currencyCode:String!,$cultureName:String,$id:String!){"
    " product(storeId:$storeId,id:$id,currencyCode:$currencyCode,cultureName:$cultureName){"
    " code id assets { id name url group description optiUrl mimeType } } }"
)

#: BOMB's family roots, minus objectives/prisms (the snapshot carries those).
LENS_SLUGS = [
    "plano-convex-spherical-lenses",
    "bi-convex-spherical-lenses",
    "plano-concave-spherical-lenses",
    "bi-concave-spherical-lenses",
    "best-form-lenses",
    "positive-meniscus-lenses",
    "negative-meniscus-lenses",
    "unmounted-achromatic-doublets-ar-coated-400---700-nm",
    "mounted-achromatic-doublets-ar-coated-400---700-nm",
    "plano-convex-round-cylindrical-lenses-caf2-mounted",
    "molded-glass-aspheric-lenses-uncoated",
    "molded-glass-aspheric-lenses-350---700-nm-ar-coating",
    "molded-glass-aspheric-lenses-405-nm-or-1064-nm-ar-coating",
    "molded-glass-aspheric-lenses-finite-conjugate-uncoated",
    "aspheric-condenser-lenses",
]
FOLD_SLUGS = [
    "economy-front-surface-mirrors",
    "protected-silver-mirrors",
    "fused-silica-broadband-dielectric-mirrors",
    "30-mm-cage-cube-mounted-turning-prism-mirrors",
    "16-mm-cage-cube-mounted-turning-prism-mirrors",
    "concave-mirrors-protected-silver-450-nm---20-m",
    "concave-mirrors-protected-gold-800-nm---20-m",
    "concave-mirrors-nir-dielectric-coating-750---1100-nm-back-side-polished",
    "broadband-polarizing-beamsplitter-cubes",
    "high-power-laser-line-polarizing-beamsplitter-cubes",
    "high-power-laser-line-polarizing-beamsplitter-cubes-mounted",
    "non-polarizing-plate-beamsplitters",
    "non-polarizing-beamsplitter-cubes",
    "non-polarizing-beamsplitter-cubes-in-30-mm-cage-cubes",
    "shortpass-dichroic-mirrors-beamsplitters",
    "longpass-dichroic-mirrorsbeamsplitters",
    "hot-and-cold-mirrors-uv-fused-silica-substrate",
]
FILTER_SLUGS = [
    "hard-coated-uvvis-bandpass-filters",
    "hard-coated-nir-bandpass-filters",
    "hard-coated-edgepass-filters",
    "ir-bandpass-filters-1.75---12.00-m-central-wavelength",
    "wedged-hard-coated-bandpass-filters",
    "hard-coated-bandpass-filters-for-machine-vision-lenses",
]
SCOPES: dict[str, tuple[list[str], str, int]] = {
    # scope → (start slugs, parser scope, BOMB's max depth)
    "lenses": (LENS_SLUGS, "lenses", 4),
    "fold": (FOLD_SLUGS, "fold", 1),
    "filters": (FILTER_SLUGS, "fold", 1),
}

Transport = Callable[[str, dict[str, Any]], dict[str, Any]]


class CrawlError(Exception):
    pass


def _http_transport(timeout: float) -> Transport:
    def post(query: str, variables: dict[str, Any]) -> dict[str, Any]:
        body = json.dumps({"query": query, "variables": variables}).encode("utf-8")
        req = urllib.request.Request(
            GRAPHQL,
            data=body,
            headers={"Content-Type": "application/json", "User-Agent": USER_AGENT},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 — the vendor's own API
            payload = json.loads(resp.read().decode("utf-8"))
        if payload.get("errors"):
            raise CrawlError(json.dumps(payload["errors"])[:500])
        return payload.get("data") or {}

    return post


class ThorlabsClient:
    """The content API behind a rate limit and a per-slug page cache."""

    def __init__(
        self,
        cache_dir: Path,
        *,
        delay_s: float = 30.0,
        timeout: float = 60.0,
        transport: Transport | None = None,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.cache_dir = Path(cache_dir)
        self.delay_s = delay_s
        self._transport = transport or _http_transport(timeout)
        self._clock, self._sleep = clock, sleep
        self._last: float | None = None
        self.requests = 0

    def _throttle(self) -> None:
        if self._last is not None:
            wait = self.delay_s - (self._clock() - self._last)
            if wait > 0:
                self._sleep(wait)
        self._last = self._clock()

    def graphql(self, query: str, variables: dict[str, Any]) -> dict[str, Any]:
        self._throttle()
        self.requests += 1
        return self._transport(query, variables)

    def _cached(self, kind: str, key: str) -> Path:
        safe = re.sub(r"[^a-z0-9.-]+", "_", key.lower()).strip("_") or "root"
        path = self.cache_dir / kind / f"{safe}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def slug_info(self, slug: str) -> dict[str, Any] | None:
        data = self.graphql(SLUG_INFO_QUERY, {"slug": slug, **STORE})
        return (data.get("slugInfo") or {}).get("entityInfo")

    def page(self, slug: str) -> dict[str, Any] | None:
        """``{id, name, content, permalink}`` for a family page — from the cache when present."""
        path = self._cached("pages", slug)
        if path.is_file():
            return json.loads(path.read_text(encoding="utf-8"))
        info = self.slug_info(slug)
        if not info or not info.get("objectId") or info.get("objectType") != "ContentFile":
            return None
        data = self.graphql(
            PAGE_QUERY,
            {
                "id": info["objectId"],
                "cultureName": STORE["cultureName"],
                "storeId": STORE["storeId"],
            },
        )
        page = data.get("page")
        if not page or not page.get("content"):
            return None
        from .thorlabs import page_title

        page = {
            "id": page.get("id"),
            "name": page_title(page),
            "content": page["content"],
            "permalink": page.get("permalink") or info.get("semanticUrl") or f"/{slug}",
        }
        path.write_text(json.dumps(page), encoding="utf-8")
        return page

    def product_assets(self, sku: str) -> list[dict[str, Any]]:
        """The per-SKU downloads (zmx/zar/step/pdf …) the product page lists."""
        path = self._cached("assets", sku)
        if path.is_file():
            return json.loads(path.read_text(encoding="utf-8"))
        info = self.slug_info(f"item/{sku}")
        if not info or info.get("objectType") != "CatalogProduct":
            return []
        data = self.graphql(
            ASSETS_QUERY,
            {
                "storeId": STORE["storeId"],
                "currencyCode": "USD",
                "cultureName": STORE["cultureName"],
                "id": info["objectId"],
            },
        )
        assets = (data.get("product") or {}).get("assets") or []
        path.write_text(json.dumps(assets), encoding="utf-8")
        return assets


_KIND_BY_EXT = {
    "zmx": ("zemax", "opticalPrescription"),
    "zar": ("opticStudio", "opticalPrescription"),
    "zos": ("opticStudio", "opticalPrescription"),
    "step": ("step", "mechanicalModel"),
    "stp": ("step", "mechanicalModel"),
    "sldprt": ("solidworks", "mechanicalModel"),
    "pdf": ("pdf", "datasheet"),
    "dxf": ("dxf", "drawing"),
}


def assets_to_files(assets: list[dict[str, Any]]) -> list[CatalogFile]:
    files: list[CatalogFile] = []
    for asset in assets:
        url = str(asset.get("url") or "")
        ext = url.split("?")[0].rsplit(".", 1)[-1].lower() if "." in url.split("?")[0] else ""
        if ext in _KIND_BY_EXT:
            kind, role = _KIND_BY_EXT[ext]
            files.append(CatalogFile(kind=kind, role=role, url=url))
    return files


@dataclass
class CrawlReport:
    pages: int = 0
    parts: int = 0
    diagnostics: list[dict[str, Any]] = field(default_factory=list)


def crawl(
    client: ThorlabsClient,
    start_slugs: list[str],
    *,
    scope: str,
    max_depth: int = 4,
    indexed_at: str | None = None,
    log: Callable[[str], None] | None = None,
) -> tuple[list[CatalogPart], CrawlReport]:
    """BFS from ``start_slugs`` over the family pages the scope allows; first row per SKU wins."""
    indexed_at = indexed_at or today()
    report = CrawlReport()
    queue: list[tuple[str, int]] = [(s, 0) for s in start_slugs]
    seen: set[str] = set()
    parts: dict[str, CatalogPart] = {}
    while queue:
        slug, depth = queue.pop(0)
        if slug in seen or not (slug in start_slugs or should_crawl(slug, scope)):
            continue
        seen.add(slug)
        try:
            page = client.page(slug)
        except (OSError, CrawlError, ValueError) as exc:
            report.diagnostics.append({"slug": slug, "depth": depth, "error": str(exc)[:300]})
            continue
        if not page:
            report.diagnostics.append({"slug": slug, "depth": depth, "skipped": "no page content"})
            continue
        report.pages += 1
        found = parse_family_page(page, slug, indexed_at, scope=scope)
        new = 0
        for part in found:
            if part.sku not in parts:
                parts[part.sku] = part
                new += 1
        report.diagnostics.append(
            {"slug": slug, "depth": depth, "title": page.get("name"), "parts": len(found)}
        )
        if log:
            log(f"{slug}: {len(found)} rows ({new} new)")
        if depth < max_depth:
            for linked in linked_slugs(str(page.get("content") or ""), scope):
                if linked not in seen:
                    queue.append((linked, depth + 1))
    report.parts = len(parts)
    return sorted(parts.values(), key=lambda p: p.sku), report


def crawl_snapshot(
    client: ThorlabsClient,
    *,
    scopes: tuple[str, ...] = ("lenses", "fold", "filters"),
    slugs: list[str] | None = None,
    max_depth: int | None = None,
    version: str | None = None,
    log: Callable[[str], None] | None = None,
) -> tuple[Snapshot, list[CrawlReport]]:
    """One snapshot over the scopes, or over ``slugs`` alone (each parsed by its own scope)."""
    indexed_at = today()
    all_parts: dict[str, CatalogPart] = {}
    reports: list[CrawlReport] = []
    if slugs:
        from .thorlabs import page_scope

        by_scope: dict[str, list[str]] = {}
        for s in slugs:
            by_scope.setdefault(page_scope(s), []).append(s)
        runs = [(v, k, max_depth if max_depth is not None else 1) for k, v in by_scope.items()]
    else:
        runs = [
            (SCOPES[s][0], SCOPES[s][1], max_depth if max_depth is not None else SCOPES[s][2])
            for s in scopes
        ]
    for start, parser_scope, depth in runs:
        parts, report = crawl(
            client, start, scope=parser_scope, max_depth=depth, indexed_at=indexed_at, log=log
        )
        reports.append(report)
        for p in parts:
            all_parts.setdefault(p.sku, p)
    return Snapshot(
        version=version or f"thorlabs-{indexed_at}",
        source="optikit-core catalog crawl (Thorlabs content API)",
        retrieved_at=indexed_at,
        parts=sorted(all_parts.values(), key=lambda p: p.sku),
    ), reports
