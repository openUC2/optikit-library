"""Convert BOMB's generated Thorlabs catalogs into one snapshot (WP-225a).

BOMB (Bezia Lemma's microscope_builder) ships its crawl as TypeScript modules
holding a chunked JSON string — ``const X_JSON = ["[{…", "…}]"].join('')``.
Reuse is by Bezia's permission (plan §1); the rows are copied verbatim.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from .snapshot import Snapshot, today
from .types import CatalogPart

GENERATED_FILES = (
    "src/catalog/thorlabsGeneratedCatalog.ts",
    "src/catalog/thorlabsGeneratedFoldOpticsCatalog.ts",
    "src/catalog/thorlabsGeneratedFiltersCatalog.ts",
)
_VERSION_RE = re.compile(r"CATALOG_SNAPSHOT_VERSION\s*=\s*'([^']+)'")
_JS_STRING_RE = re.compile(r'"((?:[^"\\]|\\.)*)"')


def parse_generated_ts(path: Path) -> list[dict]:
    """The rows inside one ``*Generated*Catalog.ts`` module."""
    text = Path(path).read_text(encoding="utf-8")
    start = text.find("_JSON = [")
    end = text.find("].join(")
    if start < 0 or end < 0:
        raise ValueError(f"{path}: not a BOMB generated catalog module")
    chunks = [json.loads(f'"{m.group(1)}"') for m in _JS_STRING_RE.finditer(text[start:end])]
    rows = json.loads("".join(chunks))
    if not isinstance(rows, list):
        raise ValueError(f"{path}: expected a JSON array of parts")
    return rows


def bomb_snapshot_version(repo: Path) -> str:
    catalog_ts = Path(repo) / "src/catalog/catalog.ts"
    if catalog_ts.is_file():
        m = _VERSION_RE.search(catalog_ts.read_text(encoding="utf-8"))
        if m:
            return m.group(1)
    return f"bomb-{today()}"


def convert_bomb(repo: Path, files: tuple[str, ...] = GENERATED_FILES) -> Snapshot:
    """Every generated module in ``repo`` → one snapshot; the first row per id wins."""
    repo = Path(repo)
    seen: set[str] = set()
    parts: list[CatalogPart] = []
    for rel in files:
        path = repo / rel
        if not path.is_file():
            continue
        for row in parse_generated_ts(path):
            part = CatalogPart.model_validate(row)
            if part.id in seen:
                continue
            seen.add(part.id)
            parts.append(part)
    if not parts:
        raise ValueError(f"{repo}: no generated catalog modules found ({', '.join(files)})")
    parts.sort(key=lambda p: p.sku)
    return Snapshot(
        version=bomb_snapshot_version(repo),
        source=f"bomb:{repo.name}",
        retrieved_at=max((p.last_indexed for p in parts if p.last_indexed), default=today()),
        parts=parts,
    )
