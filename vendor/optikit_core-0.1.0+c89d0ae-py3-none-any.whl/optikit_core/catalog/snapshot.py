"""The pinned catalog snapshot: one versioned JSON artifact, never library records.

Lives under the library root's sibling ``vendor/catalog/`` (or
``OPTIKIT_CATALOG_DIR``), gzipped. Rows are derived numbers plus URLs — the
vendor's own files are never inside it.
"""

from __future__ import annotations

import gzip
import json
import os
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .types import CatalogPart

SNAPSHOT_SCHEMA = "optikit-catalog-snapshot/1"
CATALOG_DIR_ENV = "OPTIKIT_CATALOG_DIR"


@dataclass
class Snapshot:
    version: str
    source: str = ""
    retrieved_at: str = ""
    parts: list[CatalogPart] = field(default_factory=list)

    def by_id(self, part_id: str) -> CatalogPart | None:
        for p in self.parts:
            if p.id == part_id:
                return p
        return None

    def summary(self) -> dict[str, Any]:
        kinds: dict[str, int] = {}
        for p in self.parts:
            kinds[p.kind] = kinds.get(p.kind, 0) + 1
        return {
            "version": self.version,
            "source": self.source,
            "retrievedAt": self.retrieved_at,
            "count": len(self.parts),
            "kinds": dict(sorted(kinds.items())),
        }


def today() -> str:
    return datetime.now(UTC).date().isoformat()


def default_catalog_dir(library_root: Path) -> Path:
    configured = os.environ.get(CATALOG_DIR_ENV)
    if configured:
        return Path(configured).expanduser().resolve()
    return (Path(library_root).resolve().parent / "vendor" / "catalog").resolve()


def snapshot_path(directory: Path, version: str) -> Path:
    slug = re.sub(r"[^a-z0-9.-]+", "-", version.lower()).strip("-")
    return Path(directory) / f"{slug}.json.gz"


def write_json(doc: dict[str, Any], path: Path) -> Path:
    """Compact JSON, gzipped when the path ends in ``.gz``; parents are created."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(doc, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if path.suffix == ".gz":
        with gzip.open(path, "wb", compresslevel=6) as fh:
            fh.write(data)
    else:
        path.write_bytes(data)
    return path


def read_json(path: Path) -> dict[str, Any]:
    path = Path(path)
    if path.suffix == ".gz":
        with gzip.open(path, "rb") as fh:
            return json.loads(fh.read())
    return json.loads(path.read_bytes())


def write_snapshot(snapshot: Snapshot, path: Path) -> Path:
    doc = {
        "schema": SNAPSHOT_SCHEMA,
        "version": snapshot.version,
        "source": snapshot.source,
        "retrievedAt": snapshot.retrieved_at or today(),
        "parts": [p.to_json() for p in snapshot.parts],
    }
    return write_json(doc, path)


def load_snapshot(path: Path) -> Snapshot:
    doc = read_json(path)
    if doc.get("schema") != SNAPSHOT_SCHEMA:
        raise ValueError(f"{path}: not a catalog snapshot (schema {doc.get('schema')!r})")
    return Snapshot(
        version=str(doc.get("version", "")),
        source=str(doc.get("source", "")),
        retrieved_at=str(doc.get("retrievedAt", "")),
        parts=[CatalogPart.model_validate(p) for p in doc.get("parts", [])],
    )


def find_snapshots(directory: Path) -> list[Path]:
    directory = Path(directory)
    if not directory.is_dir():
        return []
    return sorted(p for p in directory.iterdir() if p.name.endswith((".json", ".json.gz")))


def latest_snapshot_path(directory: Path) -> Path | None:
    """The newest snapshot by file name (versions embed their date) — None if empty."""
    found = find_snapshots(directory)
    return found[-1] if found else None


# --- querying ----------------------------------------------------------------------------


def _haystack(part: CatalogPart) -> str:
    cells = " ".join(str(v.value) for v in part.specs.values())
    return f"{part.sku} {part.title} {part.kind} {cells}".lower()


def query(
    parts: list[CatalogPart],
    *,
    kind: str | None = None,
    vendor: str | None = None,
    q: str = "",
    cased: bool | None = None,
) -> list[CatalogPart]:
    """Filter: exact kind/vendor, every ``q`` token a substring, ``cased`` mounted-or-bare."""
    tokens = [t for t in q.lower().split() if t]
    out: list[CatalogPart] = []
    for p in parts:
        if kind and p.kind != kind:
            continue
        if vendor and p.vendor != vendor:
            continue
        if cased is not None and p.is_cased() != cased:
            continue
        if tokens:
            hay = _haystack(p)
            if not all(t in hay for t in tokens):
                continue
        out.append(p)
    return out


def paginate(items: list[Any], page: int, size: int) -> dict[str, Any]:
    page = max(1, int(page))
    size = max(1, min(int(size), 1000))
    start = (page - 1) * size
    return {
        "page": page,
        "size": size,
        "total": len(items),
        "items": items[start : start + size],
    }
