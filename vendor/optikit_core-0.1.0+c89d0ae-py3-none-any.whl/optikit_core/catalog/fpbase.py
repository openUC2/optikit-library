"""FPbase fluorophore spectra as one pinned snapshot, beside the vendor catalog.

Lives under ``<library root>/../vendor/spectra/`` (or ``OPTIKIT_SPECTRA_DIR``),
gzipped. FPbase content is CC BY-SA 4.0 — the file header carries the
attribution. Network only in :func:`fetch_fpbase`.
"""

from __future__ import annotations

import json
import math
import os
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .fetch import USER_AGENT
from .snapshot import read_json, today, write_json

SPECTRA_SCHEMA = "optikit-spectra-snapshot/1"
SPECTRA_DIR_ENV = "OPTIKIT_SPECTRA_DIR"
FPBASE_URL = "https://www.fpbase.org"
FPBASE_LICENSE = "CC BY-SA 4.0"
DYES_QUERY = "{ dyes { name slug spectra { subtype data } } }"
PROTEINS_URL = f"{FPBASE_URL}/api/proteins/spectra/?format=json"

Curve = list[list[float]]


@dataclass
class SpectrumEntry:
    id: str
    name: str
    kind: str  # "dye" | "protein"
    ex: Curve
    em: Curve
    ex_max_nm: float
    em_max_nm: float

    def head(self) -> dict[str, Any]:
        """The index row: identity and peaks, no curves."""
        return {"id": self.id, "name": self.name, "kind": self.kind,
                "ex_max_nm": self.ex_max_nm, "em_max_nm": self.em_max_nm}


@dataclass
class SpectraSnapshot:
    version: str
    retrieved_at: str = ""
    provenance: dict[str, Any] = field(default_factory=dict)
    entries: list[SpectrumEntry] = field(default_factory=list)

    def by_id(self, entry_id: str) -> SpectrumEntry | None:
        return next((e for e in self.entries if e.id == entry_id), None)

    def summary(self) -> dict[str, Any]:
        kinds: dict[str, int] = {}
        for e in self.entries:
            kinds[e.kind] = kinds.get(e.kind, 0) + 1
        return {"version": self.version, "retrievedAt": self.retrieved_at,
                "count": len(self.entries), "kinds": dict(sorted(kinds.items()))}


def default_spectra_dir(library_root: Path) -> Path:
    configured = os.environ.get(SPECTRA_DIR_ENV)
    if configured:
        return Path(configured).expanduser().resolve()
    return (Path(library_root).resolve().parent / "vendor" / "spectra").resolve()


def spectra_path(directory: Path, version: str) -> Path:
    return Path(directory) / f"{version}.json.gz"


def write_spectra(snapshot: SpectraSnapshot, path: Path) -> Path:
    doc = {
        "schema": SPECTRA_SCHEMA,
        "version": snapshot.version,
        "retrievedAt": snapshot.retrieved_at or today(),
        "provenance": snapshot.provenance,
        "entries": [asdict(e) for e in snapshot.entries],
    }
    return write_json(doc, path)


def load_spectra(path: Path) -> SpectraSnapshot:
    doc = read_json(path)
    if doc.get("schema") != SPECTRA_SCHEMA:
        raise ValueError(f"{path}: not a spectra snapshot (schema {doc.get('schema')!r})")
    return SpectraSnapshot(
        version=str(doc.get("version", "")),
        retrieved_at=str(doc.get("retrievedAt", "")),
        provenance=dict(doc.get("provenance", {})),
        entries=[SpectrumEntry(**e) for e in doc.get("entries", [])],
    )


# --- normalization -----------------------------------------------------------------------


def normalize_curve(data: Any) -> Curve:
    """``[[nm, v], …]`` → sorted, finite, scaled to a peak of 1 (empty when no positive value)."""
    points: list[tuple[float, float]] = []
    for pair in data or []:
        try:
            nm, v = float(pair[0]), float(pair[1])
        except (TypeError, ValueError, IndexError):
            continue
        if math.isfinite(nm) and math.isfinite(v):
            points.append((nm, max(v, 0.0)))
    peak = max((v for _, v in points), default=0.0)
    if peak <= 0:
        return []
    return [[round(nm, 1), round(v / peak, 4)] for nm, v in sorted(points)]


def _peak_nm(curve: Curve) -> float:
    return max(curve, key=lambda p: p[1])[0]


def _entry(slug: str, name: str, kind: str, ex: Any, em: Any) -> SpectrumEntry | None:
    ex_curve, em_curve = normalize_curve(ex), normalize_curve(em)
    if not slug or not ex_curve or not em_curve:
        return None
    return SpectrumEntry(id=f"fpbase:{slug}", name=name or slug, kind=kind, ex=ex_curve,
                         em=em_curve, ex_max_nm=_peak_nm(ex_curve), em_max_nm=_peak_nm(em_curve))


def dye_entries(payload: dict[str, Any]) -> list[SpectrumEntry]:
    """The GraphQL ``dyes`` response → entries with both an EX and an EM spectrum."""
    out: list[SpectrumEntry] = []
    for dye in (payload.get("data") or {}).get("dyes") or []:
        by_type = {s.get("subtype"): s.get("data") for s in dye.get("spectra") or []}
        entry = _entry(dye.get("slug", ""), dye.get("name", ""), "dye",
                       by_type.get("EX"), by_type.get("EM"))
        if entry:
            out.append(entry)
    return out


def _state_curve(spectra: list[dict[str, Any]], suffix: str) -> Any:
    """The ``default_<suffix>`` spectrum, else the first ``*_<suffix>``."""
    matching = [s for s in spectra if str(s.get("state", "")).endswith(f"_{suffix}")]
    default = next((s for s in matching if s.get("state") == f"default_{suffix}"), None)
    chosen = default or (matching[0] if matching else None)
    return chosen.get("data") if chosen else None


def protein_entries(payload: list[dict[str, Any]]) -> list[SpectrumEntry]:
    """The REST ``proteins/spectra`` response → entries with both an ex and an em state."""
    out: list[SpectrumEntry] = []
    for protein in payload or []:
        spectra = protein.get("spectra") or []
        entry = _entry(protein.get("slug", ""), protein.get("name", ""), "protein",
                       _state_curve(spectra, "ex"), _state_curve(spectra, "em"))
        if entry:
            out.append(entry)
    return out


def build_snapshot(dyes: dict[str, Any], proteins: list[dict[str, Any]],
                   version: str | None = None) -> SpectraSnapshot:
    """One snapshot from the two raw payloads; the first entry per id wins."""
    seen: set[str] = set()
    entries: list[SpectrumEntry] = []
    for e in dye_entries(dyes) + protein_entries(proteins):
        if e.id not in seen:
            seen.add(e.id)
            entries.append(e)
    entries.sort(key=lambda e: e.name.lower())
    retrieved = datetime.now(UTC).isoformat(timespec="seconds")
    return SpectraSnapshot(
        version=version or f"fpbase-{today()}",
        retrieved_at=retrieved,
        provenance={"source": "fpbase", "license": FPBASE_LICENSE, "url": FPBASE_URL,
                    "retrievedAt": retrieved},
        entries=entries,
    )


# --- network -----------------------------------------------------------------------------


def _get_json(url: str, body: dict[str, Any] | None = None, timeout: float = 120.0) -> Any:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 — https, fixed host
        return json.loads(resp.read())


def fetch_fpbase(version: str | None = None) -> SpectraSnapshot:
    """Dyes over GraphQL, proteins over REST — the only function here that touches the network."""
    dyes = _get_json(f"{FPBASE_URL}/graphql/", {"query": DYES_QUERY})
    proteins = _get_json(PROTEINS_URL)
    return build_snapshot(dyes, proteins, version)
