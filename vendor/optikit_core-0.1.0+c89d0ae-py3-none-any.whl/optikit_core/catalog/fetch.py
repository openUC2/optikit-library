"""Fetch a row's vendor files into the vendor cache (plan §7.1 policy).

Zemax files are fetched on demand, one per part, cached by URL hash with a
sidecar recording url · sha256 · retrievedAt. STEP/DXF/SolidWorks are NOT
fetched here — Thorlabs' robots asks crawlers not to, so a mechanical file is
the user's own download (WP-223).
"""

from __future__ import annotations

import hashlib
import json
import urllib.request
import zipfile
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from .types import CatalogPart

USER_AGENT = "optikit-core catalog/0.1 (+https://github.com/openUC2/optikit-v2)"
MECHANICAL_KINDS = {"step", "solidworks", "dxf"}


class CatalogFetchError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass
class FetchedFile:
    path: Path
    url: str
    sha256: str
    retrieved_at: str
    from_cache: bool = False


def cache_path(cache_dir: Path, url: str) -> Path:
    base = url.split("?")[0].rsplit("/", 1)[-1] or "file"
    return Path(cache_dir) / f"{hashlib.sha256(url.encode()).hexdigest()[:16]}-{base}"


def fetch_bytes(
    url: str, cache_dir: Path, *, timeout: float = 60.0, force: bool = False
) -> FetchedFile:
    """Download once; a cached copy (with its sidecar) is returned as-is."""
    if url.split("?")[0].lower().rsplit(".", 1)[-1] in {
        "step",
        "stp",
        "sldprt",
        "dxf",
        "igs",
        "iges",
    }:
        raise CatalogFetchError(
            "E_CATALOG_POLICY",
            "mechanical files are not fetched by the catalog tools "
            "(Thorlabs' robots disallows it) — "
            "download the STEP yourself and attach it (WP-223)",
        )
    path = cache_path(cache_dir, url)
    side = path.with_suffix(path.suffix + ".json")
    if path.is_file() and side.is_file() and not force:
        meta = json.loads(side.read_text())
        return FetchedFile(
            path, url, meta.get("sha256", ""), meta.get("retrievedAt", ""), from_cache=True
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 — https vendor asset
            data = resp.read()
    except OSError as exc:
        raise CatalogFetchError("E_CATALOG_FETCH", f"{url}: {exc}") from exc
    digest = hashlib.sha256(data).hexdigest()
    retrieved = datetime.now(UTC).isoformat(timespec="seconds")
    path.write_bytes(data)
    side.write_text(json.dumps({"url": url, "sha256": digest, "retrievedAt": retrieved}, indent=1))
    return FetchedFile(path, url, digest, retrieved)


def fetch_prescription(part: CatalogPart, cache_dir: Path, *, timeout: float = 60.0) -> FetchedFile:
    """The row's product-level ``.zmx``, unpacked from a ``.zar``/``.zip`` when that is the link."""
    f = part.prescription_file()
    if f is None:
        raise CatalogFetchError(
            "E_CATALOG_NO_ZMX",
            f"{part.sku}: the row names no product-level Zemax file — use the row-derived road, "
            "or download the zmx from the product page and `import zmx` it",
        )
    fetched = fetch_bytes(f.url, cache_dir, timeout=timeout)
    if fetched.path.suffix.lower() == ".zmx":
        return fetched
    try:
        with zipfile.ZipFile(fetched.path) as zf:
            members = [m for m in zf.namelist() if m.lower().endswith(".zmx")]
            if not members:
                raise CatalogFetchError(
                    "E_CATALOG_NO_ZMX", f"{fetched.path.name}: archive holds no .zmx"
                )
            target = fetched.path.with_suffix(".zmx")
            target.write_bytes(zf.read(members[0]))
    except zipfile.BadZipFile as exc:
        raise CatalogFetchError(
            "E_CATALOG_FETCH", f"{fetched.path.name}: not a zip archive"
        ) from exc
    return FetchedFile(
        target, fetched.url, fetched.sha256, fetched.retrieved_at, fetched.from_cache
    )
