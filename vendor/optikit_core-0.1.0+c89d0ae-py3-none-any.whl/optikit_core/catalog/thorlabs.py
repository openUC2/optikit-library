"""Thorlabs family pages → catalog rows (WP-225b). No network in this module.

A family page from Thorlabs' content API is JSON; the product tables are HTML
inside ``tabs[]…content`` / ``subgroups[]…content``. This is a port of BOMB's
two importers (``import-thorlabs-lenses.mjs``, ``import-thorlabs-fold-optics.mjs``,
reused by Bezia's permission), kept to the families the picker lists and
WP-255 mints: spherical · cylindrical · aspheric · achromat lenses, mirrors,
curved mirrors, beamsplitters, PBS, dichroics, filters.
"""

from __future__ import annotations

import html as _html
import json
import math
import re
from typing import Any

from .types import CatalogFile, CatalogPart, CatalogProvenance, CatalogValue

THORLABS = "https://www.thorlabs.com"
ZEMAX_CATALOG_PAGE = "https://www.thorlabs.com/software-pages/zemax"

# --- text -------------------------------------------------------------------------------

_TAG_RE = re.compile(r"<[^>]+>")
_NUM_RE = re.compile(r"[+-]?\d+(?:\.\d+)?")


def clean_text(value: Any) -> str:
    s = _html.unescape(str(value or ""))
    s = re.sub(
        r"<script[\s\S]*?</script>|<style[\s\S]*?</style>|<sup[\s\S]*?</sup>", " ", s, flags=re.I
    )
    s = re.sub(r"<br\s*/?>", " ", s, flags=re.I)
    s = _TAG_RE.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


def normalize_header(value: Any) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[_{}]", "", clean_text(value).lower())).strip()


def first_number(text: Any) -> float | None:
    m = _NUM_RE.search(str(text).replace(",", ""))
    return float(m.group(0)) if m else None


def all_numbers(text: Any) -> list[float]:
    return [float(m) for m in _NUM_RE.findall(str(text).replace(",", ""))]


def parse_number(value: Any) -> float | None:
    """A numeric cell; ``inf``/``∞`` → ``math.inf`` (a flat surface); blanks → None."""
    text = clean_text(value)
    if not text or re.fullmatch(r"n/a|na|-|—", text, re.I):
        return None
    if re.search(r"inf|∞", text, re.I):
        return math.inf
    return first_number(text)


def parse_length(value: Any, header: str = "") -> float | None:
    """A length in mm — metric wins, inches (``1"``, ``1/2"``) convert, a bare small number under
    a diameter-ish header without ``(mm)`` is inches (Thorlabs' ``Diameter`` columns)."""
    text = clean_text(value)
    if not text:
        return None
    metric = re.search(r"([+-]?\d+(?:\.\d+)?)\s*mm\b", text, re.I)
    if metric:
        return float(metric.group(1))
    measure = re.sub(r"\bS\s*[12]\s*:", " ", text, flags=re.I)
    frac = re.search(r"(\d+)\s*/\s*(\d+)\s*\"", measure)
    if frac:
        return 25.4 * float(frac.group(1)) / float(frac.group(2))
    inch = re.search(r"([+-]?\d+(?:\.\d+)?)\s*\"", measure)
    if inch:
        return float(inch.group(1)) * 25.4
    number = first_number(measure)
    if number is None:
        return None
    if re.search(r"\"|inch", measure, re.I) and not re.search(r"mm", measure, re.I):
        return number * 25.4
    if (
        not re.search(r"\(mm\)|mm", header, re.I)
        and 0 < number <= 4
        and re.search(r"diameter|width|height|length|aperture|size", header, re.I)
    ):
        return number * 25.4
    return number


def parse_dimension_set(value: Any, header: str = "") -> dict[str, float]:
    """``Ø25.4 mm`` → diameter; ``25 x 36 mm`` → width/height(/depth); a lone length → all three."""
    text = clean_text(value)
    if not text:
        return {}
    metric = [
        float(m) for m in re.findall(r"([+-]?\d+(?:\.\d+)?)\s*mm\b", text, re.I) if float(m) > 0
    ]
    is_dia = re.search(r"ø|diameter|dia\b", text + header, re.I)
    if metric:
        if is_dia:
            return {"diameter": metric[0]}
        if len(metric) >= 2 and re.search(r"[x×]", text, re.I):
            out = {"width": metric[0], "height": metric[1]}
            if len(metric) > 2:
                out["depth"] = metric[2]
            return out
        return {"diameter": metric[0], "width": metric[0], "height": metric[0]}
    frac = re.search(r"(\d+)\s*/\s*(\d+)\s*\"", text)
    if frac and not re.search(r"[x×]", text, re.I):
        length = 25.4 * float(frac.group(1)) / float(frac.group(2))
        return {"diameter": length, "width": length, "height": length}
    numbers = all_numbers(text)
    if not numbers:
        return {}
    scale = (
        25.4
        if re.search(r"\"|inch", text, re.I) and not re.search(r"mm", text + header, re.I)
        else 1.0
    )
    values = [n * scale for n in numbers]
    if any(v <= 0 for v in values):
        return {}
    if is_dia:
        return {"diameter": values[0]}
    if len(values) >= 2 and re.search(r"[x×]", text, re.I):
        out = {"width": values[0], "height": values[1]}
        if len(values) > 2:
            out["depth"] = values[2]
        return out
    return {"diameter": values[0], "width": values[0], "height": values[0]}


def parse_diameter(value: Any, header: str = "") -> float | None:
    dims = parse_dimension_set(value, header)
    return dims.get("diameter") or dims.get("width") or dims.get("height")


def parse_wavelength_nm(value: Any) -> float | None:
    text = clean_text(value)
    if not text:
        return None
    m = re.search(r"([+-]?\d+(?:\.\d+)?)\s*(nm|µm|um)\b", text, re.I)
    if m:
        n = float(m.group(1))
        return n * 1000.0 if m.group(2).lower() in ("µm", "um") else n
    return parse_number(text)


_SKU_RE = re.compile(r"\b(?:[A-Z]{1,8}\d{2,6}[A-Z0-9]*(?:-[A-Z0-9]+)*|\d{5,6}(?:-[A-Z0-9]+)+)\b")


def sku_from_cell(value: Any) -> str | None:
    m = _SKU_RE.search(clean_text(value))
    return m.group(0).upper() if m else None


# --- HTML tables -----------------------------------------------------------------------------


def html_strings(content: str) -> list[str]:
    """Every HTML string with a table inside a page's ``content`` (JSON), or the content itself."""
    try:
        doc = json.loads(content)
    except (TypeError, ValueError):
        return [content] if "<table" in content.lower() else []
    out: list[str] = []

    def walk(o: Any, depth: int = 0) -> None:
        if depth > 12:
            return
        if isinstance(o, dict):
            for v in o.values():
                walk(v, depth + 1)
        elif isinstance(o, list):
            for v in o:
                walk(v, depth + 1)
        elif isinstance(o, str) and "<table" in o.lower():
            out.append(o)

    walk(doc)
    return out


def html_tables(html: str) -> list[str]:
    return re.findall(r"<table[\s\S]*?</table>", html, re.I)


def _span(attrs: str, name: str) -> int:
    m = re.search(rf"{name}\s*=\s*[\"']?(\d+)", attrs, re.I)
    return max(1, int(m.group(1))) if m else 1


def table_rows(table_html: str) -> list[list[str]]:
    """Cell texts per row, with ``colspan``/``rowspan`` expanded so columns line up."""
    active: dict[int, tuple[str, int]] = {}
    rows: list[list[str]] = []
    for row_html in re.findall(r"<tr[\s\S]*?</tr>", table_html, re.I):
        cells = [
            (clean_text(body), _span(attrs, "colspan"), _span(attrs, "rowspan"))
            for attrs, body in re.findall(r"<t[dh]([^>]*)>([\s\S]*?)</t[dh]>", row_html, re.I)
        ]
        if not cells:
            continue
        row: dict[int, str] = {}
        col = 0
        for text, colspan, rowspan in cells:
            col = _fill_spanned(active, row, col)
            for k in range(colspan):
                row[col + k] = text
                if rowspan > 1:
                    active[col + k] = (text, rowspan - 1)
            col += colspan
        while active and col <= max(active):
            col = _fill_spanned(active, row, col) if col in active else col + 1
        rows.append([row[i] for i in sorted(row) if row[i]])
    return [r for r in rows if r]


def _fill_spanned(active: dict[int, tuple[str, int]], row: dict[int, str], col: int) -> int:
    """Copy cells still spanning down from earlier rows into ``row`` from ``col`` on."""
    while col in active:
        text, left = active[col]
        row[col] = text
        if left <= 1:
            del active[col]
        else:
            active[col] = (text, left - 1)
        col += 1
    return col


def header_and_rows(table_html: str) -> tuple[list[str], list[list[str]], dict[str, str]]:
    rows = table_rows(table_html)
    for i, cells in enumerate(rows):
        joined = " | ".join(normalize_header(c) for c in cells)
        if re.search(r"(?:^| \| )(?:item|part)\s*#?(?: \||$)", joined) or (
            re.search(r"item|part", joined)
            and re.search(
                r"diameter|size|thickness|wavelength|ratio|reflect|transmission|focal|radius|magnification|material|aperture",
                joined,
            )
        ):
            common: dict[str, str] = {}
            for row in rows[:i]:
                if len(row) >= 2:
                    key = normalize_header(row[0])
                    if key and not re.match(r"specifications|table|image|click", key):
                        common[key] = row[1]
            return rows[i], rows[i + 1 :], common
    return (rows[0] if rows else []), rows[1:], {}


def rows_as_objects(table_html: str) -> list[dict[str, str]]:
    """One ``{normalized header: cell}`` per product row (transposed tables handled too)."""
    rows = table_rows(table_html)
    if len(rows) >= 2 and re.match(r"(?:item|part)\s*#?", clean_text(rows[0][0]), re.I):
        skus = [sku_from_cell(c) for c in rows[0][1:]]
        if any(skus):
            out = []
            for offset, sku in enumerate(skus):
                if not sku:
                    continue
                values = {"item #": sku}
                for row in rows[1:]:
                    key = normalize_header(row[0]) if row else ""
                    if key:
                        values[key] = (
                            row[offset + 1]
                            if offset + 1 < len(row)
                            else (row[1] if len(row) > 1 else "")
                        )
                out.append(values)
            return out
    headers, data, common = header_and_rows(table_html)
    if not headers:
        return []
    keys = [normalize_header(h) for h in headers]
    out = []
    for row in data:
        values = dict(common)
        for key, cell in zip(keys, row, strict=False):
            if key:
                values[key] = cell
        if sku_from_cell(
            values.get("item #")
            or values.get("part #")
            or values.get("item")
            or values.get("part")
            or ""
        ):
            out.append(values)
    return out


def cell_for(values: dict[str, str], patterns: list[str]) -> str | None:
    for key, value in values.items():
        if any(re.search(p, key) for p in patterns):
            return value
    return None


def header_for(values: dict[str, str], patterns: list[str]) -> str:
    for key in values:
        if any(re.search(p, key) for p in patterns):
            return key
    return ""


def sku_of(values: dict[str, str]) -> str | None:
    for key in ("item #", "part #", "item", "part"):
        if key in values:
            sku = sku_from_cell(values[key])
            if sku:
                return sku
    for key, value in values.items():
        if re.search(r"item|part", key):
            sku = sku_from_cell(value)
            if sku:
                return sku
    return None


# --- inference --------------------------------------------------------------------------------

MATERIAL_IOR: list[tuple[str, str, float]] = [
    (r"\bN-BK7\b|\bBK7\b", "N-BK7", 1.5168),
    (r"\bUV Fused Silica\b|\bUVFS\b|\bFused Silica\b", "UV Fused Silica", 1.4585),
    (r"\bN-SF11\b|\bSF11\b", "N-SF11", 1.7847),
    (r"\bN-F2\b", "N-F2", 1.6200),
    (r"\bF2\b", "F2", 1.6200),
    (r"\bZinc Selenide\b|\bZnSe\b", "ZnSe", 2.403),
    (r"\bCalcium Fluoride\b|\bCaF\s*2\b|\bCaF\b", "CaF2", 1.4338),
    (r"\bBarium Fluoride\b|\bBaF\s*2\b", "BaF2", 1.474),
    (r"\bMagnesium Fluoride\b|\bMgF\s*2\b", "MgF2", 1.378),
    (r"\bGermanium\b|\bGe\b", "Germanium", 4.003),
    (r"\bHRFZ-Si\b|\bSilicon\b|\bSi\b", "Silicon", 3.42),
    (r"\bPTFE\b", "PTFE", 1.43),
]

GLASS_IOR = {
    "N-BK7": 1.5168,
    "N-SF5": 1.6727,
    "N-SF6": 1.8052,
    "N-SF6HT": 1.8052,
    "N-SF10": 1.7283,
    "N-SF11": 1.7847,
    "N-SF57": 1.8467,
    "N-SF64": 1.7055,
    "N-SF66": 1.9229,
    "SF2": 1.6477,
    "SF5": 1.6727,
    "SF10": 1.7283,
    "SF11": 1.7847,
    "N-BAF10": 1.6700,
    "N-BAK4": 1.5688,
    "N-BAK1": 1.5725,
    "N-LAK22": 1.6516,
    "N-LAK21": 1.6405,
    "N-SK16": 1.6204,
    "N-SK2": 1.6074,
    "N-SSK5": 1.6584,
    "N-SSK8": 1.6177,
    "N-LASF9": 1.8503,
    "N-LASF44": 1.8042,
    "N-KZFS4": 1.6134,
    "N-KZFS5": 1.6541,
    "N-K5": 1.5225,
    "N-LAK9": 1.6910,
    "N-F2": 1.6200,
    "F2": 1.6200,
    "CaF2": 1.4338,
    "MgF2": 1.378,
    "BaF2": 1.474,
    "ZnSe": 2.403,
    "UV Fused Silica": 1.4585,
    "Germanium": 4.003,
    "Silicon": 3.42,
    "PTFE": 1.43,
}

SHAPE_LABELS = {
    "planoConvex": "Plano-Convex",
    "biConvex": "Bi-Convex",
    "planoConcave": "Plano-Concave",
    "biConcave": "Bi-Concave",
    "positiveMeniscus": "Positive Meniscus",
    "negativeMeniscus": "Negative Meniscus",
    "bestForm": "Best Form",
    "hemispherical": "Hemispherical",
    "unknown": "Spherical Lens",
}


def infer_shape(text: str) -> str:
    t = text.lower()
    for pattern, shape in (
        (r"best[-\s]?form", "bestForm"),
        (r"positive[-\s]?meniscus", "positiveMeniscus"),
        (r"negative[-\s]?meniscus", "negativeMeniscus"),
        (r"hemispherical", "hemispherical"),
        (r"bi[-\s]?concave", "biConcave"),
        (r"bi[-\s]?convex", "biConvex"),
        (r"plano[-\s]?concave", "planoConcave"),
        (r"plano[-\s]?convex", "planoConvex"),
    ):
        if re.search(pattern, t):
            return shape
    return "unknown"


def infer_material(text: str) -> tuple[str, float]:
    for pattern, material, ior in MATERIAL_IOR:
        if re.search(pattern, text, re.I):
            return material, ior
    return "Optical Glass", 1.5168


def normalize_glass_name(value: Any) -> str | None:
    s = clean_text(value)
    for pattern, repl in (
        (r"calcium fluoride", "CaF2"),
        (r"barium fluoride", "BaF2"),
        (r"magnesium fluoride", "MgF2"),
        (r"\bCaF\s*2\b", "CaF2"),
        (r"\bBaF\s*2\b", "BaF2"),
        (r"\bMgF\s*2\b", "MgF2"),
        (r"zinc selenide", "ZnSe"),
        (r"uv fused silica", "UV Fused Silica"),
    ):
        s = re.sub(pattern, repl, s, flags=re.I)
    s = re.sub(r"\s+", " ", s).strip()
    return s or None


def ior_for_material(value: Any, fallback: float = 1.5168) -> float:
    text = normalize_glass_name(value)
    if not text:
        return fallback
    upper = re.sub(r"[^A-Z0-9-]", " ", text.upper())
    for name, ior in GLASS_IOR.items():
        key = name.upper()
        if key in upper.split() or key in upper:
            return ior
    return infer_material(text)[1] or fallback


def parse_glass_pair(value: Any) -> dict[str, Any]:
    text = normalize_glass_name(value)
    if not text:
        return {}
    tokens = [
        normalize_glass_name(t)
        for t in re.split(r"[/,+;]", re.sub(r"\band\b", "/", text, flags=re.I))
    ]
    tokens = [t for t in tokens if t]
    out: dict[str, Any] = {
        "ior1": ior_for_material(tokens[0] if tokens else None, 1.658),
        "ior2": ior_for_material(tokens[1] if len(tokens) > 1 else None, 1.750),
    }
    if tokens:
        out["glass1"] = tokens[0]
    if len(tokens) > 1:
        out["glass2"] = tokens[1]
    return out


def infer_coating(text: str) -> str | None:
    clean = re.sub(r"\s+", " ", text)
    if re.search(r"uncoated", clean, re.I):
        return "Uncoated"
    ar = re.search(
        r"(?:AR\s*)?(?:Coated|Coating|V-Coated|V Coated)?(?:\s*:)?\s*"
        r"([0-9.]+\s*(?:-|to|/)\s*[0-9.]+\s*(?:nm|µm|um|m)|[0-9.]+\s*nm)"
        r"(?:\s*(?:and|/)\s*[0-9.]+\s*nm)?",
        clean,
        re.I,
    )
    if ar:
        return re.sub(r"^:\s*", "AR Coating: ", ar.group(0).strip())
    suffix = re.search(r"\b-([A-Z0-9]{1,3})\s*(?:Coating|Coated)\b", clean, re.I)
    return f"{suffix.group(1).upper()} coating" if suffix else None


def infer_mounting(text: str) -> str:
    if re.search(r"\bunmounted\b", text, re.I):
        return "Unmounted"
    if re.search(r"\bmounted\b", text, re.I):
        return "Mounted"
    return "Unmounted"


def infer_substrate(text: str) -> str | None:
    for pattern, name in (
        (r"uv fused silica|uvfs", "UV Fused Silica"),
        (r"fused silica", "Fused Silica"),
        (r"n-bk7|bk7", "N-BK7"),
        (r"borofloat", "Borofloat 33"),
        (r"zerodur", "Zerodur"),
        (r"calcium fluoride|caf2", "CaF2"),
        (r"zinc selenide|znse", "ZnSe"),
        (r"germanium", "Germanium"),
    ):
        if re.search(pattern, text, re.I):
            return name
    return None


def infer_lens_family(text: str) -> str:
    t = text.lower()
    if "objective" in t:
        return "objective"
    if "prism" in t:
        return "prism"
    if re.search(r"achromat|achromatic|doublet", t):
        return "achromatDoublet"
    if "cylindrical" in t and "acylindrical" not in t:
        return "cylindricalLens"
    if re.search(r"aspheric|asphere", t):
        return "asphericLens"
    return "sphericalLens"


def infer_fold_type(sku: str, text: str, values: dict[str, str]) -> str:
    t = f"{sku} {text} {' '.join(values.values())}".lower()
    if (
        re.match(r"f(?:bh|lh|esh|elh)", sku, re.I)
        or re.match(r"mvf", sku, re.I)
        or "fluorescence imaging filters" in t
        or re.search(
            r"bandpass filter|edgepass filter|longpass filter|shortpass filter|spectral filter", t
        )
    ):
        return "filter"
    if re.match(r"dm(?:sp|lp|bp)", sku, re.I) or re.search(r"dichroic|hot and cold mirror", t):
        return "dichroic"
    if re.search(r"non[-\s]?polarizing", t):
        return "beamSplitter"
    if (
        re.match(r"pbs", sku, re.I)
        or "polarizing beamsplitter" in t
        or re.match(r"cm1-pbs", sku, re.I)
    ):
        return "polarizingBeamSplitter"
    if re.search(r"beamsplitter|beam splitter|^bs", t) or re.match(r"cm1-bs", sku, re.I):
        return "beamSplitter"
    if re.match(r"cm\d", sku, re.I) or re.search(
        r"concave mirror|radius of curvature|focal length", t
    ):
        return "curvedMirror"
    return "mirror"


def filter_kind_for(sku: str, text: str, values: dict[str, str]) -> str:
    t = f"{sku} {text} {' '.join(values.values())}".lower()
    if re.match(r"fesh", sku, re.I) or "shortpass" in t:
        return "shortpass"
    if re.match(r"felh", sku, re.I) or "longpass" in t:
        return "longpass"
    return "bandpass"


def filter_dimensions_from_sku(sku: str) -> dict[str, float]:
    u = sku.upper()
    if u.startswith("MVF"):
        return {"diameter": 29, "clearAperture": 23, "thickness": 8.1}
    if re.match(r"(?:FBH|FLH)", u):
        half = bool(re.match(r"(?:FBH|FLH)0\d", u))
        return {
            "diameter": 12.5 if half else 25,
            "clearAperture": 10 if half else 21.1,
            "thickness": 3.5,
        }
    if re.match(r"(?:FELH|FESH|FBW)", u):
        return {"diameter": 25, "clearAperture": 21, "thickness": 3.5}
    if re.match(r"FB\d", u):
        return {"diameter": 25, "clearAperture": 21, "thickness": 2}
    return {}


# --- geometry helpers ------------------------------------------------------------------------


def _finite(r: float | None) -> bool:
    return r is not None and math.isfinite(r) and abs(r) < 1e8


def orient_radii(shape: str, radius: float | None) -> tuple[float | None, float | None]:
    if radius is None:
        return None, None
    if math.isinf(radius):
        return math.inf, math.inf
    r = abs(radius)
    return {
        "planoConvex": (r, math.inf),
        "planoConcave": (-r, math.inf),
        "biConvex": (r, -r),
        "biConcave": (-r, r),
    }.get(shape, (radius, None))


def sign_correct_meniscus(
    shape: str, r1: float | None, r2: float | None
) -> tuple[float | None, float | None]:
    if shape in ("positiveMeniscus", "negativeMeniscus"):
        return (abs(r1) if _finite(r1) else r1), (abs(r2) if _finite(r2) else r2)
    return r1, r2


def _surface_z(radius: float | None, apex: float, radial: float) -> float:
    if not _finite(radius):
        return apex
    val = radius * radius - radial * radial  # type: ignore[operator]
    if val < 0:
        return math.nan
    return (apex + radius) - (1 if radius > 0 else -1) * math.sqrt(val)  # type: ignore[operator]


def _thickness_at(r1: float | None, r2: float | None, ct: float, radial: float) -> float:
    front = _surface_z(r1, -ct / 2, radial)
    back = _surface_z(r2, ct / 2, radial)
    return back - front if math.isfinite(front) and math.isfinite(back) else math.nan


def derive_optical_aperture_radius(
    diameter: float, ct: float, et: float | None, r1: float | None, r2: float | None
) -> float:
    """The radius at which the surfaces still exist (and meet the edge thickness when given)."""
    nominal = diameter / 2
    limit = nominal
    for r in (r1, r2):
        if _finite(r):
            limit = min(limit, abs(r) * (1 - 1e-6))  # type: ignore[arg-type]
    usable = limit if limit > 0 else nominal
    if et is None or not math.isfinite(et):
        return min(nominal, usable)
    edge_at_high = _thickness_at(r1, r2, ct, usable)
    if not math.isfinite(edge_at_high) or abs(edge_at_high - ct) < 1e-9:
        return min(nominal, usable)
    lo_b, hi_b = min(ct, edge_at_high) - 1e-6, max(ct, edge_at_high) + 1e-6
    if not (lo_b <= et <= hi_b):
        return min(nominal, usable)
    increasing = edge_at_high > ct
    lo, hi = 0.0, usable
    for _ in range(50):
        mid = (lo + hi) / 2
        t = _thickness_at(r1, r2, ct, mid)
        if not math.isfinite(t):
            hi = mid
        elif (t < et) if increasing else (t > et):
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


# --- rows → parts ---------------------------------------------------------------------------


def _suffix(text: str | None) -> str:
    return f", {text}" if text else ""


def _sv(value: Any, unit: str | None = None) -> CatalogValue:
    return CatalogValue(value=value, unit=unit, source="vendorPage")


def _page_urls(page: dict[str, Any], slug: str, sku: str) -> tuple[str, str]:
    path = page.get("permalink") or f"/{slug}"
    if not path.startswith("/"):
        path = "/" + path
    family = f"{THORLABS}{path}"
    return family, f"{family}?pn={sku}"


def page_title(page: dict[str, Any]) -> str:
    """The family page's human title — inside its content JSON; the API's ``name`` is an id."""
    try:
        doc = json.loads(str(page.get("content") or ""))
        title = doc.get("title") or doc.get("name") if isinstance(doc, dict) else None
        if isinstance(title, str) and title and not re.fullmatch(r"\d+\.op", title):
            return title
    except (TypeError, ValueError):
        pass
    return str(page.get("name") or "")


def _page_text(page: dict[str, Any], slug: str) -> str:
    return f"{page_title(page)} {page.get('permalink') or ''} {slug}"


def _provenance(url: str, note: str, indexed_at: str) -> list[CatalogProvenance]:
    return [CatalogProvenance(source="vendorPage", url=url, note=note, retrieved_at=indexed_at)]


_LENS_NOTE = (
    "Parsed from public Thorlabs GraphQL family-page product tables. Product-level "
    "Zemax files are available through the linked Thorlabs Zemax catalog/page assets."
)


def _lens_files() -> list[CatalogFile]:
    return [CatalogFile(kind="zemax", role="opticalPrescription", url=ZEMAX_CATALOG_PAGE)]


def spherical_part(
    sku: str, page: dict, slug: str, values: dict[str, str], indexed_at: str
) -> CatalogPart | None:
    text = _page_text(page, slug)
    shape = infer_shape(text)
    dia_key = header_for(values, [r"diameter", r"\bdia\b"])
    diameter = parse_diameter(values.get(dia_key), dia_key) if dia_key else None
    focal = parse_number(cell_for(values, [r"focal length", r"\befl\b", r"^f\b"]))
    ct = parse_number(cell_for(values, [r"center thickness", r"\bct\b", r"^tc\b", r"\btc\b"]))
    et = parse_number(cell_for(values, [r"edge thickness", r"\bet\b", r"^te\b", r"\bte\b"]))
    bfl = parse_number(cell_for(values, [r"back focal", r"\bbfl\b"]))
    diopter = parse_number(cell_for(values, [r"diopter"]))
    r1 = parse_number(cell_for(values, [r"r\s*1\b", r"r1\b", r"radius.*1"]))
    r2 = parse_number(cell_for(values, [r"r\s*2\b", r"r2\b", r"radius.*2"]))
    if r1 is None and r2 is None:
        r1, r2 = orient_radii(
            shape, parse_number(cell_for(values, [r"radius of curvature", r"\bradius\b", r"^r\b"]))
        )
    else:
        r1, r2 = sign_correct_meniscus(shape, r1, r2)
    if (
        diameter is None
        or focal is None
        or ct is None
        or (r1 is None and r2 is None)
        or not math.isfinite(focal)
    ):
        return None
    material, ior = infer_material(text)
    coating = infer_coating(text)
    label = SHAPE_LABELS.get(shape, SHAPE_LABELS["unknown"])
    family_url, product_url = _page_urls(page, slug, sku)
    aperture_r = derive_optical_aperture_radius(diameter, ct, et, r1, r2)

    def rv(r: float | None) -> CatalogValue | None:
        return None if r is None else _sv("Infinity" if math.isinf(r) else r, "mm")

    specs: dict[str, CatalogValue] = {
        "diameter": _sv(diameter, "mm"),
        "effectiveFocalLength": _sv(focal, "mm"),
        "centerThickness": _sv(ct, "mm"),
        "material": _sv(material),
        "shape": _sv(label),
        "mounting": _sv(infer_mounting(text)),
    }
    if abs(2 * aperture_r - diameter) > 0.01:
        specs["modeledApertureDiameter"] = _sv(round(2 * aperture_r, 4), "mm")
    for key, val in (("diopter", diopter), ("backFocalLength", bfl), ("edgeThickness", et)):
        if val is not None:
            specs[key] = _sv(val, None if key == "diopter" else "mm")
    for key, r in (("r1", r1), ("r2", r2)):
        v = rv(r)
        if v is not None:
            specs[key] = v
    if coating:
        specs["coating"] = _sv(coating)
    normalized: dict[str, Any] = {
        "kind": "sphericalLens",
        "focalLengthMm": focal,
        "apertureRadiusMm": aperture_r,
        "thicknessMm": ct,
        "ior": ior,
        "material": material,
    }
    if r1 is not None:
        normalized["r1Mm"] = 1e9 if math.isinf(r1) else r1
    if r2 is not None:
        normalized["r2Mm"] = 1e9 if math.isinf(r2) else r2
    return CatalogPart(
        id=f"thorlabs:{sku}",
        vendor="thorlabs",
        sku=sku,
        title=f"{sku}: {label} {material} Lens, Ø{round(diameter, 3)} mm, "
        f"f = {focal} mm{_suffix(coating)}",
        product_url=product_url,
        category_path=["Optics", "Lenses", "Spherical Singlet Lenses", label],
        component_type="sphericalLens",
        specs=specs,
        normalized=normalized,
        files=_lens_files(),
        provenance=_provenance(family_url, _LENS_NOTE, indexed_at),
        confidence="derived",
        last_indexed=indexed_at,
    )


def cylindrical_part(
    sku: str, page: dict, slug: str, values: dict[str, str], indexed_at: str
) -> CatalogPart | None:
    text = _page_text(page, slug)
    shape = infer_shape(text)
    dia_key = header_for(values, [r"diameter", r"\bdia\b", r"\bod\b"])
    diameter = parse_diameter(values.get(dia_key), dia_key) if dia_key else None
    dim_key = header_for(values, [r"dimension", r"size"])
    dims = parse_dimension_set(values.get(dim_key, ""), dim_key) if dim_key else {}
    length = parse_length(cell_for(values, [r"length"]) or "", header_for(values, [r"length"]))
    height = parse_length(cell_for(values, [r"height"]) or "", header_for(values, [r"height"]))
    ca = parse_length(
        cell_for(values, [r"clear aperture", r"\bca\b"]) or "",
        header_for(values, [r"clear aperture"]),
    )
    focal = parse_number(cell_for(values, [r"focal length", r"\befl\b", r"^f\b"]))
    ct = parse_number(cell_for(values, [r"center thickness", r"\bct\b", r"^tc\b", r"\btc\b"]))
    et = parse_number(cell_for(values, [r"edge thickness", r"\bet\b", r"^te\b", r"\bte\b"]))
    bfl = parse_number(cell_for(values, [r"back focal", r"\bbfl\b"]))
    r1 = parse_number(cell_for(values, [r"r\s*1\b", r"r1\b", r"radius.*1"]))
    r2 = parse_number(cell_for(values, [r"r\s*2\b", r"r2\b", r"radius.*2"]))
    if r1 is None and r2 is None:
        r1, r2 = orient_radii(
            shape, parse_number(cell_for(values, [r"radius of curvature", r"\bradius\b", r"^r\b"]))
        )
    diameter_like = diameter or ca or height or dims.get("width")
    if (
        diameter_like is None
        or focal is None
        or ct is None
        or r1 is None
        or not math.isfinite(focal)
    ):
        return None
    material, ior = infer_material(
        f"{text} {cell_for(values, [r'material', r'substrate', r'glass']) or ''}"
    )
    coating = infer_coating(text)
    label = SHAPE_LABELS.get(shape, "Cylindrical")
    family_url, product_url = _page_urls(page, slug, sku)
    aperture_r = derive_optical_aperture_radius(diameter_like, ct, et, r1, r2)
    width = length or dims.get("height") or dims.get("width") or diameter or ca or aperture_r * 2
    specs: dict[str, CatalogValue] = {
        "width": _sv(width, "mm"),
        "effectiveFocalLength": _sv(focal, "mm"),
        "r1": _sv("Infinity" if math.isinf(r1) else r1, "mm"),
        "r2": _sv("Infinity" if r2 is None or math.isinf(r2) else r2, "mm"),
        "centerThickness": _sv(ct, "mm"),
        "material": _sv(material),
        "shape": _sv(label),
        "mounting": _sv(infer_mounting(text)),
    }
    for key, val in (
        ("diameter", diameter),
        ("clearAperture", ca),
        ("length", length),
        ("height", height),
        ("backFocalLength", bfl),
        ("edgeThickness", et),
    ):
        if val is not None:
            specs[key] = _sv(val, "mm")
    if coating:
        specs["coating"] = _sv(coating)
    size = f"Ø{round(diameter, 3)} mm" if diameter else f"{round(width, 3)} mm wide"
    return CatalogPart(
        id=f"thorlabs:{sku}",
        vendor="thorlabs",
        sku=sku,
        title=f"{sku}: {label} {material} Cylindrical Lens, {size}, "
        f"f = {focal} mm{_suffix(coating)}",
        product_url=product_url,
        category_path=["Optics", "Lenses", "Cylindrical Lenses", label],
        component_type="cylindricalLens",
        specs=specs,
        normalized={
            "kind": "cylindricalLens",
            "focalLengthMm": focal,
            "apertureRadiusMm": aperture_r,
            "widthMm": width,
            "thicknessMm": ct,
            "r1Mm": 1e9 if math.isinf(r1) else r1,
            "r2Mm": 1e9 if r2 is None or math.isinf(r2) else r2,
            "ior": ior,
            "material": material,
        },
        files=_lens_files(),
        provenance=_provenance(family_url, _LENS_NOTE, indexed_at),
        confidence="derived",
        last_indexed=indexed_at,
    )


def aspheric_part(
    sku: str, page: dict, slug: str, values: dict[str, str], indexed_at: str
) -> CatalogPart | None:
    """Row-only asphere: the table has no conic/polynomial terms, so the surface is approximate
    until the product zmx is fetched (``surfaceSource: catalogRow``)."""
    text = _page_text(page, slug)
    focal = parse_number(cell_for(values, [r"focal length", r"\befl\b", r"^f\b"]))
    ct = parse_number(
        cell_for(values, [r"center thickness", r"\bct\b", r"^tc\b", r"\btc\b", r"thickness"])
    )
    if focal is None or ct is None or not math.isfinite(focal):
        return None
    dia_key = header_for(values, [r"diameter", r"\bod\b", r"outer diameter"])
    diameter = parse_diameter(values.get(dia_key), dia_key) if dia_key else None
    ca = parse_length(
        cell_for(values, [r"clear aperture", r"\bca\b"]) or "",
        header_for(values, [r"clear aperture"]),
    )
    na = parse_number(cell_for(values, [r"numerical aperture", r"^na\b", r"\bna\b"]))
    wd = parse_number(cell_for(values, [r"working distance", r"^wd\b", r"\bwd\b"]))
    material_cell = cell_for(values, [r"material", r"substrate", r"glass"])
    material, ior = infer_material(f"{material_cell or ''} {text}")
    aperture_r = (ca or diameter or 2 * focal * 0.25) / 2
    r1 = (
        parse_number(cell_for(values, [r"r\s*1\b", r"r1\b"]))
        or parse_number(cell_for(values, [r"radius of curvature", r"\bradius\b", r"\broc\b"]))
        or (ior - 1) * focal
    )
    r2 = parse_number(cell_for(values, [r"r\s*2\b", r"r2\b"])) or math.inf
    conic = parse_number(cell_for(values, [r"conic", r"\bk\b"])) or 0.0
    coating = infer_coating(text)
    family_url, product_url = _page_urls(page, slug, sku)
    specs: dict[str, CatalogValue] = {
        "effectiveFocalLength": _sv(focal, "mm"),
        "centerThickness": _sv(ct, "mm"),
        "material": _sv(material),
        "mounting": _sv(infer_mounting(text)),
    }
    for key, val, unit in (
        ("diameter", diameter, "mm"),
        ("clearAperture", ca, "mm"),
        ("numericalAperture", na, None),
        ("workingDistance", wd, "mm"),
    ):
        if val is not None:
            specs[key] = _sv(val, unit)
    if coating:
        specs["coating"] = _sv(coating)
    return CatalogPart(
        id=f"thorlabs:{sku}",
        vendor="thorlabs",
        sku=sku,
        title=f"{sku}: {material} Aspheric Lens, "
        f"{'Ø' + str(round(diameter, 3)) + ' mm, ' if diameter else ''}"
        f"f = {focal} mm{_suffix(coating)}",
        product_url=product_url,
        category_path=["Optics", "Lenses", "Aspheric Lenses"],
        component_type="asphericLens",
        specs=specs,
        normalized={
            "kind": "asphericLens",
            "focalLengthMm": focal,
            "apertureRadiusMm": aperture_r,
            "thicknessMm": ct,
            "r1Mm": 1e9 if math.isinf(r1) else r1,
            "r2Mm": 1e9 if math.isinf(r2) else r2,
            "k1": conic,
            "k2": 0.0,
            "ior": ior,
            "material": material,
            "surfaceSource": "catalogRow",
        },
        files=_lens_files(),
        provenance=_provenance(
            family_url,
            "Catalog row parsed from public Thorlabs GraphQL family-page product tables; "
            "asphere coefficients are not present in the row, so normalized optical geometry is "
            "approximate until product Zemax data is imported.",
            indexed_at,
        ),
        confidence="approximate",
        last_indexed=indexed_at,
    )


def achromat_part(
    sku: str, page: dict, slug: str, values: dict[str, str], indexed_at: str
) -> CatalogPart | None:
    text = _page_text(page, slug)
    dia_key = header_for(values, [r"diameter", r"\bdia\b"])
    diameter = parse_diameter(values.get(dia_key), dia_key) if dia_key else None
    focal = parse_number(cell_for(values, [r"focal length", r"\befl\b", r"^f\b"]))
    bfl = parse_number(cell_for(values, [r"back focal", r"\bbfl\b"]))
    r1 = parse_number(cell_for(values, [r"r\s*1\b", r"r1\b", r"radius.*1"]))
    r2 = parse_number(cell_for(values, [r"r\s*2\b", r"r2\b", r"radius.*2"]))
    r3 = parse_number(cell_for(values, [r"r\s*3\b", r"r3\b", r"radius.*3"]))
    t1 = parse_number(
        cell_for(
            values,
            [r"center thickness\s*1", r"\bct\s*1\b", r"\btc\s*1\b", r"\bt\s*1\b", r"thickness.*1"],
        )
    )
    t2 = parse_number(
        cell_for(
            values,
            [r"center thickness\s*2", r"\bct\s*2\b", r"\btc\s*2\b", r"\bt\s*2\b", r"thickness.*2"],
        )
    )
    et = parse_number(cell_for(values, [r"edge thickness", r"\bet\b", r"^te\b", r"\bte\b"]))
    glass_cell = cell_for(values, [r"glass", r"material"])
    if diameter is None or focal is None or not math.isfinite(focal):
        return None
    if any(v is None or not math.isfinite(v) for v in (r1, r2, r3)) or t1 is None or t2 is None:
        return None
    glass = parse_glass_pair(glass_cell or text)
    coating = infer_coating(text)
    family_url, product_url = _page_urls(page, slug, sku)
    specs: dict[str, CatalogValue] = {
        "diameter": _sv(diameter, "mm"),
        "effectiveFocalLength": _sv(focal, "mm"),
        "r1": _sv(r1, "mm"),
        "r2": _sv(r2, "mm"),
        "r3": _sv(r3, "mm"),
        "centerThickness1": _sv(t1, "mm"),
        "centerThickness2": _sv(t2, "mm"),
        "mounting": _sv(infer_mounting(text)),
    }
    if bfl is not None:
        specs["backFocalLength"] = _sv(bfl, "mm")
    if et is not None:
        specs["edgeThickness"] = _sv(et, "mm")
    if glass_cell:
        specs["glass"] = _sv(normalize_glass_name(glass_cell) or glass_cell)
    if coating:
        specs["coating"] = _sv(coating)
    normalized: dict[str, Any] = {
        "kind": "achromatDoublet",
        "focalLengthMm": focal,
        "apertureRadiusMm": diameter / 2,
        "r1Mm": r1,
        "r2Mm": r2,
        "r3Mm": r3,
        "t1Mm": t1,
        "t2Mm": t2,
        "ior1": glass.get("ior1", 1.658),
        "ior2": glass.get("ior2", 1.750),
    }
    for k in ("glass1", "glass2"):
        if glass.get(k):
            normalized[k] = glass[k]
    return CatalogPart(
        id=f"thorlabs:{sku}",
        vendor="thorlabs",
        sku=sku,
        title=f"{sku}: Achromatic Doublet, Ø{round(diameter, 3)} mm, "
        f"f = {focal} mm{_suffix(coating)}",
        product_url=product_url,
        category_path=["Optics", "Lenses", "Achromatic Lenses"],
        component_type="achromatDoublet",
        specs=specs,
        normalized=normalized,
        files=_lens_files(),
        provenance=_provenance(
            family_url,
            "Parsed from public Thorlabs GraphQL family-page product tables. Glass "
            "indices are reference approximations unless product Zemax data is imported.",
            indexed_at,
        ),
        confidence="derived",
        last_indexed=indexed_at,
    )


def _dims_of(values: dict[str, str]) -> dict[str, float]:
    key = header_for(
        values,
        [
            r"cube size",
            r"mirror size",
            r"optic size",
            r"^size$",
            r"dimension",
            r"substrate dimensions",
        ],
    ) or header_for(values, [r"^diameter$", r"^dia\b", r"^od$"])
    dims = parse_dimension_set(values.get(key, ""), key) if key else {}
    out: dict[str, float] = {}
    d = dims.get("diameter") or parse_length(
        cell_for(values, [r"^diameter$", r"^dia\b", r"^od$"]) or "", "diameter"
    )
    w = dims.get("width") or parse_length(
        cell_for(values, [r"^width$", r"^length$"]) or "", "width"
    )
    h = dims.get("height") or parse_length(cell_for(values, [r"^height$"]) or "", "height")
    for k, v in (("diameter", d), ("width", w), ("height", h), ("depth", dims.get("depth"))):
        if v is not None:
            out[k] = v
    return out


def _shape_for(dims: dict[str, float], kind: str) -> str:
    w, h = dims.get("width"), dims.get("height")
    if kind in ("beamSplitter", "polarizingBeamSplitter") and (
        dims.get("depth") is not None or (w is not None and h is not None and abs(w - h) < 0.01)
    ):
        return "cube"
    if dims.get("diameter") is not None:
        return "round"
    if w is not None and h is not None and abs(w - h) < 0.01:
        return "square"
    if w is not None or h is not None:
        return "rectangular"
    return "unknown"


def _split_ratio(text: str) -> float | None:
    clean = clean_text(text)
    m = re.search(r"\b(\d{1,2})\s*[:/]\s*(\d{1,2})\b", clean)
    if m:
        r, t = float(m.group(1)), float(m.group(2))
        return r / (r + t) if r + t > 0 else None
    m = re.search(r"\bR\s*=\s*(\d{1,3})\s*%|\b(\d{1,3})\s*%\s*R\b", clean, re.I)
    if m:
        return max(0.0, min(1.0, float(m.group(1) or m.group(2)) / 100))
    return None


def _dichroic_size(sku: str) -> dict[str, Any]:
    suffix = sku[-1].upper() if sku else ""
    return {
        "T": {"diameter": 12.7, "shape": "round"},
        "L": {"diameter": 50.8, "shape": "round"},
        "R": {"width": 25, "height": 36, "shape": "rectangular"},
        "B": {"width": 35, "height": 52, "shape": "rectangular"},
    }.get(suffix, {"diameter": 25.4, "shape": "round"})


def fold_part(
    sku: str, page: dict, slug: str, values: dict[str, str], indexed_at: str
) -> CatalogPart | None:
    text = _page_text(page, slug)
    all_text = f"{text} {' '.join(values.values())}"
    kind = infer_fold_type(sku, text, values)
    if kind == "mirror" and (
        re.match(r"mpd", sku, re.I)
        or re.search(r"off[-\s]?axis parabolic|parabolic mirror", all_text, re.I)
    ):
        return None
    family_url, product_url = _page_urls(page, slug, sku)
    coating = clean_text(cell_for(values, [r"coating"]) or "") or infer_coating(all_text)
    substrate = infer_substrate(all_text)
    mounting = infer_mounting(all_text)

    if kind == "filter":
        fk = filter_kind_for(sku, text, values)
        fallback = filter_dimensions_from_sku(sku)
        d = (
            fallback.get("diameter")
            or parse_diameter(
                cell_for(values, [r"outer diameter", r"^diameter$", r"^dia\b", r"^od$"]) or "",
                "diameter",
            )
            or parse_diameter(
                cell_for(values, [r"filter size", r"^size$", r"dimension"]) or "", "diameter"
            )
        )
        ca = fallback.get("clearAperture") or parse_diameter(
            cell_for(values, [r"clear aperture"]) or "", "clear aperture"
        )
        w = parse_length(cell_for(values, [r"^width$", r"^length$"]) or "", "width")
        h = parse_length(cell_for(values, [r"^height$"]) or "", "height")
        t = (
            fallback.get("thickness")
            or parse_length(
                cell_for(values, [r"mounted thickness", r"^thickness$", r"\bct\b"]) or "",
                "thickness",
            )
            or (3.5 if re.search(r"\bmounted\b", all_text, re.I) else 2)
        )
        centre = parse_wavelength_nm(cell_for(values, [r"center wavelength", r"\bcwl\b"]))
        width = parse_wavelength_nm(cell_for(values, [r"fwhm", r"bandwidth"]))
        cut_on = parse_wavelength_nm(
            cell_for(values, [r"cut[-\s]?on", r"edge wavelength", r"cutoff wavelength"])
        )
        cut_off = parse_wavelength_nm(cell_for(values, [r"cut[-\s]?off", r"cutoff wavelength"]))
        cutoff = (
            (cut_on or cut_off)
            if fk == "longpass"
            else (cut_off or cut_on)
            if fk == "shortpass"
            else None
        )
        if fk == "bandpass" and centre is None:
            return None
        if fk in ("longpass", "shortpass") and cutoff is None:
            return None
        blocking = clean_text(cell_for(values, [r"blocking"]) or "") or None
        od_text = clean_text(cell_for(values, [r"optical density", r"^od\b", r"blocking"]) or "")
        od_m = re.search(r"\bOD(?:abs|avg)?\s*(?:>|≥|>=|=)?\s*([0-9.]+)", od_text, re.I)
        od = float(od_m.group(1)) if od_m else None
        f_mount = "Mounted" if re.match(r"(?:FBH|FLH|FELH|FESH|MVF|FBW)", sku, re.I) else mounting
        shape = (
            "round"
            if d
            else "square"
            if (w and h and abs(w - h) < 0.01)
            else "rectangular"
            if (w or h)
            else "unknown"
        )
        specs: dict[str, CatalogValue] = {
            "thickness": _sv(t, "mm"),
            "mounting": _sv(f_mount),
            "shape": _sv(shape),
        }
        for key, val, unit in (
            ("diameter", d, "mm"),
            ("clearAperture", ca, "mm"),
            ("width", w, "mm"),
            ("height", h, "mm"),
            ("centerWavelength", centre, "nm"),
            ("bandwidth", width, "nm"),
            ("cutoffWavelength", cutoff, "nm"),
            ("blockingBand", blocking, None),
            ("opticalDensity", od, None),
            ("coating", coating or None, None),
            ("substrate", substrate, None),
        ):
            if val is not None:
                specs[key] = _sv(val, unit)
        normalized: dict[str, Any] = {
            "kind": "filter",
            "thicknessMm": t,
            "filterKind": fk,
            "shape": shape,
        }
        for key, val in (
            ("diameterMm", d),
            ("widthMm", w),
            ("heightMm", h),
            ("cutoffWavelengthNm", cutoff),
            ("centerWavelengthNm", centre),
            ("bandwidthNm", width),
            ("blockingBand", blocking),
            ("opticalDensity", od),
            ("coating", coating or None),
            ("substrate", substrate),
        ):
            if val is not None:
                normalized[key] = val
        size = f"Ø{round(d, 3)} mm" if d else f"{w} x {h} mm" if (w and h) else ""
        band = (
            f"CWL = {centre} nm" + (f", FWHM = {width} nm" if width else "")
            if fk == "bandpass"
            else f"Cut-{'On' if fk == 'longpass' else 'Off'} = {cutoff} nm"
        )
        return CatalogPart(
            id=f"thorlabs:{sku}",
            vendor="thorlabs",
            sku=sku,
            title=f"{sku}: {fk.capitalize()} Filter, {size + ', ' if size else ''}"
            f"{band}{_suffix(coating)}",
            product_url=product_url,
            category_path=["Optics", "Filters", fk],
            component_type="filter",
            specs=specs,
            normalized=normalized,
            files=[],
            provenance=_provenance(
                family_url,
                "Parsed from public Thorlabs filter family-page product tables.",
                indexed_at,
            ),
            confidence="derived",
            last_indexed=indexed_at,
        )

    dims = _dims_of(values)
    if kind == "dichroic":
        for k, v in _dichroic_size(sku).items():
            if k != "shape":
                dims.setdefault(k, v)
    if kind == "curvedMirror":
        m = re.match(r"CM(\d{3})-", sku, re.I)
        if m:
            dims.setdefault("diameter", float(m.group(1)) / 10)
    shape = _shape_for(dims, kind)
    if shape == "unknown" and kind == "dichroic":
        shape = _dichroic_size(sku)["shape"]
    t = (
        parse_length(
            cell_for(values, [r"center thickness", r"^thickness$", r"\bct\b"]) or "", "thickness"
        )
        or dims.get("depth")
        or (6.35 if kind == "mirror" else 1.1 if kind == "dichroic" else 2)
    )
    wl_range = clean_text(cell_for(values, [r"wavelength range", r"coating range"]) or "") or None
    focal = parse_number(cell_for(values, [r"focal length"]))
    roc = parse_number(cell_for(values, [r"radius of curvature", r"\broc\b"])) or (
        2 * focal if focal else None
    )
    cutoff = parse_number(cell_for(values, [r"cutoff wavelength", r"cut[-\s]?on wavelength"]))
    t_band = clean_text(cell_for(values, [r"transmission band"]) or "") or None
    r_band = clean_text(cell_for(values, [r"reflection band"]) or "") or None
    split = _split_ratio(f"{' '.join(values.values())} {text}")

    specs = {"thickness": _sv(t, "mm"), "mounting": _sv(mounting), "shape": _sv(shape)}
    for key, val, unit in (
        ("diameter", dims.get("diameter"), "mm"),
        ("width", dims.get("width"), "mm"),
        ("height", dims.get("height"), "mm"),
        ("focalLength", focal, "mm"),
        ("radiusOfCurvature", roc, "mm"),
        ("cutoffWavelength", cutoff, "nm"),
        ("wavelengthRange", wl_range, None),
        ("transmissionBand", t_band, None),
        ("reflectionBand", r_band, None),
        ("coating", coating or None, None),
        ("substrate", substrate, None),
    ):
        if val is not None:
            specs[key] = _sv(val, unit)
    if kind == "beamSplitter" and split is not None:
        specs["splitRatio"] = _sv(split)
    normalized = {"kind": kind, "thicknessMm": t, "shape": shape}
    for key, val in (
        ("diameterMm", dims.get("diameter")),
        ("widthMm", dims.get("width")),
        ("heightMm", dims.get("height")),
        ("coating", coating or None),
        ("substrate", substrate),
    ):
        if val is not None:
            normalized[key] = val
    if kind == "curvedMirror":
        if not dims.get("diameter") or not roc:
            return None
        normalized["radiusOfCurvatureMm"] = roc
        if focal is not None:
            normalized["focalLengthMm"] = focal
    elif kind in ("beamSplitter", "polarizingBeamSplitter"):
        if kind == "beamSplitter" and split is not None:
            normalized["splitRatio"] = split
        if wl_range:
            normalized["wavelengthRange"] = wl_range
    elif kind == "dichroic":
        normalized["filterKind"] = (
            "shortpass"
            if (re.match(r"dmsp", sku, re.I) or "shortpass" in text.lower())
            else "bandpass"
            if re.match(r"dmbp", sku, re.I)
            else "longpass"
        )
        for key, val in (
            ("cutoffWavelengthNm", cutoff),
            ("transmissionBand", t_band),
            ("reflectionBand", r_band),
        ):
            if val is not None:
                normalized[key] = val
    elif not any(k in dims for k in ("diameter", "width", "height")):
        return None
    size = (
        f"Ø{round(dims['diameter'], 3)} mm"
        if "diameter" in dims
        else f"{dims.get('width')} x {dims.get('height')} mm"
        if ("width" in dims and "height" in dims)
        else ""
    )
    label = {
        "mirror": "Mirror",
        "curvedMirror": "Concave Mirror",
        "beamSplitter": "Beam Splitter",
        "polarizingBeamSplitter": "Polarizing Beam Splitter",
        "dichroic": "Dichroic Mirror",
    }[kind]
    return CatalogPart(
        id=f"thorlabs:{sku}",
        vendor="thorlabs",
        sku=sku,
        title=f"{sku}: {label}{_suffix(size)}{_suffix(wl_range or coating)}",
        product_url=product_url,
        category_path=["Optics", "Mirrors & Splitters", kind],
        component_type=kind,
        specs=specs,
        normalized=normalized,
        files=[],
        provenance=_provenance(
            family_url,
            "Parsed from public Thorlabs GraphQL family-page product tables.",
            indexed_at,
        ),
        confidence="derived",
        last_indexed=indexed_at,
    )


_FOLD_SLUG_RE = re.compile(
    r"mirror|beamsplitter|beam-splitter|dichroic|filter|edgepass|bandpass|longpass|shortpass"
)
_SKIP_FOLD_SKU_RE = re.compile(
    r"^(?:PCM|BSH|FBTB|KM|K6|SC|ARV|CRM|C4W|C6W|SB|B6C|B3|B4|PM|KC|LMR|SM|TR|TPS|FK)", re.I
)


def page_scope(slug: str) -> str:
    return "fold" if _FOLD_SLUG_RE.search(slug) else "lenses"


def parse_family_page(
    page: dict[str, Any], slug: str, indexed_at: str, scope: str | None = None
) -> list[CatalogPart]:
    """Every product row on one family page → parts; the first row per SKU wins."""
    scope = scope or page_scope(slug)
    text = _page_text(page, slug)
    family = infer_lens_family(text)
    parts: dict[str, CatalogPart] = {}
    for html in html_strings(str(page.get("content") or "")):
        for table in html_tables(html):
            for values in rows_as_objects(table):
                sku = sku_of(values)
                if not sku or sku in parts:
                    continue
                part: CatalogPart | None
                if scope == "fold":
                    if _SKIP_FOLD_SKU_RE.match(sku):
                        continue
                    part = fold_part(sku, page, slug, values, indexed_at)
                elif family in ("objective", "prism"):
                    part = None  # not this crawler's business (BOMB's snapshot carries them)
                elif family == "achromatDoublet":
                    part = achromat_part(sku, page, slug, values, indexed_at)
                elif family == "cylindricalLens":
                    part = cylindrical_part(sku, page, slug, values, indexed_at)
                elif family == "asphericLens":
                    part = aspheric_part(sku, page, slug, values, indexed_at)
                else:
                    if re.match(r"(?:LSB|LSS|LSP|LST)", sku):
                        continue
                    keys = " | ".join(values)
                    if not re.search(r"focal|efl|diopter|radius|r\s*1|r1", keys):
                        continue
                    part = spherical_part(sku, page, slug, values, indexed_at)
                if part is not None:
                    parts[sku] = part
    return list(parts.values())


# --- slugs ---------------------------------------------------------------------------------


def normalize_slug(raw: str | None) -> str | None:
    if not raw:
        return None
    value = _html.unescape(raw).strip()
    if not value or value == "#":
        return None
    if re.match(r"https?://", value, re.I):
        m = re.match(r"https?://([^/]+)(/[^?#]*)?", value, re.I)
        if not m or "thorlabs." not in m.group(1).lower():
            return None
        value = m.group(2) or ""
    value = re.sub(r"^/(?:en|zh|ja)/", "/", value, flags=re.I)
    value = re.split(r"[?#]", value.lstrip("/"))[0].rstrip("/")
    if not value or re.search(
        r"\.(?:webp|png|jpg|jpeg|gif|svg|pdf|dxf|step|stp|sldprt|zar|zmx|zip)$", value, re.I
    ):
        return None
    return value.lower()


def should_crawl(slug: str | None, scope: str) -> bool:
    if not slug:
        return False
    if re.search(r"globalassets|contentassets|catalogpages|software-pages|item/", slug):
        return False
    if re.search(r"(?:cleaning|handling|adapter|retaining|lens-tube|kit|kits)(?:-|$)", slug):
        return False
    if re.search(r"(?:^|-)mounts?(?:-|$)", slug):
        return False
    if scope == "fold":
        if re.search(r"fluorescence-imaging-filters|dichroic-color-filters", slug):
            return False
        return bool(_FOLD_SLUG_RE.search(slug))
    if re.match(r"(?:optics|optical-elements|optical-lenses|main-visual-navigation)$", slug):
        return False
    if re.search(
        r"objective|mirror|beamsplitter|polarizer|waveplate|filter|prism|acylindrical", slug
    ):
        return False
    return bool(
        re.search(
            r"spherical|singlet|plano-convex|bi-convex|plano-concave|bi-concave|meniscus|best-form|"
            r"hemispherical|cylindrical|aspheric|asphere|achromatic|doublet|lens|lenses",
            slug,
        )
    )


def linked_slugs(content: str, scope: str) -> list[str]:
    """Family slugs a page links to — from its ``url``/``externalURL`` fields and hrefs."""
    found: list[str] = []
    seen: set[str] = set()
    patterns = (r'"(?:url|externalURL)"\s*:\s*"([^"]+)"', r'href=\\"([^"\\]+)\\"|href="([^"]+)"')
    for pattern in patterns:
        for m in re.finditer(pattern, content):
            raw = next((g for g in m.groups() if g), None)
            slug = normalize_slug(raw)
            if slug and slug not in seen and should_crawl(slug, scope):
                seen.add(slug)
                found.append(slug)
    return found
