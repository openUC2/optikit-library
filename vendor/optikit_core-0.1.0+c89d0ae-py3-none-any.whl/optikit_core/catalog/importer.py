"""The one import road (plan §3): a catalog row → a proposed component record.

``zmx`` fetches the row's product-level Zemax file and hands it to the
existing importer; ``derive`` mints the record from the table (WP-255);
``auto`` takes the zmx when the row names one and falls back to the table,
saying so in ``review``. Nothing here writes to the library.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from .derive import CatalogDeriveError, derive_component
from .fetch import CatalogFetchError, fetch_prescription
from .snapshot import Snapshot
from .types import CatalogPart

Road = Literal["auto", "zmx", "derive"]


class CatalogImportError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass
class ImportOutcome:
    component: dict[str, Any]
    review: list[str] = field(default_factory=list)
    efl_mm: float | None = None
    road: str = "derive"
    part_id: str = ""
    zmx_path: Path | None = None


def _zmx_road(
    part: CatalogPart, cache_dir: Path, namespace: str, snapshot_version: str
) -> ImportOutcome:
    try:
        from ..importers.thorlabs import ZmxImportError, zmx_to_component
    except ImportError as exc:
        raise CatalogImportError(
            "E_NO_OPTILAND", "the zmx road needs optiland: pip install optikit-core[sim]"
        ) from exc
    fetched = fetch_prescription(part, cache_dir)
    try:
        result = zmx_to_component(
            fetched.path, mpn=part.sku, namespace=namespace, vendor_name=part.vendor.capitalize()
        )
    except ZmxImportError as exc:
        raise CatalogImportError("E_BAD_ZMX", str(exc)) from exc
    component = result.component
    vendor = component.setdefault("vendor", {})
    vendor["url"] = part.product_url
    if part.price:
        vendor["price"], vendor["currency"] = part.price.amount, part.price.currency
    tags = list(component.get("tags") or [])
    component["tags"] = (
        tags + ["catalog"] + ([f"catalog/{snapshot_version}"] if snapshot_version else [])
    )
    review = list(result.review)
    review.append(
        f"prescription from the vendor zmx {fetched.url} "
        f"(sha256 {fetched.sha256[:12]}…, retrieved {fetched.retrieved_at})"
    )
    component["review"] = review
    return ImportOutcome(
        component=component,
        review=review,
        efl_mm=result.efl_mm,
        road="zmx",
        part_id=part.id,
        zmx_path=fetched.path,
    )


def import_part(
    snapshot: Snapshot,
    part_id: str,
    *,
    road: Road = "auto",
    namespace: str = "thorlabs",
    cache_dir: Path,
) -> ImportOutcome:
    part = snapshot.by_id(part_id)
    if part is None:
        raise CatalogImportError(
            "E_CATALOG_UNKNOWN_PART", f"no row {part_id!r} in snapshot {snapshot.version}"
        )
    if road == "derive":
        return _derive(part, namespace, snapshot.version, [])
    if road == "zmx":
        return _zmx_road(part, cache_dir, namespace, snapshot.version)
    # auto: the zmx when the row names one, else the table — and say which.
    if part.prescription_file() is None:
        return _derive(part, namespace, snapshot.version, [])
    try:
        return _zmx_road(part, cache_dir, namespace, snapshot.version)
    except (CatalogFetchError, CatalogImportError) as exc:
        return _derive(
            part,
            namespace,
            snapshot.version,
            [f"vendor zmx not used ({exc.code}: {exc}) — derived from the table instead"],
        )


def _derive(
    part: CatalogPart, namespace: str, snapshot_version: str, notes: list[str]
) -> ImportOutcome:
    try:
        result = derive_component(part, namespace=namespace, snapshot_version=snapshot_version)
    except CatalogDeriveError as exc:
        raise CatalogImportError(exc.code, str(exc)) from exc
    if notes:
        result.review.extend(notes)
        result.component["review"] = result.review
    return ImportOutcome(
        component=result.component,
        review=result.review,
        efl_mm=result.efl_mm,
        road="derive",
        part_id=part.id,
    )
