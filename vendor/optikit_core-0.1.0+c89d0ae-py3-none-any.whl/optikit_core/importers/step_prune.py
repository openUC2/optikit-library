"""Drop fasteners, cables and boards from a STEP's assembly tree.

A production export carries every screw, and they are most of its triangles
and none of its meaning: FRAME #0008 is 528 named parts and 599 pieces of
hardware. The node names ARE the contract
(`DOCS/editor/frame-assembly-contract.md`), so the prune works on the XCAF
tree the importer already reads — same names, same poses, fewer solids.
Anything the spec names is protected whatever the rules say.
"""

from __future__ import annotations

import re
from typing import Any

#: Standard-parts library and loose hardware.
FASTENERS = re.compile(
    r"^(ISO|DIN|GB/T|ANSI|JIS|BS|NF|UNI|SFS)[\s_-]|"
    r"washer|screw|threaded pin|sleeve nut|hexagon|circlip|dowel pin|"
    r"set screw|grub screw|spring pin|retaining ring|hex nut|"
    r"schraube|mutter|scheibe",
    re.I,
)
#: Cables and connectors — swept helices, and they move.
CABLES = re.compile(r"\bcables?\b|\bkabel\b|\bpatch\b|\bwire\b|jumper", re.I)
#: Boards and power — dense, and the record is the case that holds them.
ELECTRONICS = re.compile(
    r"^BRD[\s_-]|raspberry.?pi|raspi|\bpcb\b|mainboard|maibrd|esp32|"
    r"tmc2209|motordriver|motor driver|power supply|usb hub|wifi adapter|"
    r"micro.?sd|sd.?card|argb|led light bar|hard drive|touch display",
    re.I,
)
RULES: dict[str, re.Pattern[str]] = {
    "fastener": FASTENERS, "cable": CABLES, "electronics": ELECTRONICS,
}


def _name(label: Any) -> str:
    from OCP.TDataStd import TDataStd_Name

    attr = TDataStd_Name()
    if label.FindAttribute(TDataStd_Name.GetID_s(), attr):
        return attr.Get().ToExtString()
    return ""


def _entry(label: Any) -> str:
    from OCP.TCollection import TCollection_AsciiString
    from OCP.TDF import TDF_Tool

    entry = TCollection_AsciiString()
    TDF_Tool.Entry_s(label, entry)
    return entry.ToCString()


def prune_document(
    doc: Any, *, protect: tuple[str, ...] = (), rules: dict[str, re.Pattern[str]] | None = None
) -> dict[str, int]:
    """Remove hardware instances from an XCAF document; returns what went.

    ``protect`` holds substrings — a node whose name contains one survives,
    but the walk still descends into it (the boards inside a protected case
    still go).
    """
    from OCP.TDF import TDF_Label, TDF_LabelSequence
    from OCP.XCAFDoc import XCAFDoc_DocumentTool

    tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    rules = RULES if rules is None else rules
    keep = tuple(p.lower() for p in protect)
    gone: dict[str, int] = {}

    def classify(name: str) -> str | None:
        if any(p in name.lower() for p in keep):
            return None
        for why, pattern in rules.items():
            if pattern.search(name):
                return why
        return None

    def walk(label: Any) -> None:
        comps = TDF_LabelSequence()
        if not tool.GetComponents_s(label, comps, False):
            return
        doomed = []
        for i in range(1, comps.Length() + 1):
            comp = comps.Value(i)
            referred = TDF_Label()
            has_ref = tool.GetReferredShape_s(comp, referred)
            why = classify(_name(comp) or (_name(referred) if has_ref else ""))
            if why is not None:
                gone[why] = gone.get(why, 0) + 1
                doomed.append(comp)
                continue
            walk(referred if has_ref else comp)
        for comp in reversed(doomed):
            tool.RemoveComponent(comp)

    roots = TDF_LabelSequence()
    tool.GetFreeShapes(roots)
    root_entries = {_entry(roots.Value(i)) for i in range(1, roots.Length() + 1)}
    for i in range(1, roots.Length() + 1):
        walk(roots.Value(i))

    # RemoveComponent cuts the INSTANCE only; the definition it referred to is
    # then a free shape, and the glTF writer emits every free shape as a scene
    # root — the pruned parts would come back as loose objects at the origin.
    # Sweep the new orphans, repeating because one removal orphans the next.
    while True:
        free = TDF_LabelSequence()
        tool.GetFreeShapes(free)
        orphans = [free.Value(i) for i in range(1, free.Length() + 1)
                   if _entry(free.Value(i)) not in root_entries]
        if not orphans:
            break
        removed = 0
        for label in orphans:
            before = _entry(label)
            tool.RemoveShape(label, True)
            after = TDF_LabelSequence()
            tool.GetFreeShapes(after)
            if before not in {_entry(after.Value(i)) for i in range(1, after.Length() + 1)}:
                removed += 1
        gone["orphan-defs"] = gone.get("orphan-defs", 0) + removed
        if removed == 0:
            break
    tool.UpdateAssemblies()
    return gone
