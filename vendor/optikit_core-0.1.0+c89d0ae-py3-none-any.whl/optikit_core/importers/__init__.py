"""Importers: external CAD/vendor formats → library records."""

from .glb2template import (
    ImportResult,
    LensPrescription,
    glb_to_records,
    parse_lens_prescription,
)
from .optiland_setup import (
    OptilandSetupError,
    OptilandSetupResult,
    setup_to_components,
)
from .thorlabs import (
    ZmxImportError,
    ZmxImportResult,
    import_thorlabs_mpns,
    zmx_to_component,
)

__all__ = [
    "ImportResult",
    "LensPrescription",
    "OptilandSetupError",
    "OptilandSetupResult",
    "ZmxImportError",
    "ZmxImportResult",
    "glb_to_records",
    "import_glb_file",
    "import_thorlabs_mpns",
    "parse_lens_prescription",
    "setup_to_components",
    "zmx_to_component",
]


def import_glb_file(
    glb_path, namespace: str = "openuc2", *, catalog=None, catalog_road: str = "auto",
    cache_dir=None,
) -> ImportResult:
    """Load a GLB and derive records. Requires the ``importers`` extra.

    ``catalog`` (a snapshot) lets a BUY part number resolve to the vendor's
    own prescription — see ``glb_to_records``.
    """
    from pathlib import Path

    try:
        import pygltflib
    except ImportError as exc:  # pragma: no cover - exercised via CLI message
        raise ImportError(
            "pygltflib is required: pip install optikit-core[importers]"
        ) from exc
    gltf = pygltflib.GLTF2().load(str(glb_path))
    return glb_to_records(
        gltf, Path(glb_path).name, namespace=namespace,
        catalog=catalog, catalog_road=catalog_road, cache_dir=cache_dir,
    )
