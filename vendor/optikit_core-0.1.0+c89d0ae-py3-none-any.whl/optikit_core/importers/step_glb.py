"""STEP → GLB preserving assembly structure, names, and colors (WP-175).

Read through the OCP XCAF pipeline (``STEPCAFControl_Reader`` with name+color
transfer, ``RWGltf_CafWriter`` out), so a converted STP is node-for-node
equivalent to a direct PyInventor export. The old
``importStep`` + ``cq.Assembly`` route fused everything into ONE anonymous grey
shape, silently breaking every feature that reads the Inventor naming contract
off the node tree: the ``PRT - CUBHLF`` mask (WP-117), the insert re-mount
split (WP-156), and part colors — all of which the STEP itself carries.

Conventions (DSN contract §2, and PyInventor's own exports):

- **Units:** vertices stay in MILLIMETRES — no unit conversion configured.
- **Axes:** **Z-up, untransformed** — the cube frame, so an STP and a GLB of
  the same assembly load identically (``mesh-frame: cube``). The first WP-175
  cut copied the old converter's −90°-about-X into glTF Y-up; baked into the
  vertices with no wrapper node, the wizard read it as a cube-frame file lying
  on its side and demanded a manual x⟳90° on every STP import.
"""

from __future__ import annotations

import logging
import struct
from pathlib import Path

from ..units import SPEC_UNIT

_log = logging.getLogger(__name__)


class StepGlbError(Exception):
    """A STEP could not be read or converted; ``code`` names the stage."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


#: Meshing tolerances (WP-231). cadquery's own defaults are 0.1/0.1, which
#: for a 50 mm cube part is finer than anything the assembly view can show:
#: measured on the worst specimen in the library (electronic_galvo, 27 MB of
#: STEP), 0.1/0.1 gives 709k triangles / 22.3 MB while 0.3/0.5 gives 140k /
#: 9.0 MB — 5x fewer triangles for a 0.3 mm chord error nobody can see at
#: assembly scale. Past that the curve flattens (1.0/1.0 saves a further
#: 0.3 MB), so this is the knee, not the floor.
#:
#: Override per call with `step_file_to_glb(..., linear=, angular=)`, or per
#: run with `library retessellate --linear/--angular`.
LIN_DEFLECTION = 0.3
ANG_DEFLECTION = 0.5


def stamp_glb_unit(glb_path: Path, unit: str = SPEC_UNIT) -> None:
    """Record the file's length unit in ``asset.extras`` (WP-237).

    glTF has no unit field, so "metres" is only a convention a reader may or
    may not follow — and a corpus that mixes these with the pre-WP-237
    millimetre files has to tell them apart by measuring. A stamped file is
    decidable instead of guessable.
    """
    from ..library.mesh import _chunks, _write_glb
    from ..units import stamp_unit

    gltf, binary = _chunks(glb_path.read_bytes())
    stamp_unit(gltf, unit)
    glb_path.write_bytes(_write_glb(gltf, binary or b""))


def step_file_to_glb(
    step_path: Path,
    glb_path: Path,
    *,
    linear: float | None = None,
    angular: float | None = None,
    merge: bool = True,
    prune: bool = False,
    protect: tuple[str, ...] = (),
    warnings: list[str] | None = None,
) -> None:
    """Convert one STEP file to a binary glTF, keeping names/colors/tree.

    ``linear``/``angular`` override the module tessellation defaults (mm of
    chord error, radians of normal deviation) — coarser means fewer
    triangles and a smaller file, at a surface error no viewer resolves.

    ``prune`` drops the fasteners, cables and boards the assembly carries
    before meshing (``protect`` names substrings that survive it) — see
    ``step_prune``; the tree, names and poses are untouched.

    ``merge`` (WP-224) collapses each mesh's primitives by material, which is
    what makes the result renderable: OCCT writes one primitive per B-rep
    face, and every primitive is a draw call. A merge that cannot be proven
    safe is SKIPPED, not fatal — it appends to ``warnings`` (or logs) and the
    converted mesh stands.
    """
    from OCP.BRepMesh import BRepMesh_IncrementalMesh
    from OCP.IFSelect import IFSelect_RetDone
    from OCP.Message import Message_ProgressRange
    from OCP.RWGltf import RWGltf_CafWriter
    from OCP.RWMesh import RWMesh_CoordinateSystem
    from OCP.STEPCAFControl import STEPCAFControl_Reader
    from OCP.TCollection import TCollection_AsciiString, TCollection_ExtendedString
    from OCP.TColStd import TColStd_IndexedDataMapOfStringString
    from OCP.TDF import TDF_LabelSequence
    from OCP.TDocStd import TDocStd_Document
    from OCP.XCAFDoc import XCAFDoc_DocumentTool

    doc = TDocStd_Document(TCollection_ExtendedString("BinXCAF"))
    reader = STEPCAFControl_Reader()
    reader.SetNameMode(True)
    reader.SetColorMode(True)
    reader.SetLayerMode(True)

    status = reader.ReadFile(str(step_path))
    if status != IFSelect_RetDone:
        raise StepGlbError("E_BAD_STEP", f"OCCT could not read the STEP ({status!r})")
    if not reader.Transfer(doc):
        raise StepGlbError("E_BAD_STEP", "STEP transfer into the XCAF document failed")

    if prune:
        from .step_prune import prune_document

        gone = prune_document(doc, protect=protect)
        note = "pruned " + ", ".join(f"{k} {v}" for k, v in sorted(gone.items()))
        if warnings is not None:
            warnings.append(note)
        _log.info("%s: %s", step_path.name, note)

    # RWGltf_CafWriter exports EXISTING triangulations only — mesh every free
    # shape first (a free shape is a whole assembly compound; meshing it
    # meshes all its solids).
    shape_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    free_shapes = TDF_LabelSequence()
    shape_tool.GetFreeShapes(free_shapes)
    if free_shapes.Length() == 0:
        raise StepGlbError("E_BAD_STEP", "the STEP contains no shapes")
    for i in range(1, free_shapes.Length() + 1):
        shape = shape_tool.GetShape_s(free_shapes.Value(i))
        BRepMesh_IncrementalMesh(
            shape,
            LIN_DEFLECTION if linear is None else linear,
            False,
            ANG_DEFLECTION if angular is None else angular,
            True,
        )

    # WP-237: METRES, as the glTF spec requires. This line used to declare
    # the document's unit as 1.0 m to SUPPRESS Open CASCADE's rescale, so the
    # stored numerals stayed millimetres — the PyInventor-era convention every
    # consumer then grew to assume. It cost Ethan a manual 1000x on every mesh
    # we shipped (GO-PROPOSAL-OPTICS §2.2). The STEP reader has already
    # stamped the file's real unit on the document, so leaving it alone is
    # what makes RWGltf_CafWriter rescale correctly; our readers normalize
    # both conventions (optikit_core.units), which is what lets the corpus
    # migrate one file at a time.

    writer = RWGltf_CafWriter(TCollection_AsciiString(str(glb_path)), True)
    # No axis transformation: input AND output declared Z-up, so the GLB is
    # in the cube frame like PyInventor's exports (see module docstring).
    converter = writer.ChangeCoordinateSystemConverter()
    converter.SetInputCoordinateSystem(RWMesh_CoordinateSystem.RWMesh_CoordinateSystem_Zup)
    converter.SetOutputCoordinateSystem(RWMesh_CoordinateSystem.RWMesh_CoordinateSystem_Zup)
    ok = writer.Perform(doc, TColStd_IndexedDataMapOfStringString(), Message_ProgressRange())
    if not ok or not glb_path.is_file():
        raise StepGlbError("E_GLB_WRITE", "glTF writer failed")

    # WP-237: say the unit out loud. glTF has no unit field, so "metres" is
    # only a convention a reader may or may not follow — and a corpus that
    # mixes the old mm files with these has to tell them apart by measuring.
    # A stamped file is decidable instead of guessable.
    stamp_glb_unit(glb_path)

    if merge:
        # WP-224: OCCT emits ONE glTF primitive per B-rep face, so a machined
        # bracket ships as thousands of draw calls — 11,275 for the galvo
        # board, which is why the assembly view ran at 2-3 fps. Merging by
        # material inside each mesh is exact (one node transform, same
        # triangles) and collapses that to 28.
        from ..library.glb_merge import merge_glb_file

        try:
            merge_glb_file(glb_path)
        except (ValueError, KeyError, struct.error) as exc:
            # A file we cannot merge still CONVERTS. Draw calls are a
            # performance problem; a refused merge leaves a correct, if fat,
            # mesh behind. Raising here turned a working STEP import into a
            # 422 — the optimization failing must never fail the import.
            note = f"primitives not merged ({exc}); the mesh is correct but heavy"
            if warnings is not None:
                warnings.append(note)
            else:
                _log.warning("%s: %s", glb_path.name, note)
