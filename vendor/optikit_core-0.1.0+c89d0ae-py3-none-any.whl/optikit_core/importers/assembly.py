"""A named CAD assembly → carrier + mounted-part records (the FRAME road).

One STEP whose subassembly names the XCAF converter keeps (Fusion and
Inventor both), plus a spec (``assembly.yml``) saying which node becomes
which record and what it mounts on. Every part mesh is re-based Z-up with
its node origin at (0, 0, 0); the root carrier's origin moves to
``origin-mm`` (the optical axis on the layer-0 lattice), so mount poses are
the child origin in the parent's frame — millimetres only. Group members
snap to the 50/50/55 lattice through ``origin-mm``; z stays lattice-absolute
(an OPM whose optics sit on its upper layer keeps them there).
Contract: ``DOCS/editor/frame-assembly-contract.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from ..io.yamlio import _to_plain, dump_document, load_document
from ..library.mesh import (
    IDENTITY,
    _apply,
    _chunks,
    _dequantize,
    _matrix,
    _mm_scale,
    _mul,
    _write_glb,
    glb_extract_subtrees,
)

PITCH_MM = (50.0, 50.0, 55.0)
#: A member this far off its lattice point is reported, not silently snapped.
SNAP_TOLERANCE_MM = 5.0
PRICE_NOTE = "price is a placeholder — fill the real one"


@dataclass
class PartSpec:
    node: str
    template: str
    component: dict[str, str] | None = None
    fits: str = ""
    mount_on: str = ""
    mount: str = ""
    carrier: bool = False
    bays: dict[str, Any] = field(default_factory=dict)
    footprint_grid: list[int] | None = None
    seat_node: str = ""
    #: A stated mount pose ({x, y, z} mm) and/or grid rotation ([z, x]) that
    #: replace the measured ones — for a seat the export shows wrong or not at all.
    mount_offset_mm: dict[str, float] | None = None
    mount_grid: list[str] | None = None
    #: WP-284: extra docking poses on THIS part, for occupants the spec does
    #: not mint a record for (the objective changer's two positions) —
    #: {mount name: {accepts, and either `node` to measure from or
    #: `offset-mm` for a seat this export does not show; optional `grid`
    #: [z, x] = how the occupant is turned}}.
    seats: dict[str, dict[str, Any]] = field(default_factory=dict)
    price: float | None = None
    description: str = ""
    review: list[str] = field(default_factory=list)


@dataclass
class GroupSpec:
    id: str
    nodes: list[str]
    members: dict[str, str]  # node-name prefix → module id
    overhang: list[str] = field(default_factory=list)
    #: Members the export lacks (a layer not yet modelled): key → {module, cell}.
    extra_members: dict[str, dict[str, Any]] = field(default_factory=dict)
    interface: dict[str, dict[str, str]] = field(default_factory=dict)
    #: Plates as the CAD has them (face → {module, origin, size}); joints are
    #: still derived. Empty = plates suggested from the members.
    plates: dict[str, dict[str, Any]] = field(default_factory=dict)
    description: str = ""
    tags: list[str] = field(default_factory=list)
    review: list[str] = field(default_factory=list)


@dataclass
class AssemblySpec:
    source: str
    exported: str
    origin_mm: np.ndarray
    pitch_mm: tuple[float, float, float]
    parts: list[PartSpec]
    groups: list[GroupSpec]


def load_spec(path: Path) -> AssemblySpec:
    raw = _to_plain(load_document(path)) or {}
    parts = [
        PartSpec(
            node=p["node"],
            template=p["template"],
            component=p.get("component"),
            fits=p.get("fits", ""),
            mount_on=p.get("mount-on", ""),
            mount=p.get("mount", ""),
            carrier=bool(p.get("carrier", False)),
            bays=p.get("bays", {}) or {},
            footprint_grid=p.get("footprint-grid"),
            seat_node=p.get("seat-node", ""),
            mount_offset_mm=p.get("mount-offset-mm"),
            mount_grid=p.get("mount-grid"),
            seats=dict(p.get("seats", {}) or {}),
            price=p.get("price"),
            description=p.get("description", ""),
            review=list(p.get("review", []) or []),
        )
        for p in raw.get("parts", []) or []
    ]
    groups = [
        GroupSpec(
            id=g["id"],
            nodes=list(g["nodes"]),
            members=dict(g.get("members", {})),
            overhang=list(g.get("overhang", []) or []),
            extra_members=dict(g.get("extra-members", {}) or {}),
            interface=dict(g.get("interface", {}) or {}),
            plates=dict((g.get("structure") or {}).get("plates") or {}),
            description=g.get("description", ""),
            tags=list(g.get("tags", []) or []),
            review=list(g.get("review", []) or []),
        )
        for g in raw.get("groups", []) or []
    ]
    return AssemblySpec(
        source=str(raw.get("source", "")),
        exported=str(raw.get("exported", "")),
        origin_mm=np.array(raw.get("origin-mm", [0, 0, 0]), dtype=float),
        pitch_mm=tuple(raw.get("pitch-mm", PITCH_MM)),
        parts=parts,
        groups=groups,
    )


# --- the measured tree --------------------------------------------------------------


class AssemblyTree:
    """A GLB's node tree with world matrices (column-major, file units) and boxes in mm."""

    def __init__(self, data: bytes) -> None:
        self.data = data
        self.gltf, self.binary = _chunks(data)
        self.nodes: list[dict[str, Any]] = self.gltf.get("nodes", [])
        self.world: dict[int, list[float]] = {}
        scene = self.gltf["scenes"][self.gltf.get("scene", 0)]
        stack = [(i, IDENTITY) for i in scene.get("nodes", [])]
        while stack:
            i, parent = stack.pop()
            self.world[i] = _mul(parent, _matrix(self.nodes[i]))
            stack.extend((c, self.world[i]) for c in self.nodes[i].get("children", []))
        lo, hi = self._box_units(list(self.world))
        self.scale = _mm_scale(self.gltf, lo, hi)

    def index(self, name: str) -> int:
        hits = [i for i, n in enumerate(self.nodes) if n.get("name") == name]
        if len(hits) == 1:
            return hits[0]
        if not hits:
            stem = name.split(":")[0][:14]
            names = (n.get("name", "") for n in self.nodes)
            near = sorted({n for n in names if n.startswith(stem)})
            raise ValueError(f"no node named {name!r}; nearest: {near[:8]}")
        raise ValueError(f"{len(hits)} nodes named {name!r} — the spec needs an unambiguous name")

    def subtree(self, i: int) -> list[int]:
        out, stack = [], [i]
        while stack:
            j = stack.pop()
            out.append(j)
            stack.extend(self.nodes[j].get("children", []))
        return out

    def _box_units(self, indices: list[int]) -> tuple[list[float], list[float]]:
        lo, hi = [float("inf")] * 3, [float("-inf")] * 3
        meshes, accessors = self.gltf.get("meshes", []), self.gltf.get("accessors", [])
        for j in indices:
            mi = self.nodes[j].get("mesh")
            if mi is None:
                continue
            for prim in meshes[mi]["primitives"]:
                acc = accessors[prim["attributes"]["POSITION"]]
                mn, mx = acc.get("min"), acc.get("max")
                if not mn or not mx:
                    continue
                mn, mx = _dequantize(acc, mn), _dequantize(acc, mx)
                for k in range(8):
                    corner = (mx[0] if k & 1 else mn[0], mx[1] if k & 2 else mn[1],
                              mx[2] if k & 4 else mn[2])
                    for axis, v in enumerate(_apply(self.world[j], corner)):
                        lo[axis], hi[axis] = min(lo[axis], v), max(hi[axis], v)
        if lo[0] == float("inf"):
            lo = hi = [0.0, 0.0, 0.0]
        return lo, hi

    def origin_mm(self, name: str) -> np.ndarray:
        return np.array(self.world[self.index(name)][12:15]) * self.scale

    def bbox_mm(self, name: str) -> tuple[np.ndarray, np.ndarray]:
        lo, hi = self._box_units(self.subtree(self.index(name)))
        return np.array(lo) * self.scale, np.array(hi) * self.scale

    def rebase(self, name: str, origin_mm: np.ndarray) -> bytes:
        """The subtree alone, world-oriented, with ``origin_mm`` at (0, 0, 0)."""
        w = np.array(self.world[self.index(name)]).reshape(4, 4).T
        shift = np.eye(4)
        shift[:3, 3] = -origin_mm / self.scale
        gltf, binary = _chunks(glb_extract_subtrees(self.data, {name}))
        nodes = gltf["nodes"]
        target = next(i for i, n in enumerate(nodes) if n.get("name") == name)
        parent_of = {c: i for i, n in enumerate(nodes) for c in n.get("children", [])}
        # Ancestors survived as transform carriers; the target's world matrix
        # already folds them in, so they become identity and the target takes
        # the whole chain plus the origin shift.
        cur = parent_of.get(target)
        while cur is not None:
            for key in ("translation", "rotation", "scale", "matrix"):
                nodes[cur].pop(key, None)
            cur = parent_of.get(cur)
        for key in ("translation", "rotation", "scale"):
            nodes[target].pop(key, None)
        nodes[target]["matrix"] = [float(v) for v in (shift @ w).T.flatten()]
        return _write_glb(gltf, binary or b"")


# --- records -------------------------------------------------------------------------


def _xyz(v: np.ndarray) -> dict[str, float]:
    return {k: round(float(x), 2) + 0.0 for k, x in zip("xyz", v, strict=True)}


def _mount(offset_mm: dict[str, float], grid: list[str] | None, accepts: str) -> dict[str, Any]:
    """A `mounts:` entry: mm translation, an optional [z, x] grid rotation, the key."""
    pose: dict[str, Any] = {"translation": {"offset-mm": offset_mm}}
    if grid:
        pose["rotation"] = {"kind": "grid", "grid": {"z": grid[0], "x": grid[1]}}
    return {"pose": pose, "accepts": accepts}


def _bump_patch(version: str) -> str:
    major, minor, patch = version.split(".")[:3]
    return f"{major}.{minor}.{int(patch.split('-')[0]) + 1}"


def _load_or_new(path: Path, skeleton: dict[str, Any]) -> dict[str, Any]:
    if path.is_file():
        record = _to_plain(load_document(path)) or {}
        record["version"] = _bump_patch(str(record.get("version", "0.1.0")))
        return record
    return dict(skeleton)


def _measured_note(spec: AssemblySpec) -> str:
    return f"measured from {spec.source} (exported {spec.exported})"


def _review(spec: AssemblySpec, lines: list[str]) -> list[str]:
    # The spec owns these records: hand-written review lines belong in it.
    return [_measured_note(spec), *lines]


def import_assembly(spec: AssemblySpec, glb: bytes, root: Path) -> list[Path]:
    """Write every record the spec names; returns the files written."""
    tree = AssemblyTree(glb)
    by_template = {p.template: p for p in spec.parts}
    origins: dict[str, np.ndarray] = {}
    for part in spec.parts:
        origins[part.template] = (
            spec.origin_mm if not part.mount_on else tree.origin_mm(part.node)
        )

    mounts: dict[str, dict[str, Any]] = {p.template: {} for p in spec.parts}
    for part in spec.parts:
        if not part.mount_on:
            continue
        if part.mount_on not in by_template:
            raise ValueError(f"{part.template}: mount-on {part.mount_on!r} is not in this spec")
        seat = tree.origin_mm(part.seat_node) if part.seat_node else origins[part.template]
        delta = seat - origins[part.mount_on]
        mounts[part.mount_on][part.mount or part.template.rsplit(".", 1)[-1]] = _mount(
            dict(part.mount_offset_mm) if part.mount_offset_mm else _xyz(delta),
            part.mount_grid, part.fits)

    for part in spec.parts:
        for name, seat in part.seats.items():
            if "node" in seat:
                offset = _xyz(tree.origin_mm(seat["node"]) - origins[part.template])
            elif "offset-mm" in seat:
                offset = dict(seat["offset-mm"])
            else:
                raise ValueError(f"{part.template}: seat {name!r} needs a node or an offset-mm")
            mounts[part.template][name] = _mount(offset, seat.get("grid"), seat["accepts"])

    written: list[Path] = []
    for part in spec.parts:
        tpl_dir = root / "templates" / part.template
        tpl_dir.mkdir(parents=True, exist_ok=True)
        (tpl_dir / "model.glb").write_bytes(tree.rebase(part.node, origins[part.template]))
        written.append(tpl_dir / "model.glb")

        lo, hi = tree.bbox_mm(part.node)
        size = hi - lo
        tpl_path = tpl_dir / "template.yml"
        record = _load_or_new(tpl_path, {
            "kind": "mechanical_template", "id": part.template, "version": "0.1.0",
            "class": "fixed", "description": (part.component or {}).get("description", part.node),
            "tags": ["frame"],
        })
        if part.description:
            record["description"] = part.description
        record.update({
            "glb": "model.glb",
            "mesh-frame": "cube",
            "envelope": {"x-mm": round(float(size[0]), 1), "y-mm": round(float(size[1]), 1),
                         "z-mm": round(float(size[2]), 1)},
            "carrier": part.carrier or bool(part.bays) or bool(mounts[part.template]),
        })
        record.pop("mesh-pose", None)
        record["footprint_grid"] = part.footprint_grid if not part.mount_on else None
        if part.bays:
            record["bays"] = part.bays
        if mounts[part.template]:
            record["mounts"] = mounts[part.template]
        else:
            record.pop("mounts", None)
        if part.fits:
            record["fits"] = part.fits
        if part.component:
            record["component"] = f"{part.component['id']}@^0.1"
        record["review"] = _review(spec, part.review)
        tpl_path.write_text(dump_document(record), encoding="utf-8")
        written.append(tpl_path)

        if part.component:
            written.extend(_write_component(root, part, spec))

    for group in spec.groups:
        written.extend(_write_group(root, group, spec, tree))
    return written


def _write_component(root: Path, part: PartSpec, spec: AssemblySpec) -> list[Path]:
    assert part.component is not None
    comp_dir = root / "components" / part.component["id"]
    comp_dir.mkdir(parents=True, exist_ok=True)
    path = comp_dir / "component.yml"
    if path.is_file():
        record = _to_plain(load_document(path)) or {}
        if part.price is not None and (record.get("vendor") or {}).get("price") is None:
            record["version"] = _bump_patch(str(record.get("version", "0.1.0")))
            record.setdefault("vendor", {}).update(
                {"name": "openUC2", "price": part.price, "currency": "EUR"})
            record["review"] = [*record.get("review", []), PRICE_NOTE]
            path.write_text(dump_document(record), encoding="utf-8")
            return [path]
        return []
    record: dict[str, Any] = {
        "kind": "optical_component",
        "id": part.component["id"],
        "version": "0.1.0",
        "category": part.component["category"],
        "description": part.component.get("description", part.node),
        "tags": ["frame", part.component["category"]],
        "review": [_measured_note(spec)],
    }
    if part.price is not None:
        record["vendor"] = {"name": "openUC2", "price": part.price, "currency": "EUR"}
        record["review"].append(PRICE_NOTE)
    path.write_text(dump_document(record), encoding="utf-8")
    return [path]


def _member_nodes(tree: AssemblyTree, group: GroupSpec) -> list[tuple[str, str, int]]:
    """(prefix, module, node index) per matched cube; a match's children are its own parts."""
    out: list[tuple[str, str, int]] = []
    for name in group.nodes:
        stack = [tree.index(name)]
        while stack:
            i = stack.pop()
            node_name = tree.nodes[i].get("name", "")
            hit = next((p for p in group.members if node_name.startswith(p)), None)
            if hit is not None:
                out.append((hit, group.members[hit], i))
                continue
            stack.extend(reversed(tree.nodes[i].get("children", [])))
    return sorted(out, key=lambda t: t[2])


def _ref(module_id: str, library: Any) -> str:
    """``<id>@^<range>`` for the highest shipped version (``@^0.1`` when unknown)."""
    if "@" in module_id:
        return module_id
    versions = [r.record.version for r in library.versions_of(module_id)]
    if not versions:
        return f"{module_id}@^0.1"
    newest = max(versions, key=lambda v: tuple(int(x) for x in v.split(".")[:3]))
    major, minor = newest.split(".")[:2]
    return f"{module_id}@^{major}" if int(major) else f"{module_id}@^{major}.{minor}"


def _write_group(
    root: Path, group: GroupSpec, spec: AssemblySpec, tree: AssemblyTree
) -> list[Path]:
    from ..library import load_library
    from ..library.groups import suggest_structure
    from ..schema.library import GroupRecord

    library = load_library(root)
    pitch = np.array(spec.pitch_mm, dtype=float)
    found = _member_nodes(tree, group)
    if not found:
        raise ValueError(f"{group.id}: no member matched under {group.nodes}")
    cells, notes, overhang = [], [], []
    for _prefix, _module, i in found:
        name = tree.nodes[i].get("name", "")
        rel = (tree.origin_mm(name) - spec.origin_mm) / pitch
        cell = np.rint(rel).astype(int)
        off = np.abs((rel - cell) * pitch)
        if off.max() > SNAP_TOLERANCE_MM:
            notes.append(f"{name!r} sits {off.max():.1f} mm off its cell")
        cells.append(cell)
        overhang.append(any(name.startswith(o) for o in group.overhang))
    # The body (what the plates cover) starts at x = y = 0; overhang may go
    # negative. z is never shifted: layer 0 is the lattice origin.
    body_cells = [c for c, hangs in zip(cells, overhang, strict=True) if not hangs]
    shift = np.min(np.array(body_cells or cells), axis=0)
    shift[2] = 0

    members: dict[str, dict[str, Any]] = {}
    key_of_prefix: dict[str, str] = {}
    counts: dict[str, int] = {}
    for (prefix, module, _i), cell, hangs in zip(found, cells, overhang, strict=True):
        short = module.rsplit(".", 1)[-1]
        counts[short] = counts.get(short, 0) + 1
        key = short if counts[short] == 1 else f"{short}_{counts[short]}"
        key_of_prefix.setdefault(prefix, key)
        entry: dict[str, Any] = {
            "module": _ref(module, library), "cell": [int(v) for v in cell - shift],
        }
        if hangs:
            entry["overhang"] = True
        members[key] = entry
    for key, extra in group.extra_members.items():
        members[key] = {"module": _ref(extra["module"], library), "cell": list(extra["cell"]),
                        **({"overhang": True} if extra.get("overhang") else {})}
    body = [m["cell"] for m in members.values() if not m.get("overhang")]
    envelope = [int(max(c[k] for c in body)) + 1 for k in range(3)] if body else [1, 1, 1]

    grp_dir = root / "groups" / group.id
    grp_dir.mkdir(parents=True, exist_ok=True)
    path = grp_dir / "group.yml"
    record = _load_or_new(path, {
        "kind": "cube_group", "id": group.id, "version": "0.1.0",
        "description": group.description or group.id.rsplit(".", 1)[-1],
        "tags": group.tags or ["opm"],
    })
    if group.description:
        record["description"] = group.description
    if group.tags:
        record["tags"] = group.tags
    record.update({"envelope-grid": envelope, "members": members})
    record["interface"] = {
        name: {"member": key_of_prefix.get(ref["member"], ref["member"]), "port": ref["port"]}
        for name, ref in group.interface.items()
    }
    record["review"] = _review(spec, [*group.review, *notes])
    # Joints follow the measured members; plates too unless the spec carries
    # the CAD's own (an existing plate keeps its module ref).
    suggested = suggest_structure(GroupRecord.model_validate(record), library)
    old_plates = (record.get("structure") or {}).get("plates") or {}
    plates = {
        face: {"module": _ref(p["module"], library), "origin": list(p["origin"]),
               "size": list(p["size"])}
        for face, p in group.plates.items()
    } or {
        face: {
            "module": old_plates.get(face, {}).get("module") or _ref(p["module_hint"], library),
            "origin": p["origin"],
            "size": p["size"],
        }
        for face, p in suggested["plates"].items()
    }
    record["structure"] = {
        "plates": plates,
        "joints": "puzzle",
        "joint-cells": suggested["joint_cells"],
    }
    path.write_text(dump_document(record), encoding="utf-8")
    return [path]
