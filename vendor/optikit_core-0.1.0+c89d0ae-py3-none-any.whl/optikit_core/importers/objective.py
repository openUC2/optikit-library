"""Mint an objective from vendor facts, with optional ``.zmx`` and STEP.

The catalog road for objectives (`DOCS/editor/objectives-from-catalog.md`):
the vendor table gives the FACTS (mag/NA/WD…), a ``.zmx`` — when the vendor
publishes one — gives the real prescription, a STEP gives the barrel as a
housing. Without a zmx the record traces as an ideal thin lens at the stated
EFL and says so; nothing is guessed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..io.yamlio import dump_document
from ..schema.library import ComponentRecord

FACTS_NOTE = "facts from the vendor table — confirm against current vendor data"
STAND_IN_NOTE = (
    "traces as an ideal thin lens at the stated EFL — attach the vendor .zmx "
    "for the real prescription"
)


@dataclass
class ObjectiveFacts:
    """The vendor-table row, typed. ``efl_mm`` = tube_lens_f / magnification."""

    slug: str
    display: str
    manufacturer: str
    magnification: float
    numerical_aperture: float
    efl_mm: float
    working_distance_mm: float | None = None
    tube_lens_f_mm: float = 180.0
    immersion: str = "air"
    thread: str = ""
    parfocal_distance_mm: float | None = None
    field_number_mm: float | None = None
    correction: str = ""
    price_eur: float | None = None
    mpn: str = ""
    docs: list[str] = field(default_factory=list)


def _thin_lens_sidecar(record_id: str, efl_mm: float, semi_aperture_mm: float) -> str:
    """A standalone Optiland file: object at infinity → thin lens → image at EFL.

    The shape `openuc2.objective.paraxial_20x` ships (WP-220a's dialect-legal
    spelling: planar StandardGeometry + ThinLensInteractionModel).
    """
    return f"""\
# GENERATED stand-in for {record_id}: an ideal thin lens at the vendor EFL.
# Replace by re-importing with the vendor .zmx when one exists.
version: 1.0
name: {record_id}
aperture:
  type: EPD
  value: {2 * semi_aperture_mm}
fields:
  fields:
    - {{x: 0.0, y: 0.0, vx: 0.0, vy: 0.0, weight: 1.0}}
  telecentric: false
  field_definition: {{field_type: AngleField}}
wavelengths:
  polarization: ignore
  wavelengths:
    - {{value: 0.532, unit: um, is_primary: true, weight: 1.0}}
apodization:
pickups: []
solves:
  solves: []
surface_group:
  surfaces:
    - type: ObjectSurface
      geometry:
        type: Plane
        cs: {{x: 0.0, y: 0.0, z: -1000000000.0, rx: 0.0, ry: 0.0, rz: 0.0, reference_cs: }}
        radius: .inf
      material_post: {{type: IdealMaterial, index: 1.0, absorb_coeff: 0.0}}
      comment: 'object: at infinity (placeholder — the design decides)'
    - type: Surface
      geometry:
        type: StandardGeometry
        radius: .inf
        conic: 0.0
        cs: {{x: 0.0, y: 0.0, z: 0.0, rx: 0.0, ry: 0.0, rz: 0.0, reference_cs: }}
      interaction_model:
        type: ThinLensInteractionModel
        focal_length: {efl_mm}
        is_reflective: false
        coating:
        bsdf:
      is_stop: true
      semi_aperture: {semi_aperture_mm}
      material_post:
        type: IdealMaterial
        propagation_model: {{class: HomogeneousPropagation}}
        index: 1.0
        absorp: 0.0
      aperture:
    - type: Surface
      thickness: 0.0
      geometry:
        type: Plane
        cs: {{x: 0.0, y: 0.0, z: {efl_mm}, rx: 0.0, ry: 0.0, rz: 0.0, reference_cs: }}
        radius: .inf
      material_post: {{type: IdealMaterial, index: 1.0, absorb_coeff: 0.0}}
      is_stop: false
      aperture:
      comment: "image: at the record's EFL (placeholder)"
      interaction_model: {{type: RefractiveReflectiveModel, is_reflective: false}}
"""


#: Which mesh axis points at the SAMPLE (the record's ``front`` port, cube -z)
#: -> the ``mesh-pose`` grid that turns the file into the cube frame. The
#: openUC2 barrel parts are drawn axis-along-+y, shoulder at the origin.
FRONT_AXIS_GRID: dict[str, dict[str, str] | None] = {
    "-z": None,
    "+z": {"z": "-z", "x": "+x"},
    "+y": {"z": "+y", "x": "+x"},
    "-y": {"z": "-y", "x": "+x"},
    "+x": {"z": "+x", "x": "-z"},
    "-x": {"z": "-x", "x": "+z"},
}


def mint_objective(
    root: Path,
    facts: ObjectiveFacts,
    *,
    namespace: str = "openuc2",
    zmx: Path | None = None,
    step: Path | None = None,
    front_axis: str = "-z",
) -> list[Path]:
    """Write the objective's component (and housing, given a STEP); returns files.

    With ``zmx`` the optics are the vendor prescription (through the existing
    zmx importer); without, the thin-lens stand-in. An existing record is
    overwritten — the vendor table is the source, re-minting is the update.
    """
    record_id = f"{namespace}.objective.{facts.slug}"
    comp_dir = root / "components" / record_id
    comp_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    review = [FACTS_NOTE]
    # 2·f·NA is the infinity-beam pupil the stated NA implies — the optical
    # minimum, not the barrel's mechanical clear aperture.
    semi_aperture = round(facts.efl_mm * facts.numerical_aperture, 3)
    optics: dict[str, Any] = {
        "frames": {"optical": {"z-mm": 0.0, "clear-aperture-mm": 2 * semi_aperture}},
        "ports": {
            "front": {"frame": "optical", "direction": "-z"},
            "back": {"frame": "optical", "direction": "+z", "after-surface": 0},
        },
    }
    if zmx is not None:
        from .thorlabs import zmx_to_component

        result = zmx_to_component(zmx, mpn=facts.mpn or facts.slug,
                                  namespace=namespace, vendor_name=facts.manufacturer)
        optics = result.component.get("optics", optics)
        review += result.review
    else:
        (comp_dir / "optics.optiland.yml").write_text(
            _thin_lens_sidecar(record_id, facts.efl_mm, semi_aperture), encoding="utf-8"
        )
        written.append(comp_dir / "optics.optiland.yml")
        optics["fragment-file"] = "optics.optiland.yml"
        review.append(STAND_IN_NOTE)

    record = {
        "kind": "optical_component",
        "id": record_id,
        "version": "0.1.0",
        "category": "objective",
        "description": (
            f"{facts.display} — {facts.magnification:g}×/{facts.numerical_aperture:g}"
            + (f", WD {facts.working_distance_mm:g} mm" if facts.working_distance_mm else "")
            + (f" ({facts.correction})" if facts.correction else "")
        ),
        "tags": ["objective", f"objective/{facts.immersion}"],
        "docs": facts.docs,
        "vendor": {
            "name": facts.manufacturer,
            "mpn": facts.mpn,
            "url": facts.docs[0] if facts.docs else "",
            **({"price": facts.price_eur, "currency": "EUR"}
               if facts.price_eur is not None else {}),
        },
        "effective_focal_length_mm": facts.efl_mm,
        "objective": {
            "magnification": facts.magnification,
            "numerical_aperture": facts.numerical_aperture,
            "working_distance_mm": facts.working_distance_mm,
            "tube_lens_f_mm": facts.tube_lens_f_mm,
            "immersion": facts.immersion,
            "thread": facts.thread,
            "parfocal_distance_mm": facts.parfocal_distance_mm,
            "field_number_mm": facts.field_number_mm,
            "correction": facts.correction,
        },
        "optics": optics,
        "review": review,
    }
    ComponentRecord.model_validate(record)
    path = comp_dir / "component.yml"
    path.write_text(dump_document(record), encoding="utf-8")
    written.append(path)

    if step is not None:
        written += _mint_housing(root, record_id, facts, step, front_axis=front_axis)
    return written


def _mint_housing(
    root: Path, record_id: str, facts: ObjectiveFacts, step: Path, *, front_axis: str = "-z"
) -> list[Path]:
    """The barrel as a housing template: STEP → GLB, component ref, free placement.

    ``front_axis`` names the mesh axis that points at the sample; anything but
    ``-z`` is said as a ``mesh-pose`` grid rotation, so the GLB stays exactly
    what the CAD exported.
    """
    from ..library.mesh import _mesh_to_cube, glb_bounding_box
    from .step_glb import step_file_to_glb

    if front_axis not in FRONT_AXIS_GRID:
        raise ValueError(
            f"front axis must be one of {sorted(FRONT_AXIS_GRID)}, got {front_axis!r}"
        )
    grid = FRONT_AXIS_GRID[front_axis]
    template_id = record_id.replace(".objective.", ".tpl.objective_")
    tpl_dir = root / "templates" / template_id
    tpl_dir.mkdir(parents=True, exist_ok=True)
    step_file_to_glb(step, tpl_dir / "model.glb")
    box = glb_bounding_box(tpl_dir / "model.glb")
    # The envelope is stated in the CUBE frame, so it follows the mesh-pose.
    to_cube = _mesh_to_cube("", (grid["z"], grid["x"]) if grid else None)
    size = tuple(abs(v) for v in to_cube(box.size))
    record = {
        "kind": "mechanical_template",
        "id": template_id,
        "version": "0.1.0",
        "class": "fixed",
        "description": f"{facts.display} barrel (housing)",
        "tags": ["objective", "housing"],
        "glb": "model.glb",
        "mesh-frame": "cube",
        "envelope": {
            k: round(v, 1) for k, v in zip(("x-mm", "y-mm", "z-mm"), size, strict=True)
        },
        **({"mesh-pose": {"rotation": {"kind": "grid", "grid": grid}}} if grid else {}),
        "footprint_grid": None,
        "fits": "openuc2.frame.objective",
        "component": f"{record_id}@^0.1",
        "review": [
            f"mesh converted from {step.name}"
            + ("" if grid is None else f" — drawn with the sample side along {front_axis},"
               " turned into the cube frame by mesh-pose"),
            "the barrel's mounting datum is the mesh origin — verify against the thread shoulder",
        ],
    }
    path = tpl_dir / "template.yml"
    path.write_text(dump_document(record), encoding="utf-8")
    return [tpl_dir / "model.glb", path]
