"""Ingest openUC2 Inventor GLB exports into library records.

Node names follow the fixed convention in ``DOCS/inventor-naming-contract.md``,
which is enough to derive template + component + module from geometry alone:
``__mm_scale__`` (root scale, honored) · ``ASS``/``SUB`` (assembly roots; a SUB
named ``MASINS`` is the master insert → T2, its absence → T1) · ``PRT``
(printed) · ``BUY - <descr>`` (purchased; for optics ``<descr>`` encodes a
prescription) · ``TP`` (trade parts, ignored).

Datum markers (contract v2) STATE the optics rather than leaving them to be
guessed: ``PLN - <ROLE> - <frame>`` → a frame with origin, rotation and clear
aperture; ``AXIS - <ROLE>`` → port beam direction; ``PT - <name>`` → origin
only. They must be real part occurrences — Inventor work planes/axes/points are
construction geometry that no exporter emits (verified on 2025.3), and body
names do not survive GLB conversion, only occurrence names. Markers are
excluded from the envelope bbox.

A part with no markers still imports (pre-v2 fallback: optical frame at the
``BUY`` origin, ports ``±z``) and is always review-flagged. Nothing is guessed
silently: every undetermined field gets a placeholder, the record's ``review:``
block, and a stderr line.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from ..constants import UC2_GRID_MM

# --- node-name parsing -----------------------------------------------------------------

# "ASS - 2028 - CUBLEND12.7F40 - V04"  /  "SUB - 0032 - MASINSLEND12.7F40 - virt ass"
# "PLN - OPT - optical"  /  "AXIS - OPT"  /  "PT - FOCUS"
# ``PRT``/``PT`` and ``TP``/``PT`` are distinct tokens; ``\b`` keeps them apart.
_PREFIX_RE = re.compile(r"^(ASS|SUB|PRT|BUY|TP|PLN|AXIS|PT)\b")

#: Node kinds that are datum markers rather than mechanics.
MARKER_KINDS = ("PLN", "AXIS", "PT")


def node_kind(name: str) -> str:
    """The convention prefix (ASS/SUB/PRT/BUY/TP/PLN/AXIS/PT) or '' for scale nodes."""
    m = _PREFIX_RE.match(name.strip())
    return m.group(1) if m else ""


def strip_instance(name: str) -> str:
    """Drop a trailing ``:N`` glTF instance suffix."""
    return re.sub(r":\d+$", "", name.strip())


@dataclass
class LensPrescription:
    focal_mm: float | None = None
    diameter_mm: float | None = None
    center_thickness_mm: float | None = None
    edge_thickness_mm: float | None = None
    radius_mm: float | None = None
    shape: str = ""  # pl-cx | bi-cx | pl-cv | bi-cv | cx-cv | meniscus …
    raw: str = ""
    unparsed: list[str] = field(default_factory=list)


_TOKEN_RES = {
    "focal_mm": re.compile(r"^f(-?\d+(?:\.\d+)?)$"),
    "diameter_mm": re.compile(r"^D(-?\d+(?:\.\d+)?)$"),
    "center_thickness_mm": re.compile(r"^sI(-?\d+(?:\.\d+)?)$"),
    "edge_thickness_mm": re.compile(r"^sA(-?\d+(?:\.\d+)?)$"),
    "radius_mm": re.compile(r"^R(-?\d+(?:\.\d+)?)$"),
}
_SHAPE_RE = re.compile(r"^(pl|bi|cx|cv)-(cx|cv|pl)$")


def parse_lens_prescription(descr: str) -> LensPrescription:
    """Parse a ``BUY - Lens - <tokens>`` prescription string.

    Recognized tokens: ``f<focal>``, ``D<diameter>``, ``sI<center-thickness>``,
    ``sA<edge-thickness>``, ``R<radius>``, and a shape like ``pl-cx``. Tokens
    the parser does not recognize are collected in ``unparsed`` for review.
    """
    body = descr.split("-", 1)[1].strip() if "-" in descr else descr
    result = LensPrescription(raw=descr)
    for token in body.split():
        for field_name, pattern in _TOKEN_RES.items():
            if (m := pattern.match(token)) is not None:
                setattr(result, field_name, float(m.group(1)))
                break
        else:
            if _SHAPE_RE.match(token):
                result.shape = token
            else:
                result.unparsed.append(token)
    return result


def _catalog_optics(
    tokens: list[str],
    catalog: Any,
    road: str,
    cache_dir: Path | None,
    review: list[str],
) -> tuple[list[dict[str, Any]], float | None, str, dict[str, Any]] | None:
    """(surfaces, EFL, category, vendor) from the first BUY token that is a catalog SKU.

    Case-insensitive on the SKU; a token that matches nothing stays an
    unparsed token. The row's own record is minted through the catalog
    importer, so the optics are the vendor's, verbatim.
    """
    if catalog is None or not tokens:
        return None
    from ..catalog.importer import CatalogImportError, import_part

    by_sku = {p.sku.lower(): p for p in catalog.parts if p.sku}
    for token in list(tokens):
        row = by_sku.get(token.lower())
        if row is None:
            continue
        try:
            outcome = import_part(
                catalog, row.id, road=road, namespace=row.vendor.lower() or "vendor",
                cache_dir=cache_dir or Path("."),
            )
        except CatalogImportError as exc:
            review.append(f"{token}: catalog row {row.id} could not be imported ({exc})")
            return None
        tokens.remove(token)
        optics = outcome.component.get("optics", {})
        surfaces = list(optics.get("fragment", {}).get("surfaces", []))
        if not surfaces:
            review.append(f"{token}: catalog row {row.id} carries no surfaces")
            return None
        review.append(
            f"optics from catalog row {row.id} ({outcome.road}); the name tokens "
            f"{tokens or 'none'} were not used"
        )
        review.extend(outcome.review)
        vendor = dict(outcome.component.get("vendor") or {"mpn": row.sku})
        return surfaces, outcome.efl_mm, str(outcome.component.get("category", "lens")), vendor
    return None


def _surfaces_for_shape(p: LensPrescription) -> tuple[list[dict[str, Any]], list[str]]:
    """Two Optiland surfaces for the prescription's shape, plus review notes.

    Signs follow the Optiland/optics convention (positive radius = center of
    curvature downstream). Exact orientation is a best guess and always flagged.
    """
    review: list[str] = []
    r = p.radius_mm
    thickness = p.center_thickness_mm or p.edge_thickness_mm or 2.0
    material = {"type": "Material", "name": "N-BK7"}
    review.append("glass is a placeholder (N-BK7) — set from the datasheet")
    if p.center_thickness_mm is None:
        review.append("center thickness unknown — used edge/2mm placeholder")

    def curved(radius: float) -> dict[str, Any]:
        return {
            "type": "standard",
            "geometry": {"type": "StandardGeometry", "radius": radius, "conic": 0.0},
        }

    def plano() -> dict[str, Any]:
        return {"type": "standard", "geometry": {"type": "StandardGeometry", "radius": ".inf"}}

    shape = p.shape
    if r is None:
        review.append("no radius token (R…) — emitting two plano surfaces")
        first, second = plano(), plano()
    elif shape in ("pl-cx", "pl-cv"):
        first = plano()
        second = curved(-r if shape == "pl-cx" else r)
    elif shape in ("cx-pl", "cv-pl"):
        first = curved(r if shape == "cx-pl" else -r)
        second = plano()
    elif shape in ("bi-cx", "bi-cv"):
        sign = 1.0 if shape == "bi-cx" else -1.0
        first = curved(sign * r)
        second = curved(-sign * r)
    else:
        review.append(f"unrecognized lens shape {shape!r} — assumed biconvex")
        first = curved(r)
        second = curved(-r)

    first["material_post"] = material
    first["thickness"] = thickness
    if p.diameter_mm:
        semi = p.diameter_mm / 2.0
        first["semi_aperture"] = semi
        second["semi_aperture"] = semi
    review.append("surface orientation (front/back, radius signs) is a guess — verify the trace")
    return [first, second], review


# --- geometry: world transforms + bbox -------------------------------------------------


def _node_matrix(node: Any) -> np.ndarray:
    """A glTF node's local transform as a 4×4 matrix (column-major → row-major)."""
    if node.matrix:
        return np.array(node.matrix, dtype=float).reshape(4, 4).T
    m = np.eye(4)
    if node.scale:
        m[:3, :3] = np.diag(node.scale)
    if node.rotation:  # quaternion [x, y, z, w]
        x, y, z, w = node.rotation
        rot = np.array([
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ])
        m[:3, :3] = rot @ m[:3, :3]
    if node.translation:
        m[:3, 3] = node.translation
    return m


@dataclass
class SceneNode:
    index: int
    name: str
    kind: str
    world: np.ndarray  # 4×4 in the __mm_scale__ frame (mm)
    has_mesh: bool
    parent: int | None
    bbox_min: np.ndarray | None = None  # world-space mm, if it has a mesh
    bbox_max: np.ndarray | None = None
    #: Mesh AABB in the node's own local space. A tilted marker's world AABB is
    #: inflated by the rotation, so disc diameters are measured from this.
    local_min: np.ndarray | None = None
    local_max: np.ndarray | None = None


def _accessor_bbox(gltf: Any, mesh_index: int) -> tuple[np.ndarray, np.ndarray] | None:
    """Local-space AABB of a mesh from its POSITION accessor min/max."""
    lo = np.array([np.inf, np.inf, np.inf])
    hi = -lo
    found = False
    for prim in gltf.meshes[mesh_index].primitives:
        pos = prim.attributes.POSITION
        if pos is None:
            continue
        acc = gltf.accessors[pos]
        if acc.min is None or acc.max is None:
            continue
        lo = np.minimum(lo, acc.min)
        hi = np.maximum(hi, acc.max)
        found = True
    return (lo, hi) if found else None


def _transform_corners(
    lo: np.ndarray, hi: np.ndarray, world: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    corners = np.array([[x, y, z, 1.0] for x in (lo[0], hi[0])
                        for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
    transformed = (world @ corners.T).T[:, :3]
    return transformed.min(axis=0), transformed.max(axis=0)


def _unit_scale(gltf: Any, nodes: list[SceneNode]) -> float:
    """Millimetres per glTF unit for this file (WP-237).

    The `__mm_scale__` root convention below covers the Inventor exports; this
    covers everything else — our own converter (spec metres, stamped since
    WP-237) and any file a user converted with a spec-following tool.
    """
    from ..units import mm_per_unit

    extras = getattr(getattr(gltf, "asset", None), "extras", None) or {}
    boxed = [n for n in nodes if n.bbox_min is not None and n.bbox_max is not None]
    if not boxed:
        return mm_per_unit({"asset": {"extras": extras}}, 0.0)
    lo = np.min([n.bbox_min for n in boxed], axis=0)
    hi = np.max([n.bbox_max for n in boxed], axis=0)
    return mm_per_unit({"asset": {"extras": extras}}, float(np.max(hi - lo)))


def _walk_scene(gltf: Any) -> list[SceneNode]:
    """Flatten the scene graph with accumulated world transforms (mm frame).

    WP-237: the root transform carries the file's unit, so every world box,
    datum and envelope below is in millimetres whatever the file was written
    in — the alternative is a second opinion about units at each reader.
    """
    nodes = _walk_from(gltf, np.eye(4))
    scale = _unit_scale(gltf, nodes)
    if scale == 1.0:
        return nodes
    return _walk_from(gltf, np.diag([scale, scale, scale, 1.0]))


def _walk_from(gltf: Any, root_world: np.ndarray) -> list[SceneNode]:
    scene = gltf.scenes[gltf.scene or 0]
    out: list[SceneNode] = []

    def visit(idx: int, parent: int | None, parent_world: np.ndarray) -> None:
        node = gltf.nodes[idx]
        world = parent_world @ _node_matrix(node)
        name = strip_instance(node.name or "")
        sn = SceneNode(
            index=idx, name=name, kind=node_kind(name),
            world=world, has_mesh=node.mesh is not None, parent=parent,
        )
        if node.mesh is not None:
            local = _accessor_bbox(gltf, node.mesh)
            if local is not None:
                sn.local_min, sn.local_max = local
                sn.bbox_min, sn.bbox_max = _transform_corners(local[0], local[1], world)
        out.append(sn)
        for child in node.children or []:
            visit(child, idx, world)

    for root in scene.nodes or []:
        visit(root, None, root_world)
    return out


# --- template class + envelope ---------------------------------------------------------


def _is_master_insert(name: str) -> bool:
    return "MASINS" in name.upper()


def _grid_envelope(
    nodes: list[SceneNode],
) -> tuple[tuple[float, float, float], tuple[int, int, int], list[str]]:
    """Envelope (mm) and integer grid footprint from the mesh AABB.

    Datum markers are excluded: they are annotation, and a marker placed at the
    focal point would otherwise stretch the envelope well past the mechanics.
    """
    review: list[str] = []
    boxes = [
        (n.bbox_min, n.bbox_max)
        for n in nodes
        if n.bbox_min is not None and n.kind not in MARKER_KINDS
    ]
    if not boxes:
        review.append("no mesh geometry — envelope defaulted to 1 grid cell")
        return (UC2_GRID_MM[0], UC2_GRID_MM[1], UC2_GRID_MM[2]), (1, 1, 1), review
    lo = np.min([b[0] for b in boxes], axis=0)
    hi = np.max([b[1] for b in boxes], axis=0)
    extent = np.abs(hi - lo)
    grid = tuple(max(1, round(extent[i] / UC2_GRID_MM[i])) for i in range(3))
    envelope = tuple(float(grid[i] * UC2_GRID_MM[i]) for i in range(3))
    return envelope, grid, review  # type: ignore[return-value]


# --- datum markers ---------------------------------------------------------------------

#: Beam directions a port may declare, and their unit vectors.
_AXIS_DIRS = {
    "+x": np.array([1.0, 0.0, 0.0]), "-x": np.array([-1.0, 0.0, 0.0]),
    "+y": np.array([0.0, 1.0, 0.0]), "-y": np.array([0.0, -1.0, 0.0]),
    "+z": np.array([0.0, 0.0, 1.0]), "-z": np.array([0.0, 0.0, -1.0]),
}

#: An AXIS marker further than this from the axis it snapped to is flagged.
AXIS_SNAP_WARN_DEG = 1.0
#: Beyond this it is an error — it exceeds the compiler's own ANGLE_TOL_DEG.
AXIS_SNAP_MAX_DEG = 20.0


@dataclass
class Marker:
    """A parsed datum-marker occurrence, in the ASS root's frame."""

    kind: str  # PLN | AXIS | PT
    role: str  # SRC | SNS | OPT | …
    name: str  # frame key it maps to
    origin_mm: np.ndarray
    rotation: np.ndarray  # 3×3, component-local
    aperture_mm: float | None = None


def parse_marker_name(name: str) -> tuple[str, str, str] | None:
    """Split a marker node name into ``(kind, role, frame-key)``.

    ``PLN - OPT - optical`` → ``("PLN", "OPT", "optical")``;
    ``AXIS - OPT`` → ``("AXIS", "OPT", "")``; ``PT - FOCUS`` → ``("PT", "", "focus")``.
    Returns None for a name that is not a marker.
    """
    kind = node_kind(name)
    if kind not in MARKER_KINDS:
        return None
    parts = [p.strip() for p in name.split("-")]
    if kind == "PLN":
        # PLN - <ROLE> - <frame>; the frame key may itself contain dashes.
        if len(parts) < 3:
            return None
        return ("PLN", parts[1], "-".join(parts[2:]).strip().lower())
    if kind == "AXIS":
        return ("AXIS", parts[1] if len(parts) > 1 else "", "")
    return ("PT", "", "-".join(parts[1:]).strip().lower())


def _matrix_to_quat(r: np.ndarray) -> list[float]:
    """A 3×3 rotation as an ``[x, y, z, w]`` quaternion (glTF/schema order)."""
    m = r / np.array([np.linalg.norm(r[:, i]) or 1.0 for i in range(3)])  # drop scale
    t = float(np.trace(m))
    if t > 0.0:
        s = math.sqrt(t + 1.0) * 2.0
        w = 0.25 * s
        x, y, z = (m[2, 1] - m[1, 2]) / s, (m[0, 2] - m[2, 0]) / s, (m[1, 0] - m[0, 1]) / s
    elif m[0, 0] > m[1, 1] and m[0, 0] > m[2, 2]:
        s = math.sqrt(1.0 + m[0, 0] - m[1, 1] - m[2, 2]) * 2.0
        w, x = (m[2, 1] - m[1, 2]) / s, 0.25 * s
        y, z = (m[0, 1] + m[1, 0]) / s, (m[0, 2] + m[2, 0]) / s
    elif m[1, 1] > m[2, 2]:
        s = math.sqrt(1.0 + m[1, 1] - m[0, 0] - m[2, 2]) * 2.0
        w, y = (m[0, 2] - m[2, 0]) / s, 0.25 * s
        x, z = (m[0, 1] + m[1, 0]) / s, (m[1, 2] + m[2, 1]) / s
    else:
        s = math.sqrt(1.0 + m[2, 2] - m[0, 0] - m[1, 1]) * 2.0
        w, z = (m[1, 0] - m[0, 1]) / s, 0.25 * s
        x, y = (m[0, 2] + m[2, 0]) / s, (m[1, 2] + m[2, 1]) / s
    return [round(float(v), 6) for v in (x, y, z, w)]


def _is_identity(quat: list[float], tol: float = 1e-4) -> bool:
    return abs(abs(quat[3]) - 1.0) < tol


def _disc_diameter_mm(node: SceneNode) -> float | None:
    """A marker disc's diameter: its largest extent, measured in local space."""
    if node.local_min is None or node.local_max is None:
        return None
    scale = np.array([np.linalg.norm(node.world[:3, i]) for i in range(3)])
    extents = np.abs(node.local_max - node.local_min) * scale
    largest = float(np.max(extents))
    return largest if largest > 0.0 else None


def snap_direction(vec: np.ndarray) -> tuple[str, float]:
    """Nearest axis literal to ``vec``, and the angle (deg) discarded by snapping."""
    unit = vec / (np.linalg.norm(vec) or 1.0)
    best, best_dot = "+z", -2.0
    for label, axis in _AXIS_DIRS.items():
        dot = float(np.dot(unit, axis))
        if dot > best_dot:
            best, best_dot = label, dot
    return best, math.degrees(math.acos(min(1.0, max(-1.0, best_dot))))


def collect_markers(
    nodes: list[SceneNode], ass: SceneNode | None
) -> tuple[list[Marker], list[str]]:
    """Parse every datum-marker node into the ASS root's local frame."""
    review: list[str] = []
    markers: list[Marker] = []
    inv_ass = np.linalg.inv(ass.world) if ass is not None else np.eye(4)

    for n in nodes:
        parsed = parse_marker_name(n.name)
        if parsed is None:
            continue
        kind, role, key = parsed
        if kind == "PLN" and not key:
            review.append(f"marker {n.name!r} is malformed — expected 'PLN - <ROLE> - <frame>'")
            continue
        local = inv_ass @ n.world
        m = Marker(
            kind=kind, role=role, name=key,
            origin_mm=local[:3, 3].copy(), rotation=local[:3, :3].copy(),
        )
        if kind == "PLN":
            m.aperture_mm = _disc_diameter_mm(n)
            if m.aperture_mm is None:
                review.append(
                    f"marker {n.name!r} has no mesh — clear aperture unknown, add the disc")
        markers.append(m)
    return markers, review


# --- record assembly -------------------------------------------------------------------


@dataclass
class ImportResult:
    component: dict[str, Any]
    template: dict[str, Any]
    module: dict[str, Any]
    review: list[str]
    #: Envelope extents (mm) for the fallback thumbnail.
    envelope_mm: tuple[float, float, float] = (50.0, 50.0, 55.0)
    thumbnail_written: bool = False


def bbox_thumbnail_svg(envelope_mm: tuple[float, float, float], label: str) -> str:
    """Isometric wireframe of the envelope box — the scene-bbox fallback
    thumbnail (no renderer available in the base install)."""
    ex, ey, ez = envelope_mm
    scale = 90.0 / max(ex, ey, ez)
    ux, uy = 0.87 * scale, 0.5 * scale  # isometric x axis (screen)
    vx, vy = -0.87 * scale, 0.5 * scale  # isometric y axis
    wy = -1.0 * scale  # isometric z axis (up)
    cx, cy = 128.0, 150.0

    def proj(x: float, y: float, z: float) -> tuple[float, float]:
        return cx + x * ux + y * vx, cy + x * uy + y * vy + z * wy

    corners = {
        (i, j, k): proj(i * ex, j * ey, k * ez)
        for i in (0, 1) for j in (0, 1) for k in (0, 1)
    }
    edges = [
        ((0, 0, 0), (1, 0, 0)), ((1, 0, 0), (1, 1, 0)), ((1, 1, 0), (0, 1, 0)),
        ((0, 1, 0), (0, 0, 0)), ((0, 0, 1), (1, 0, 1)), ((1, 0, 1), (1, 1, 1)),
        ((1, 1, 1), (0, 1, 1)), ((0, 1, 1), (0, 0, 1)), ((0, 0, 0), (0, 0, 1)),
        ((1, 0, 0), (1, 0, 1)), ((1, 1, 0), (1, 1, 1)), ((0, 1, 0), (0, 1, 1)),
    ]
    lines = "".join(
        f'<line x1="{corners[a][0]:.1f}" y1="{corners[a][1]:.1f}" '
        f'x2="{corners[b][0]:.1f}" y2="{corners[b][1]:.1f}" '
        f'stroke="#4aa3ff" stroke-width="1.5"/>'
        for a, b in edges
    )
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" '
        'viewBox="0 0 256 256">'
        '<rect width="256" height="256" fill="#171c24"/>'
        f"{lines}"
        f'<text x="128" y="240" fill="#8f9aa6" font-family="sans-serif" '
        f'font-size="12" text-anchor="middle">{label}</text>'
        "</svg>"
    )


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")


def _frames_and_ports(
    markers: list[Marker], fallback_z_mm: float, n_surfaces: int
) -> tuple[dict[str, Any], dict[str, Any], list[str]]:
    """Datum frames and ports from markers, falling back to the BUY node origin.

    The fallback reproduces the pre-v2 guess (optical frame at the BUY origin,
    beam along ±z) and is always flagged — markers are how a part stops guessing.
    """
    review: list[str] = []
    frames: dict[str, Any] = {}

    for m in (x for x in markers if x.kind in ("PLN", "PT")):
        frame: dict[str, Any] = {
            "x-mm": round(float(m.origin_mm[0]), 3),
            "y-mm": round(float(m.origin_mm[1]), 3),
            "z-mm": round(float(m.origin_mm[2]), 3),
        }
        if m.kind == "PLN":
            quat = _matrix_to_quat(m.rotation)
            if not _is_identity(quat):
                frame["rotation"] = quat
            if m.aperture_mm is not None:
                frame["clear-aperture-mm"] = round(m.aperture_mm, 3)
        if m.name in frames:
            review.append(f"duplicate datum frame {m.name!r} — kept the first")
            continue
        frames[m.name] = frame

    # --- beam direction: an AXIS marker, else the ±z assumption ----------------------
    axis = next((m for m in markers if m.kind == "AXIS"), None)
    if axis is not None:
        forward, err_deg = snap_direction(axis.rotation @ np.array([0.0, 0.0, 1.0]))
        if err_deg > AXIS_SNAP_MAX_DEG:
            review.append(
                f"AXIS marker is {err_deg:.1f}° from {forward} — beyond the "
                f"{AXIS_SNAP_MAX_DEG:.0f}° limit; the optical axis is not cube-aligned, "
                "fix the model")
        elif err_deg > AXIS_SNAP_WARN_DEG:
            review.append(
                f"AXIS marker is {err_deg:.1f}° off {forward} — snapped; the residual tilt is "
                "carried by the frame rotation, verify the trace")
    else:
        forward = "+z"
        review.append("no AXIS marker — beam direction assumed +z; add 'AXIS - OPT'")

    backward = ("-" if forward.startswith("+") else "+") + forward[1]

    # --- pick the frame the ports hang off -------------------------------------------
    optical_frame = next(
        (m.name for m in markers if m.kind == "PLN" and m.role.upper() == "OPT"),
        next((m.name for m in markers if m.kind == "PLN"), ""),
    )
    if not optical_frame:
        optical_frame = "optical"
        frames.setdefault(optical_frame, {"z-mm": round(fallback_z_mm, 3)})
        review.append(
            "no PLN datum marker — optical frame fell back to the BUY node origin; "
            "add 'PLN - OPT - optical' to state it")

    ports = {
        "front": {"frame": optical_frame, "direction": backward},
        "back": {"frame": optical_frame, "direction": forward,
                 "after-surface": max(0, n_surfaces - 1)},
    }
    return frames, ports, review


def glb_to_records(
    gltf: Any,
    assembly_name: str,
    namespace: str = "openuc2",
    *,
    catalog: Any = None,
    catalog_road: str = "auto",
    cache_dir: Path | None = None,
) -> ImportResult:
    """Build component/template/module record dicts from a parsed GLB scene.

    With a catalog ``Snapshot``, a BUY token that is a vendor part number
    (``BUY - Lens - f50 D25.4 LA1131-A``) makes the optics the VENDOR's — the
    row's zmx when it names one, else derived from its table — and the name
    tokens become a cross-check rather than the source.
    """
    nodes = _walk_scene(gltf)
    comp_review: list[str] = []
    tpl_review: list[str] = []

    if not any(n.name == "__mm_scale__" for n in nodes):
        # WP-237: no longer a silent 1000x. `_walk_scene` normalizes from the
        # file's own stamp (or its size) before anything here reads a number,
        # so this is now a provenance note rather than a warning about wrong
        # values.
        tpl_review.append(
            "no __mm_scale__ root — not an Inventor export; the scene's unit came "
            "from its glTF stamp or its measured size (WP-237). Check the declared "
            "envelope below against the real part before publishing.")

    ass = next((n for n in nodes if n.kind == "ASS"), None)
    ass_name = ass.name if ass else assembly_name
    base_slug = _slug(re.sub(r"^ASS\s*-\s*\d+\s*-\s*", "", ass_name).split(" - ")[0]) or "part"

    master = next((n for n in nodes if n.kind == "SUB" and _is_master_insert(n.name)), None)
    template_class = "adaptive" if master else "fixed"

    envelope, grid, env_review = _grid_envelope(nodes)
    tpl_review += env_review

    buy_optics = [
        n for n in nodes
        if n.kind == "BUY" and re.search(r"\b(Lens|Mirror|Filter|Window|Prism)\b", n.name)
    ]

    # --- optical component -----------------------------------------------------------
    category = "lens"
    surfaces: list[dict[str, Any]]
    efl: float | None = None
    vendor: dict[str, Any] = {}
    optical_z_mm = 0.0
    if not buy_optics:
        comp_review.append("no BUY optic node found — component is a bare stub")
        category = "other"
        surfaces = [
            {"type": "standard", "geometry": {"type": "StandardGeometry", "radius": ".inf"}}
        ]
    else:
        buy = buy_optics[0]
        if len(buy_optics) > 1:
            comp_review.append(f"multiple BUY optics; used {buy.name!r}, review the rest")
        descr = re.sub(r"^BUY\s*-\s*", "", buy.name)
        if descr.lower().startswith("mirror"):
            category = "mirror"
            surfaces = [{
                "type": "standard",
                "geometry": {"type": "StandardGeometry", "radius": ".inf"},
                "interaction_model": {"type": "refractive_reflective", "is_reflective": True},
            }]
            comp_review.append("mirror surface parsed from bbox only — set reflectivity/coating")
        else:
            presc = parse_lens_prescription(descr)
            catalog_optics = _catalog_optics(
                presc.unparsed, catalog, catalog_road, cache_dir, comp_review)
            if catalog_optics is not None:
                surfaces, efl, category, vendor = catalog_optics
            else:
                efl = presc.focal_mm
                surfaces, shape_review = _surfaces_for_shape(presc)
                comp_review += shape_review
                if presc.unparsed:
                    comp_review.append(f"unparsed prescription tokens: {presc.unparsed}")
        # optical frame at the BUY part's origin along the cube z axis:
        if buy.bbox_min is not None and ass is not None:
            optical_z_mm = float((buy.world @ np.array([0, 0, 0, 1.0]))[2]
                                 - (ass.world @ np.array([0, 0, 0, 1.0]))[2])

    # --- datum frames + ports --------------------------------------------------------
    markers, marker_review = collect_markers(nodes, ass)
    comp_review += marker_review
    frames, ports, port_review = _frames_and_ports(markers, optical_z_mm, len(surfaces))
    comp_review += port_review

    component_id = f"{namespace}.{category}.{base_slug}"
    component: dict[str, Any] = {
        "kind": "optical_component",
        "id": component_id,
        "version": "0.1.0",
        "category": category,
        "description": f"Imported from {ass_name}",
        "optics": {
            "fragment": {"surfaces": surfaces},
            "frames": frames,
            "ports": ports,
        },
        "review": comp_review,
    }
    if efl is not None:
        component["effective_focal_length_mm"] = efl
    if vendor:
        component["vendor"] = vendor

    # --- mechanical template ---------------------------------------------------------
    template_id = f"{namespace}.tpl.{base_slug}"
    template: dict[str, Any] = {
        "kind": "mechanical_template",
        "id": template_id,
        "version": "0.1.0",
        "class": template_class,
        "description": f"Insert template from {ass_name}",
        "envelope": {"x-mm": envelope[0], "y-mm": envelope[1], "z-mm": envelope[2]},
        "glb": Path(assembly_name).name,
        "footprint_grid": list(grid),
        "optical_ports": {
            "front": {"frame": "optical", "direction": "-z"},
            "back": {"frame": "optical", "direction": "+z"},
        },
        "review": tpl_review,
    }
    # The marker-derived frames also become the template's declared insert
    # frames — what `library verify-t1` checks the bound component's datums
    # against (WP-35). Only real markers count; a fallback frame does not.
    marker_frame_keys = {m.name for m in markers if m.kind in ("PLN", "PT")}
    template_frames = {k: frames[k] for k in marker_frame_keys if k in frames}
    if template_frames:
        template["frames"] = template_frames
    if template_class == "adaptive":
        template["dof"] = [{
            "name": "dz", "kind": "translation", "axis": "z",
            "range": None, "unit": "mm", "actuatable": False,
        }]
        tpl_review.append(
            f"MASINS insert '{master.name}' → T2, but DOF range is unknown — set range")

    # --- cube module -----------------------------------------------------------------
    module: dict[str, Any] = {
        "kind": "cube_module",
        "id": f"{namespace}.cube.{base_slug}",
        "version": "0.1.0",
        "description": f"Imported cube: {ass_name}",
        "component": f"{component_id}@^0.1",
        "template": f"{template_id}@^0.1",
        "footprint_grid": list(grid),
    }

    return ImportResult(
        component, template, module, comp_review + tpl_review,
        envelope_mm=envelope,
    )
