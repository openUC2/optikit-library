"""A1c: pin the discovered path set, so drift is a diff rather than a surprise.

part2r §0.2/§0.6. Discovery (:mod:`.discover`) answers what beams exist right
now; a pin freezes that answer and the next trace is compared against it.

**The key is `(variant, path, band)`, not the path name.** Both extra terms are
load-bearing: **variant**, because a filter-cube swap or another DOF value is
the same design in a different state (``VariantSpec`` + ``instantiation
.variant``) — keying by name alone lets a two-cube instrument pin only one
state, and the golden snapshots then silently cover the default; and **band**,
because the same path through the same variant is a different chain at 488 nm
and 520 nm, which is the entire point of a dichroic.

**A pin stores topology, never geometry** — the ordered ``(component, fragment
index, kind, action)`` list and the terminals, nothing positional. Poses are
re-derived on every trace, so a frozen sequence survives a DOF change, a
re-cubify, or a nudge that moves every part 5 mm: none change WHICH surfaces
the light meets, and a pin that tripped on them would cry wolf until ignored.

First trace auto-accepts the set (§0.2, "a human blesses the set"); re-pinning
is per path whose topology actually changed.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any

from ..schema.design import DesignDecl
from .discover import Discovery

#: Document format tag, so a pin file is self-describing like `.ocanvas` is.
PIN_FORMAT = "optikit-sequence-pin"
PIN_VERSION = 1


def band_of(lambda_um: float) -> str:
    """The band key of a traced wavelength: nanometres to 0.1 nm.

    A *key*, not a measurement — it exists to be compared for equality and to
    read sensibly in a diff ("488.0nm"). Fixed precision because a float
    formatted at full precision is a key that changes when the sixteenth digit
    does.
    """
    return f"{float(lambda_um) * 1000.0:.1f}nm"


@dataclass(frozen=True, order=True)
class PinKey:
    """`(variant, path, band)` — the identity of one pinned sequence."""

    #: `""` is the base design, not a missing value: a design with no variants
    #: has exactly one state and it is spelled this way.
    variant: str
    path: str
    band: str

    def __str__(self) -> str:
        return f"{self.variant}/{self.path}@{self.band}"

    @staticmethod
    def parse(text: str) -> PinKey:
        variant, _, rest = text.partition("/")
        path, _, band = rest.rpartition("@")
        return PinKey(variant=variant, path=path, band=band)


@dataclass(frozen=True)
class PinnedHop:
    """One frozen interaction, in document identity.

    `kind` and `action` are both here on purpose: a beamsplitter surface is the
    same object whether the light reflected or transmitted through it, so the
    object alone does not identify what happened at it.
    """

    component: str
    fragment_index: int
    kind: str
    action: str


@dataclass(frozen=True)
class PinnedPath:
    """The frozen topology of one beam."""

    source: tuple[str, str]
    detector: tuple[str, str]
    hops: list[PinnedHop]

    def same_topology(self, other: PinnedPath) -> bool:
        return (self.source == other.source
                and self.detector == other.detector
                and self.hops == other.hops)


@dataclass
class SequencePin:
    """Every pinned path of one design, keyed by :class:`PinKey`."""

    design: str = ""
    paths: dict[PinKey, PinnedPath] = field(default_factory=dict)

    # -- serialization ------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Deterministic, key-sorted, ready to write beside the design."""
        return {
            "format": PIN_FORMAT,
            "version": PIN_VERSION,
            "design": self.design,
            "paths": {
                str(key): asdict(self.paths[key]) for key in sorted(self.paths)
            },
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=False)

    @staticmethod
    def from_dict(raw: dict[str, Any]) -> SequencePin:
        if raw.get("format") != PIN_FORMAT:
            raise ValueError(f"not a {PIN_FORMAT} document: {raw.get('format')!r}")
        if raw.get("version") != PIN_VERSION:
            raise ValueError(f"unsupported pin version {raw.get('version')!r}")
        paths: dict[PinKey, PinnedPath] = {}
        for text, body in (raw.get("paths") or {}).items():
            paths[PinKey.parse(text)] = PinnedPath(
                source=tuple(body["source"]),  # type: ignore[arg-type]
                detector=tuple(body["detector"]),  # type: ignore[arg-type]
                hops=[PinnedHop(**hop) for hop in body["hops"]],
            )
        return SequencePin(design=raw.get("design", ""), paths=paths)

    @staticmethod
    def from_json(text: str) -> SequencePin:
        return SequencePin.from_dict(json.loads(text))


def pin_from(discovery: Discovery, decl: DesignDecl) -> SequencePin:
    """Freeze a discovery pass — the "first trace auto-accepts the set" move."""
    variant = decl.instantiation.variant
    pin = SequencePin(design=decl.design.name)
    for path in discovery.found:
        key = PinKey(variant=variant, path=path.name,
                     band=band_of(path.sequence.lambda_um))
        pin.paths[key] = PinnedPath(
            source=path.source,
            detector=path.detector,
            hops=[PinnedHop(component=h.component, fragment_index=h.fragment_index,
                            kind=h.kind, action=h.action)
                  for h in path.sequence.hits],
        )
    return pin


# ---------------------------------------------------------------------------
# Diffing a fresh trace against the pin
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class PinDrift:
    """A pinned path whose topology moved."""

    key: PinKey
    pinned: PinnedPath
    traced: PinnedPath

    def summary(self) -> str:
        was = " → ".join(h.component for h in self.pinned.hops) or "(nothing)"
        now = " → ".join(h.component for h in self.traced.hops) or "(nothing)"
        return f"{self.key}: {was}  ⇒  {now}"


@dataclass
class PinDiff:
    """How a fresh trace compares to the pin."""

    #: Pinned and traced, identical topology.
    held: list[PinKey] = field(default_factory=list)
    #: Pinned and traced, but the light now meets something else. **These are
    #: the ones a human re-blesses** (§0.2: re-pinning is per path).
    drifted: list[PinDrift] = field(default_factory=list)
    #: Traced, not pinned — a beam that appeared. Not an error: adding a
    #: detector legitimately adds paths.
    appeared: list[PinKey] = field(default_factory=list)
    #: Pinned, not traced — a beam that stopped existing. Usually the
    #: interesting one: something that used to reach the sensor no longer does.
    vanished: list[PinKey] = field(default_factory=list)

    @property
    def held_fast(self) -> bool:
        """True when the design's optical topology is exactly what was blessed."""
        return not (self.drifted or self.appeared or self.vanished)


def diff_pin(pin: SequencePin, discovery: Discovery, decl: DesignDecl) -> PinDiff:
    """Compare a fresh discovery pass against a pin.

    Note what is NOT compared: positions, path lengths, OPL, angles. A pin is a
    statement about topology, and a design whose parts all moved 5 mm has the
    same topology. Numeric drift is the analysis lane's business.
    """
    fresh = pin_from(discovery, decl)
    diff = PinDiff()
    for key in sorted(pin.paths):
        pinned = pin.paths[key]
        traced = fresh.paths.get(key)
        if traced is None:
            diff.vanished.append(key)
        elif pinned.same_topology(traced):
            diff.held.append(key)
        else:
            diff.drifted.append(PinDrift(key=key, pinned=pinned, traced=traced))
    diff.appeared.extend(sorted(set(fresh.paths) - set(pin.paths)))
    return diff


def repin(pin: SequencePin, diff: PinDiff, discovery: Discovery,
          decl: DesignDecl) -> SequencePin:
    """Accept the drifted and appeared paths, keeping everything else.

    §0.2's "re-blesses any path whose topology changed": accepting one path's
    new shape must not silently re-bless the others, and a vanished path stays
    in the pin until someone says otherwise — dropping it on the caller's
    behalf would erase the evidence that it used to work.
    """
    fresh = pin_from(discovery, decl)
    updated = SequencePin(design=pin.design or fresh.design, paths=dict(pin.paths))
    for drift in diff.drifted:
        updated.paths[drift.key] = drift.traced
    for key in diff.appeared:
        updated.paths[key] = fresh.paths[key]
    return updated
