"""Fragment dialect v0 — the sole reader of Optiland surface dicts.

Locked decision 3 of SPEC-OPTIKIT-CORE-CANVAS-INTEGRATION: this module is the
only code in optikit-core that interprets the *contents* of an Optiland surface
fragment beyond its count and order. It accepts exactly the surface content of
spec section 8 and rejects everything else with the typed diagnostics of
section 15, naming the offending key path. ``compile/compiler.py`` keeps its
verbatim pass-through (it reads only ``thickness``); no third reader may appear.

The dialect resolves geometry and structure only. It extracts a glass *name* but
does not resolve it to Sellmeier coefficients — that is ``materials.py`` (KIT-01).
Findings are inert until the materializer (KIT-02+) consumes a parsed fragment;
``library validate`` surfaces them as informational findings today.

The measured production dialect (whole library at ``d311ada``) is surfaces of
revolution — plane / sphere / conic — with per-surface thickness, clear
semi-aperture, a stop flag, and a post-surface glass. ``material_post`` is
written as ``{type: Material, name: <glass>}`` in every record, so the dialect
accepts that form as well as a bare name string.

Dialect v1 adds Optiland's ``EvenAsphere`` (radius, conic, even polynomial
terms). The kernel's polynomial has eight terms starting at r⁴, so an r² term
or one beyond r¹⁸ is refused, never dropped; ``tol``/``max_iter`` are
Optiland's solver knobs, not geometry, and are accepted and ignored.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Literal

from ..schema.checks import Finding
from ..schema.common import is_expr

#: Dialect version, recorded in the scene manifest. A numbered revision lands
#: only after a kernel-parity test exists for the new content (spec section 8).
FRAGMENT_DIALECT = 1

# Whitelists — anything outside these is E_FRAG_UNSUPPORTED with the key path.
_SURFACE_KEYS = frozenset(
    {"type", "geometry", "interaction_model", "thickness", "semi_aperture",
     "is_stop", "material_post", "response", "aperture"}
)
_GEOMETRY_KEYS = frozenset({"type", "radius", "conic"})
_ASPHERE_KEYS = _GEOMETRY_KEYS | {"coefficients", "tol", "max_iter"}
#: Even-asphere terms the kernel traces: r⁴ … r¹⁸.
KERNEL_ASPHERE_TERMS = 8
_INTERACTION_KEYS = frozenset({"type", "is_reflective", "focal_length"})
_MATERIAL_KEYS = frozenset({"type", "name"})
_APERTURE_KEYS = frozenset({"type", "x_min", "x_max", "y_min", "y_max"})


@dataclass(frozen=True)
class SagModel:
    """Sag profile of a surface of revolution, in the kernel's own vocabulary.

    ``plane`` maps to ``SagModel::Plane``; ``conic`` to ``SagModel::Conic``
    (a sphere when ``conic`` is 0); ``asphere`` to ``SagModel::EvenAsphere``
    with ``coefficients`` in the kernel's order — eight terms, r⁴ first.
    """

    kind: Literal["plane", "conic", "asphere"]
    curvature_per_mm: float = 0.0
    conic: float = 0.0
    coefficients: tuple[float, ...] = ()


@dataclass(frozen=True)
class RectAperture:
    """Optiland ``RectangularAperture`` resolved to centered half-extents (mm).

    Only carried for PLANE reflective surfaces, where it becomes the mirror's
    ``PlanarShape2::Rectangle``; every other bearer keeps its revolved profile
    and the block degrades with ``W_APERTURE_UNUSED``.
    """

    half_width_mm: float
    half_height_mm: float


@dataclass(frozen=True)
class DialectSurface:
    """One dialect-v0 surface, resolved to kernel-facing values.

    ``material_post`` is the glass *name* exactly as authored (or ``None`` when
    absent); resolution to coefficients and the ``air`` → ambient rule belong to
    ``materials.py``. ``thickness`` is the on-axis spacing to the next surface.
    """

    index: int
    sag: SagModel
    is_reflective: bool
    thickness: float
    semi_aperture: float | None
    is_stop: bool
    material_post: str | None
    #: WP-74 spectral/polarization response block, validated by the same
    #: ``schema.response.SurfaceResponse`` model the chain inferencer uses
    #: (one validator, not a divergent second reading). ``None`` when absent.
    response: Any = None
    #: WP-75 paraxial black box: ``interaction_model: {type: thin_lens,
    #: focal_length}`` → the kernel's ideal-lens surface. ``None`` for the
    #: ordinary refractive/reflective model.
    thin_lens_f: float | None = None
    #: Optiland ``aperture`` block on a plane mirror → the mirror's rectangular
    #: extent (WP-43 migrated records author it; the 1" square mirror). ``None``
    #: when absent or degraded.
    aperture: RectAperture | None = None


@dataclass
class DialectFragment:
    """A parsed fragment: the clean surfaces plus every finding raised.

    ``surfaces`` holds only surfaces that parsed without an error, so a
    materializer that gates on :pyattr:`ok` never sees partial content. Findings
    are exhaustive: parsing continues past the first bad surface.
    """

    surfaces: list[DialectSurface] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not any(f.severity == "error" for f in self.findings)


def parse_fragment(surfaces: list[dict[str, Any]], where: str) -> DialectFragment:
    """Parse a verbatim Optiland surface list against dialect v0.

    ``where`` is the dotted document location of the surface list, e.g.
    ``components.objective.optics.fragment.surfaces``; it prefixes every finding.
    """
    frag = DialectFragment()
    stop_indices: list[int] = []
    for i, raw in enumerate(surfaces):
        w = f"{where}[{i}]"
        if not isinstance(raw, dict):
            frag.findings.append(
                _unsupported(w, f"surface must be a mapping, got {type(raw).__name__}")
            )
            continue
        surface, findings = _parse_surface(raw, w, i)
        frag.findings.extend(findings)
        if surface is None:
            continue
        frag.surfaces.append(surface)
        if surface.is_stop:
            stop_indices.append(i)
        if surface.is_stop and surface.semi_aperture is None:
            frag.findings.append(
                Finding("W_STOP_UNSIZED", "warning", w,
                        "is_stop set without semi_aperture; stop is metadata only")
            )
        if surface.is_reflective and surface.semi_aperture is None and surface.aperture is None:
            frag.findings.append(
                Finding("W_APERTURE_DEFAULTED", "warning", w,
                        "reflective surface has no semi_aperture; 12.7 mm applied later")
            )
    if len(stop_indices) > 1:
        frag.findings.append(
            Finding("E_STOP_MULTIPLE", "error", where,
                    f"fragment declares {len(stop_indices)} stop surfaces "
                    f"(indices {stop_indices}); at most one is allowed")
        )
    return frag


def _parse_surface(
    raw: dict[str, Any], w: str, index: int
) -> tuple[DialectSurface | None, list[Finding]]:
    findings: list[Finding] = []

    bad_keys = set(raw) - _SURFACE_KEYS
    if bad_keys:
        findings.append(_unsupported(f"{w}.{sorted(bad_keys)[0]}", "unknown surface key"))

    if raw.get("type") != "standard":
        findings.append(_unsupported(f"{w}.type", f"expected 'standard', got {raw.get('type')!r}"))

    sag, sag_findings = _parse_geometry(raw.get("geometry"), f"{w}.geometry")
    findings.extend(sag_findings)

    is_reflective, thin_lens_f, refl_findings = _parse_interaction(
        raw.get("interaction_model"), f"{w}.interaction_model"
    )
    findings.extend(refl_findings)

    thickness, th_findings = _parse_number(
        raw.get("thickness", 0.0), f"{w}.thickness", minimum=0.0, default=0.0
    )
    findings.extend(th_findings)

    semi_aperture: float | None = None
    if "semi_aperture" in raw:
        semi_aperture, sa_findings = _parse_number(
            raw["semi_aperture"], f"{w}.semi_aperture", exclusive_min=0.0, default=None
        )
        findings.extend(sa_findings)

    is_stop = bool(raw.get("is_stop", False))

    material_post, mat_findings = _parse_material(raw.get("material_post"), f"{w}.material_post")
    findings.extend(mat_findings)

    response, resp_findings = _parse_response(raw.get("response"), f"{w}.response")
    findings.extend(resp_findings)

    aperture, ap_findings = _parse_aperture(raw.get("aperture"), f"{w}.aperture")
    findings.extend(ap_findings)
    if aperture is not None and not (is_reflective and sag is not None and sag.kind == "plane"):
        # A revolved profile (lens body, curved mirror) cannot take a
        # rectangular boundary; only the plane-mirror case maps to the
        # kernel's Rectangle shape. Degrade, keep the surface.
        findings.append(Finding(
            "W_APERTURE_UNUSED", "warning", f"{w}.aperture",
            "rectangular aperture is only representable on a plane reflective "
            "surface in dialect v0 — ignored; the profile uses semi_aperture"))
        aperture = None

    if thin_lens_f is not None:
        # The black box is exactly one ideal plane: no glass, no sag, no
        # spectral response — anything more belongs in a real prescription.
        if material_post is not None:
            findings.append(_unsupported(
                f"{w}.material_post", "a thin_lens surface cannot carry glass"))
        if response is not None:
            findings.append(_unsupported(
                f"{w}.response", "a thin_lens surface cannot carry a response block"))
        if sag is not None and sag.kind != "plane":
            findings.append(_unsupported(
                f"{w}.geometry.radius", "a thin_lens surface must be planar (.inf radius)"))

    if any(f.severity == "error" for f in findings) or sag is None:
        return None, findings
    return (
        DialectSurface(
            index=index,
            sag=sag,
            is_reflective=is_reflective,
            thickness=thickness if thickness is not None else 0.0,
            semi_aperture=semi_aperture,
            is_stop=is_stop,
            material_post=material_post,
            response=response,
            thin_lens_f=thin_lens_f,
            aperture=aperture,
        ),
        findings,
    )


def _parse_geometry(geo: Any, w: str) -> tuple[SagModel | None, list[Finding]]:
    if not isinstance(geo, dict):
        return None, [_unsupported(w, "geometry must be a mapping")]
    findings: list[Finding] = []
    gtype = geo.get("type")
    if gtype not in ("StandardGeometry", "EvenAsphere", "Plane"):
        findings.append(_unsupported(
            f"{w}.type", f"expected 'StandardGeometry' or 'EvenAsphere', got {gtype!r}"))
    bad_keys = set(geo) - (_ASPHERE_KEYS if gtype == "EvenAsphere" else _GEOMETRY_KEYS)
    if bad_keys:
        findings.append(_unsupported(f"{w}.{sorted(bad_keys)[0]}", "unknown geometry key"))

    conic, conic_findings = _parse_number(geo.get("conic", 0.0), f"{w}.conic", default=0.0)
    findings.extend(conic_findings)
    coefficients: tuple[float, ...] = ()
    if gtype == "EvenAsphere":
        coefficients, coeff_findings = _parse_coefficients(
            geo.get("coefficients", []), f"{w}.coefficients")
        findings.extend(coeff_findings)

    # Optiland's own spelling of a flat carries no radius at all.
    radius = geo.get("radius", math.inf if gtype == "Plane" else None)
    # The WP-43 CSV importer quotes infinities (``radius: '.inf'``), and the
    # rest of the toolchain reads them; accept the YAML string spellings
    # BEFORE the expression test — since WP-195 every other string is an
    # (unresolved) expression, and '.inf' would not parse as one.
    if isinstance(radius, str):
        spelled = {".inf": math.inf, "+.inf": math.inf, "-.inf": -math.inf,
                   "inf": math.inf, "-inf": -math.inf}.get(radius.strip().lower())
        if spelled is not None:
            radius = spelled
    if is_expr(radius):
        findings.append(Finding("E_TEMPLATED", "error", f"{w}.radius",
                                f"unresolved templated radius {radius!r}"))
        return None, findings
    if not isinstance(radius, (int, float)) or isinstance(radius, bool):
        findings.append(
            _unsupported(f"{w}.radius", f"radius must be a number or .inf, got {radius!r}")
        )
        return None, findings
    radius = float(radius)
    if math.isnan(radius):
        findings.append(_unsupported(f"{w}.radius", "radius is NaN"))
        return None, findings

    if any(f.severity == "error" for f in findings):
        return None, findings
    if math.isinf(radius):
        if any(coefficients):
            return SagModel("asphere", 0.0, float(conic), coefficients), findings
        return SagModel("plane"), findings
    if radius == 0.0:
        findings.append(_unsupported(f"{w}.radius", "radius 0 has undefined curvature"))
        return None, findings
    if any(coefficients):
        return SagModel("asphere", 1.0 / radius, float(conic), coefficients), findings
    return SagModel("conic", curvature_per_mm=1.0 / radius, conic=float(conic)), findings


def _parse_coefficients(raw: Any, w: str) -> tuple[tuple[float, ...], list[Finding]]:
    """Optiland's even-asphere list (r² first) → the kernel's eight terms (r⁴ first)."""
    if not isinstance(raw, list):
        return (), [_unsupported(w, f"coefficients must be a list, got {type(raw).__name__}")]
    findings: list[Finding] = []
    values: list[float] = []
    for i, item in enumerate(raw):
        value, item_findings = _parse_number(item, f"{w}[{i}]", default=0.0)
        findings.extend(item_findings)
        values.append(value if value is not None else 0.0)
    if values and values[0] != 0.0:
        findings.append(_unsupported(
            f"{w}[0]", "an r² term has no kernel spelling — the even asphere starts at r⁴"))
    beyond = 1 + KERNEL_ASPHERE_TERMS
    if any(values[beyond:]):
        findings.append(_unsupported(f"{w}[{beyond}]", "terms beyond r¹⁸ are not traced"))
    kernel = values[1:beyond]
    kernel += [0.0] * (KERNEL_ASPHERE_TERMS - len(kernel))
    return tuple(kernel), findings


def _parse_interaction(inter: Any, w: str) -> tuple[bool, float | None, list[Finding]]:
    """``(is_reflective, thin_lens_focal_length, findings)`` of an authored
    ``interaction_model``. Two models exist: the default
    ``refractive_reflective`` (Snell/mirror, ``is_reflective`` flag) and the
    WP-75 ``thin_lens`` black box (ideal-lens surface, ``focal_length`` in mm,
    finite and nonzero — Optiland's ``ThinLensInteractionModel`` and the
    kernel's ``ThinLens`` response implement the same slope law)."""
    if inter is None:
        return False, None, []
    if not isinstance(inter, dict):
        return False, None, [_unsupported(w, "interaction_model must be a mapping")]
    findings: list[Finding] = []
    bad_keys = set(inter) - _INTERACTION_KEYS
    if bad_keys:
        findings.append(_unsupported(f"{w}.{sorted(bad_keys)[0]}", "unknown interaction_model key"))
    itype = inter.get("type")
    if itype == "thin_lens":
        if inter.get("is_reflective"):
            findings.append(_unsupported(f"{w}.is_reflective", "a thin lens is not reflective"))
        f = inter.get("focal_length")
        if not isinstance(f, (int, float)) or isinstance(f, bool) or not math.isfinite(f) or f == 0:
            findings.append(_unsupported(
                f"{w}.focal_length", f"thin_lens needs a finite nonzero focal_length, got {f!r}"))
            return False, None, findings
        return False, float(f), findings
    if itype is not None and itype != "refractive_reflective":
        findings.append(_unsupported(
            f"{w}.type", f"expected 'refractive_reflective' or 'thin_lens', got {itype!r}"))
    reflective = inter.get("is_reflective", False)
    if not isinstance(reflective, bool):
        findings.append(_unsupported(f"{w}.is_reflective", f"expected bool, got {reflective!r}"))
        reflective = False
    return bool(reflective), None, findings


def _parse_material(mat: Any, w: str) -> tuple[str | None, list[Finding]]:
    if mat is None:
        return None, []
    if isinstance(mat, str):
        return (mat or None), []
    if isinstance(mat, dict):
        bad_keys = set(mat) - _MATERIAL_KEYS
        if bad_keys:
            return None, [_unsupported(f"{w}.{sorted(bad_keys)[0]}", "unknown material_post key")]
        mtype = mat.get("type")
        if mtype is not None and mtype != "Material":
            return None, [_unsupported(f"{w}.type", f"expected 'Material', got {mtype!r}")]
        name = mat.get("name")
        if not isinstance(name, str) or not name:
            return None, [
                _unsupported(f"{w}.name", f"material name must be a non-empty string, got {name!r}")
            ]
        return name, []
    return None, [
        _unsupported(w, f"material_post must be a glass name or {{type, name}}, got {mat!r}")
    ]


def _parse_aperture(block: Any, w: str) -> tuple[RectAperture | None, list[Finding]]:
    """Optiland's ``aperture`` block → centered half-extents.

    Only ``RectangularAperture`` is in the dialect (the WP-43 migrated mirror
    records author it); other aperture types stay E_FRAG_UNSUPPORTED. A
    decentered rectangle keeps its size and warns — dialect v0 materializes
    the shape centered on the surface axis.
    """
    if block is None:
        return None, []
    if not isinstance(block, dict):
        return None, [_unsupported(w, "aperture must be a mapping")]
    findings: list[Finding] = []
    bad_keys = set(block) - _APERTURE_KEYS
    if bad_keys:
        return None, [_unsupported(f"{w}.{sorted(bad_keys)[0]}", "unknown aperture key")]
    atype = block.get("type")
    if atype != "RectangularAperture":
        return None, [
            _unsupported(f"{w}.type", f"expected 'RectangularAperture', got {atype!r}")
        ]
    bounds: list[float] = []
    for key in ("x_min", "x_max", "y_min", "y_max"):
        num, num_findings = _parse_number(block.get(key), f"{w}.{key}", default=None)
        findings.extend(num_findings)
        if num is not None:
            bounds.append(num)
    if len(bounds) != 4:
        return None, findings
    x_min, x_max, y_min, y_max = bounds
    if x_max <= x_min or y_max <= y_min:
        findings.append(_unsupported(w, "aperture bounds must satisfy min < max"))
        return None, findings
    center_x = (x_max + x_min) / 2.0
    center_y = (y_max + y_min) / 2.0
    if abs(center_x) > 1e-9 or abs(center_y) > 1e-9:
        findings.append(Finding(
            "W_APERTURE_DECENTERED", "warning", w,
            f"aperture center ({center_x:g}, {center_y:g}) mm is ignored — "
            "dialect v0 centers the rectangle on the surface axis"))
    return RectAperture((x_max - x_min) / 2.0, (y_max - y_min) / 2.0), findings


def _parse_response(block: Any, w: str) -> tuple[Any, list[Finding]]:
    """Validate a WP-74 ``response`` block through ``schema.response``.

    The pydantic model is the single validator for this vocabulary; the dialect
    only translates its rejection into the fragment's typed findings.
    """
    if block is None:
        return None, []
    from pydantic import ValidationError

    from ..schema.response import SurfaceResponse

    try:
        return SurfaceResponse.model_validate(block), []
    except ValidationError as exc:
        first = exc.errors()[0]
        loc = ".".join(str(part) for part in first.get("loc", ()))
        where = f"{w}.{loc}" if loc else w
        return None, [_unsupported(where, f"invalid response block: {first.get('msg')}")]


def _parse_number(
    value: Any,
    w: str,
    *,
    minimum: float | None = None,
    exclusive_min: float | None = None,
    default: float | None = 0.0,
) -> tuple[float | None, list[Finding]]:
    if is_expr(value):
        return default, [
            Finding("E_TEMPLATED", "error", w, f"unresolved templated value {value!r}")
        ]
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return default, [_unsupported(w, f"expected a finite number, got {value!r}")]
    num = float(value)
    if not math.isfinite(num):
        return default, [_unsupported(w, f"expected a finite number, got {value!r}")]
    if minimum is not None and num < minimum:
        return default, [_unsupported(w, f"value {num} is below the minimum {minimum}")]
    if exclusive_min is not None and num <= exclusive_min:
        return default, [_unsupported(w, f"value {num} must be greater than {exclusive_min}")]
    return num, []


def _unsupported(where: str, message: str) -> Finding:
    return Finding("E_FRAG_UNSUPPORTED", "error", where, message)
