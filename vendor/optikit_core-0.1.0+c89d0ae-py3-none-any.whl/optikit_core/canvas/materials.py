"""KIT-01: resolve glass names to baked Sellmeier catalog entries.

Locked decision 5: materials are baked. A ``material_post`` glass name resolves
to full three-term Sellmeier coefficients at materialization time and is emitted
into the scene's ``GlassCatalog``, so neither the browser nor the kernel needs
Optiland at trace time. Resolution uses Optiland's own glass database (the
``data-nk/glass`` catalog, the same names ``scripts/export_materials_ts.py`` and
the WP-9 importer use), so this module needs the ``sim`` extra (ADR-2: until
coefficients are vendored, the export path depends on Optiland).

The emitted catalog mirrors ``oc-core``'s ``GlassCatalog`` serde shape exactly:
``{"glasses": [{"name", "sell": {"b": [3], "c": [3]}, "nd", "vd"}]}`` with
``Material::Catalog`` referencing a glass by its positional id. ``nd``/``vd`` are
computed from the baked Sellmeier with the kernel's own reference lines, so the
emitted caches equal what ``oc-core`` would compute from the coefficients.

Optiland's "formula 2" is ``n² = 1 + c0 + Σ Bₖ·λ²/(λ² − Cₖ)`` with the ``Cₖ``
already in µm² — identical to ``Sellmeier::index`` when ``c0 = 0``. Rather than
trust a formula-name string, every resolution reconstructs the index from the
extracted coefficients and verifies it against Optiland's ``n()`` at the
reference lines; anything that does not reproduce is refused, not approximated
(section 10: no nd/vd-only approximations for catalog glasses).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..schema.checks import Finding

# Kernel reference lines (oc-core material.rs LAMBDA_*), micrometres.
LAMBDA_D = 0.587_56
LAMBDA_F = 0.486_13
LAMBDA_C = 0.656_27

#: A ``material_post`` naming ambient air closes no body (section 10).
AMBIENT_NAMES = frozenset({"", "air"})

#: How closely the baked Sellmeier must reproduce Optiland's own index before it
#: is accepted. Identical coefficients + identical formula agree to rounding;
#: a wider gap means the glass is not a c0=0 three-term Sellmeier.
_INDEX_TOL = 1e-9


@dataclass(frozen=True)
class ResolvedGlass:
    """A baked catalog glass: full Sellmeier plus the kernel-consistent caches."""

    name: str  # canonical database name (file stem)
    b: tuple[float, float, float]
    c: tuple[float, float, float]
    nd: float
    vd: float

    def index(self, lambda_um: float) -> float:
        l2 = lambda_um * lambda_um
        n2 = 1.0
        for bi, ci in zip(self.b, self.c, strict=True):
            n2 += bi * l2 / (l2 - ci)
        return n2 ** 0.5


def is_ambient(name: str | None) -> bool:
    """True when ``name`` denotes ambient air, closing no body."""
    return name is None or name.strip().lower() in AMBIENT_NAMES


#: Process-wide resolution memo. Optiland's ``Material(name)`` runs a pandas
#: catalog search plus a YAML file parse (~10 ms) — per call, so an uncached
#: materialize paid it once per glass surface and dominated /v1/scene3 wall
#: time on large designs. The glass database is immutable for the process
#: lifetime, so results are cached by normalized name. Findings are stored
#: without their ``where`` (call-site context) and re-stamped per caller.
_RESOLVE_CACHE: dict[str, tuple[ResolvedGlass | None, tuple[tuple[str, str, str], ...]]] = {}


def resolve_glass(name: str, where: str) -> tuple[ResolvedGlass | None, list[Finding]]:
    """Resolve one glass name to a baked ``ResolvedGlass``.

    Returns ``(None, [])`` for ambient air. An unresolvable or non-bakeable name
    returns ``(None, [E_MAT_UNKNOWN])``; a fuzzy match adds ``W_MAT_NORMALIZED``.
    """
    if is_ambient(name):
        return None, []
    try:
        from optiland.materials import Material
    except ImportError:
        # Not cached: the environment could gain the 'sim' extra only across
        # processes, but tests monkeypatch imports within one.
        return None, [Finding("E_MAT_UNKNOWN", "error", where,
                              "Optiland (the 'sim' extra) is required to bake glass materials")]

    key = name.strip().lower()
    cached = _RESOLVE_CACHE.get(key)
    if cached is None:
        cached = _resolve_uncached(Material, name)
        _RESOLVE_CACHE[key] = cached
    glass, packed = cached
    return glass, [Finding(code, severity, where, message)  # type: ignore[arg-type]
                   for code, severity, message in packed]


def _resolve_uncached(
    material_cls: Any, name: str
) -> tuple[ResolvedGlass | None, tuple[tuple[str, str, str], ...]]:
    try:
        mat = material_cls(name)
    except ValueError as exc:
        return None, (("E_MAT_UNKNOWN", "error", f"unknown glass {name!r}: {exc}"),)

    findings: list[tuple[str, str, str]] = []
    canonical = Path(mat.filename).stem
    if canonical.lower() != name.strip().lower():
        findings.append(("W_MAT_NORMALIZED", "warning",
                         f"glass {name!r} normalized to database name {canonical!r}"))

    coeffs, coeff_findings = _sellmeier_from_material(mat, canonical, "")
    findings += [(f.code, f.severity, f.message) for f in coeff_findings]
    if coeffs is None:
        return None, tuple(findings)
    return _from_coefficients(canonical, coeffs[0], coeffs[1]), tuple(findings)


class GlassCatalogBuilder:
    """Accumulate resolved glasses, assign positional ids, emit the catalog.

    Glasses are interned by canonical name, case-insensitively — matching the
    kernel's ``GlassCatalog::intern`` and the canvas glass-merge policy — so a
    glass shared by two components is emitted once and both reference one id.
    """

    def __init__(self) -> None:
        self._glasses: list[ResolvedGlass] = []
        self._index: dict[str, int] = {}

    def intern(self, name: str, where: str) -> tuple[int | None, list[Finding]]:
        """Resolve and intern ``name``; return its glass id (``None`` if ambient
        or unresolvable) plus any findings."""
        glass, findings = resolve_glass(name, where)
        if glass is None:
            return None, findings
        key = glass.name.lower()
        existing = self._index.get(key)
        if existing is not None:
            return existing, findings
        gid = len(self._glasses)
        self._glasses.append(glass)
        self._index[key] = gid
        return gid, findings

    def to_catalog(self) -> dict[str, Any]:
        """The ``GlassCatalog`` object for a Scene3 ``catalog`` field."""
        return {
            "glasses": [
                {"name": g.name, "sell": {"b": list(g.b), "c": list(g.c)}, "nd": g.nd, "vd": g.vd}
                for g in self._glasses
            ]
        }

    def __len__(self) -> int:
        return len(self._glasses)


def catalog_material(glass_id: int) -> dict[str, int]:
    """The ``Material::Catalog`` JSON referencing a glass by id."""
    return {"Catalog": glass_id}


def _sellmeier_from_material(
    mat: Any, canonical: str, where: str
) -> tuple[tuple[tuple[float, float, float], tuple[float, float, float]] | None, list[Finding]]:
    raw = _flatten(mat.coefficients)
    if len(raw) < 3 or len(raw) % 2 == 0:
        return None, [_unbakeable(where, canonical, f"{len(raw)} dispersion coefficients")]
    c0, terms = raw[0], raw[1:]
    if abs(c0) > _INDEX_TOL:
        return None, [_unbakeable(where, canonical, f"non-zero constant term c0={c0}")]
    pairs = [(terms[i], terms[i + 1]) for i in range(0, len(terms), 2)]
    if len(pairs) > 3:
        return None, [_unbakeable(where, canonical, f"{len(pairs)} Sellmeier terms (max 3)")]
    # Pad to exactly three terms; a b=0 term vanishes for any wavelength.
    while len(pairs) < 3:
        pairs.append((0.0, 0.0))
    b = (float(pairs[0][0]), float(pairs[1][0]), float(pairs[2][0]))
    c = (float(pairs[0][1]), float(pairs[1][1]), float(pairs[2][1]))

    # Verify the baked coefficients reproduce Optiland's own index. Identical
    # formula + coefficients agree to rounding; a wider gap means this glass is
    # not a c0=0 three-term Sellmeier and must not be silently approximated.
    probe = ResolvedGlass(canonical, b, c, 0.0, 0.0)
    for lam in (LAMBDA_F, LAMBDA_D, LAMBDA_C):
        reference = _scalar(mat.n(lam))
        if reference is None:
            return None, [_unbakeable(where, canonical, "index not evaluable at a reference line")]
        if abs(probe.index(lam) - reference) > 1e-6:
            return None, [_unbakeable(where, canonical, "coefficients disagree with Optiland")]
    return (b, c), []


def _from_coefficients(
    name: str, b: tuple[float, float, float], c: tuple[float, float, float]
) -> ResolvedGlass:
    probe = ResolvedGlass(name, b, c, 0.0, 0.0)
    nd = probe.index(LAMBDA_D)
    vd = (nd - 1.0) / (probe.index(LAMBDA_F) - probe.index(LAMBDA_C))
    return ResolvedGlass(name, b, c, nd, vd)


def _flatten(coeffs: Any) -> list[float]:
    """Flatten Optiland's ``(n, 1)`` coefficient array to plain floats."""
    try:
        import numpy as np

        return [float(x) for x in np.asarray(coeffs, dtype=float).reshape(-1)]
    except (TypeError, ValueError):
        return [float(x) for x in coeffs]


def _scalar(value: Any) -> float | None:
    """Extract a single float from Optiland's ``n()`` (a 1-element array)."""
    try:
        import numpy as np

        flat = np.asarray(value, dtype=float).reshape(-1)
        return float(flat[0]) if flat.size else None
    except (TypeError, ValueError, IndexError):
        try:
            return float(value)
        except (TypeError, ValueError):
            return None


def _unbakeable(where: str, name: str, reason: str) -> Finding:
    return Finding("E_MAT_UNKNOWN", "error", where,
                   f"glass {name!r} is not a bakeable catalog glass: {reason}")
