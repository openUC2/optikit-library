"""Physical constants of the UC2 system, normative for the whole toolchain."""

# Distance between the centers of adjacent UC2 grid cells along each axis (x, y, z),
# in millimeters.
#
# NOTE: the Go repo (github.com/openUC2/optikit, exp/designs/geometry.go) currently has
# UC2GridSpacings = {5, 5, 5.5} with a comment claiming centimeters while the values are
# consumed as millimeters. That is a bug; the physical UC2 pitch is 50/50/55 mm and the
# Go repo must migrate to these values (Ethan TODO E1 in
# openUC2-OptiKit/DOCS/kicad-for-optics-execution.md).
UC2_GRID_MM: tuple[float, float, float] = (50.0, 50.0, 55.0)

# The optikit-version this schema implementation targets. Designs declaring a newer
# version are rejected by tools that cannot guarantee forward compatibility.
SCHEMA_VERSION = "v0"
