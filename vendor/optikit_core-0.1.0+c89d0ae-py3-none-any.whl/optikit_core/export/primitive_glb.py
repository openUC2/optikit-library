"""WP-236: a stand-in mesh for an optic that ships without one.

A component with `optics` but no `static-models` renders as nothing outside
our own viewers — the beam is there, the glass is not. That is fine inside
the library (our editors draw a derived glyph from the prescription) and
wrong in an exported ``.dsn``, whose whole point is to be standalone: Ethan's
Go renderer, glTF viewers and CAD importers see an empty component.

So the export synthesizes one from what the record already says: a disc of
the surface's own clear aperture, one millimetre thick, on the component's
optical axis (local +z, the F2 convention). It is a PLACEHOLDER — deliberately
plain, never mistaken for the real part, and never written into the library.

It is written in glTF-spec metres and stamped as such (WP-237), like
everything else the converter emits.
"""

from __future__ import annotations

import base64
import json
import math
import struct
from typing import Any

from ..units import MM_PER_M, SPEC_UNIT, stamp_unit

#: glTF units per millimetre. WP-237: the spec's metres, like everything the
#: converter writes now — and the file says so via `asset.extras`, so no
#: reader has to guess.
GLTF_UNITS_PER_MM = 1.0 / MM_PER_M

#: Radius used when a record declares no aperture at all — half a 25 mm optic.
DEFAULT_SEMI_APERTURE_MM = 12.5
#: How thick the stand-in disc is. Thin enough to read as "a surface", thick
#: enough to be visible edge-on in a viewer.
THICKNESS_MM = 1.0
#: Sides of the disc's polygon. 32 is smooth at assembly scale and keeps the
#: file a few kB.
SEGMENTS = 32


def semi_aperture_mm(optics: Any) -> float:
    """The widest clear radius the record declares, in mm.

    Reads the fragment's surfaces first (`semi_aperture` is the real number),
    then the frames' `clear-aperture-mm` (a DIAMETER, §9.1). Falls back to
    :data:`DEFAULT_SEMI_APERTURE_MM` — a placeholder with a made-up size still
    beats no geometry.
    """
    best = 0.0
    fragment = getattr(optics, "fragment", None)
    for surface in getattr(fragment, "surfaces", None) or []:
        value = (surface or {}).get("semi_aperture")
        if isinstance(value, int | float) and math.isfinite(value) and value > best:
            best = float(value)
    for frame in (getattr(optics, "frames", None) or {}).values():
        value = getattr(frame, "clear_aperture_mm", None)
        if isinstance(value, int | float) and math.isfinite(value) and value / 2 > best:
            best = float(value) / 2
    return best or DEFAULT_SEMI_APERTURE_MM


def _disc_mesh(radius: float, half_thickness: float) -> tuple[bytes, list[float], list[float]]:
    """(interleaved-free position buffer, min, max) for a closed cylinder."""
    positions: list[tuple[float, float, float]] = []

    def ring(z: float) -> list[tuple[float, float, float]]:
        return [
            (radius * math.cos(2 * math.pi * i / SEGMENTS),
             radius * math.sin(2 * math.pi * i / SEGMENTS),
             z)
            for i in range(SEGMENTS)
        ]

    back, front = ring(-half_thickness), ring(half_thickness)
    centre_back = (0.0, 0.0, -half_thickness)
    centre_front = (0.0, 0.0, half_thickness)
    # Triangles written out directly: no index buffer keeps this file trivial
    # to verify by hand, and 32 segments is 192 triangles.
    for i in range(SEGMENTS):
        j = (i + 1) % SEGMENTS
        positions += [centre_back, back[j], back[i]]          # back cap
        positions += [centre_front, front[i], front[j]]       # front cap
        positions += [back[i], back[j], front[j]]             # rim
        positions += [back[i], front[j], front[i]]
    blob = b"".join(struct.pack("<3f", *p) for p in positions)
    lo = [min(p[k] for p in positions) for k in range(3)]
    hi = [max(p[k] for p in positions) for k in range(3)]
    return blob, lo, hi


def placeholder_glb(name: str, semi_aperture_mm_: float) -> bytes:
    """A .glb holding one disc on the local z axis, sized from the aperture."""
    scale = GLTF_UNITS_PER_MM
    blob, lo, hi = _disc_mesh(
        semi_aperture_mm_ * scale, (THICKNESS_MM / 2) * scale
    )
    padded = blob + b"\x00" * (-len(blob) % 4)
    gltf: dict[str, Any] = {
        "asset": {"version": "2.0",
                  "generator": "optikit-core placeholder (WP-236)"},
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": [{"mesh": 0, "name": name}],
        "meshes": [{"name": name,
                    "primitives": [{"attributes": {"POSITION": 0}, "material": 0}]}],
        "materials": [{
            "name": "optikit-placeholder",
            "pbrMetallicRoughness": {
                "baseColorFactor": [0.41, 0.82, 1.0, 0.45],
                "metallicFactor": 0.0,
                "roughnessFactor": 0.6,
            },
            "alphaMode": "BLEND",
            "doubleSided": True,
        }],
        "accessors": [{
            "bufferView": 0, "componentType": 5126, "count": len(blob) // 12,
            "type": "VEC3", "min": lo, "max": hi,
        }],
        "bufferViews": [{"buffer": 0, "byteOffset": 0, "byteLength": len(blob),
                         "target": 34962}],
        "buffers": [{"byteLength": len(padded)}],
    }
    stamp_unit(gltf, SPEC_UNIT)
    body = json.dumps(gltf, separators=(",", ":")).encode("utf-8")
    body += b" " * (-len(body) % 4)
    total = 12 + 8 + len(body) + 8 + len(padded)
    out = bytearray()
    out += b"glTF" + struct.pack("<II", 2, total)
    out += struct.pack("<II", len(body), 0x4E4F534A) + body   # JSON chunk
    out += struct.pack("<II", len(padded), 0x004E4942) + padded  # BIN chunk
    return bytes(out)


def placeholder_data_uri(name: str, semi_aperture_mm_: float) -> str:
    """The same GLB as a data URI, for callers that cannot write a file."""
    payload = base64.b64encode(placeholder_glb(name, semi_aperture_mm_)).decode()
    return f"data:model/gltf-binary;base64,{payload}"
