"""WP-232: a component's prescription as a standalone Optiland file.

A component record's ``optics.fragment`` is already Optiland's own surface
dict shape, but it is a SLICE — Optiland's ``Optic.from_dict`` also wants an
aperture, fields and wavelengths, which a component does not own. So the
sidecar wraps the fragment in the smallest honest context:

- an object plane at infinity and an image plane one focal length out, so the
  file is a complete system rather than a floating stack of surfaces;
- a default aperture / field / wavelength block, built by the SAME helpers
  the compiler uses (:mod:`..compile.compiler`) so the two cannot drift.

**The context is a placeholder, and the file says so.** Simulation context
belongs to the DESIGN (``paths.<name>.simulation``), which overrides every
field of it at compile time. What the sidecar carries authoritatively is the
prescription — the surfaces, their materials, their apertures. Anyone can
point Optiland at the file and see the glass; only a design says at what
wavelength and through what pupil.

Frames and ports stay on the RECORD: they position the prescription in the
cube and say where light enters and leaves, which is the DSN's optical layer
(GO-SYNC §4), not the prescription. That split is the point of the ask filed
as GO-SYNC §6d.
"""

from __future__ import annotations

import math
from typing import Any

from ..schema.library import ComponentRecord

#: Placeholder context, replaced by the design's `simulation:` at compile
#: time. Written into the file so it LOADS, never so it is believed.
DEFAULT_EPD_MM = 10.0
DEFAULT_WAVELENGTH_UM = 0.532

_AIR: dict[str, Any] = {"type": "IdealMaterial", "index": 1.0, "absorb_coeff": 0.0}

#: The infinity spellings the corpus uses (GO-SYNC §7.3) — YAML `.inf`, the
#: strings, and JSON's `1e999`. Optiland wants a real float.
_INFINITIES = {".inf", "inf", "+inf", "infinity", "+infinity"}


def _number(value: Any, default: float) -> float:
    """A geometry leaf as a float, accepting every infinity spelling."""
    if isinstance(value, int | float):
        return float(value)
    if isinstance(value, str):
        text = value.strip().lower()
        if text in _INFINITIES:
            return math.inf
        if text.lstrip("-") in _INFINITIES:
            return -math.inf
        try:
            return float(text)
        except ValueError:
            return default
    return default


def _cs(z: float) -> dict[str, Any]:
    # `reference_cs` is required by optiland 0.6.0's CoordinateSystem.from_dict
    # (null = the global frame). The sidecar test pins this against the real
    # loader, so a schema change upstream fails loudly instead of silently.
    return {
        "x": 0.0, "y": 0.0, "z": z,
        "rx": 0.0, "ry": 0.0, "rz": 0.0,
        "reference_cs": None,
    }


def _object_plane(z: float, comment: str) -> dict[str, Any]:
    """Optiland's ObjectSurface — a distinct type, not a plain Surface."""
    return {
        "type": "ObjectSurface",
        "geometry": {"type": "Plane", "cs": _cs(z), "radius": math.inf},
        "material_post": dict(_AIR),
        "comment": comment,
    }


def _plane(z: float, comment: str) -> dict[str, Any]:
    return {
        "type": "Surface",
        "thickness": 0.0,
        "geometry": {"type": "Plane", "cs": _cs(z), "radius": math.inf},
        "material_post": dict(_AIR),
        "is_stop": False,
        "aperture": None,
        "comment": comment,
        "interaction_model": {
            "type": "RefractiveReflectiveModel",
            "is_reflective": False,
        },
    }


def _sidecar_interaction(authored: Any) -> dict[str, Any]:
    """The authored interaction model, renamed onto optiland's registry.

    Unlike the compile path this KEEPS ``is_reflective`` as the record wrote
    it: a mirror in a sidecar is reflective, because the file describes the
    component, not a path that folds through it.
    """
    from ..compile.compiler import _INTERACTION_CLASSES

    if not isinstance(authored, dict):
        return {"type": "RefractiveReflectiveModel", "is_reflective": False,
                "coating": None, "bsdf": None}
    raw = str(authored.get("type") or "refractive_reflective").lower()
    out = {**authored, "type": _INTERACTION_CLASSES.get(raw, "RefractiveReflectiveModel")}
    out["is_reflective"] = bool(authored.get("is_reflective", False))
    out.setdefault("coating", None)
    out.setdefault("bsdf", None)
    return out


def component_to_optiland(record: ComponentRecord) -> dict[str, Any]:
    """The record's prescription as a dict ``Optic.from_dict`` accepts.

    Surfaces travel VERBATIM (F2 ships unchanged) — only the object/image
    planes and the context are added around them.
    """
    # Materials share the compiler's normalizer — that map is a pure rename
    # onto optiland's registry, no semantics. The INTERACTION model does NOT:
    # `_normalize_interaction` forces `is_reflective: False` because the
    # compiler unfolds folds onto a straight axis, which is a decision about
    # a PATH, not a property of the glass. Reusing it here turned every
    # mirror into a window (`E_MIRROR_NO_REFLECTIVE` on the flat mirror).
    # So the sidecar renames the type and keeps the record's own answer.
    from ..compile.compiler import _normalize_material

    fragment = record.optics.fragment
    surfaces: list[dict[str, Any]] = []
    if fragment is not None:
        surfaces = [
            dict(s) for s in fragment.model_dump(by_alias=True, exclude_none=True)
            .get("surfaces", [])
        ]

    # Place the stack on the axis: each surface sits at the running sum of the
    # thicknesses before it, which is what the record's `thickness` means.
    z = 0.0
    placed: list[dict[str, Any]] = []
    for index, surface in enumerate(surfaces):
        out = dict(surface)
        geometry = dict(out.get("geometry") or {})
        geometry.setdefault("type", "StandardGeometry")
        geometry["cs"] = _cs(z)
        geometry["radius"] = _number(geometry.get("radius"), math.inf)
        if "conic" in geometry:
            geometry["conic"] = _number(geometry.get("conic"), 0.0)
        out["geometry"] = geometry
        out["type"] = "Surface"
        out["material_post"] = _normalize_material(
            out.get("material_post"), record.id, index
        )
        out["interaction_model"] = _sidecar_interaction(out.get("interaction_model"))
        out.setdefault("is_stop", False)
        out.setdefault("aperture", None)
        # `semi_aperture` is AUTHORED record data (the clear half-diameter),
        # not scaffolding — it has to survive the round trip.
        placed.append(out)
        thickness = out.get("thickness") or 0.0
        z += float(thickness) if isinstance(thickness, int | float) else 0.0

    efl = record.effective_focal_length_mm
    image_z = z + (float(efl) if isinstance(efl, int | float) and efl else 0.0)

    return {
        "version": 1.0,
        "name": record.id,
        "aperture": {"type": "EPD", "value": DEFAULT_EPD_MM},
        "fields": {
            "fields": [{"x": 0.0, "y": 0.0, "vx": 0.0, "vy": 0.0, "weight": 1.0}],
            "telecentric": False,
            "field_definition": {"field_type": "AngleField"},
        },
        "wavelengths": {
            "polarization": "ignore",
            "wavelengths": [
                {
                    "value": DEFAULT_WAVELENGTH_UM,
                    "unit": "um",
                    "is_primary": True,
                    "weight": 1.0,
                }
            ],
        },
        "apodization": None,
        "pickups": [],
        "solves": {"solves": []},
        "surface_group": {
            "surfaces": [
                _object_plane(
                    -1e9, "object: at infinity (placeholder — the design decides)"
                ),
                *placed,
                _plane(image_z, "image: at the record's EFL (placeholder)"),
            ]
        },
    }


#: The sidecar's filename beside a `component.yml`.
SIDECAR_NAME = "optics.optiland.yml"

_HEADER = """\
# GENERATED from {record_id}'s `optics.fragment` — the prescription, in
# Optiland's own dict shape, loadable directly with `Optic.from_dict`.
#
# The SURFACES are authoritative: they are the record's optical truth,
# shipped verbatim. The aperture, fields and wavelengths are PLACEHOLDERS so
# that this file loads on its own — simulation context belongs to the design
# (`paths.<name>.simulation`), which overrides all of it at compile time.
#
# Frames and ports stay on the record: they position this prescription in
# the cube and say where light enters and leaves (DSN, not Optiland).
"""


def sidecar_text(record: ComponentRecord) -> str:
    """The sidecar file's contents, header included."""
    from ..io.yamlio import dump_document

    return _HEADER.format(record_id=record.id) + dump_document(
        component_to_optiland(record)
    )


# --- the inverse: canonical Optiland back into the record's dialect ----------------

#: Optiland's class names → the dialect's spellings (the inverse of the map
#: `component_to_optiland` applies). The dialect is a deliberate WHITELIST —
#: an unsupported optiland feature must be REPORTED, not silently traced — so
#: the sidecar is converted back on the way in rather than the whitelist
#: being widened to swallow optiland's whole vocabulary.
_DIALECT_INTERACTIONS = {
    "RefractiveReflectiveModel": "refractive_reflective",
    "ThinLensInteractionModel": "thin_lens",
}
_DIALECT_MATERIALS = {"IdealMaterial": "ideal", "Material": "Material"}

#: Keys the sidecar carries for optiland's sake that the dialect does not
#: model: `cs` is the standalone file's on-axis scaffolding (the DESIGN poses
#: every surface), and coating/bsdf are optiland defaults we never authored.
_SCAFFOLDING = {"cs"}
_INTERACTION_SCAFFOLDING = {"coating", "bsdf"}


def optiland_to_fragment(optic: dict[str, Any]) -> list[dict[str, Any]]:
    """The record's surfaces, back from a sidecar (the inverse of the above).

    Drops the object/image planes and the placeholder context, and returns the
    prescription in the dialect the records author — so a round trip through
    the sidecar is the identity, which is what makes the file safe to store.
    """
    out: list[dict[str, Any]] = []
    for raw in (optic.get("surface_group") or {}).get("surfaces", []):
        if not isinstance(raw, dict):
            continue
        if raw.get("type") in ("ObjectSurface", "ImageSurface"):
            continue
        if str(raw.get("comment", "")).startswith(("object:", "image:")):
            continue
        surface: dict[str, Any] = {"type": "standard"}

        geometry = {
            k: v for k, v in (raw.get("geometry") or {}).items() if k not in _SCAFFOLDING
        }
        if geometry:
            surface["geometry"] = geometry

        interaction = raw.get("interaction_model")
        if isinstance(interaction, dict):
            model = {
                k: v
                for k, v in interaction.items()
                if k not in _INTERACTION_SCAFFOLDING and v is not None
            }
            model["type"] = _DIALECT_INTERACTIONS.get(
                str(interaction.get("type")), "refractive_reflective"
            )
            if not model.get("is_reflective"):
                model.pop("is_reflective", None)
            # An absent `interaction_model` in the dialect MEANS the plain
            # refractive default, and the forward map has to write one for
            # optiland's sake. Emitting it back would add a key the record
            # never had, so the default collapses to absent again.
            if model != {"type": "refractive_reflective"}:
                surface["interaction_model"] = model

        material = raw.get("material_post")
        if isinstance(material, dict) and material.get("name"):
            surface["material_post"] = {"type": "Material", "name": material["name"]}

        for key in ("thickness", "semi_aperture", "aperture", "response"):
            value = raw.get(key)
            if value not in (None, "", 0) or (key == "thickness" and value):
                surface[key] = value
        if raw.get("is_stop"):
            surface["is_stop"] = True
        out.append(surface)
    return out
