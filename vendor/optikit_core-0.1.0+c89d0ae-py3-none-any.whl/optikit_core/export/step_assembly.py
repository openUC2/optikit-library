"""Export a design as one grouped STEP assembly (WP-57).

Three kinds of geometry, each under a node named for its part, so the CAD tree
is navigable rather than a soup of solids:

- **mechanics** — the placed module's template STEP at the module pose; the
  real part, not an approximation.
- **optics** — solids LATHED FROM THE PRESCRIPTION (a lens is the volume its
  own radii/conic/thickness/semi-aperture describe, a mirror a thin disc, a
  detector a sensor plate). Nothing is a stand-in: wrong numbers give a
  visibly wrong solid, which is the point.
- **beam_path** — the traced ray as geometry, so the light survives into CAD.

Frame: the design frame, mm, z-up (as ``src/document/mapping.ts``). cadquery
writes the units into the STEP header; nothing here rescales.

Determinism (WP-18): parts are emitted sorted and every number is rounded to
``ROUND_MM`` before OCCT, so re-exporting an unchanged design is byte-identical
apart from the timestamp ``rebuild`` already skips — verified across separate
invocations, which is the real case.

Caveat: exporting twice INSIDE one process differs, because OCCT's global
occurrence counter keeps incrementing (``NEXT_ASSEMBLY_USAGE_OCCURRENCE('1'…)``
→ ``('17'…)``). Geometry is identical; only those ids move, and nothing here
can reset the counter — use separate processes for comparable exports.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from ..geometry.flatten import FlatPose, flatten
from ..schema.design import CompSpec, DesignDecl
from ..schema.merge import instantiate

#: Everything is rounded to this before hitting OCCT, so the same design
#: exports the same bytes.
ROUND_MM = 6
#: Default radius of a beam segment rendered as a solid.
BEAM_RADIUS_MM = 0.5
#: A "flat" surface: radii beyond this are treated as planes.
FLAT_RADIUS_MM = 1e6
#: Fallback semi-aperture when a surface declares none.
DEFAULT_SEMI_APERTURE_MM = 12.5
#: Thickness of a mirror disc / sensor plate (they have no prescription depth).
PLATE_THICKNESS_MM = 3.0


class ExportError(Exception):
    """Typed export failure; ``code`` is stable API."""

    def __init__(self, code: str, where: str, message: str) -> None:
        super().__init__(f"{code} at {where}: {message}")
        self.code = code
        self.where = where


@dataclass
class ExportReport:
    """What actually made it into the file — and what did not."""

    modules: list[str] = field(default_factory=list)
    optics: list[str] = field(default_factory=list)
    beam_segments: int = 0
    warnings: list[str] = field(default_factory=list)


# --- prescription → profile ---------------------------------------------------


def _sag(radius: float, conic: float, r: float) -> float:
    """Conic sag z(r). Returns 0 for a flat surface.

    Standard conic: z = r²/(R(1+√(1−(1+k)r²/R²))). Guarded so a ray height
    beyond the surface's own curvature does not produce a complex number —
    a too-wide aperture is clamped to the sphere's edge instead of crashing.
    """
    if not math.isfinite(radius) or abs(radius) > FLAT_RADIUS_MM or r == 0:
        return 0.0
    disc = 1.0 - (1.0 + conic) * (r * r) / (radius * radius)
    if disc <= 0:
        # Beyond the conic's valid zone: fall back to the sphere's edge.
        disc = 0.0
    return (r * r) / (radius * (1.0 + math.sqrt(disc)))


def _surface_profile(radius: float, conic: float, semi: float, steps: int = 24
                     ) -> list[tuple[float, float]]:
    """Points (r, z) along one surface from the axis out to its semi-aperture."""
    return [
        (round(semi * i / steps, ROUND_MM), round(_sag(radius, conic, semi * i / steps), ROUND_MM))
        for i in range(steps + 1)
    ]


def _surface_values(surface: dict[str, Any]) -> tuple[float, float, float, float]:
    """(radius, conic, thickness, semi_aperture) from one prescription surface."""
    geometry = surface.get("geometry") or {}
    radius = geometry.get("radius", math.inf)
    radius = float(radius) if isinstance(radius, int | float) else math.inf
    conic = float(geometry.get("conic", 0.0) or 0.0)
    thickness = surface.get("thickness", 0.0)
    thickness = float(thickness) if isinstance(thickness, int | float) else 0.0
    semi = surface.get("semi_aperture")
    if not isinstance(semi, int | float):
        aperture = surface.get("aperture_diameter")
        semi = (
            float(aperture) / 2.0
            if isinstance(aperture, int | float)
            else DEFAULT_SEMI_APERTURE_MM
        )
    return radius, conic, thickness, float(semi)


def lens_profile(surfaces: list[dict[str, Any]]) -> list[tuple[float, float]]:
    """The closed (r, z) outline of an element, ready to revolve.

    Walks the surface stack front to back accumulating thickness, then returns
    along the back surface — the outline of the glass the prescription
    describes, including the edge that joins the two faces.
    """
    if not surfaces:
        raise ExportError("E_NO_SURFACES", "optics", "element has no surfaces to lathe")
    semi = max(_surface_values(s)[3] for s in surfaces)
    z = 0.0
    front: list[tuple[float, float]] = []
    offsets: list[float] = []
    for surface in surfaces:
        radius, conic, thickness, _s = _surface_values(surface)
        offsets.append(z)
        front.append((radius, conic, z))
        z += thickness
    first_r, first_k, first_z = front[0]
    last_r, last_k, last_z = front[-1]
    # Out along the front face, across the edge, back along the rear face.
    outline = [(r, first_z + dz) for r, dz in _surface_profile(first_r, first_k, semi)]
    outline += [
        (r, last_z + dz)
        for r, dz in reversed(_surface_profile(last_r, last_k, semi))
    ]
    return outline


# --- geometry builders (cadquery is imported lazily) --------------------------


def _require_cadquery() -> Any:
    try:
        import cadquery as cq
    except ImportError as exc:  # pragma: no cover - depends on the extra
        raise ExportError(
            "E_NO_CADQUERY",
            "export",
            "STEP export needs the generate extra: pip install optikit-core[generate]",
        ) from exc
    return cq


def _revolve(cq: Any, outline: list[tuple[float, float]]) -> Any:
    """Revolve an (r, z) outline about the z axis into a solid."""
    workplane = cq.Workplane("XZ").moveTo(outline[0][0], outline[0][1])
    for r, z in outline[1:]:
        workplane = workplane.lineTo(r, z)
    return workplane.close().revolve(360, (0, 0, 0), (0, 0, 1))


def _element_solid(cq: Any, comp: CompSpec, comp_id: str) -> Any | None:
    """The optical solid a component's own record describes, or None."""
    optics = comp.optics
    if optics is None:
        return None
    if optics.fragment and optics.fragment.surfaces:
        surfaces = optics.fragment.surfaces
        reflective = any(
            (s.get("interaction_model") or {}).get("is_reflective") or s.get("is_reflective")
            for s in surfaces
        )
        if reflective:
            # A mirror has no thickness in the prescription — it is a face.
            # Give it a real disc so CAD has something to collide with.
            semi = max(_surface_values(s)[3] for s in surfaces)
            return cq.Workplane("XY").circle(semi).extrude(-PLATE_THICKNESS_MM)
        # Span = the glass between the first and last face. Zero span means
        # the faces coincide and there is no volume to lathe — the outline
        # would close over a zero-length edge and OCC refuses (BRep_API:
        # command not done). That is exactly what a WP-167 filter (one planar
        # response surface) and a WP-75 thin-lens black box declare: a
        # response at a plane, not a solid. Emitting nothing keeps the STEP
        # at the shape it had while these elements were passthrough.
        span = sum(_surface_values(s)[2] for s in surfaces[:-1])
        if span <= 0.0:
            return None
        return _revolve(cq, lens_profile(surfaces))
    if comp.category == "detector":
        # A sensor is a plate at the port; its size is the clear aperture.
        return cq.Workplane("XY").box(24.0, 18.0, 1.0, centered=(True, True, False))
    return None


def _placement(cq: Any, pose: FlatPose) -> Any:
    """FlatPose → a cadquery Location (rotation matrix + translation)."""
    from OCP.gp import gp_Mat, gp_Quaternion, gp_Trsf, gp_Vec

    r = np.round(pose.rotation, 12)
    mat = gp_Mat(*(float(v) for v in r.flatten()))
    trsf = gp_Trsf()
    px, py, pz = (round(v, ROUND_MM) for v in pose.position_mm)
    trsf.SetTransformation(gp_Quaternion(mat), gp_Vec(px, py, pz))
    return cq.Location(trsf)


def _beam_solid(cq: Any, a: tuple[float, float, float], b: tuple[float, float, float],
                radius: float) -> Any | None:
    """A cylinder from a to b — the beam as something CAD can hold."""
    vec = np.array(b) - np.array(a)
    length = float(np.linalg.norm(vec))
    if length < 1e-6:
        return None
    direction = vec / length
    solid = cq.Workplane("XY").circle(radius).extrude(round(length, ROUND_MM))
    # Point +z along the segment, then move to its start.
    z = np.array([0.0, 0.0, 1.0])
    axis = np.cross(z, direction)
    norm = float(np.linalg.norm(axis))
    if norm > 1e-9:
        angle = math.degrees(math.acos(max(-1.0, min(1.0, float(z @ direction)))))
        solid = solid.rotate(
            (0, 0, 0),
            tuple(round(float(v), ROUND_MM) for v in (axis / norm)),
            round(angle, ROUND_MM),
        )
    elif float(z @ direction) < 0:
        solid = solid.rotate((0, 0, 0), (1, 0, 0), 180)
    return solid.translate(tuple(round(float(v), ROUND_MM) for v in a))


# --- the assembly -------------------------------------------------------------


def _template_step_path(comp: CompSpec, library_root: Path | None) -> Path | None:
    """The placed module's mechanical STEP, when the record ships one."""
    if library_root is None or comp.template is None:
        return None
    step = getattr(comp.template, "step", "") or ""
    if not step:
        return None
    candidate = Path(step)
    if candidate.is_absolute() and candidate.is_file():
        return candidate
    for base in (library_root, library_root.parent):
        hit = base / step
        if hit.is_file():
            return hit
    return None


def _beam_segments(
    decl: DesignDecl, components: dict[str, CompSpec], poses: dict[str, FlatPose]
) -> list[tuple[str, tuple[float, float, float], tuple[float, float, float]]]:
    """The beam as (name, start, end) in the design frame.

    Uses the declared chains' port anchors — the same geometry the schematic
    draws. When a design declares no path there is simply no beam group; we do
    not invent one.
    """
    from ..compile.compiler import _port_frame, parse_chain_entry

    segments: list[tuple[str, tuple[float, float, float], tuple[float, float, float]]] = []
    for path_name in sorted(decl.paths):
        points: list[tuple[float, float, float]] = []
        for raw in decl.paths[path_name].chain:
            try:
                comp_id, port_in, port_out = parse_chain_entry(raw)
            except ValueError:
                continue
            comp = components.get(comp_id)
            if comp is None or comp_id not in poses:
                continue
            for port in (port_in, port_out):
                if not port:
                    continue
                frame = _port_frame(comp_id, comp, port, poses[comp_id])
                point = tuple(round(float(v), ROUND_MM) for v in frame.position)
                if not points or point != points[-1]:
                    points.append(point)  # type: ignore[arg-type]
        for i in range(len(points) - 1):
            segments.append((f"{path_name}/seg-{i + 1:02d}", points[i], points[i + 1]))
    return segments


def export_step(
    decl: DesignDecl,
    out_path: Path,
    *,
    library_root: Path | None = None,
    beam: str = "solid",
    beam_radius_mm: float = BEAM_RADIUS_MM,
) -> ExportReport:
    """Write the design as one grouped STEP assembly; returns what went in.

    ``beam`` is ``solid`` (swept cylinders), ``wires`` (edges only) or
    ``off``.
    """
    if beam not in ("solid", "wires", "off"):
        raise ExportError("E_BAD_BEAM", "export", f"beam must be solid|wires|off, got {beam!r}")
    cq = _require_cadquery()

    components = instantiate(decl)
    poses = flatten(components)
    # WP-177: the optic solid follows the insert re-mount; the mechanics
    # (template STEP = the cube) stay at the module pose.
    optic_pose_map = flatten(components)
    report = ExportReport()

    root = cq.Assembly(name=decl.design.name or "design")

    # Sorted so the STEP tree — and the bytes — are deterministic.
    for comp_id in sorted(components):
        comp = components[comp_id]
        pose = poses.get(comp_id)
        if pose is None:
            continue
        location = _placement(cq, pose)

        step_path = _template_step_path(comp, library_root)
        if step_path is not None:
            try:
                mechanics = cq.importers.importStep(str(step_path))
                root.add(mechanics, name=comp_id, loc=location)
                report.modules.append(comp_id)
            except Exception as exc:  # noqa: BLE001 - a bad STEP must not kill the export
                report.warnings.append(f"{comp_id}: template STEP failed to import ({exc})")

        try:
            solid = _element_solid(cq, comp, comp_id)
        except ExportError as exc:
            report.warnings.append(f"{comp_id}: {exc}")
            solid = None
        if solid is not None:
            optic_location = _placement(cq, optic_pose_map[comp_id])
            root.add(solid, name=f"{comp_id}/optic", loc=optic_location)
            report.optics.append(comp_id)

    if beam != "off":
        segments = _beam_segments(decl, components, poses)
        if segments:
            beams = cq.Assembly(name="beam_path")
            for name, a, b in segments:
                if beam == "solid":
                    geometry = _beam_solid(cq, a, b, beam_radius_mm)
                else:
                    geometry = cq.Workplane("XY").moveTo(a[0], a[1]).workplane(offset=a[2])
                    geometry = cq.Workplane(
                        obj=cq.Edge.makeLine(cq.Vector(*a), cq.Vector(*b))
                    )
                if geometry is not None:
                    beams.add(geometry, name=name)
                    report.beam_segments += 1
            if report.beam_segments:
                root.add(beams, name="beam_path")

    if not report.modules and not report.optics:
        raise ExportError(
            "E_NOTHING_TO_EXPORT",
            decl.design.name or "design",
            "no module STEP and no optical prescription in the whole design — "
            "nothing to put in the file",
        )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    # cadquery 2.8 renamed Assembly.save → .export; keep working on both.
    writer = getattr(root, "export", None) or root.save
    writer(str(out_path))
    return report
