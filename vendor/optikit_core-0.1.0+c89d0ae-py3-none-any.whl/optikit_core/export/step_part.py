"""WP-84: per-part STEP export, posed w.r.t. its CUBE frame.

The Inventor round-trip's outbound leg. An ME who wants to design a cube
module around a housed device (a galvo, a kinematic mount, a laser body)
needs the part exactly where it will sit INSIDE the cube — not at its world
position on the grid. This exporter writes one part as a STEP whose frame is
the part's cube: origin at the cell center, axes the cube's own, the part at
its intra-cube residual pose

    p_cube = R24ᵀ · δ        (the offset-mm decenter, in cube axes)
    R_cube = ΔR              (the offset-deg residual — R_world = R24 · ΔR)

with the design's current ``dof_values`` applied first, so an objective at
dz = 1.85 exports 1.85 mm along its axis — the pose the module must hold.

What lands in the file mirrors the WP-57 assembly exporter, scoped to one
part: the template STEP when the record ships one (the real mechanics) and
the optic solid lathed from the prescription. The return leg — attaching the
resulting Inventor STP/GLB back onto the SAME record — is deliberately not
here: it is a plain file write onto the existing template id
(``/v1/library/save``), no merge logic, because the optical model does not
change.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from ..geometry.cubify import cubify_pose
from ..geometry.flatten import FlatPose, flatten
from ..geometry.rotations import euler_zxy_to_matrix, rot24_matrix
from ..schema.design import DesignDecl
from ..schema.merge import instantiate
from .step_assembly import (
    ExportError,
    ExportReport,
    _element_solid,
    _placement,
    _require_cadquery,
    _template_step_path,
)


def export_step_part(
    decl: DesignDecl,
    component_key: str,
    out_path: Path,
    *,
    library_root: Path | None = None,
) -> ExportReport:
    """Write ONE component as a STEP posed w.r.t. its cube frame."""
    cq = _require_cadquery()

    components = instantiate(decl)
    poses = flatten(components)
    # The current instance state matters: the cube must hold the part where
    # the design actually put it (the same displacement compile applies).
    # WP-230: motion is the pose (instantiate() already evaluated it).

    comp = components.get(component_key)
    pose = poses.get(component_key)
    if comp is None or pose is None:
        raise ExportError(
            "E_BAD_COMPONENT",
            component_key,
            f"design has no component {component_key!r} "
            f"(have: {', '.join(sorted(components))})",
        )

    # World pose → intra-cube pose. R_world = R24 · ΔR, p = S·g + δ.
    cub = cubify_pose(tuple(pose.position_mm), pose.rotation)
    delta_r = euler_zxy_to_matrix(
        cub.offset_deg.get("x", 0.0),
        cub.offset_deg.get("y", 0.0),
        cub.offset_deg.get("z", 0.0),
    )
    r24 = rot24_matrix(*cub.rot24)
    p_cube = r24.T @ np.array(cub.offset_mm, dtype=float)
    cube_pose = FlatPose(
        offset_grid=(0, 0, 0),
        offset_mm=(float(p_cube[0]), float(p_cube[1]), float(p_cube[2])),
        rotation=delta_r,
    )
    location = _placement(cq, cube_pose)

    report = ExportReport()
    root = cq.Assembly(name=f"{component_key}-in-cube")

    step_path = _template_step_path(comp, library_root)
    if step_path is not None:
        try:
            mechanics = cq.importers.importStep(str(step_path))
            root.add(mechanics, name=component_key, loc=location)
            report.modules.append(component_key)
        except Exception as exc:  # noqa: BLE001 — a bad STEP must not kill the export
            report.warnings.append(
                f"{component_key}: template STEP failed to import ({exc})"
            )

    try:
        solid = _element_solid(cq, comp, component_key)
    except ExportError as exc:
        report.warnings.append(f"{component_key}: {exc}")
        solid = None
    if solid is not None:
        root.add(solid, name=f"{component_key}/optic", loc=location)
        report.optics.append(component_key)

    if not report.modules and not report.optics:
        raise ExportError(
            "E_NOTHING_TO_EXPORT",
            component_key,
            "the part has neither a template STEP nor an optical prescription — "
            "nothing to put in the file",
        )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    # cadquery 2.8 renamed Assembly.save → .export; keep working on both.
    writer = getattr(root, "export", None) or root.save
    writer(str(out_path))
    return report
