"""Go-composable ``.dsn`` export (WP-172/173).

Our export is flat — every placed part a leaf ``type: primitive`` whose model
is a LIBRARY ID. Go's designs are recursive assemblies whose model files live
in the design folder. This converts our shape into Go's without losing ours:

- a library-bound primitive becomes ``type: design`` pointing at a materialized
  ``modules/<module-id>.dsn/`` fragment (one per module, shared by placements);
- the fragment holds the mechanical payload — an ``optikit-design.yml`` with
  the template mesh as a ``static-models`` primitive (posed by the template's
  ``mesh-pose``) and the mesh files COPIED IN, so the folder is self-contained;
- the component keeps ``optics``/``dof``/``category`` and gains ``module:``
  naming the library record, so the optical superset and the palette binding
  survive (the module-ref rule and the frontend importer both read it);
- everything else (``paths``, ``variants``, metadata) passes through verbatim.

The result composes in Go (``FSDesign.Flattened`` needs nothing new) and still
compiles HERE via ``design_dir_loader`` — what the round-trip test pins.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ..io.yamlio import dump_design, load_design
from ..library.build import Library, resolve
from ..library.subdesigns import is_library_ref
from ..schema.common import is_expr
from ..schema.design import (
    DESIGN_DECL_FILE,
    ROT_TYPE_GRID,
    ROT_TYPE_UC2,
    DesignDecl,
    DesignSpec,
    PoseSpec,
    PrimSpec,
    RotSpec,
)
from ..schema.library import SUBDESIGN_FILE, ModuleRecord, TemplateRecord
from ..schema.merge import merged_rot

#: Where module fragments land inside the exported design folder.
MODULES_DIR = "modules"
#: …and where library SUBDESIGN folders land (WP-198).
SUBDESIGNS_DIR = "subdesigns"


@dataclass
class GoDsnResult:
    """The exported design folder as a file map (POSIX-relative paths)."""

    files: dict[str, str | bytes] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    #: module id → fragment dir path, for callers that report what nested.
    fragments: dict[str, str] = field(default_factory=dict)


def _go_rotation(rot: RotSpec) -> tuple[RotSpec, str | None]:
    """The rotation re-spelled so Go loses nothing (WP-194).

    Go (@8ccf629) reads ``grid``/``uc2``/``euler``/``quaternion`` and silently
    ignores unknown keys — our ``offset-deg`` residual would VANISH on their
    side. A pure grid rotation is kept verbatim (the discrete state survives
    into Go's report); one carrying a residual is emitted as ``type: euler``
    with the full-rotation extrinsic-ZXY angles, which Go composes to the
    identical matrix. Quaternion/euler inputs normalize first, so the output
    speaks at most two types: ``grid`` and ``euler``.
    """
    rot = rot.normalized()
    if rot.kind not in ("", ROT_TYPE_UC2, ROT_TYPE_GRID):
        return rot, None  # euler-with-templates, z-spherical drafts: verbatim
    off = rot.offset_deg
    leaves = (off.x, off.y, off.z)
    if any(is_expr(v) for v in leaves):
        return rot, (
            "offset-deg holds an unresolved template — Go ignores the "
            "residual; instantiate before exporting"
        )
    if not any(abs(float(v)) > 1e-12 for v in leaves):
        return rot, None
    from ..geometry.rotations import compose, matrix_to_euler_zxy

    full = compose(
        rot.grid.z, rot.grid.x, {"x": float(off.x), "y": float(off.y), "z": float(off.z)}
    )
    ex, ey, ez = matrix_to_euler_zxy(full)
    return (
        RotSpec.model_validate({"kind": "euler", "euler": {"x": ex, "y": ey, "z": ez}}),
        None,
    )


def _module_ref_of(comp) -> str:
    """The component's library reference (``module:`` first, then the model)."""
    extra = getattr(comp, "__pydantic_extra__", None) or {}
    for candidate in (extra.get("module"), extra.get("template")):
        if candidate:
            return str(candidate)
    return comp.primitive.model_path()


def _template_mesh_files(
    template: TemplateRecord, template_dir: Path
) -> dict[str, Path]:
    """format → existing mesh file, honouring the record's declared names.

    The declared name is DATA from a library record, so it is not trusted to
    stay inside the record directory. Copilot review (PR #15, go_dsn.py:75):
    a record with ``glb: ../../../etc/passwd`` made this endpoint read
    arbitrary files off the service host and ship them in the returned ZIP.
    A name that resolves outside its own record is ignored, exactly like a
    name that does not exist.
    """
    out: dict[str, Path] = {}
    base = template_dir.resolve()
    for fmt, declared, default in (
        ("gltf", template.glb, "model.glb"),
        ("step", template.step, "model.step"),
    ):
        candidate = (template_dir / (declared or default)).resolve()
        if base != candidate and base not in candidate.parents:
            continue
        if candidate.is_file():
            out[fmt] = candidate
    return out


def _fragment_decl(
    module: ModuleRecord, template: TemplateRecord, mesh_names: dict[str, str]
) -> DesignDecl:
    """The subdesign declaration for one module fragment."""
    pose = template.mesh_pose
    if pose is None:
        pose = PoseSpec(rotation=RotSpec(kind="grid"))
    else:
        # A housing's mesh-pose may carry a residual offset-deg (§4e) —
        # re-spell it as euler so Go's readers keep the orientation.
        rotation, _ = _go_rotation(pose.rotation)
        pose = PoseSpec(rotation=rotation, translation=pose.translation)
    return DesignDecl.model_validate(
        {
            "optikit-version": "v0.0.0-alpha.1",
            "design": DesignSpec(
                description=module.description or f"library module {module.id}",
                tags=["cube-module", "generated/go-dsn"],
            ).dump(),
            "components": {
                "housing": {
                    "kind": "primitive",
                    "primitive": PrimSpec.model_validate(
                        {"static-models": mesh_names}
                    ).dump(),
                    "pose": pose.dump(),
                }
            },
        }
    )


def _materialize_subdesign(
    comp, comp_id: str, library: Library, result: GoDsnResult
) -> list[str]:
    """Copy a library subdesign's folder into the export and repoint at it."""
    from ..library.subdesigns import SubdesignError, subdesign_dir

    try:
        record, design_file = subdesign_dir(library, comp.design)
    except SubdesignError as exc:
        return [f"{comp_id}: {exc.args[0]} — kept as an unresolvable ref"]
    folder = f"{SUBDESIGNS_DIR}/{record.id}.dsn"
    if record.id not in result.fragments:
        # rglob, not iterdir: a WP-228 record nests further .dsn folders
        # (mirror-static's shape) and Go resolves them relative to the copy.
        for path in sorted(design_file.parent.rglob("*")):
            if not path.is_file() or path.name == SUBDESIGN_FILE:
                continue  # the library record itself is not design data
            rel = path.relative_to(design_file.parent).as_posix()
            name = DESIGN_DECL_FILE if path == design_file else rel
            data = path.read_bytes()
            if path.suffix in (".yml", ".yaml"):
                # Go preserves unknown subtrees (our optics) but JSON-marshals
                # them internally, and ±inf has no JSON spelling — a flat
                # mirror's `radius: .inf` crashed `dev dsn geom report-prim`
                # (9eb701e, "json: unsupported value"). Our dialect reads the
                # STRING spellings back (GO-SYNC §7.3), so the export
                # normalizes to those.
                data = (
                    data.replace(b": .inf", b": 'inf'")
                    .replace(b": -.inf", b": '-inf'")
                    .replace(b": .Inf", b": 'inf'")
                )
            result.files[f"{folder}/{name}"] = data
        result.fragments[record.id] = folder
        # WP-236: the children are optics-only by construction (decompose
        # authors no meshes), so without this the whole subdesign renders
        # empty in a standalone folder. Their paths are relative to THIS
        # folder, which is where Go resolves them from.
        child_decl = load_design(design_file.parent)
        notes: list[str] = []
        child_result = GoDsnResult()
        _placeholder_meshes(child_decl, child_result, prefix=f"{folder}/")
        if child_result.files:
            result.files.update(child_result.files)
            result.files[f"{folder}/{DESIGN_DECL_FILE}"] = dump_design(child_decl)
            notes = [f"{comp_id}/{w}" for w in child_result.warnings]
        result.fragments[record.id] = folder
        if notes:
            return notes
    comp.design = folder
    return []


def _copy_relative_subassembly(
    rel: str, comp_id: str, source_dir: Path | None, result: GoDsnResult
) -> list[str]:
    """Copy a relative ``*.dsn`` folder into the export, recursively (WP-187).

    Returns warnings. Refuses to escape ``source_dir`` (a ``../`` ref would
    otherwise pull arbitrary files into a shared export), and reports rather
    than silently skipping — a dangling ref breaks the whole design in Go, so
    "we could not carry this" has to be visible.
    """
    if source_dir is None:
        return [
            f"{comp_id}: subassembly {rel!r} is a relative path and this export "
            "was given no source directory — its folder is NOT copied and Go "
            "will fail to resolve it (pass source_dir=)"
        ]
    root = source_dir.resolve()
    folder = (root / rel).resolve()
    if root not in folder.parents and folder != root:
        return [f"{comp_id}: subassembly {rel!r} resolves outside the design folder"]
    if not folder.is_dir():
        return [f"{comp_id}: subassembly {rel!r} is not a folder under {root}"]
    if rel in result.fragments:
        return []
    result.fragments[rel] = rel

    warnings: list[str] = []
    for path in sorted(folder.rglob("*")):
        if path.is_file():
            result.files[f"{rel}/{path.relative_to(folder).as_posix()}"] = path.read_bytes()
    # …and anything IT references, one level deeper each time.
    try:
        child = load_design(folder)
    except Exception as exc:
        return [f"{comp_id}: subassembly {rel!r} copied but does not load ({exc})"]
    for child_id, child_comp in child.components.items():
        if child_comp.kind == "design" and child_comp.design and not is_library_ref(
            child_comp.design
        ):
            warnings += _copy_relative_subassembly(
                f"{rel}/{child_comp.design}", f"{comp_id}/{child_id}", source_dir, result
            )
    return warnings


#: Where synthesized stand-in meshes land (WP-236).
PRIMITIVES_DIR = "primitives"


def _placeholder_meshes(decl: DesignDecl, result: GoDsnResult, prefix: str = "") -> None:
    """Give every optics-carrying component without a mesh a stand-in (WP-236).

    A bare optic — a decomposed mirror child, a palette placement, anything
    not backed by a library module — exports with no ``static-models`` at
    all, so the folder is only standalone for the parts that happen to have
    CAD. Outside our editors (which draw a glyph from the prescription) that
    component is simply invisible. A disc sized from its own clear aperture
    is honest about being a placeholder and makes the export renderable
    everywhere.

    ``prefix`` is the path the design file itself sits at, so a subdesign's
    children reference the mesh relative to THEIR folder, as Go resolves it.
    """
    from .primitive_glb import placeholder_glb, semi_aperture_mm

    def _is_mesh_file(ref: str) -> bool:
        return ref.rsplit(".", 1)[-1].lower() in {"glb", "gltf", "step", "stp"} \
            if "." in ref.rsplit("/", 1)[-1] else False

    for comp_id, comp in decl.components.items():
        if comp.kind != "primitive" or comp.optics is None:
            continue
        models = comp.primitive.static_models
        if any(_is_mesh_file(r) for r in (models.gltf, models.step) if r):
            continue
        # A RECORD id in `static-models` (the palette's join key) is not a
        # mesh: the materializer already tried it and found nothing to copy
        # ("kept flat"), so left as-is it dangles — the camera was simply
        # invisible in Go, with no placeholder either.
        if models.gltf and not _is_mesh_file(models.gltf):
            result.warnings.append(
                f"{comp_id}: static-models.gltf {models.gltf!r} is a record "
                "reference, not a mesh file — replaced by the placeholder")
            models.gltf = ""
        radius = semi_aperture_mm(comp.optics)
        name = f"{comp_id.replace('/', '-')}.placeholder.glb"
        result.files[f"{prefix}{PRIMITIVES_DIR}/{name}"] = placeholder_glb(
            comp_id, radius)
        comp.primitive.static_models.gltf = f"{PRIMITIVES_DIR}/{name}"
        comp.primitive.__pydantic_fields_set__.add("static_models")
        comp.__pydantic_fields_set__.add("primitive")
        result.warnings.append(
            f"{comp_id}: no mesh in the record — exported a placeholder disc "
            f"(Ø{radius * 2:g} mm) so the folder renders standalone (WP-236)"
        )


def design_to_go_dsn(
    decl: DesignDecl, library: Library, source_dir: Path | None = None
) -> GoDsnResult:
    """Convert one design into a self-contained, Go-composable folder map.

    ``source_dir`` is the folder the design was LOADED from. Go resolves a
    relative ``design: sub.dsn`` inside that folder, so without it the export
    ships a dangling ref and Go fails to flatten the whole design (WP-187).
    Given it, the referenced folders are copied in — recursively, because a
    subassembly may reference further ones.
    """
    result = GoDsnResult()
    out = decl.model_copy(deep=True)

    # WP-194: residual rotations become Go-readable `type: euler`, because Go
    # silently ignores the unknown `offset-deg` key.
    for comp_id, comp in out.components.items():
        rotation, warning = _go_rotation(comp.pose.rotation)
        if warning:
            result.warnings.append(f"{comp_id}: {warning}")
        if rotation is not comp.pose.rotation:
            comp.pose.rotation = rotation
        # An all-identity pose is OMITTED rather than spelled `kind: grid`
        # with no axes: go3d's ExtractEulerAngles (Asin, unclamped) NaNs on a
        # composed subassembly with ±90° pitch when the parent carries the
        # explicit empty-grid pose, and works when the pose is absent
        # (verified @9eb701e; the one-line clamp is filed in GO-SYNC §6b).
        pose = comp.pose
        if (
            pose.rotation.kind in ("", "grid", "uc2")
            and not pose.rotation.grid.z and not pose.rotation.grid.x
            and not any((pose.rotation.offset_deg.x, pose.rotation.offset_deg.y,
                         pose.rotation.offset_deg.z))
            and comp.model_fields_set  # pydantic guard: pose may be defaulted
        ):
            t = pose.translation
            zero = lambda v: not v  # noqa: E731 — 0 and 0.0 and "" are all identity
            if (
                all(zero(getattr(t.offset_grid, a)) for a in "xyz")
                and all(zero(getattr(t.offset_mm, a)) for a in "xyz")
                and not t.anchor
            ):
                comp.model_fields_set.discard("pose")
    # WP-196: the same for a residual inside a VARIANT overlay, which WP-194
    # had to leave verbatim. An overlay is a delta, so it cannot be converted
    # on its own — but now that the merge is type-switched (Go:
    # CompPoseRotExprSpec.Merged), an overlay that names `type: euler` DROPS
    # the base's grid, so writing the MERGED rotation's full euler triple
    # there reproduces our composed matrix exactly on Go's side. This bakes
    # the base into the overlay, which is right for an export snapshot and
    # wrong for authoring — so it happens here, never in the document.
    for variant_id, variant in out.variants.items():
        for comp_id, comp in variant.components.items():
            base = decl.components.get(comp_id)
            merged = merged_rot(base.pose.rotation, comp.pose.rotation) if base else None
            rotation, warning = _go_rotation(merged or comp.pose.rotation)
            if warning:
                result.warnings.append(f"variants.{variant_id}.{comp_id}: {warning}")
                continue
            if rotation.kind == "euler":
                comp.pose.rotation = rotation
    # Go @21dc193 removed the top-level `instantiation:` (it lives on the
    # component now) and ignores unknown keys, so ours would VANISH there:
    # a design saved as "variant z, off-axis true" would render as its base.
    inst = out.instantiation
    if inst.variant or inst.inputs:
        result.warnings.append(
            f"instantiation: top-level variant/inputs "
            f"({inst.variant or 'inputs'!r}) is not read by Go — it selects the "
            f"design's own instantiation, which Go takes from its caller; "
            f"export the instantiated design if you need it baked in"
        )

    for comp_id, comp in out.components.items():
        if comp.kind == "design" and is_library_ref(comp.design):
            # WP-198: a placed subdesign-backed module. Its design is a
            # LIBRARY ref, meaningless to Go — materialize the record's
            # design folder (design file + its meshes) and repoint at it,
            # the same rule `static-models` follows for library ids.
            result.warnings.extend(
                _materialize_subdesign(comp, comp_id, library, result)
            )
            continue
        if comp.kind == "design":
            # WP-187: a relative `*.dsn` path. Go resolves it inside the
            # design folder, so the folder must travel with the export or the
            # ref dangles and Go fails to flatten everything.
            result.warnings.extend(
                _copy_relative_subassembly(comp.design, comp_id, source_dir, result)
            )
            continue
        if comp.kind != "primitive":
            continue
        ref = _module_ref_of(comp)
        if not ref:
            continue
        try:
            hit = resolve(library, ref if "@" in ref else f"{ref}@*")
        except ValueError:
            # Not a record reference at all (e.g. a raw STEP filename) —
            # a legal leaf, kept as-is.
            continue
        if hit is None or not isinstance(hit.record, ModuleRecord):
            # Bare optics, foreign refs: legal leaves, kept as-is.
            continue
        module = hit.record
        tpl_hit = resolve(library, module.template)
        if tpl_hit is None or not isinstance(tpl_hit.record, TemplateRecord):
            result.warnings.append(
                f"{comp_id}: module {module.id} has no resolvable template "
                f"({module.template!r}) — kept flat"
            )
            continue
        template = tpl_hit.record
        mesh_files = _template_mesh_files(template, tpl_hit.path.parent)
        if not mesh_files:
            result.warnings.append(
                f"{comp_id}: template {template.id} bundles no mesh files — kept flat"
            )
            continue

        fragment_dir = f"{MODULES_DIR}/{module.id}.dsn"
        if module.id not in result.fragments:
            mesh_names = {fmt: path.name for fmt, path in mesh_files.items()}
            fragment = _fragment_decl(module, template, mesh_names)
            result.files[f"{fragment_dir}/optikit-design.yml"] = dump_design(fragment)
            for path in mesh_files.values():
                result.files[f"{fragment_dir}/{path.name}"] = path.read_bytes()
            result.fragments[module.id] = fragment_dir

        if comp.instantiation.inputs:
            result.warnings.append(
                f"{comp_id}: DOF values ride instantiation.inputs (D1) but "
                f"the module fragment declares no inputs yet — inert in Go "
                f"until the subdesign packaging binds them (WP-198)"
            )
        comp.kind = "design"
        comp.design = fragment_dir
        comp.primitive = PrimSpec()
        # Unmark so the emptied primitive is omitted from the serialization
        # (dump() is exclude_unset — Go's zero value carries no information).
        comp.__pydantic_fields_set__.discard("primitive")
        # Extension field: the palette binding survives the shape change
        # (the frontend importer resolves `module:` first, same as here).
        comp.module = f"{module.id}@{module.version}"

    _placeholder_meshes(out, result)
    result.files["optikit-design.yml"] = dump_design(out)
    return result
