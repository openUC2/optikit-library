"""Shared scalar and vector types for the design schema.

Semantics mirror the Go reference (github.com/openUC2/optikit,
exp/designs/geometry.go + designs-decl.go); this package is the normative
implementation and the Go repo conforms to it (see kicad-for-optics-execution.md).

Any numeric leaf may instead hold an EXPRESSION string (WP-195, Go @8ccf629):
expr-lang syntax over the design's declared inputs, e.g. ``-0.5 - 3`` or
``~ inputs['off-axis'].value ? 45 : 0`` — see
:mod:`optikit_core.schema.expressions`. On numeric leaves the ``~ `` prefix
is cosmetic (Go compiles these fields unconditionally). Expression values are
preserved verbatim by the schema, skipped by numeric semantic checks, and
resolved by ``schema.merge.instantiate()``; a value still unresolved by the
time an engine needs the number is a typed ``E_TEMPLATED``.

(The pre-WP-195 ``'{{get inputs "x"}}'`` Go-template spelling came from an
UNIMPLEMENTED sketch in the corpus — Ethan's shipped implementation is
expr-lang, and that is the contract now.)
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, field_validator


def is_expr(value: Any) -> bool:
    """True if the value is an (unresolved) expression string, not a literal."""
    return isinstance(value, str)


# Numeric leaves: literal number, or an expression string resolved at instantiation.
ExprFloat = float | int | str
ExprInt = int | str

# Axis direction names, exactly the six used by the Go reference.
AXIS_DIRS = ("+x", "-x", "+y", "-y", "+z", "-z")
AXES = ("x", "y", "z")


class SchemaModel(BaseModel):
    """Base for all schema models.

    ``extra="allow"`` keeps unknown keys so that (a) draft syntax in existing designs
    survives a load→dump round trip losslessly and (b) newer documents degrade
    gracefully in older tools. Semantic errors are reported by ``checks.check()``,
    not by structural parsing.
    """

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
        validate_assignment=True,
        # Keep infinities (flat surfaces use radius: .inf) instead of nulling them.
        ser_json_inf_nan="constants",
    )

    def dump(self) -> dict[str, Any]:
        """Dump to plain data using YAML key aliases, omitting unset fields."""
        return self.model_dump(mode="json", by_alias=True, exclude_unset=True)


class DiscreteXYZ(SchemaModel):
    """Integer vector, e.g. ``offset-grid: {x: 1, y: 0, z: -2}`` (units: grid cells)."""

    x: ExprInt = 0
    y: ExprInt = 0
    z: ExprInt = 0

    @field_validator("x", "y", "z", mode="before")
    @classmethod
    def _no_float_cells(cls, v: Any) -> Any:
        if isinstance(v, float) and not v.is_integer():
            raise ValueError(f"grid offsets must be integers, got {v}")
        return int(v) if isinstance(v, float) else v


class ContinuousXYZ(SchemaModel):
    """Float vector, e.g. ``offset-mm: {x: -80}`` (units given by the field name)."""

    x: ExprFloat = 0.0
    y: ExprFloat = 0.0
    z: ExprFloat = 0.0


def reject_type_key(data):
    """Before-validator for Go-renamed models (openUC2/optikit#20): ``type`` →
    ``kind``. With ``extra="allow"`` an old document would otherwise validate
    SILENTLY (``type`` lands in extras, ``kind`` defaults to "") and mean the
    wrong thing — so the old spelling is a hard, pointed error instead."""
    if isinstance(data, dict) and "type" in data:
        raise ValueError(
            "'type' was renamed to 'kind' (Go schema, openUC2/optikit#20); "
            "run `optikit-core library migrate --root <tree>` on this tree"
        )
    return data
