"""Instantiation: variant overlays + input-variable evaluation (Go: Instantiated).

Mirrors ``DesignExprDecl.Instantiated`` (openUC2/optikit@8ccf629) in Go's order:

1. **Variant merge** — overlay onto base, ``cmp.Or`` per field (overlay wins
   iff non-zero). Two refinements the naive reading gets wrong (WP-196):
   Go's "an overlay can never reset a field to zero" quirk now survives only
   for genuine STRING fields, because @8ccf629 made every numeric leaf an
   ``Expr`` — an authored ``x: 0`` is ``"0"``, non-zero, and DOES override
   (:func:`_merged_xyz` mirrors this with ``fields_set``); and rotations merge
   TYPE-SWITCHED (:func:`merged_rot`), so a `grid` → `euler` overlay drops the
   base's grid rather than composing with it.
2. **Environment** — caller input values coerced to the merged declared types
   (:func:`optikit_core.schema.inputs.make_env`).
3. **Evaluation** — expressions resolve in the fields Go compiles (pose
   ``euler``/``offset-mm``/``offset-grid``, ``instantiation.inputs`` always,
   ``instantiation.variant`` only when ``~ ``-prefixed), plus our ``offset-deg``
   residual, which rides the same environment.

Overlays may themselves hold expressions — merged before evaluation, so a
variant can re-pose a component by an input value.
"""

from __future__ import annotations

from typing import Any, TypeVar

from .common import ContinuousXYZ, DiscreteXYZ, is_expr
from .design import (
    ROT_TYPE_EULER,
    ROT_TYPE_GRID,
    ROT_TYPE_QUATERNION,
    ROT_TYPE_UC2,
    ROT_TYPE_Z_SPHERICAL,
    CompInstSpec,
    CompSpec,
    DesignDecl,
    InstSpec,
    PoseSpec,
    PrimSpec,
    RotGridSpec,
    RotSpec,
    StaticModelsSpec,
    TranslSpec,
)
from .expressions import E_EXPR_TYPE, EXPR_PREFIX, ExprError, evaluate
from .inputs import InputVarSpec, make_env

# --- variant merging (Go: XSpec.Merged, cmp.Or per field) --------------------------


T = TypeVar("T")


def _or(overlay: T, base: T) -> T:
    """Go's cmp.Or over a STRING field: overlay unless it is empty.

    Correct for `type`, `design`, `anchor`, the grid axis names — every field
    that is a Go `string`, where an explicitly authored ``""`` and an absent
    key are the same value. NOT correct for numeric leaves: see
    :func:`_merged_xyz`.
    """
    return overlay if overlay else base


_XYZ = TypeVar("_XYZ", DiscreteXYZ, ContinuousXYZ)


def _merged_xyz(base: _XYZ, overlay: _XYZ) -> _XYZ:
    """Per-leaf merge of a numeric vector — authored-in-the-overlay wins.

    Go's XYZ leaves are `Expr` STRINGS since @8ccf629, so its `cmp.Or` defers
    to the base only when the overlay leaf is ABSENT (the zero value ``""``):
    an authored ``x: 0`` arrives as the non-empty expression ``"0"`` and DOES
    override. Our leaves are real numbers, where `cmp.Or` on a falsy ``0``
    would silently keep the base instead — the one place the documented
    "an overlay cannot reset a field to zero" quirk does NOT apply to Go any
    more. Pydantic's ``fields_set`` is the faithful mirror of "the author
    wrote this leaf", so a variant CAN zero an offset, exactly like Go.
    """
    values = {
        axis: getattr(overlay if axis in overlay.__pydantic_fields_set__ else base, axis)
        for axis in ("x", "y", "z")
    }
    extras = {**(base.model_extra or {}), **(overlay.model_extra or {})}
    return type(base)(**extras, **values)


#: Kept as the historical spelling for callers; both vectors merge alike now.
merged_xyz_int = _merged_xyz
merged_xyz_float = _merged_xyz


def merged_rot(base: RotSpec, overlay: RotSpec) -> RotSpec:
    """Rotation overlay, TYPE-SWITCHED like Go (``CompPoseRotExprSpec.Merged``).

    The merged type is ``cmp.Or(overlay.kind, base.kind)`` and ONLY that type's
    parameter family survives: a `grid` → `euler` variant DROPS the base's grid
    rather than composing with it (which is how `mounted-mirror.dsn`'s `xy`
    variant means "45° about z", not "45° on top of whatever the base named").
    Go's ``default`` returns the ZERO rotation, so an untyped pair merges to
    "no spatial geometry".

    Three riders of ours: ``offset-deg`` belongs to the grid/uc2 branch (it is
    the ΔR in ``R = R24 · ΔR``, meaningless without its R24) and is dropped by
    the euler/quaternion branches, which already carry a full rotation;
    ``z-spherical`` (draft) gets its own branch instead of being zeroed; and an
    unknown non-empty type keeps its NAME instead of being zeroed, so
    ``checks.check()`` can still report ``E_ROT_TYPE``. None of this can change
    a Go-valid document — Go writes only the four known types.

    Extras are preserved (GO-SYNC §4; Go's fixed struct has none).
    """
    merged_type = _or(overlay.kind, base.kind)
    extras = {**(base.model_extra or {}), **(overlay.model_extra or {})}
    if merged_type in (ROT_TYPE_UC2, ROT_TYPE_GRID):
        return RotSpec(
            **extras,
            kind=merged_type,
            grid=RotGridSpec(
                z=_or(overlay.grid.z, base.grid.z),
                x=_or(overlay.grid.x, base.grid.x),
            ),
            **{"offset-deg": _merged_xyz(base.offset_deg, overlay.offset_deg)},
        )
    if merged_type == ROT_TYPE_EULER:
        return RotSpec(
            **extras, kind=merged_type, euler=_merged_xyz(base.euler, overlay.euler)
        )
    if merged_type == ROT_TYPE_QUATERNION:
        return RotSpec(
            **extras,
            kind=merged_type,
            quaternion=_or(overlay.quaternion, base.quaternion),
        )
    if merged_type == ROT_TYPE_Z_SPHERICAL:
        return RotSpec(
            **extras,
            kind=merged_type,
            **{"z-spherical": _or(overlay.z_spherical, base.z_spherical)},
        )
    # Go's `default` branch: the zero rotation. An unknown type is kept (above).
    return RotSpec(**extras, kind=merged_type) if merged_type else RotSpec(**extras)


def merged_transl(base: TranslSpec, overlay: TranslSpec) -> TranslSpec:
    return TranslSpec(
        anchor=_or(overlay.anchor, base.anchor),
        **{"offset-grid": _merged_xyz(base.offset_grid, overlay.offset_grid)},
        **{"offset-mm": _merged_xyz(base.offset_mm, overlay.offset_mm)},
    )


def merged_pose(base: PoseSpec, overlay: PoseSpec) -> PoseSpec:
    return PoseSpec(
        rotation=merged_rot(base.rotation, overlay.rotation),
        translation=merged_transl(base.translation, overlay.translation),
    )


def merged_static_models(
    base: StaticModelsSpec, overlay: StaticModelsSpec
) -> StaticModelsSpec:
    """`static-models` merged WITHOUT losing keys we do not model yet.

    reconstructing this from `gltf` and
    `step` alone silently dropped every other key. `SchemaModel` is
    `extra="allow"` precisely so Go can add fields ahead of us — `bom:` is one
    today — and a load → variant-merge → dump round trip must not eat them.
    Extras follow the same rule as the named fields: overlay wins, base shows
    through where the overlay is silent.
    """
    extras = {**(base.model_extra or {}), **(overlay.model_extra or {})}
    return StaticModelsSpec(
        **extras,
        gltf=_or(overlay.gltf, base.gltf),
        step=_or(overlay.step, base.step),
    )


def merged_prim(base: PrimSpec, overlay: PrimSpec) -> PrimSpec:
    return PrimSpec(
        kind=_or(overlay.kind, base.kind),
        static_models=merged_static_models(base.static_models, overlay.static_models),
        function=_or(overlay.function, base.function),
        inputs=_or(overlay.inputs, base.inputs),
    )


def merged_inst(base: CompInstSpec, overlay: CompInstSpec) -> CompInstSpec:
    """Per-component instantiation overlay (Go: `InstExprSpec.Merged`).

    ``variant`` follows cmp.Or. Input VALUES merge **per key** with the same
    rule over Go's `Expr` strings: an overlay key wins unless it is the empty
    expression, which defers to the base. A key the overlay does not mention
    is untouched — so a variant can re-bind one input without restating the
    others.
    """
    inputs = dict(base.inputs)
    for name, value in overlay.inputs.items():
        if value == "" and name in inputs:
            continue
        inputs[name] = value
    return CompInstSpec(variant=_or(overlay.variant, base.variant), inputs=inputs)


def merged_comp(base: CompSpec, overlay: CompSpec) -> CompSpec:
    """Merge one component overlay onto a base component (Go: CompSpec.Merged).

    Every field is carried. Until WP-195 this function rebuilt a CompSpec from
    nine fields and silently dropped `category`,
    `enabled`, `wavelength_um`, `source`, `programmable` and every extension
    key — selecting any variant corrupted the component (WP-196a, pulled
    forward). Go-shaped fields follow cmp.Or; our v0-extension objects overlay
    wholesale when the overlay explicitly sets them (they are authored, not
    diffed); extras merge overlay-wins.
    """
    explicitly = overlay.__pydantic_fields_set__
    extras = {**(base.model_extra or {}), **(overlay.model_extra or {})}
    return CompSpec(
        **extras,
        kind=_or(overlay.kind, base.kind),
        category=_or(overlay.category, base.category),
        design=_or(overlay.design, base.design),
        primitive=merged_prim(base.primitive, overlay.primitive),
        pose=merged_pose(base.pose, overlay.pose),
        optics=overlay.optics if overlay.optics is not None else base.optics,
        template=overlay.template if overlay.template is not None else base.template,
        enabled=overlay.enabled if "enabled" in explicitly else base.enabled,
        wavelength_um=(
            overlay.wavelength_um
            if overlay.wavelength_um is not None
            else base.wavelength_um
        ),
        source=overlay.source if overlay.source is not None else base.source,
        programmable=(
            overlay.programmable if overlay.programmable is not None else base.programmable
        ),
        instantiation=merged_inst(base.instantiation, overlay.instantiation),
        computation=_or(overlay.computation, base.computation),
    )


def merged_components(
    base: dict[str, CompSpec], overlay: dict[str, CompSpec]
) -> dict[str, CompSpec]:
    """Apply a variant's component overlay (Go: CompsSpec.Merged)."""
    merged = dict(base)
    for comp_id, over in overlay.items():
        if comp_id in merged:
            merged[comp_id] = merged_comp(merged[comp_id], over)
        else:
            merged[comp_id] = over
    return merged


def merged_input_decls(
    base: dict[str, InputVarSpec], overlay: dict[str, InputVarSpec]
) -> dict[str, InputVarSpec]:
    """A variant's input-declaration overlay (Go: InputsSpec.Merged) —
    per entry, per field, overlay-wins-iff-non-zero."""
    merged = dict(base)
    for name, over in overlay.items():
        already = merged.get(name)
        if already is None:
            merged[name] = over
            continue
        merged[name] = InputVarSpec(
            description=_or(over.description, already.description),
            kind=_or(over.kind, already.kind),
            units=_or(over.units, already.units),
            min=over.min if over.min is not None else already.min,
            max=over.max if over.max is not None else already.max,
        )
    return merged


# --- expression evaluation (Go: CompExprsSpec.Evaluated) ---------------------------


def _located(exc: ExprError, where: str) -> ExprError:
    relocated = ExprError(exc.code, f"{where}: {exc.args[0].split(': ', 1)[-1]}")
    return relocated


def _eval_number(value: Any, env: dict, where: str, *, integer: bool = False) -> Any:
    """A numeric leaf: literal numbers pass, strings evaluate (Go compiles both)."""
    if not is_expr(value):
        return value
    try:
        result = evaluate(value, env)
    except ExprError as exc:
        raise _located(exc, where) from None
    if isinstance(result, bool) or not isinstance(result, int | float):
        raise ExprError(E_EXPR_TYPE, f"{where}: {value!r} evaluated to {result!r}, need a number")
    if integer:
        if float(result).is_integer():
            return int(result)
        raise ExprError(
            E_EXPR_TYPE, f"{where}: {value!r} evaluated to {result!r}, need an integer"
        )
    return float(result)


def _eval_xyz(
    vec: ContinuousXYZ | DiscreteXYZ, env: dict, where: str, *, integer: bool = False
) -> ContinuousXYZ | DiscreteXYZ:
    updates = {
        axis: _eval_number(getattr(vec, axis), env, f"{where}.{axis}", integer=integer)
        for axis in ("x", "y", "z")
        if is_expr(getattr(vec, axis))
    }
    return vec.model_copy(update=updates) if updates else vec


def _evaluated_comp(comp_id: str, comp: CompSpec, env: dict) -> CompSpec:
    """The component with Go's expression fields resolved against ``env``."""
    where = f"components.{comp_id}"
    pose_updates: dict[str, Any] = {}

    rot = comp.pose.rotation
    rot_updates: dict[str, Any] = {}
    euler = _eval_xyz(rot.euler, env, f"{where}.pose.rotation.euler")
    if euler is not rot.euler:
        rot_updates["euler"] = euler
    offset_deg = _eval_xyz(rot.offset_deg, env, f"{where}.pose.rotation.offset-deg")
    if offset_deg is not rot.offset_deg:
        rot_updates["offset_deg"] = offset_deg
    if rot_updates:
        pose_updates["rotation"] = rot.model_copy(update=rot_updates)

    transl = comp.pose.translation
    transl_updates: dict[str, Any] = {}
    offset_mm = _eval_xyz(transl.offset_mm, env, f"{where}.pose.translation.offset-mm")
    if offset_mm is not transl.offset_mm:
        transl_updates["offset_mm"] = offset_mm
    offset_grid = _eval_xyz(
        transl.offset_grid, env, f"{where}.pose.translation.offset-grid", integer=True
    )
    if offset_grid is not transl.offset_grid:
        transl_updates["offset_grid"] = offset_grid
    if transl_updates:
        pose_updates["translation"] = transl.model_copy(update=transl_updates)

    updates: dict[str, Any] = {}
    if pose_updates:
        updates["pose"] = comp.pose.model_copy(update=pose_updates)

    inst = comp.instantiation
    inst_updates: dict[str, Any] = {}
    if inst.variant.startswith(EXPR_PREFIX):
        # The one field where `~ ` is load-bearing: unprefixed = literal id.
        try:
            selected = evaluate(inst.variant, env)
        except ExprError as exc:
            raise _located(exc, f"{where}.instantiation.variant") from None
        if not isinstance(selected, str):
            raise ExprError(
                E_EXPR_TYPE,
                f"{where}.instantiation.variant: {inst.variant!r} evaluated to "
                f"{selected!r}, need a variant id (string)",
            )
        inst_updates["variant"] = selected
    if any(is_expr(v) for v in inst.inputs.values()):
        evaluated_inputs = dict(inst.inputs)
        for name, value in inst.inputs.items():
            if not is_expr(value):
                continue
            try:
                evaluated_inputs[name] = evaluate(value, env)
            except ExprError as exc:
                raise _located(exc, f"{where}.instantiation.inputs.{name}") from None
        inst_updates["inputs"] = evaluated_inputs
    if inst_updates:
        updates["instantiation"] = inst.model_copy(update=inst_updates)

    return comp.model_copy(update=updates) if updates else comp


# --- the pipeline (Go: DesignExprDecl.Instantiated) --------------------------------


def instantiate(
    decl: DesignDecl, instantiation: InstSpec | None = None
) -> dict[str, CompSpec]:
    """Variant-merged, expression-evaluated components (Go: Instantiated).

    With no variant selected the base components are used; input values from
    ``instantiation.inputs`` (missing ones: the declared type's zero value)
    feed the expression environment either way. Requesting a variant that
    does not exist raises KeyError; expression and input failures raise the
    typed :class:`ExprError` / :class:`~optikit_core.schema.inputs.InputError`.
    """
    inst = instantiation if instantiation is not None else decl.instantiation
    comps = dict(decl.components)
    declared = dict(decl.inputs)
    if inst.variant:
        if inst.variant not in decl.variants:
            raise KeyError(f"requested variant not found: {inst.variant}")
        variant = decl.variants[inst.variant]
        comps = merged_components(comps, variant.components)
        declared = merged_input_decls(declared, variant.inputs)
    env = make_env(inst.inputs, declared)
    return {
        comp_id: _evaluated_comp(comp_id, comp, env)
        for comp_id, comp in comps.items()
    }
