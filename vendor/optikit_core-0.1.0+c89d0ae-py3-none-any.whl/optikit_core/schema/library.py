"""Library record schemas: the three git-versioned record kinds.

Mirrors KiCad's symbol / footprint / library-part split (execution plan WS-C1):

- **optical component** ("symbol") — the physics: an Optiland fragment plus
  datum frames, ports, and vendor provenance.
- **mechanical template** ("footprint") — how the optic is held: the T1/T2/T3
  class, envelope, degrees of freedom, and a geometry source reference.
- **cube module** ("library part") — binds one component to one template and
  adds the optional electronics contract.

Records reuse the design-time models (``OpticsSpec``, ``EnvelopeSpec``,
``DofSpec``, ``GeneratorSpec``, ``PortSpec``) so a component's optics are
authored once and dropped verbatim into a design's ``optics`` block.

Ids are namespaced ``<vendor>.<kind>.<name>`` — ``openuc2.*`` / ``thorlabs.*``
/ ``user.*``. Every record carries a semver ``version``; setups pin exact
versions at export (lockfile).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Literal

from pydantic import Field, field_validator, model_validator

from .common import SchemaModel
from .design import (
    KNOWN_CATEGORIES,
    DetectorSpec,
    EnvelopeSpec,
    FrameSpec,
    GeneratorSpec,
    ObjectiveSpec,
    OpticsSpec,
    PortSpec,
    PoseSpec,
    ProgrammableSpec,
    RotGridSpec,
    SourceSpec,
    TemplateClass,
    _dashed,
)

#: A library record file is named after its kind.
COMPONENT_FILE = "component.yml"
TEMPLATE_FILE = "template.yml"
MODULE_FILE = "module.yml"
GROUP_FILE = "group.yml"
SUBDESIGN_FILE = "subdesign.yml"

_SEMVER_RE = re.compile(
    r"^\d+\.\d+\.\d+(?:-[0-9A-Za-z-.]+)?(?:\+[0-9A-Za-z-.]+)?$"
)
_ID_RE = re.compile(r"^[a-z0-9]+(?:\.[a-z0-9][a-z0-9_-]*)+$")
#: A dependency reference: ``<id>@<range>`` where range is a semver or caret/tilde range.
_REF_RE = re.compile(r"^(?P<id>[a-z0-9][a-z0-9_.-]+)@(?P<range>[\^~]?[0-9].*|\*|latest)$")

KNOWN_NAMESPACES = ("openuc2", "thorlabs", "user")


class VendorSpec(SchemaModel):
    """Commercial provenance of a purchased optic."""

    name: str = ""
    mpn: str = ""  # manufacturer part number
    url: str = ""
    #: Unit price as the vendor lists it (a snapshot, never a quote); None = unpriced.
    price: float | None = None
    currency: str = "EUR"


class RecordBase(SchemaModel):
    """Fields shared by every library record kind."""

    id: str
    version: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    docs: list[str] = Field(default_factory=list)
    thumbnail: str = ""
    #: Free-form list of unresolved authoring issues (populated by importers).
    #: A record with a non-empty review block validates but is flagged as a
    #: draft in the index.
    review: list[str] = Field(default_factory=list)
    #: A curated record the tests, the golden designs or the FRAME configurator
    #: rely on: the service refuses to overwrite or archive it
    #: (`E_RECORD_LOCKED`) unless `OPTIKIT_ALLOW_LOCKED_WRITE=1`; the PR road
    #: and the CLI still change it. Library-level — nothing on the DSN wire.
    locked: bool = False

    @field_validator("version")
    @classmethod
    def _semver(cls, v: str) -> str:
        if not _SEMVER_RE.match(v):
            raise ValueError(f"version {v!r} is not semver (MAJOR.MINOR.PATCH)")
        return v

    @field_validator("id")
    @classmethod
    def _namespaced_id(cls, v: str) -> str:
        if not _ID_RE.match(v):
            raise ValueError(
                f"id {v!r} must be dotted lowercase, e.g. openuc2.lens.achromat_25mm_f50"
            )
        return v

    @property
    def namespace(self) -> str:
        return self.id.split(".", 1)[0]


class ComponentRecord(RecordBase):
    """Optical component — the "symbol"."""

    kind: Literal["optical_component"] = "optical_component"
    category: str
    # WP-30: non-optical records (electronics/mechanics) carry no optics —
    # an absent block defaults to an empty OpticsSpec.
    optics: OpticsSpec = Field(default_factory=OpticsSpec)
    vendor: VendorSpec = Field(default_factory=VendorSpec)
    #: Effective focal length in mm, when meaningful (informational; the truth
    #: is the fragment). Populated by importers where derivable.
    effective_focal_length_mm: float | None = None
    #: WP-47: what a `category: source` record emits (line list + divergence).
    source: SourceSpec | None = None
    #: WP-47: pixel-addressable surface facts for `slm`/`display` records.
    programmable: ProgrammableSpec | None = None
    #: Objective fact sheet (mag/NA/WD…) — what a per-slot picker shows.
    objective: ObjectiveSpec | None = None
    #: Camera fact sheet (pixel pitch…) — what the Nyquist check reads.
    detector: DetectorSpec | None = None
    #: WP-48: relative path to an authored schematic symbol (SVG) next to this
    #: record. Optional — the editors derive a glyph from category + surfaces
    #: when it is absent, and the symbol NEVER defines connectivity (pins keep
    #: coming from optics.ports). Contract: viewBox centered on the part
    #: origin, 1 unit = 1 mm, beam axis +x, `currentColor` strokes so the
    #: symbol themes with light/dark.
    symbol: str = ""

    @field_validator("category")
    @classmethod
    def _known_category(cls, v: str) -> str:
        if v not in KNOWN_CATEGORIES:
            raise ValueError(f"unknown category {v!r} (one of {KNOWN_CATEGORIES})")
        return v


class GroovesSpec(SchemaModel):
    """The cube's holder groove lattice (WP-35, T2): positions g_n = center +
    n·pitch for n in −(count−1)/2 … +(count−1)/2. A T2 holder clamps a groove
    pair with its origin at the pair midpoint; the optic keeps a bounded
    continuous offset inside the pocket. Pitch comes from the Inventor master
    design — never hardcode it."""

    model_config = SchemaModel.model_config | {"alias_generator": _dashed}

    pitch_mm: float
    count: int = 7
    center_mm: float = 0.0

    def positions_mm(self) -> list[float]:
        half = (self.count - 1) // 2
        return [self.center_mm + n * self.pitch_mm for n in range(-half, half + 1)]


class BaySpec(SchemaModel):
    """A docking region on a carrier where a cube array (or group) fits (WP-45).

    ``origin-cell`` is the bay's lower corner in the carrier's own grid frame
    (relative to the carrier's placement cell); ``size`` its extent in cells.
    The miniFRAME bay of the FRAME is the canonical case: 3x3x2 cubes.
    """

    origin_cell: tuple[int, int, int] = Field(default=(0, 0, 0), alias="origin-cell")
    size: tuple[int, int, int] = (1, 1, 1)
    #: Optical axis constraint of the bay ("" = none): the docked group's
    #: vertical beam must align with the carrier axis (FRAME objective axis).
    axis: str = ""


class MountSpec(SchemaModel):
    """A docking pose on a carrier for one non-cube part (one whose template
    declares ``fits: <accepts>``). Millimetres only: ``offset-mm`` plus a grid
    rotation and an optional ``offset-deg`` residual — no ``offset-grid``, no
    ``anchor``."""

    #: Where the mounted part's origin sits, in the carrier's frame.
    pose: PoseSpec = Field(default_factory=PoseSpec)
    #: The interface key a part must declare as ``fits`` to dock here.
    accepts: str

    @field_validator("accepts")
    @classmethod
    def _named_interface(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("mount accepts must name an interface key")
        return v

    @field_validator("pose")
    @classmethod
    def _mm_only(cls, v: PoseSpec) -> PoseSpec:
        t = v.translation
        if t.anchor or any((t.offset_grid.x, t.offset_grid.y, t.offset_grid.z)):
            raise ValueError(
                "mount poses are millimetres only: offset-mm, no offset-grid, no anchor"
            )
        if v.rotation.kind not in ("", "uc2", "grid"):
            raise ValueError(
                f"mount pose rotation must be a grid rotation, got {v.rotation.kind!r}"
            )
        return v


class TemplateRecord(RecordBase):
    """Mechanical template — the "footprint", classified by DOF."""

    kind: Literal["mechanical_template"] = "mechanical_template"
    class_: TemplateClass = Field(alias="class")
    envelope: EnvelopeSpec = Field(default_factory=EnvelopeSpec)
    #: WP-45: carriers are mechanics that HOST cubes (FRAME, baseplates,
    #: puzzle pieces, sandwich plates) rather than filling a cell themselves.
    carrier: bool = False
    #: Named docking bays (carrier templates only).
    bays: dict[str, BaySpec] = Field(default_factory=dict)
    #: Named docking poses for non-cube parts (carrier templates only).
    mounts: dict[str, MountSpec] = Field(default_factory=dict)
    #: The mount interface key this template fills ("" = not mountable).
    fits: str = ""
    #: WP-192: which mesh subtrees each DOF moves. A consumer holding the GLB
    #: and a ``dof_values`` map poses the mechanism without asking anyone —
    #: the assembly canvas, the optimizer preview, and newswitch's live view
    #: all read this one table.
    #: Named datum frames of the template itself (WP-35, T1): where the
    #: mechanics HOLD the optic, in the cube frame — verify-t1 asserts the
    #: bound component's optical frame lands here.
    frames: dict[str, FrameSpec] = Field(default_factory=dict)
    #: T2 groove lattice (None = template is not lattice-placed).
    grooves: GroovesSpec | None = None
    #: Where the mechanics come from — exactly one of these is normally set.
    #: (An `inventor:` urn naming a master part on the Inventor machine lived
    #: here until the bridge was retired. `extra="allow"` means a record that
    #: still carries one loads fine; nothing reads it.)
    glb: str = ""  # relative path to a bundled GLB
    step: str = ""  # relative path to the bundled STEP source (pairs with glb)
    #: How the mesh relates to the module (WP-41). "whole-module" means the
    #: bundled STEP/GLB IS the complete cube module (cube + insert + optic +
    #: fasteners, one Inventor export); the optical primitive is placed against
    #: it in the editor rather than derived from a separate insert body. Empty
    #: = the pre-WP-41 default (insert-only mesh).
    provenance: str = ""  # "" | "whole-module" | "insert"
    generator: GeneratorSpec | None = None  # T3
    optical_ports: dict[str, PortSpec] = Field(default_factory=dict)
    #: Footprint size in integer grid cells (x, y, z). **None = a bare
    #: HOUSING (WP-67)**: mechanics that are not cube-mounted at all — a
    #: Thorlabs laser body, a kinematic mount on a breadboard. A housing is
    #: component + template with NO cube_module (check_references rejects a
    #: module referencing one); the part places freely until it is packaged
    #: as a cube (T3) or exported for Inventor (WP-84).
    footprint_grid: tuple[int, int, int] | None = (1, 1, 1)
    #: WP-67: the optical component this housing realizes (``<id>@<range>``,
    #: same spelling as a module's ref). Housings need it because no module
    #: exists to carry the pair; cube-insert templates leave it empty (their
    #: module owns the association).
    component: str = ""

    @field_validator("component")
    @classmethod
    def _valid_component_ref(cls, v: str) -> str:
        if v and not _REF_RE.match(v):
            raise ValueError(f"component ref {v!r} is not <id>@<range>")
        return v
    #: T1 discrete configuration states (Inventor positional representations,
    #: e.g. a mirror's XY ⇄ YZ reflective plane). The editors show a state
    #: switcher instead of free pose fields when these are declared.
    #: WP-115: the F2→F3 pose — where the bound component's RECORD frame
    #: (+z = optical axis, DSN-CONTRACT §Frames) sits inside this template's
    #: CUBE frame (z = pin axis). Same rot24 ``grid`` map + ``offset-deg``
    #: residual + ``offset-mm`` spelling a design pose uses, because the
    #: insert-in-cube orientation IS a 24-fold discrete rotation plus
    #: residuals. None = identity (legacy records stay valid; verify-t1
    #: warns W_NO_INSERT_POSE when frames are declared without it).
    insert_pose: PoseSpec | None = Field(default=None, alias="insert-pose")
    #: WP-115: which frame the bundled STEP/GLB is authored in — "cube" (the
    #: Inventor convention, z = pin axis) or "record" (+z = optical axis;
    #: the pre-rotated wrapper-node exports). "" = undeclared legacy; a
    #: declared frame lets the mesh checks be axis-exact instead of
    #: orientation-tolerant.
    mesh_frame: str = Field(default="", alias="mesh-frame")
    #: WP-137: the FILE→cube correction for a wrongly exported mesh — one of
    #: the 24 grid rotations plus an optional offset-mm, spelled exactly like
    #: `insert-pose` because it is the same kind of hop (a frame the file was
    #: authored in, mapped into F3). `mesh-frame` stays as sugar for the two
    #: common cases: `cube` = identity, `record` = grid {z: -y, x: +x} (the
    #: y-up glTF convention). When both are given, `mesh-pose` wins. The
    #: rotation must be pure grid — a residual offset-deg would make the mesh
    #: checks' 24-fold un-rotation ambiguous, so it is rejected.
    mesh_pose: PoseSpec | None = Field(default=None, alias="mesh-pose")

    @field_validator("mesh_pose")
    @classmethod
    def _mesh_pose_is_grid(cls, v: PoseSpec | None) -> PoseSpec | None:
        if v is None:
            return v
        rot = v.rotation
        if rot.kind not in ("", "uc2", "grid"):
            raise ValueError(f"mesh-pose rotation must be a grid rotation, got {rot.kind!r}")
        return v

    @model_validator(mode="after")
    def _docking_only_on_carriers(self) -> TemplateRecord:
        if not self.carrier and (self.bays or self.mounts):
            raise ValueError("bays/mounts belong to a carrier template (carrier: true)")
        return self

    @model_validator(mode="after")
    def _mesh_pose_residual_only_on_housings(self) -> TemplateRecord:
        """WP-156: a mesh-pose offset-deg is the HOUSING's orientation in the
        cell — a free device (footprint_grid: null) may sit at any angle, and
        grid + offset-deg spells any rotation (the same normalization the
        design pose applies to quaternion input). A CUBE-MOUNTED template
        stays grid-only: the cube is pins-up always, so a residual tilt
        there belongs to the part, never to the file."""
        pose = self.mesh_pose
        if pose is None or self.footprint_grid is None:
            return self
        off = pose.rotation.offset_deg
        if any(abs(float(v_)) > 1e-9 for v_ in (off.x, off.y, off.z)):
            raise ValueError(
                "mesh-pose carries a non-zero offset-deg on a cube-mounted template — "
                "the mesh correction is one of the 24 grid rotations; a residual tilt "
                "belongs to the part, not the file. (Housings — footprint_grid: null — "
                "may carry one: it is the device's orientation in the cell.)"
            )
        return self

    @field_validator("mesh_frame")
    @classmethod
    def _known_mesh_frame(cls, v: str) -> str:
        if v not in ("", "cube", "record"):
            raise ValueError(f"mesh-frame must be 'cube' or 'record', got {v!r}")
        return v


class AxisMapEntry(SchemaModel):
    """Binds one actuatable DOF to a firmware/CANopen object."""

    dof: str
    can_object: int | str = Field(alias="can-object")


class ElectronicsSpec(SchemaModel):
    """The electronics contract of an active cube (optional)."""

    pcb: str = ""  # kicad:z_stage_driver@2.1
    firmware_contract: str = Field(default="", alias="firmware-contract")
    axis_map: list[AxisMapEntry] = Field(default_factory=list, alias="axis-map")


class ModuleRecord(RecordBase):
    """Cube module — the library part binding a component to a template."""

    kind: Literal["cube_module"] = "cube_module"
    #: The optical side, in exactly ONE of two spellings (WP-198, decision D2):
    #: ``component`` = a single ``optical_component`` record (the compact
    #: spelling, every module before WP-198); ``design`` = a ``cube_subdesign``
    #: record, i.e. Go's own decomposition — several posed child components,
    #: each with its own optics and DOFs, and design variants for the seats a
    #: grid rotation cannot spell (a mirror disc at 45° inside its master
    #: insert). Mirrors ``CompSpec.design`` vs ``CompSpec.primitive``: the
    #: field names the shape, exactly as Go distinguishes them.
    component: str = ""  # ref: <id>@<range>
    design: str = ""  # ref: <id>@<range> to a cube_subdesign
    template: str  # ref: <id>@<range>
    electronics: ElectronicsSpec | None = None
    footprint_grid: tuple[int, int, int] = (1, 1, 1)
    #: Kit price in EUR (WP-43 preserved the legacy CSV prices; the community
    #: pages' live BOM sums these — None = unpriced).
    price: float | None = None

    @field_validator("component", "design", "template")
    @classmethod
    def _valid_ref(cls, v: str) -> str:
        if v and not _REF_RE.match(v):
            raise ValueError(
                f"reference {v!r} must be '<id>@<range>', e.g. openuc2.lens.x@^1.2"
            )
        return v

    @model_validator(mode="after")
    def _one_optical_side(self) -> ModuleRecord:
        """WP-198: a module binds ONE optical side — a component or a subdesign."""
        if bool(self.component) == bool(self.design):
            raise ValueError(
                "a cube_module names exactly one optical side: `component:` "
                "(a single optical_component) or `design:` (a cube_subdesign), "
                f"got component={self.component!r} design={self.design!r}"
            )
        return self

    @property
    def component_id(self) -> str:
        return v.split("@", 1)[0] if (v := self.component) else ""

    @property
    def design_id(self) -> str:
        return v.split("@", 1)[0] if (v := self.design) else ""

    @property
    def template_id(self) -> str:
        return v.split("@", 1)[0] if (v := self.template) else ""


class GroupMember(SchemaModel):
    """One module instance inside a group, at a relative grid cell."""

    module: str  # ref: <id>@<range>
    cell: tuple[int, int, int]
    #: WP-234: the member's orientation, in Go's own spelling. `rot90: 0-3`
    #: was ours — a quarter-turn integer that could say nothing else, while
    #: the DSN already has the 24 axis-aligned rotations for exactly this.
    #: No shipped group ever set it to a non-zero value.
    rotation: RotGridSpec = Field(default_factory=lambda: RotGridSpec())
    #: True for members deliberately outside the plate footprint (the
    #: miniFRAME's camera arm hangs off the side of the sandwich).
    overhang: bool = False

    @field_validator("module")
    @classmethod
    def _valid_ref(cls, v: str) -> str:
        if not _REF_RE.match(v):
            raise ValueError(f"reference {v!r} must be '<id>@<range>'")
        return v

    @property
    def module_id(self) -> str:
        return self.module.split("@", 1)[0]


class PlateSpec(SchemaModel):
    """A sandwich plate closing one face of a group (ref + covered rect)."""

    module: str  # ref to a plate carrier module, e.g. openuc2.cube.plate_3x3@^0.1
    #: Grid cell of the plate's lower-left corner (relative, like member cells).
    origin: tuple[int, int] = (0, 0)
    #: Covered cells in x/y — matches the plate record's footprint.
    size: tuple[int, int] = (1, 1)

    @field_validator("module")
    @classmethod
    def _valid_ref(cls, v: str) -> str:
        if not _REF_RE.match(v):
            raise ValueError(f"reference {v!r} must be '<id>@<range>'")
        return v

    @property
    def module_id(self) -> str:
        return self.module.split("@", 1)[0]


class GroupStructure(SchemaModel):
    """What mechanically holds a group together (WP-53).

    The miniFRAME pattern: solid plates sandwich the cube stack top and
    bottom; puzzle pieces sit BETWEEN the layers, one per cell, holding the
    cube below and above by their pins (two noses + two notches tile the
    pieces against each other).
    """

    plates: dict[str, PlateSpec] = Field(default_factory=dict)  # "top" / "bottom"
    #: Joint system between layers ("" = none declared).
    joints: str = ""  # "" | "puzzle"
    #: Cells (x, y, z) carrying a joint piece. WP-184: z is the cell of the
    #: cube the piece sits UNDER — the 5 mm zone below cube-layer z has cell z,
    #: so a joint at z joins the layer-z cube above it to the layer-(z-1) cube
    #: below it. (It read "the LOWER layer of the joined pair" until WP-184,
    #: which put every suggested piece one 55 mm cell too low: the shipping
    #: puzzle meshes are authored with their origin at the centre of the cube
    #: ABOVE them.) Empty with joints set = derive from members (suggest).
    joint_cells: list[tuple[int, int, int]] = Field(default_factory=list, alias="joint-cells")


class InterfacePort(SchemaModel):
    """A group's outward optical port, mapped onto a member's port."""

    member: str  # member key
    port: str  # that member's port name


class GroupRecord(RecordBase):
    """Cube group — a named arrangement of modules placed as one unit.

    The library form of the openUC2 "optical module" (OPM): the miniFRAME
    engine, the focus-lock addon. Members sit at RELATIVE grid cells inside
    ``envelope_grid``; ``structure`` records the plates and inter-layer
    joints that make the arrangement one rigid, buildable thing (WP-53).
    Full editor semantics (place/enter/edit as one unit) arrive with WP-44.
    """

    kind: Literal["cube_group"] = "cube_group"
    members: dict[str, GroupMember] = Field(default_factory=dict)
    envelope_grid: tuple[int, int, int] = Field(default=(1, 1, 1), alias="envelope-grid")
    structure: GroupStructure | None = None
    interface: dict[str, InterfacePort] = Field(default_factory=dict)


class SubdesignRecord(RecordBase):
    """A library-packaged DESIGN — Go's decomposition as a shippable part (WP-198).

    The record file (``subdesign.yml``) carries identity and provenance only;
    the geometry lives next to it in an ordinary ``optikit-design.yml`` that
    stays byte-compatible with the Go reference — no ``kind:`` marker inside
    it, nothing for Go to ignore. Its components are posed children (each with
    its own optics and ``dof:``), and its ``variants`` are the seats a grid
    rotation cannot spell: a mirror disc turned 45° inside the master insert
    (decision D5) is variant ``xy``, exactly Ethan's ``mounted-mirror.dsn``.

    Declared inputs and variants are NOT restated here — the index reads them
    from the design file, which is their one source of truth (decision D4).
    """

    kind: Literal["cube_subdesign"] = "cube_subdesign"
    #: The design file, relative to the record directory.
    design_file: str = Field(default="optikit-design.yml", alias="design-file")

    @field_validator("design_file")
    @classmethod
    def _stays_in_the_record(cls, v: str) -> str:
        if not v or v.startswith("/") or ".." in Path(v).parts:
            raise ValueError(
                f"design-file {v!r} must be a relative name inside the record directory"
            )
        return v


RECORD_MODELS: dict[str, type[RecordBase]] = {
    "optical_component": ComponentRecord,
    "mechanical_template": TemplateRecord,
    "cube_module": ModuleRecord,
    "cube_group": GroupRecord,
    "cube_subdesign": SubdesignRecord,
}


def parse_ref(ref: str) -> tuple[str, str]:
    """Split ``<id>@<range>`` into (id, range)."""
    m = _REF_RE.match(ref)
    if not m:
        raise ValueError(f"invalid reference {ref!r}")
    return m.group("id"), m.group("range")


def load_record(data: dict[str, Any]) -> RecordBase:
    """Instantiate the correct record model from a ``kind`` discriminator."""
    kind = data.get("kind")
    model = RECORD_MODELS.get(kind)  # type: ignore[arg-type]
    if model is None:
        raise ValueError(
            f"unknown record kind {kind!r} (one of {sorted(RECORD_MODELS)})"
        )
    return model.model_validate(data)

def load_record_file(path: Path) -> RecordBase:
    """Load a record FROM DISK, resolving its sidecars.

    WP-232: a component may keep its prescription in a standalone Optiland
    file beside it (``optics.fragment-file``). Only a loader that knows the
    record's directory can resolve that, which is why loading a record from a
    bare dict cannot: use this wherever a path is in hand, so every consumer
    sees an ordinary ``optics.fragment`` and none of them has to know the
    sidecar exists.
    """
    from ..io.yamlio import load_document

    record = load_record(dict(load_document(path) or {}))
    inline_fragment_sidecar(record, path)
    return record


def inline_fragment_sidecar(record: RecordBase, path: Path) -> None:
    """Fold ``optics.fragment-file`` into ``optics.fragment`` (WP-232).

    The sidecar is a whole Optiland optic — object plane, prescription, image
    plane, and a placeholder context. Only the REAL surfaces come back: the
    planes are the file's standalone scaffolding and the design owns the
    context (``paths.<name>.simulation``).

    Raises :class:`ValueError` for a declared-but-broken sidecar rather than
    leaving an empty fragment. A component that lost its glass still traces,
    and the beam it "confirms" is the one that only reaches the detector
    because the lens is not there (the WP-175 failure mode).
    """
    from ..io.yamlio import load_document
    from .design import FragmentSpec

    optics = getattr(record, "optics", None)
    if optics is None or not getattr(optics, "fragment_file", ""):
        return
    if optics.fragment is not None:
        raise ValueError(
            "optics declares BOTH `fragment` and `fragment-file` — "
            "the prescription must have one home"
        )
    from ..export.optiland_sidecar import optiland_to_fragment

    sidecar = path.parent / optics.fragment_file
    data = dict(load_document(sidecar) or {})
    surfaces = optiland_to_fragment(data)
    if not surfaces:
        raise ValueError(
            f"optics.fragment-file {optics.fragment_file!r} carries no surfaces"
        )
    optics.fragment = FragmentSpec.model_validate({"surfaces": surfaces})
