"""The expression language of design inputs (WP-195).

The Go reference (openUC2/optikit@8ccf629, PR #19) parameterizes designs with
`expr-lang <https://expr-lang.org/>`_ expressions. This module implements the
subset the design contract actually uses — literals, arithmetic, comparison,
boolean logic, the ``?:`` ternary, list literals, and attribute/index access
into the ``inputs`` environment — as a plain recursive-descent parser and an
AST-walking evaluator. Nothing here calls ``eval()``; anything outside the
subset (function calls, ranges, closures, string methods …) is a **typed**
``E_EXPR_UNSUPPORTED``, never a silent fallback.

Go's rules, mirrored exactly:

- ``~ `` (:data:`EXPR_PREFIX`) is stripped before parsing wherever it appears.
  It is *required* only on ``instantiation.variant`` (where an unprefixed
  string is a literal variant id); on numeric pose fields every string is an
  expression whether or not it carries the prefix.
- The only defined name is ``inputs``: ``inputs.offset.value`` /
  ``inputs['off-axis'].value`` — plus ``.type``, ``.units``, ``.min``,
  ``.max`` (see :mod:`optikit_core.schema.inputs` for the environment shape).
- Bare YAML scalars in expression positions (``7``, ``true``) are the same
  values the expressions ``"7"`` / ``"true"`` evaluate to.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

EXPR_PREFIX = "~ "

# Error codes are stable API, same contract as schema checks / FlattenError.
E_EXPR_SYNTAX = "E_EXPR_SYNTAX"
E_EXPR_UNSUPPORTED = "E_EXPR_UNSUPPORTED"
E_EXPR_NAME = "E_EXPR_NAME"
E_EXPR_TYPE = "E_EXPR_TYPE"


class ExprError(ValueError):
    """Typed expression failure; ``code`` is stable API."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code


def strip_prefix(source: str) -> str:
    """The expression body — ``~ `` removed when present (Go: TrimPrefix)."""
    return source[len(EXPR_PREFIX):] if source.startswith(EXPR_PREFIX) else source


# --- AST ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Lit:
    value: Any


@dataclass(frozen=True)
class Name:
    name: str


@dataclass(frozen=True)
class Attr:
    obj: Any
    attr: str


@dataclass(frozen=True)
class Index:
    obj: Any
    index: Any


@dataclass(frozen=True)
class Unary:
    op: str
    operand: Any


@dataclass(frozen=True)
class Binary:
    op: str
    left: Any
    right: Any


@dataclass(frozen=True)
class Ternary:
    cond: Any
    then: Any
    other: Any


@dataclass(frozen=True)
class ListExpr:
    items: tuple


# --- tokenizer ---------------------------------------------------------------------

_PUNCT = ("||", "&&", "==", "!=", "<=", ">=",
          "?", ":", "(", ")", "[", "]", ",", ".",
          "+", "-", "*", "/", "%", "<", ">", "!")
_KEYWORDS = {"true": True, "false": False, "nil": None}
_WORD_OPS = {"not": "!", "and": "&&", "or": "||"}


@dataclass(frozen=True)
class _Tok:
    kind: str  # "lit" | "str" | "name" | "punct" | "end"
    value: Any
    pos: int


def _tokenize(src: str) -> list[_Tok]:
    toks: list[_Tok] = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c.isspace():
            i += 1
            continue
        if c.isdigit() or (c == "." and i + 1 < n and src[i + 1].isdigit()):
            j = i
            while j < n and (src[j].isdigit() or src[j] == "."):
                j += 1
            if j < n and src[j] in "eE":
                k = j + 1
                if k < n and src[k] in "+-":
                    k += 1
                while k < n and src[k].isdigit():
                    k += 1
                j = k
            text = src[i:j]
            try:
                value = (
                    float(text) if ("." in text or "e" in text or "E" in text) else int(text)
                )
            except ValueError:
                raise ExprError(E_EXPR_SYNTAX, f"bad number {text!r} at {i}") from None
            toks.append(_Tok("lit", value, i))
            i = j
            continue
        if c in "'\"":
            j = i + 1
            while j < n and src[j] != c:
                if src[j] == "\\":
                    raise ExprError(
                        E_EXPR_UNSUPPORTED, f"escape sequences in strings (at {j})"
                    )
                j += 1
            if j >= n:
                raise ExprError(E_EXPR_SYNTAX, f"unterminated string at {i}")
            toks.append(_Tok("str", src[i + 1:j], i))
            i = j + 1
            continue
        if c.isalpha() or c == "_":
            j = i
            while j < n and (src[j].isalnum() or src[j] == "_"):
                j += 1
            word = src[i:j]
            if word in _KEYWORDS:
                toks.append(_Tok("lit", _KEYWORDS[word], i))
            elif word in _WORD_OPS:
                toks.append(_Tok("punct", _WORD_OPS[word], i))
            else:
                toks.append(_Tok("name", word, i))
            i = j
            continue
        for p in _PUNCT:
            if src.startswith(p, i):
                toks.append(_Tok("punct", p, i))
                i += len(p)
                break
        else:
            raise ExprError(
                E_EXPR_UNSUPPORTED, f"character {c!r} at {i} is outside the contract subset"
            )
    toks.append(_Tok("end", None, n))
    return toks


# --- parser (recursive descent, expr-lang precedence) ------------------------------


class _Parser:
    def __init__(self, toks: list[_Tok], src: str) -> None:
        self.toks = toks
        self.src = src
        self.i = 0

    @property
    def tok(self) -> _Tok:
        return self.toks[self.i]

    def eat(self, kind: str, value: Any = None) -> _Tok:
        t = self.tok
        if t.kind != kind or (value is not None and t.value != value):
            raise ExprError(
                E_EXPR_SYNTAX,
                f"expected {value or kind} at {t.pos} in {self.src!r}",
            )
        self.i += 1
        return t

    def at(self, value: str) -> bool:
        return self.tok.kind == "punct" and self.tok.value == value

    def parse(self) -> Any:
        node = self.ternary()
        if self.tok.kind != "end":
            raise ExprError(
                E_EXPR_SYNTAX,
                f"unexpected {self.tok.value!r} at {self.tok.pos} in {self.src!r}",
            )
        return node

    def ternary(self) -> Any:
        cond = self.or_()
        if self.at("?"):
            self.eat("punct", "?")
            then = self.ternary()
            self.eat("punct", ":")
            return Ternary(cond, then, self.ternary())
        return cond

    def _binary(self, next_rule, ops: tuple[str, ...]) -> Any:
        node = next_rule()
        while self.tok.kind == "punct" and self.tok.value in ops:
            op = self.eat("punct").value
            node = Binary(op, node, next_rule())
        return node

    def or_(self) -> Any:
        return self._binary(self.and_, ("||",))

    def and_(self) -> Any:
        return self._binary(self.equality, ("&&",))

    def equality(self) -> Any:
        return self._binary(self.comparison, ("==", "!="))

    def comparison(self) -> Any:
        return self._binary(self.additive, ("<", "<=", ">", ">="))

    def additive(self) -> Any:
        return self._binary(self.multiplicative, ("+", "-"))

    def multiplicative(self) -> Any:
        return self._binary(self.unary, ("*", "/", "%"))

    def unary(self) -> Any:
        if self.tok.kind == "punct" and self.tok.value in ("-", "+", "!"):
            op = self.eat("punct").value
            return Unary(op, self.unary())
        return self.postfix()

    def postfix(self) -> Any:
        node = self.primary()
        while True:
            if self.at("."):
                self.eat("punct", ".")
                node = Attr(node, self.eat("name").value)
            elif self.at("["):
                self.eat("punct", "[")
                node = Index(node, self.ternary())
                self.eat("punct", "]")
            elif self.at("("):
                raise ExprError(
                    E_EXPR_UNSUPPORTED,
                    f"function calls are outside the contract subset ({self.src!r})",
                )
            else:
                return node

    def primary(self) -> Any:
        t = self.tok
        if t.kind in ("lit", "str"):
            self.i += 1
            return Lit(t.value)
        if t.kind == "name":
            self.i += 1
            return Name(t.value)
        if self.at("("):
            self.eat("punct", "(")
            node = self.ternary()
            self.eat("punct", ")")
            return node
        if self.at("["):
            self.eat("punct", "[")
            items = []
            while not self.at("]"):
                items.append(self.ternary())
                if self.at(","):
                    self.eat("punct", ",")
            self.eat("punct", "]")
            return ListExpr(tuple(items))
        raise ExprError(
            E_EXPR_SYNTAX, f"unexpected {t.value!r} at {t.pos} in {self.src!r}"
        )


def parse(source: str) -> Any:
    """Parse an expression (``~ `` stripped) into the AST; typed errors only."""
    body = strip_prefix(source)
    if not body.strip():
        raise ExprError(E_EXPR_SYNTAX, f"empty expression {source!r}")
    return _Parser(_tokenize(body), body).parse()


# --- evaluator ---------------------------------------------------------------------


def _number(v: Any, ctx: str) -> Any:
    if isinstance(v, bool) or not isinstance(v, int | float):
        raise ExprError(E_EXPR_TYPE, f"{ctx} needs a number, got {v!r}")
    return v


def _bool(v: Any, ctx: str) -> bool:
    if not isinstance(v, bool):
        # expr-lang is strictly typed: no truthiness coercion.
        raise ExprError(E_EXPR_TYPE, f"{ctx} needs a bool, got {v!r}")
    return v


def _eval(node: Any, env: dict[str, Any]) -> Any:
    match node:
        case Lit(value):
            return value
        case Name(name):
            if name not in env:
                raise ExprError(
                    E_EXPR_NAME, f"unknown name {name!r} — the environment defines "
                    f"{sorted(env) or 'nothing'}"
                )
            return env[name]
        case Attr(obj, attr):
            target = _eval(obj, env)
            if isinstance(target, dict) and attr in target:
                return target[attr]
            raise ExprError(E_EXPR_NAME, f"no member {attr!r} on {target!r}")
        case Index(obj, index):
            target = _eval(obj, env)
            key = _eval(index, env)
            if isinstance(target, dict):
                if key in target:
                    return target[key]
                raise ExprError(E_EXPR_NAME, f"no member {key!r} on {target!r}")
            if isinstance(target, list | tuple):
                if isinstance(key, bool) or not isinstance(key, int):
                    raise ExprError(E_EXPR_TYPE, f"list index needs an int, got {key!r}")
                try:
                    return target[key]
                except IndexError:
                    raise ExprError(E_EXPR_NAME, f"index {key} out of range") from None
            raise ExprError(E_EXPR_TYPE, f"{target!r} is not indexable")
        case Unary(op, operand):
            v = _eval(operand, env)
            if op == "!":
                return not _bool(v, "'!'")
            v = _number(v, f"unary {op!r}")
            return -v if op == "-" else +v
        case Binary(op, left, right):
            if op == "&&":
                return _bool(_eval(left, env), "'&&'") and _bool(_eval(right, env), "'&&'")
            if op == "||":
                return _bool(_eval(left, env), "'||'") or _bool(_eval(right, env), "'||'")
            lv, rv = _eval(left, env), _eval(right, env)
            if op == "==":
                return lv == rv
            if op == "!=":
                return lv != rv
            if op == "+" and isinstance(lv, str) and isinstance(rv, str):
                return lv + rv  # expr-lang string concatenation
            lv, rv = _number(lv, f"{op!r}"), _number(rv, f"{op!r}")
            if op == "+":
                return lv + rv
            if op == "-":
                return lv - rv
            if op == "*":
                return lv * rv
            if op == "/":
                if rv == 0:
                    raise ExprError(E_EXPR_TYPE, "division by zero")
                return lv / rv  # expr-lang: '/' is float division
            if op == "%":
                if rv == 0:
                    raise ExprError(E_EXPR_TYPE, "modulo by zero")
                return lv % rv
            return {"<": lv < rv, "<=": lv <= rv, ">": lv > rv, ">=": lv >= rv}[op]
        case Ternary(cond, then, other):
            return _eval(then if _bool(_eval(cond, env), "'?:'") else other, env)
        case ListExpr(items):
            return [_eval(item, env) for item in items]
    raise ExprError(E_EXPR_UNSUPPORTED, f"unsupported node {node!r}")  # pragma: no cover


def evaluate(source: str, env: dict[str, Any]) -> Any:
    """Parse and evaluate ``source`` against ``env`` (typically the inputs env)."""
    return _eval(parse(source), env)
