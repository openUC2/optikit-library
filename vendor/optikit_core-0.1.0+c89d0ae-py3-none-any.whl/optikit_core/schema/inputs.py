"""Design input variables (WP-195; Go: InputsSpec / InputVarSpec / MakeExprEnv).

An input variable is a design's typed parameter. The declaration carries no
default — **the default is the zero value of the declared type** (Go:
``InputsSpec.ZeroValues``). Values arrive from the caller (the top-level
``instantiation.inputs``, a parent design's evaluated
``components.<id>.instantiation.inputs``, or a tool), are coerced to the
declared type **in the callee's frame** (Go: ``convertTo``), and become the
expression environment ``inputs.<name>.{value,type,units,min,max}``.

Two DELIBERATE divergences from Go, both stricter, both documented in
GO-SYNC §1a:

- ``min``/``max`` are ENFORCED here (``E_INPUT_RANGE``); Go only displays
  them. A range on a physical parameter is a hard fact, same stance as
  DRC_RANGE on DOF values.
- A provided value for an undeclared input is ``E_INPUT_UNKNOWN``; Go
  silently carries it. Silence turns a typo into a default-valued design.
"""

from __future__ import annotations

from typing import Any

from pydantic import Field, model_validator

from .common import SchemaModel, reject_type_key

VAR_TYPE_BOOL = "bool"
VAR_TYPE_INT = "int"
VAR_TYPE_FLOAT = "float64"
VAR_TYPE_STRING = "string"
VAR_TYPE_QUATERNION = "quaternion"

#: type name → zero value (Go: varTypeZeroValues; a zero quaternion really is
#: [0,0,0,0] there — not a unit rotation — and we mirror it bit-for-bit).
ZERO_VALUES: dict[str, Any] = {
    VAR_TYPE_BOOL: False,
    VAR_TYPE_INT: 0,
    VAR_TYPE_FLOAT: 0.0,
    VAR_TYPE_STRING: "",
    VAR_TYPE_QUATERNION: [0.0, 0.0, 0.0, 0.0],
}

E_INPUT_TYPE = "E_INPUT_TYPE"
E_INPUT_UNKNOWN = "E_INPUT_UNKNOWN"
E_INPUT_RANGE = "E_INPUT_RANGE"


class InputError(ValueError):
    """Typed input-variable failure; ``code`` is stable API."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code


class InputVarSpec(SchemaModel):
    """One declared input variable (Go: InputVarSpec).

    ``type`` is one of ``bool | int | float64 | string | quaternion``. There
    is no ``default`` key — absence of a value means the kind's zero value.
    ``units`` is display metadata. ``min``/``max`` bound the value (enforced
    here, module docstring). ``kind`` was ``type`` until openUC2/optikit#20.
    ``tags`` is authoring metadata Go tolerates as an unknown key (Ethan's
    own examples carry it, e.g. ``adjustment/manual-assembly``).
    """

    _no_legacy_type = model_validator(mode="before")(reject_type_key)

    description: str = ""
    kind: str = ""
    units: str = ""
    min: float | int | None = None
    max: float | int | None = None
    tags: list[str] = Field(default_factory=list)
    #: Our two extension keys (WP-227), carrying what DofSpec used to: the
    #: slider/controller step, and which channel may drive the value.
    #: Go ignores both (unknown keys).
    #: the step size of a slider or controller
    resolution: float | None = None
    #: how the input is actuated — manually, by the optimizer, or by firmware
    actuation: str = "manual"


def coerce(value: Any, var_type: str, name: str) -> Any:
    """Go's ``convertTo``: the callee's declared type wins, strings parse.

    Faithful asymmetries kept: ``int`` does NOT accept a float (Go errors
    there too), ``float64`` accepts an int, ``bool``/``int``/``float64``
    parse from strings (the CLI ``--input name:value`` road).
    """
    match var_type:
        case "bool":
            if isinstance(value, bool):
                return value
            if isinstance(value, str):
                lowered = value.strip().lower()
                if lowered in ("1", "t", "true"):
                    return True
                if lowered in ("0", "f", "false"):
                    return False
            raise InputError(E_INPUT_TYPE, f"input {name!r}: can't convert {value!r} to bool")
        case "int":
            if isinstance(value, bool):
                raise InputError(E_INPUT_TYPE, f"input {name!r}: can't convert {value!r} to int")
            if isinstance(value, int):
                return value
            if isinstance(value, str):
                try:
                    return int(value.strip(), 10)
                except ValueError:
                    raise InputError(
                        E_INPUT_TYPE, f"input {name!r}: can't parse {value!r} as int"
                    ) from None
            raise InputError(E_INPUT_TYPE, f"input {name!r}: can't convert {value!r} to int")
        case "float64":
            if isinstance(value, bool):
                raise InputError(
                    E_INPUT_TYPE, f"input {name!r}: can't convert {value!r} to float64"
                )
            if isinstance(value, int | float):
                return float(value)
            if isinstance(value, str):
                try:
                    return float(value.strip())
                except ValueError:
                    raise InputError(
                        E_INPUT_TYPE,
                        f"input {name!r}: can't parse {value!r} as float64"
                        + (
                            " — it looks like an unevaluated expression; "
                            "expressions in instantiation.inputs are evaluated "
                            "in the PARENT design's environment"
                            if any(ch in value for ch in "[(?~")
                            else ""
                        ),
                    ) from None
            raise InputError(
                E_INPUT_TYPE, f"input {name!r}: can't convert {value!r} to float64"
            )
        case "string":
            return value if isinstance(value, str) else str(value)
        case "quaternion":
            if (
                isinstance(value, list | tuple)
                and len(value) == 4
                and all(isinstance(c, int | float) and not isinstance(c, bool) for c in value)
            ):
                return [float(c) for c in value]
            raise InputError(
                E_INPUT_TYPE,
                f"input {name!r}: can't convert {value!r} to quaternion "
                f"(needs a 4-element numeric array)",
            )
        case _:
            raise InputError(
                E_INPUT_TYPE,
                f"input {name!r}: unknown type {var_type!r} "
                f"(one of {', '.join(sorted(ZERO_VALUES))})",
            )


def make_env(
    values: dict[str, Any], declared: dict[str, InputVarSpec]
) -> dict[str, Any]:
    """The expression environment (Go: MakeExprEnv → ExprEnv.ToMap).

    Every DECLARED input appears — provided values coerced to the declared
    type and range-checked, missing ones at the type's zero value. A value
    for an undeclared name is a typed error (module docstring).
    """
    for name in values:
        if name not in declared:
            raise InputError(
                E_INPUT_UNKNOWN,
                f"input {name!r} is not declared by this design "
                f"(declares: {', '.join(sorted(declared)) or 'none'})",
            )
    env_inputs: dict[str, Any] = {}
    for name, spec in declared.items():
        if name in values:
            value = coerce(values[name], spec.kind, name)
            _check_range(value, spec, name)
        else:
            value = zero_value(spec.kind, name)
        env_inputs[name] = {
            "value": value,
            "type": spec.kind,
            "units": spec.units,
            "min": spec.min,
            "max": spec.max,
        }
    return {"inputs": env_inputs}


def zero_value(var_type: str, name: str) -> Any:
    try:
        value = ZERO_VALUES[var_type]
    except KeyError:
        raise InputError(
            E_INPUT_TYPE,
            f"input {name!r}: unknown type {var_type!r} "
            f"(one of {', '.join(sorted(ZERO_VALUES))})",
        ) from None
    return list(value) if isinstance(value, list) else value


def _check_range(value: Any, spec: InputVarSpec, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int | float):
        return
    if spec.min is not None and value < spec.min:
        raise InputError(
            E_INPUT_RANGE, f"input {name!r} = {value} is below min {spec.min}"
        )
    if spec.max is not None and value > spec.max:
        raise InputError(
            E_INPUT_RANGE, f"input {name!r} = {value} is above max {spec.max}"
        )
