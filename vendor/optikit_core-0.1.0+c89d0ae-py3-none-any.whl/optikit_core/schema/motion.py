"""WP-233: which input moves what, read off the pose expressions.

Before WP-230 a component declared `dof:`, so back-annotation could ask "does
this optimizer delta lie along a declared axis?" and answer from the record.
With `dof:` retired the same fact is still there — it is just written
differently: a moving child's POSE reads a design input, and which leaf it
reads tells you the axis.

The extraction is numeric, not syntactic. Every expression in the contract's
grammar is arithmetic over inputs (there are no functions — see
:mod:`.expressions`), so a leaf is AFFINE in each input and

    coefficient = f(input = 1) - f(input = 0)

is exact, not an approximation. That also means this cannot be fooled by
spelling: ``~ -5.0 + inputs['dz'].value``, ``~ inputs['dz'].value - 5.0``
and ``~ 2 * inputs['dz'].value / 2 - 5`` all report the same axis and gain.

A NON-affine leaf would make the coefficient meaningless, so it is detected
(by checking a third point) and dropped rather than reported — an axis that
is wrong is worse than an axis that is missing.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .common import is_expr
from .design import CompSpec, DesignDecl
from .expressions import ExprError, evaluate
from .inputs import InputVarSpec, make_env

#: Leaves a motion can live in, as (block, sub-block, kind). `offset-deg` is
#: the residual that composes ON TOP of a grid seat (contract §3), so it is the
#: rotation leaf that keeps the 24 orientations while being parameterized —
#: a moving `euler` triple replaces the seat instead. Both are scanned.
_TRANSLATION_LEAVES = (("translation", "offset-mm", "translation"),)
_ROTATION_LEAVES = (
    ("rotation", "euler", "rotation"),
    ("rotation", "offset-deg", "rotation"),
)
_LEAF_ATTRS = {"offset-mm": "offset_mm", "euler": "euler", "offset-deg": "offset_deg"}


@dataclass(frozen=True)
class MotionAxis:
    """One input's effect on one component: ``kind`` about/along ``axis``."""

    input_name: str
    comp_id: str
    kind: str  #: "translation" (mm) | "rotation" (deg)
    axis: str  #: "x" | "y" | "z" — the component's LOCAL axis
    #: Millimetres (or degrees) of motion per unit of the input.
    gain: float

    @property
    def key(self) -> str:
        """The value key this axis is driven through."""
        return self.input_name


def _leaf_gain(
    expression: str, name: str, declared: dict[str, InputVarSpec]
) -> float | None:
    """d(leaf)/d(input), or None when the leaf is not affine in it."""
    try:
        at0 = evaluate(expression, make_env({name: 0.0}, declared))
        at1 = evaluate(expression, make_env({name: 1.0}, declared))
        at2 = evaluate(expression, make_env({name: 2.0}, declared))
    except (ExprError, ValueError, KeyError):
        return None
    if not all(isinstance(v, int | float) and not isinstance(v, bool)
               for v in (at0, at1, at2)):
        return None
    gain = float(at1) - float(at0)
    # Affine ⇒ f(2) - f(1) == f(1) - f(0). A curved leaf has no single gain,
    # so report nothing rather than a number that is only right at the origin.
    if abs((float(at2) - float(at1)) - gain) > 1e-9:
        return None
    return gain


def component_motion_axes(
    comp_id: str, comp: CompSpec, declared: dict[str, InputVarSpec]
) -> list[MotionAxis]:
    """Every ``(input, axis, gain)`` this component's pose expresses."""
    out: list[MotionAxis] = []
    pose = comp.pose
    for block_name, sub_name, kind in (*_TRANSLATION_LEAVES, *_ROTATION_LEAVES):
        block = getattr(pose, "translation" if block_name == "translation" else "rotation")
        leaves = getattr(block, _LEAF_ATTRS[sub_name], None)
        if leaves is None:
            continue
        for axis in ("x", "y", "z"):
            value = getattr(leaves, axis, None)
            if not is_expr(value):
                continue
            for name in declared:
                if f"'{name}'" not in value and f'"{name}"' not in value:
                    continue
                gain = _leaf_gain(value, name, declared)
                if gain is None or abs(gain) < 1e-12:
                    continue
                out.append(MotionAxis(name, comp_id, kind, axis, gain))
    return out


def design_motion_axes(decl: DesignDecl) -> list[MotionAxis]:
    """Every motion the design's own inputs drive, across its components.

    One input may move SEVERAL components — decision D2's whole point (an
    objective and its z-stage on one ``dz``) — so this returns a flat list,
    not a map: the caller decides whether one delta is enough to attribute.
    """
    declared = dict(decl.inputs)
    if not declared:
        return []
    out: list[MotionAxis] = []
    for comp_id, comp in decl.components.items():
        out.extend(component_motion_axes(comp_id, comp, declared))
    return out


def axes_for_component(decl: DesignDecl, comp_id: str) -> list[MotionAxis]:
    """The motions a given component's pose expresses."""
    comp = decl.components.get(comp_id)
    if comp is None or not decl.inputs:
        return []
    return component_motion_axes(comp_id, comp, dict(decl.inputs))


def declared_inputs_for(decl: DesignDecl) -> dict[str, dict[str, Any]]:
    """The design's input declarations as plain dicts.

    The shape :func:`optikit_core.annotate.calibrate.calibrate_from_instrument`
    takes for its range and actuation checks — it is handed them because it
    sees a ``DesignDecl`` and not a library.
    """
    return {
        name: spec.model_dump(by_alias=True, exclude_none=True)
        for name, spec in decl.inputs.items()
    }
