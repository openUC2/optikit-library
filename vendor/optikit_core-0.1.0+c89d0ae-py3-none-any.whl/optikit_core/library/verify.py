"""T1 conformance: MATCH the optical model against the mechanics (WP-35).

A T1 (fixed) module has no knobs — so the only way the physical part and the
simulated part agree is if the record pair *states* the same geometry twice
and we check it: the component's ``optics.fragment`` + datum frames on one
side, the template's declared insert frames (where the mechanics HOLD the
optic, stamped from the ``PLN - OPT`` datum marker in the Inventor export) on
the other.

``verify_t1`` is deliberately a record-level check (no mesh parsing): the
marker → frame extraction happens once at ingest (``glb2template``), and this
check keeps the two record halves honest afterwards — including per declared
T1 state (Inventor positional representations, e.g. a mirror's XY ⇄ YZ
plane).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..schema.library import ComponentRecord, ModuleRecord, TemplateRecord
from .build import Library, resolve

#: |component optical frame − template insert frame| beyond this fails (mm).
POSE_TOL_MM = 0.05

#: WP-176: categories where the fixed insert holds a DEVICE or a LOCATION,
#: not glass — a fragment is not what these records are for, so verify-t1's
#: E_NO_FRAGMENT does not apply to them.
#: WP-181 adds the NON-OPTICAL kinds (WP-30: `mechanics`/`electronics`
#: records carry no `optics` block AT ALL — an empty cube, a puzzle piece, a
#: driver board). Demanding a fragment of a bare cube was a relict from when
#: every module held glass.
DEVICE_CATEGORIES = ("source", "detector", "sample", "mechanics", "electronics")

#: WP-181: records with no optical model at all. verify-t1's pose check
#: compares the OPTIC against the mechanics; with no optic there is nothing
#: to compare, so its "this OK is vacuous" nudge (stamp a PLN marker) is
#: noise — a bare cube has no insert to stamp.
NONOPTICAL_CATEGORIES = ("mechanics", "electronics")


def _insert_pose_transform(template: Any) -> tuple[Any, tuple[float, float, float]]:
    """WP-115: the F2→F3 matrix + translation the template declares.

    None ``insert-pose`` = identity, so every legacy record keeps its old
    behaviour (component frames compared against template frames verbatim).
    """
    import numpy as np

    from ..geometry.rotations import compose

    pose = getattr(template, "insert_pose", None)
    if pose is None:
        return np.eye(3), (0.0, 0.0, 0.0)
    rot = pose.rotation
    z = rot.grid.z or "+z"
    x = rot.grid.x or "+x"
    off = rot.offset_deg
    r = compose(z, x, {"x": off.x or 0.0, "y": off.y or 0.0, "z": off.z or 0.0})
    t = pose.translation.offset_mm
    return r, (t.x or 0.0, t.y or 0.0, t.z or 0.0)


@dataclass(frozen=True)
class VerifyFinding:
    """One verify-t1 finding; ``level`` is 'error' or 'warning'."""

    code: str
    level: str
    message: str

    def __str__(self) -> str:
        return f"{self.level.upper():7s} {self.code}: {self.message}"


def _num(value: object) -> float | None:
    return float(value) if isinstance(value, int | float) else None


def _fragment_reflective_count(component: ComponentRecord) -> int:
    fragment = component.optics.fragment
    if fragment is None:
        return 0
    count = 0
    for surface in fragment.surfaces:
        interaction = surface.get("interaction_model") or {}
        if isinstance(interaction, dict) and interaction.get("is_reflective"):
            count += 1
    return count


def verify_t1(library: Library, module_id: str) -> list[VerifyFinding]:
    """Cross-check a T1 module's component fragment against its template.

    Errors: ``E_NOT_T1`` (template is not class ``fixed``) · ``E_NO_FRAGMENT``
    (no surfaces — SURFACE categories only, since a fixed insert may hold a
    laser body, a camera or nothing at all; :data:`DEVICE_CATEGORIES` and
    ``passthrough: true`` are exempt, WP-176/181) · ``E_MIRROR_NO_REFLECTIVE``
    (record says mirror, fragment disagrees) · ``E_POSE_MISMATCH`` (the optical
    datum is off the template's insert frame by more than ``POSE_TOL_MM``).

    Warnings: ``W_NO_INSERT_FRAME`` (no ``frames:`` to check the datum against
    — not raised for :data:`NONOPTICAL_CATEGORIES`, which have no insert to
    stamp) ·
    """
    findings: list[VerifyFinding] = []

    module_hit = next(
        (
            e
            for e in library.records
            if isinstance(e.record, ModuleRecord) and e.record.id == module_id
        ),
        None,
    )
    if module_hit is None:
        return [VerifyFinding("E_NO_MODULE", "error", f"module {module_id!r} not found")]
    module = module_hit.record
    assert isinstance(module, ModuleRecord)

    # WP-198: verify-t1 is the COMPONENT+template contract (marker poses vs
    # the record's fragment). A subdesign-backed module states its geometry as
    # posed children instead, so it has no single record to verify against —
    # say so, rather than crashing on an empty ref.
    if not module.component:
        return [VerifyFinding(
            "W_SUBDESIGN_MODULE", "warning",
            f"module {module_id!r} binds a subdesign ({module.design!r}); "
            "verify-t1 checks a component+template pair and has nothing to "
            "compare here — the subdesign's own poses are its record",
        )]
    comp_hit = resolve(library, module.component)
    tpl_hit = resolve(library, module.template)
    if comp_hit is None or tpl_hit is None:
        missing = module.component if comp_hit is None else module.template
        return [VerifyFinding("E_REF_UNRESOLVED", "error", f"cannot resolve {missing!r}")]
    component = comp_hit.record
    template = tpl_hit.record
    assert isinstance(component, ComponentRecord)
    assert isinstance(template, TemplateRecord)

    if template.class_ != "fixed":
        return [
            VerifyFinding(
                "E_NOT_T1",
                "error",
                f"template {template.id} is class {template.class_!r} — verify-t1 "
                "only applies to fixed templates",
            )
        ]

    # --- fragment ↔ category ---------------------------------------------------------
    fragment = component.optics.fragment
    if fragment is None or not fragment.surfaces:
        if not component.optics.passthrough and component.category not in DEVICE_CATEGORIES:
            findings.append(
                VerifyFinding(
                    "E_NO_FRAGMENT",
                    "error",
                    f"component {component.id} declares no fragment surfaces — "
                    "nothing for the fixed insert to hold",
                )
            )
    elif component.category == "mirror" and _fragment_reflective_count(component) == 0:
        findings.append(
            VerifyFinding(
                "E_MIRROR_NO_REFLECTIVE",
                "error",
                f"component {component.id} is a mirror but no fragment surface is "
                "reflective — record says mirror, fragment disagrees",
            )
        )

    # --- datum pose ↔ template insert frame --------------------------------------------
    # WP-115: the component's frames are RECORD-frame (F2, +z = optical
    # axis); the template's frames are CUBE-frame (F3). The template's
    # insert-pose is the F2→F3 map — component frames travel through it
    # before comparison. A missing pose is identity (legacy), and worth a
    # warning when there ARE frames to check: identity is an ASSUMPTION.
    comp_frames = component.optics.frames
    if component.category in NONOPTICAL_CATEGORIES:
        # WP-181: no optic, nothing to compare — and nothing to stamp. The
        # cube's own mechanics are checked by `library validate` (mesh vs
        # envelope vs footprint), which is the right gate for it.
        pass
    elif not template.frames:
        findings.append(
            VerifyFinding(
                "W_NO_INSERT_FRAME",
                "warning",
                f"template {template.id} declares no frames: — stamp the PLN "
                "datum marker in Inventor and re-ingest to enable the pose check",
            )
        )
    else:
        if getattr(template, "insert_pose", None) is None:
            findings.append(
                VerifyFinding(
                    "W_NO_INSERT_POSE",
                    "warning",
                    f"template {template.id} declares frames but no insert-pose — "
                    "the record→cube rotation is assumed identity; state it "
                    "(WP-115) so the pose check stops guessing",
                )
            )
        rot, trans = _insert_pose_transform(template)
        has_pose = getattr(template, "insert_pose", None) is not None
        posed_note = " (through insert-pose)" if has_pose else ""
        for name, tpl_frame in template.frames.items():
            comp_frame = comp_frames.get(name)
            if comp_frame is None:
                findings.append(
                    VerifyFinding(
                        "E_POSE_MISMATCH",
                        "error",
                        f"template {template.id} holds frame {name!r} but component "
                        f"{component.id} declares no such datum frame",
                    )
                )
                continue
            comp_vals = [_num(getattr(comp_frame, a)) for a in ("x_mm", "y_mm", "z_mm")]
            tpl_vals = [_num(getattr(tpl_frame, a)) for a in ("x_mm", "y_mm", "z_mm")]
            bad = [
                ("x_mm", "y_mm", "z_mm")[i]
                for i in range(3)
                if comp_vals[i] is None or tpl_vals[i] is None
            ]
            if bad:
                for axis in bad:
                    findings.append(
                        VerifyFinding(
                            "E_POSE_MISMATCH",
                            "error",
                            f"frame {name!r} {axis.replace('_', '-')} is templated/"
                            "non-numeric — instantiate before verifying",
                        )
                    )
                continue
            posed = rot @ comp_vals
            posed = (posed[0] + trans[0], posed[1] + trans[1], posed[2] + trans[2])
            for i, axis in enumerate(("x_mm", "y_mm", "z_mm")):
                if abs(posed[i] - tpl_vals[i]) > POSE_TOL_MM:
                    findings.append(
                        VerifyFinding(
                            "E_POSE_MISMATCH",
                            "error",
                            f"frame {name!r} {axis.replace('_', '-')}: component datum"
                            f"{posed_note} lands at {posed[i]:.3f} mm but the template "
                            f"holds the insert at {tpl_vals[i]:.3f} mm "
                            f"(tol {POSE_TOL_MM} mm)",
                        )
                    )


    return findings


def verify_t1_ok(findings: list[VerifyFinding]) -> bool:
    return not any(f.level == "error" for f in findings)
