"""Library-packaged subdesigns: resolving a module's ``design:`` side (WP-198).

A design places a subdesign-backed module as an ordinary Go component::

    components:
      fold-1:
        type: design
        design: openuc2.subdesign.mounted_mirror@^0.1   # a LIBRARY ref
        instantiation:
          variant: xy                                    # the 45° seat (D5)
        pose:
          rotation: {type: uc2}
        module: openuc2.cube.mirror_45_sub@0.1.0

``design:`` holds a library reference until an export materializes files into
the folder — the same rule ``static-models`` already follows (DSN-CONTRACT
§3b), so nothing new enters the contract. :func:`library_subdesign_loader`
is the :class:`~optikit_core.geometry.flatten.SubdesignLoader` that resolves
those refs, and it composes with the on-disk loader so a design can mix
library subdesigns with plain relative paths.

Scope guard (proposal ask #3, ratified D2): a library subdesign is ONE level
deep — its children are primitives, not further library subdesigns. The guard
is enforced here (``E_SUBDESIGN_NESTED``) rather than left to recursion depth,
so the failure names the rule instead of the symptom.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from ..io.yamlio import design_dir_loader, load_design
from ..schema.design import CompSpec, InstSpec
from ..schema.library import SubdesignRecord
from ..schema.merge import instantiate
from .build import Library, resolve

if TYPE_CHECKING:  # pragma: no cover - typing only
    from ..geometry.flatten import SubdesignLoader

def is_library_ref(design: str) -> bool:
    """True when a ``design:`` value is a library reference, not a path.

    Library refs carry a version range (``openuc2.subdesign.x@^0.1``); Go's
    paths are relative and end in ``.dsn`` or contain a separator. The two
    shapes never collide, which is what lets one loader serve both.
    """
    return "@" in design and "/" not in design and not design.endswith(".dsn")


class SubdesignError(Exception):
    """Typed subdesign-resolution failure; ``code`` is stable API."""

    def __init__(self, code: str, ref: str, message: str) -> None:
        super().__init__(f"{code} for {ref!r}: {message}")
        self.code = code
        self.ref = ref


def subdesign_dir(library: Library, ref: str) -> tuple[SubdesignRecord, Path]:
    """The record and design-file path a ``design:`` library ref resolves to."""
    hit = resolve(library, ref)
    if hit is None:
        raise SubdesignError("E_SUBDESIGN_UNKNOWN", ref, "no such record in the library")
    record = hit.record
    if not isinstance(record, SubdesignRecord):
        raise SubdesignError(
            "E_SUBDESIGN_KIND", ref,
            f"resolves to a {record.kind!r} record — a module's `design:` side "
            "must name a cube_subdesign",
        )
    design_file = hit.path.parent / record.design_file
    if not design_file.is_file():
        raise SubdesignError(
            "E_SUBDESIGN_MISSING", ref,
            f"record declares design-file {record.design_file!r}, which is not "
            f"in {hit.path.parent.name}/",
        )
    return record, design_file


def load_subdesign(
    library: Library, ref: str, instantiation: InstSpec | None = None
) -> dict[str, CompSpec]:
    """The subdesign's components, variant-merged and expression-evaluated."""
    _record, design_file = subdesign_dir(library, ref)
    decl = load_design(design_file.parent)
    inst = instantiation if instantiation is not None else InstSpec()
    if inst.variant and inst.variant not in decl.variants:
        raise SubdesignError(
            "E_SUBDESIGN_VARIANT", ref,
            f"declares no variant {inst.variant!r} "
            f"(has: {', '.join(sorted(decl.variants)) or 'none'})",
        )
    for comp_id, comp in decl.components.items():
        if comp.kind == "design" and is_library_ref(comp.design):
            raise SubdesignError(
                "E_SUBDESIGN_NESTED", ref,
                f"child {comp_id!r} references another library subdesign "
                f"({comp.design!r}); library subdesigns are one level deep "
                "(WP-198 scope guard)",
            )
    return instantiate(decl, inst)


def library_subdesign_loader(
    library: Library, fallback: SubdesignLoader | None = None
) -> SubdesignLoader:
    """A :class:`SubdesignLoader` that resolves library ``design:`` refs.

    Non-library values (Go's relative ``*.dsn`` paths) go to ``fallback``,
    so a design may mix both. A library subdesign's own children resolve
    relative to its record directory.
    """

    def load(design_path: str, instantiation: InstSpec):
        if not is_library_ref(design_path):
            if fallback is None:
                raise SubdesignError(
                    "E_SUBDESIGN_UNKNOWN", design_path,
                    "is not a library reference and no path loader is configured",
                )
            return fallback(design_path, instantiation)
        _record, design_file = subdesign_dir(library, design_path)
        components = load_subdesign(library, design_path, instantiation)
        return components, design_dir_loader(design_file.parent)

    return load
