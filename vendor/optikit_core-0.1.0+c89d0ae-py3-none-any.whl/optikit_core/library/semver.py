"""Minimal semver comparison and range matching (no external dependency).

Supports the range forms the module references use: an exact version, a caret
range (``^1.2.3`` = compatible-with-major), a tilde range (``~1.2.3`` =
compatible-with-minor), and the wildcards ``*`` / ``latest``. Pre-release and
build metadata are compared per the semver spec's precedence rules (build
metadata ignored).
"""

from __future__ import annotations

import re
from dataclasses import dataclass

_SEMVER_RE = re.compile(
    r"^(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)"
    r"(?:-(?P<pre>[0-9A-Za-z-.]+))?(?:\+[0-9A-Za-z-.]+)?$"
)


@dataclass(frozen=True, order=False)
class Version:
    major: int
    minor: int
    patch: int
    pre: tuple[str | int, ...] = ()

    @classmethod
    def parse(cls, text: str) -> Version:
        m = _SEMVER_RE.match(text.strip())
        if not m:
            raise ValueError(f"invalid semver: {text!r}")
        pre_raw = m.group("pre")
        pre: tuple[str | int, ...] = ()
        if pre_raw:
            pre = tuple(int(p) if p.isdigit() else p for p in pre_raw.split("."))
        return cls(int(m.group("major")), int(m.group("minor")), int(m.group("patch")), pre)

    def _key(self) -> tuple:
        # A version without a pre-release ranks above one with (spec §11).
        return (self.major, self.minor, self.patch, 0 if not self.pre else -1, self._pre_key())

    def _pre_key(self) -> tuple:
        # Numeric identifiers rank below alphanumeric; compare field by field.
        return tuple((0, p) if isinstance(p, int) else (1, p) for p in self.pre)

    def __lt__(self, other: Version) -> bool:
        return self._key() < other._key()

    def __le__(self, other: Version) -> bool:
        return self._key() <= other._key()


def _parse_partial(text: str) -> tuple[Version, int]:
    """Parse a possibly-partial version (``1`` / ``1.2`` / ``1.2.3``).

    Returns the zero-filled Version and how many components were specified
    (1, 2, or 3) — the range width depends on the least-significant one given.
    """
    parts = text.strip().split("-", 1)[0].split("+", 1)[0].split(".")
    if not 1 <= len(parts) <= 3 or not all(p.isdigit() for p in parts):
        # Full form (with pre-release/build) — let Version.parse handle it.
        return Version.parse(text), 3
    nums = [int(p) for p in parts]
    nums += [0] * (3 - len(nums))
    return Version(nums[0], nums[1], nums[2]), len(parts)


def satisfies(version: str, spec: str) -> bool:
    """True if ``version`` satisfies the range ``spec``."""
    spec = spec.strip()
    if spec in ("*", "latest"):
        return True
    v = Version.parse(version)
    if spec.startswith("^"):
        base, width = _parse_partial(spec[1:])
        return base <= v < _caret_upper(base, width)
    if spec.startswith("~"):
        base, width = _parse_partial(spec[1:])
        # ~1 and ~1.2 both allow patch/minor moves up to the next minor/major.
        upper = Version(base.major + 1, 0, 0) if width == 1 else Version(
            base.major, base.minor + 1, 0
        )
        return base <= v < upper
    # A bare partial spec (e.g. "1" or "1.2") is a range, not an exact match.
    if not spec.startswith(("~", "^")) and spec.count(".") < 2 and spec[:1].isdigit():
        base, width = _parse_partial(spec)
        upper = (
            Version(base.major + 1, 0, 0) if width == 1 else Version(base.major, base.minor + 1, 0)
        )
        return base <= v < upper
    return v == Version.parse(spec)


def _caret_upper(base: Version, width: int = 3) -> Version:
    """Upper bound (exclusive) of a caret range (npm rules).

    ^1.2.3 → <2.0.0 ; ^0.2.3 → <0.3.0 ; ^0.0.3 → <0.0.4.
    Partial bases keep the least-significant *specified* component as the pivot:
    ^1 → <2.0.0 ; ^0 → <1.0.0 ; ^0.2 → <0.3.0 ; ^0.0 → <0.1.0.
    """
    if base.major > 0 or width == 1:
        return Version(base.major + 1, 0, 0)
    if base.minor > 0 or width == 2:
        return Version(0, base.minor + 1, 0)
    return Version(0, 0, base.patch + 1)
