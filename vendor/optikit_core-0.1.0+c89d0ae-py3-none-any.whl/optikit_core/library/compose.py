"""WP-204: marry a published optic onto a moving cube — the composer.

The wizard's fifth road: one ``optical_component`` (its F2 optics verbatim)
rides one carrier ``cube_module``'s axis. The result is a ``cube_subdesign``
whose single child is the optic — posed in the carrier's cell with a grid
seat (record +z → the chosen beam axis) and an affine translation expression
over a NEW design input — plus a NEW ``cube_module`` that shares the
carrier's template (the mesh) and points its optical side at the subdesign
(D2). The carrier module itself is never modified: it stays a reusable stage.

Refuses anything but the crisp case: ±axis literals, an optic with ports.
The child's motion is affine on purpose — `schema/motion.py` recovers
(axis, gain) by evaluating at 0 and 1, and that stays exact only while it is.

WP-240: a DESIGN-BACKED carrier (a decomposed stage) composes too — its
subdesign's inputs and children are copied into the new design and the optic
may ride an EXISTING input (the lens follows the stage's own ``dz``), so one
slider moves the sample, the metal and the lens together. The carrier and
its subdesign stay untouched, same as ever. An optional ``tilt_deg`` puts an
``offset-deg`` residual on the child — aligning the optic by rotation, not
only by translation.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..schema.design import DesignDecl

_AXES = ("+x", "-x", "+y", "-y", "+z", "-z")

#: Deterministic seat per beam axis: (grid z, grid x) with M(+z) = beam.
#: One fixed completion — axis-symmetric optics don't care, and a rect
#: aperture that does gets hand-authoring, same rule as decompose's axes.
_SEAT = {
    "+z": ("+z", "+x"),
    "-z": ("-z", "+x"),
    "+x": ("+x", "-z"),
    "-x": ("-x", "+z"),
    "+y": ("+y", "+x"),
    "-y": ("-y", "+x"),
}

_NAME_RE = re.compile(r"^[a-zA-Z][\w-]*$")
_SLUG_RE = re.compile(r"^[a-z][a-z0-9_]*$")


class ComposeError(Exception):
    """A refusal, with the reason the caller shows verbatim."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass
class ComposeResult:
    design_id: str
    module_id: str
    design: dict[str, Any]  #: the subdesign's optikit-design.yml
    record: dict[str, Any]  #: subdesign.yml
    module: dict[str, Any]  #: module.yml of the NEW module
    input: str
    notes: list[str] = field(default_factory=list)
    #: WP-240: mesh files copied from a design-backed carrier's subdesign.
    files: dict[str, bytes] = field(default_factory=dict)


def _axis_expr(input_name: str, gain: float, base: float) -> str:
    """The affine translation leaf, identity terms omitted (mirrors the
    editor's `linkExpression` spelling so round trips read the same)."""
    ref = f"inputs['{input_name}'].value"
    scaled = ref if gain == 1 else f"{ref} * {gain:g}"
    if base == 0:
        return f"~ {scaled}"
    return f"~ {scaled} {'-' if base < 0 else '+'} {abs(base):g}"


def compose_axis_bound(
    component: Any,
    carrier: Any,
    *,
    slug: str,
    input_name: str,
    input_spec: dict[str, Any] | None = None,
    axis: str,
    beam: str = "+x",
    ratio: float = 1.0,
    offset_mm: dict[str, float] | None = None,
    tilt_deg: dict[str, float] | None = None,
    carrier_design: dict[str, Any] | None = None,
    carrier_dir: Path | None = None,
) -> ComposeResult:
    """Build the documents that mount ``component`` onto ``carrier``'s axis.

    ``axis`` is the cube direction the optic travels (input=1 → +ratio mm
    that way); ``beam`` is where the record's +z (its optical axis) points;
    ``offset_mm`` is the optic's cell position at input=0 — the marriage.
    ``tilt_deg`` is an offset-deg residual on the child (rotation alignment).
    A design-backed carrier needs ``carrier_design`` (its design document as
    a dict) and ``carrier_dir`` (to copy its mesh files); the caller resolves
    both off the library.
    """
    if getattr(carrier, "design", "") and carrier_design is None:
        raise ComposeError(
            "E_COMPOSE_TAKEN",
            f"carrier {carrier.id} has a design: side and its subdesign was "
            "not resolved — compose needs it to carry the existing children "
            "and inputs along (WP-240)",
        )
    if axis not in _AXES or beam not in _AXES:
        raise ComposeError(
            "E_COMPOSE_AXIS",
            f"axis {axis!r} / beam {beam!r} must be ±x/±y/±z literals — a free "
            "axis needs hand-authoring",
        )
    if not _NAME_RE.match(input_name):
        raise ComposeError(
            "E_COMPOSE_INPUT",
            f"input name {input_name!r} — letters, digits, - _ only (it becomes "
            "an expression key and a YAML key)",
        )
    if not _SLUG_RE.match(slug):
        raise ComposeError(
            "E_COMPOSE_SLUG",
            f"slug {slug!r} — lowercase letters, digits, _ only (it becomes "
            "record ids and directory names)",
        )
    optics = getattr(component, "optics", None)
    if optics is None or not getattr(optics, "ports", None):
        raise ComposeError(
            "E_COMPOSE_NO_PORTS",
            f"{component.id} declares no optical ports — where light enters and "
            "leaves is what the composed chain is built from",
        )

    notes: list[str] = []
    child_optics = optics.model_dump(
        by_alias=True, exclude_defaults=True, exclude_none=True
    )
    # The library loader inlined any sidecar into `fragment`; the child is a
    # standalone design component with no record directory to resolve against.
    child_optics.pop("fragment-file", None)

    child: dict[str, Any] = {
        "kind": "primitive",
        "category": str(component.category),
        "optics": child_optics,
    }
    source = getattr(component, "source", None)
    if source is not None:
        child["source"] = source.model_dump(
            by_alias=True, exclude_defaults=True, exclude_none=True
        )

    leaf = axis[1]
    gain = (-1.0 if axis.startswith("-") else 1.0) * float(ratio)
    offsets = dict(offset_mm or {})
    translation = {
        k: v for k, v in offsets.items() if k in ("x", "y", "z") and v and k != leaf
    }
    translation[leaf] = _axis_expr(input_name, gain, float(offsets.get(leaf, 0.0)))
    pose: dict[str, Any] = {"translation": {"offset-mm": translation}}
    seat_z, seat_x = _SEAT[beam]
    tilt = {
        k: float(v) for k, v in (tilt_deg or {}).items()
        if k in ("x", "y", "z") and v
    }
    if (seat_z, seat_x) != ("+z", "+x"):
        pose["rotation"] = {"kind": "grid", "grid": {"z": seat_z, "x": seat_x}}
        if tilt:
            pose["rotation"]["offset-deg"] = tilt
    elif tilt:
        # No seat to compose onto — the residual alone (R = I · ΔR, §4).
        pose["rotation"] = {"kind": "uc2", "offset-deg": tilt}
    child["pose"] = pose

    # WP-240: a design-backed carrier's subdesign rides along — inputs and
    # children copied verbatim, so the new pair IS the stage plus the optic.
    inputs: dict[str, Any] = {}
    components: dict[str, Any] = {}
    files: dict[str, bytes] = {}
    if carrier_design is not None:
        inputs.update(dict(carrier_design.get("inputs") or {}))
        components.update(
            {k: dict(v) for k, v in (carrier_design.get("components") or {}).items()}
        )
        for cid, comp in components.items():
            models = (comp.get("primitive") or {}).get("static-models") or {}
            for ref in (models.get("gltf"), models.get("step")):
                if not ref or ref in files or carrier_dir is None:
                    continue
                mesh_path = carrier_dir / str(ref)
                if mesh_path.is_file():
                    files[str(ref)] = mesh_path.read_bytes()
                else:
                    notes.append(f"{cid}: mesh {ref!r} not found beside the "
                                 "carrier's design — not copied")

    if input_name in inputs:
        # The lens follows the stage's OWN axis: reuse the declaration, and
        # say so if the caller sent a different range along.
        if input_spec and any(
            input_spec.get(k) not in (None, inputs[input_name].get(k))
            for k in ("min", "max")
        ):
            notes.append(
                f"input {input_name!r} already declared by the carrier — its "
                "range wins over the request's")
    else:
        spec = {"kind": "float64", **(input_spec or {})}
        spec.setdefault("units", "mm")
        inputs[input_name] = spec

    ns = str(carrier.id).split(".", 1)[0]
    design_id = f"{ns}.subdesign.{slug}"
    module_id = f"{ns}.cube.{slug}"
    child_id = str(component.id).rsplit(".", 1)[-1].replace("_", "-")
    while child_id in components:
        child_id += "-2"
    components[child_id] = child
    design = {
        "optikit-version": "v0.0.0-alpha.1",
        "design": {
            "name": slug.replace("_", "-"),
            "version": "0.1.0",
            "description": f"{component.id} riding {carrier.id}'s {input_name} axis",
        },
        "inputs": inputs,
        "components": components,
    }
    DesignDecl.model_validate(design)  # refuse before anything is written

    record = {
        "kind": "cube_subdesign",
        "id": design_id,
        "version": "0.1.0",
        "description": f"{component.id} on {carrier.id} — the beam follows "
                       f"input {input_name} along {axis}",
        # Provenance, not an optical side (D2 binds the MODULE): the same
        # companion join decompose records, so editor joins on component.ref
        # (mesh resolve, rehydrate, the bound-set) survive.
        "component": f"{component.id}@^"
                     + ".".join(str(component.version).split(".")[:2]),
        "tags": ["subdesign", "composed"],
        "review": [
            "optics-only child: the module renders the CARRIER's template "
            "mesh, so the beam rides the axis while the CAD platform and the "
            "optic's own housing do not travel — a merged mesh is a follow-up "
            "CAD task, not a schema one",
        ],
    }

    module: dict[str, Any] = {
        "kind": "cube_module",
        "id": module_id,
        "version": "0.1.0",
        "description": f"{component.id} on {carrier.id} "
                       f"({input_name} along {axis})",
        "tags": ["composed"],
        "design": f"{design_id}@^0.1",
        "template": str(carrier.template),  # SHARED — the carrier stays the mesh
        "footprint_grid": list(getattr(carrier, "footprint_grid", (1, 1, 1))),
    }
    electronics = getattr(carrier, "electronics", None)
    if electronics is not None:
        # A motorized carrier's channel drives OUR input now.
        module["electronics"] = electronics.model_dump(
            by_alias=True, exclude_defaults=True, exclude_none=True
        )
        notes.append(f"carried {carrier.id}'s electronics block onto {module_id}")

    return ComposeResult(
        design_id=design_id, module_id=module_id, design=design,
        record=record, module=module, input=input_name, notes=notes,
        files=files,
    )


def write_composed(root: Path, result: ComposeResult) -> list[str]:
    """Write the subdesign + new module folders; returns library-relative paths."""
    from ..io.yamlio import dump_document

    sub_dir = root / "subdesigns" / result.design_id
    sub_dir.mkdir(parents=True, exist_ok=True)
    (sub_dir / "subdesign.yml").write_text(dump_document(result.record))
    (sub_dir / "optikit-design.yml").write_text(dump_document(result.design))
    written = [
        f"subdesigns/{result.design_id}/subdesign.yml",
        f"subdesigns/{result.design_id}/optikit-design.yml",
    ]
    # WP-240: a design-backed carrier's meshes travel with the new subdesign
    # (static-models paths resolve relative to the design file).
    for name, blob in sorted(result.files.items()):
        (sub_dir / name).write_bytes(blob)
        written.append(f"subdesigns/{result.design_id}/{name}")
    mod_dir = root / "modules" / result.module_id
    mod_dir.mkdir(parents=True, exist_ok=True)
    (mod_dir / "module.yml").write_text(dump_document(result.module))
    written.append(f"modules/{result.module_id}/module.yml")
    return written
