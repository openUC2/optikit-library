"""The OPM sandwich: the plates and joints an arrangement needs, minted on demand.

An optical module is a cube arrangement clamped between two plates, with a
puzzle piece wherever cubes stack. `suggest_structure` derives that from the
members; this adds the missing half — the plate a shape needs may not exist as
a record yet, so it is generated from `plate_nxm` and written into the library.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ..io.yamlio import dump_document
from ..schema.library import GroupRecord
from .build import load_library, resolve
from .groups import suggest_structure
from .root import CORE_ROOT

PLATE_GENERATOR = "generators/plate_nxm.py"


def plate_ids(nx: int, ny: int) -> dict[str, str]:
    """Record ids of the N×M sandwich plate (they are minted as one trio)."""
    stem = f"plate_{nx}x{ny}"
    return {
        "module": f"openuc2.cube.{stem}",
        "template": f"openuc2.tpl.{stem}",
        "component": f"openuc2.mechanics.{stem}",
    }


def ensure_plate(root: Path, nx: int, ny: int) -> tuple[str, bool]:
    """The ``<id>@^0.1`` ref of the N×M plate module, minting it when new.

    Returns (ref, minted). Minting writes the trio and runs the generator, so
    the record ships real geometry rather than an empty T3 promise.
    """
    ids = plate_ids(nx, ny)
    library = load_library(root)
    ref = f"{ids['module']}@^0.1"
    if resolve(library, ref) is not None:
        return ref, False

    (root / "components" / ids["component"]).mkdir(parents=True, exist_ok=True)
    (root / "templates" / ids["template"]).mkdir(parents=True, exist_ok=True)
    (root / "modules" / ids["module"]).mkdir(parents=True, exist_ok=True)
    note = f"generated for a {nx}x{ny} optical module — verify the hole pattern before machining"

    (root / "components" / ids["component"] / "component.yml").write_text(
        dump_document({
            "kind": "optical_component", "id": ids["component"], "version": "0.1.0",
            "category": "mechanics",
            "description": f"{nx}x{ny} aluminium sandwich plate (miniFRAME top/bottom)",
            "tags": ["mechanics", "carrier", "miniframe", "plate"], "review": [note],
        }), encoding="utf-8")
    (root / "templates" / ids["template"] / "template.yml").write_text(
        dump_document({
            "kind": "mechanical_template", "id": ids["template"], "version": "0.1.0",
            "class": "generative", "carrier": True,
            "description": (f"{nx}x{ny} sandwich plate, 4 screw holes per cell "
                            "on the cube hole circle"),
            "tags": ["carrier", "miniframe", "plate", "generated"],
            "envelope": {"x-mm": nx * 50, "y-mm": ny * 50, "z-mm": 5},
            "generator": {"script": PLATE_GENERATOR, "params": {"nx": nx, "ny": ny}},
            "footprint_grid": [nx, ny, 1],
        }), encoding="utf-8")
    (root / "modules" / ids["module"] / "module.yml").write_text(
        dump_document({
            "kind": "cube_module", "id": ids["module"], "version": "0.1.0",
            "description": f"{nx}x{ny} aluminium sandwich plate (miniFRAME)",
            "tags": ["carrier", "miniframe", "plate"],
            "component": f"{ids['component']}@^0.1", "template": f"{ids['template']}@^0.1",
            "footprint_grid": [nx, ny, 1], "review": [note],
        }), encoding="utf-8")

    _generate_plate_mesh(root, ids["template"])
    return ref, True


def _generate_plate_mesh(root: Path, template_id: str) -> None:
    """Run the plate generator and install its STEP/GLB — best effort.

    A machine without CadQuery still gets a valid T3 record (the geometry is
    a `generate` away); it just has no mesh yet, and says so.
    """
    import shutil

    from ..generate import GenerateError, generate
    from ..io.yamlio import _to_plain, load_document

    library = load_library(root)
    loaded = next(
        (e for e in library.records if e.record.id == template_id), None
    )
    if loaded is None:
        return
    try:
        result = generate(loaded.record, repo_root=CORE_ROOT, library_root=root)  # type: ignore[arg-type]
    except (GenerateError, ImportError, RuntimeError) as exc:
        record = _to_plain(load_document(loaded.path)) or {}
        record["review"] = [*record.get("review", []), f"mesh not generated here: {exc}"]
        loaded.path.write_text(dump_document(record), encoding="utf-8")
        return
    for name in ("model.glb", "model.step"):
        source = Path(result.out_dir) / name
        if source.is_file():
            shutil.copyfile(source, loaded.path.parent / name)
    record = _to_plain(load_document(loaded.path)) or {}
    record.update({"glb": "model.glb", "step": "model.step", "mesh-frame": "cube"})
    loaded.path.write_text(dump_document(record), encoding="utf-8")


def opm_structure(root: Path, members: dict[str, Any], envelope_grid: list[int]) -> dict[str, Any]:
    """Plates and puzzle joints for an arrangement, with the plate records minted.

    ``members`` is the group record's own shape (key → {module, cell,
    overhang}); the answer is a ready ``structure:`` block plus the ids that
    had to be created.
    """
    group = GroupRecord.model_validate({
        "kind": "cube_group", "id": "user.group.draft", "version": "0.1.0",
        "envelope-grid": envelope_grid, "members": members,
    })
    suggested = suggest_structure(group, load_library(root))
    minted: list[str] = []
    plates: dict[str, Any] = {}
    for face, plate in suggested["plates"].items():
        nx, ny = int(plate["size"][0]), int(plate["size"][1])
        ref, was_minted = ensure_plate(root, nx, ny)
        if was_minted:
            minted.append(ref.split("@")[0])
        plates[face] = {"module": ref, "origin": list(plate["origin"]), "size": [nx, ny]}
    return {
        "structure": {
            "plates": plates,
            "joints": "puzzle",
            "joint-cells": suggested["joint_cells"],
        },
        "minted": minted,
    }
