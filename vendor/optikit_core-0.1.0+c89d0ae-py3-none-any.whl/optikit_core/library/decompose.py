"""Turn a record's moving parts into a subdesign (WP-229 + WP-235).

WP-230 removed the record spelling the wizard's moving-parts rows used to land
in, so this is where they go instead — as Go-native inputs plus pose
expressions:

- a **surface-bound rotation** (a galvo mirror) becomes one OPTICS-ONLY child
  per driven surface, authored in CUBE axes off the template's as-mounted
  ports, its tilt an ``offset-deg`` expression (contract §3: R = R24 · ΔR);
- a **translation** (a stage) moves the whole optic, so the child is the
  record itself — optics verbatim, seated by the template's ``insert-pose`` —
  and the travel is an ``offset-mm`` expression.

Translations apply to EVERY child, so a galvo on a stage stays one flat
design: library subdesigns are one level deep, and an affine term per child
is equivalent to a parent that translates.

Either way the module's mesh stays the monolithic template — the beam moves,
the CAD does not; `optikit-core library decompose` remains the road for
splitting geometry.

Refuses anything but the crisp case: axes are ±x/±y/±z literals, and every
reflective surface is reached by an exit port. Wrong geometry silently
authored is worse than a refusal.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..schema.design import DesignDecl

#: Entry-port names (DSN-CONTRACT §4: roles are name-derived).
_ENTRY_NAMES = ("front", "sensor", "in", "plane")

_FLIP = {"+x": "-x", "-x": "+x", "+y": "-y", "-y": "+y", "+z": "-z", "-z": "+z"}


class DecomposeError(Exception):
    """A refusal, with the reason the caller shows verbatim."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass
class DecomposeResult:
    design_id: str
    design: dict[str, Any]  #: the optikit-design.yml document
    record: dict[str, Any]  #: the subdesign.yml document
    inputs: list[str]
    notes: list[str] = field(default_factory=list)
    #: WP-238: split mesh files to write beside the design, name → bytes.
    files: dict[str, bytes] = field(default_factory=dict)
    #: WP-246: the seats the insert can take, one variant id per seat.
    variants: list[str] = field(default_factory=list)


def _surface_ports(template: Any) -> tuple[dict[str, Any], dict[int, dict[str, Any]]]:
    """(entry port, {surface index: exit port}) from the as-mounted ports."""
    ports = dict(getattr(template, "optical_ports", None) or {})
    entry = next((p for n, p in ports.items() if n in _ENTRY_NAMES), None)
    if entry is None:
        raise DecomposeError(
            "E_DECOMPOSE_NO_ENTRY",
            "the template serves no entry port (front|sensor|in|plane) — "
            "the beam chain has no start to derive the children from",
        )
    exits: dict[int, dict[str, Any]] = {}
    for name, port in ports.items():
        if name in _ENTRY_NAMES:
            continue
        after = getattr(port, "after_surface", None)
        if after is not None:
            exits[int(after)] = port
    return entry, exits


def _axis_leaf(axis: str) -> tuple[str, bool]:
    """('x'|'y'|'z', negated) from a ±axis literal."""
    if axis not in _FLIP:
        raise DecomposeError(
            "E_DECOMPOSE_AXIS",
            f"tilt axis {axis!r} is not a ±x/±y/±z literal — a free axis needs "
            "hand-authoring (the pivot wants its own parent component)",
        )
    return axis[1], axis.startswith("-")


def _input_spec(row: dict[str, Any], default_unit: str) -> dict[str, Any]:
    """The declaration a wizard row becomes (range/resolution/actuation)."""
    spec: dict[str, Any] = {"kind": "float64",
                            "units": str(row.get("unit") or default_unit)}
    lo, hi = row.get("rangeMin"), row.get("rangeMax")
    if isinstance(lo, int | float) and isinstance(hi, int | float) and lo < hi:
        spec["min"], spec["max"] = float(lo), float(hi)
    if isinstance(row.get("resolution"), int | float) and row["resolution"] > 0:
        spec["resolution"] = float(row["resolution"])
    if row.get("actuation") and row["actuation"] != "manual":
        spec["actuation"] = str(row["actuation"])
    return spec


def _affine_leaf(existing: Any, term: str) -> str:
    """``term`` added onto whatever the leaf already holds.

    A child authored off a template frame carries a literal (``7.0``); a
    second axis row may already have made it an expression. Both stay affine,
    which is what `schema/motion.py` needs to read the axis back.
    """
    if isinstance(existing, str) and existing.strip():
        return f"{existing.strip().removeprefix('~ ').strip()} + {term}"
    if isinstance(existing, int | float) and existing:
        return f"~ {float(existing):g} + {term}"
    return f"~ {term}"


def _apply_translations(
    components: dict[str, Any], rows: list[dict[str, Any]], notes: list[str]
) -> dict[str, Any]:
    """Add each translation row's ``offset-mm`` expression to EVERY child.

    A stage moves the whole optic, so the term lands on all children rather
    than on a parent — library subdesigns are one level deep
    (``E_SUBDESIGN_NESTED``), and an affine term per child is exactly
    equivalent to a parent that translates.
    """
    inputs: dict[str, Any] = {}
    for row in rows:
        name = str(row.get("dof") or "")
        leaf, negated = _axis_leaf(str(row.get("axis") or ""))
        term = (f"-inputs['{name}'].value" if negated else f"inputs['{name}'].value")
        for comp in components.values():
            pose = comp.setdefault("pose", {})
            offsets = pose.setdefault("translation", {}).setdefault("offset-mm", {})
            offsets[leaf] = _affine_leaf(offsets.get(leaf), term)
        inputs[name] = _input_spec(row, "mm")
        notes.append(f"{name}: translation along {row.get('axis')}")
    return inputs



def _descends_from(tree: list[dict[str, Any]], ancestors: set[str],
                   names: set[str]) -> bool:
    """True if any of ``names`` sits under any of ``ancestors`` in the tree."""

    def walk(nodes: list[dict[str, Any]], under: bool) -> bool:
        for node in nodes:
            name = str(node.get("name") or "")
            here = under or name in ancestors
            if under and name in names:
                return True
            if walk(node.get("children", []) or [], here):
                return True
        return False

    return walk(tree, False)


def _split_moving_mesh(
    mesh: bytes,
    groups: list[tuple[frozenset[str], list[dict[str, Any]]]],
    components: dict[str, Any],
    notes: list[str],
) -> dict[str, bytes]:
    """WP-238: one child GLB per moving subtree, plus the static remainder.

    The wizard already knows WHICH mesh subtree each row moves; before this
    that pick died at publish, so the optic rode the slider and the metal did
    not ("the sliders in assembly don't do anything"). Each group becomes a
    `static-models` child carrying its own geometry and the SUM of its rows'
    affine terms — several axes on one subtree is the normal case (an XYZ
    stage), not an edge one.

    The assembly draws children instead of the module's monolithic mesh as
    soon as one of them has a GLB, so the remainder must ship too or the
    static half of the part vanishes.
    """
    from ..importers.glb2template import strip_instance
    from .mesh import glb_extract_subtrees, glb_node_tree

    tree = glb_node_tree(mesh)

    # The wizard's pick list DISPLAYS instance-stripped names while the file
    # carries `…:1`, and a record may hold either — so resolve a pick to the
    # file's own spelling before extracting, the way E_KIN_NODE_MISSING does.
    real: dict[str, str] = {}

    def index(nodes: list[dict[str, Any]]) -> None:
        for node in nodes:
            name = str(node.get("name") or "")
            if name:
                real.setdefault(name, name)
                real.setdefault(strip_instance(name), name)
            index(node.get("children", []) or [])

    index(tree)

    def resolve(names: frozenset[str]) -> set[str]:
        return {real[n] for n in names if n in real}
    # Nesting would need "extract A except B", which the extractor cannot
    # express — a carriage inside a table would ship its geometry twice.
    for i, (a_nodes, a_rows) in enumerate(groups):
        for b_nodes, b_rows in groups[i + 1:]:
            a_real, b_real = resolve(a_nodes), resolve(b_nodes)
            if _descends_from(tree, a_real, b_real) or _descends_from(
                tree, b_real, a_real
            ):
                raise DecomposeError(
                    "E_DECOMPOSE_NESTED_SUBTREE",
                    f"{a_rows[0].get('dof')} and {b_rows[0].get('dof')} move "
                    "subtrees where one contains the other — the split would "
                    "ship that geometry twice. Name the SAME subtree in both "
                    "rows (it then rides both axes), or pick sibling subtrees",
                )

    files: dict[str, bytes] = {}
    moving: set[str] = set()
    for order, (nodes, rows) in enumerate(groups):
        name = f"moving-{order}.glb"
        picked = resolve(nodes)
        if not picked:
            notes.append(
                f"{rows[0].get('dof')}: {sorted(nodes)} names no node in this "
                "mesh — not split")
            continue
        try:
            files[name] = glb_extract_subtrees(mesh, picked)
        except ValueError as exc:  # a pick that is not in this mesh
            notes.append(f"{rows[0].get('dof')}: {exc} — not split")
            continue
        moving |= picked
        child: dict[str, Any] = {
            "kind": "primitive",
            "category": "mechanics",
            "primitive": {"static-models": {"gltf": name}},
            # Authoring provenance (an unknown key Go tolerates, like `tags`):
            # WHICH subtrees of the template mesh this child was cut from.
            # The split file no longer says so, and re-opening the pair in the
            # wizard needs it to rebuild the row's pick list.
            "moving-nodes": sorted(picked),
        }
        offsets: dict[str, Any] = {}
        for row in rows:
            leaf, negated = _axis_leaf(str(row.get("axis") or ""))
            dof = str(row.get("dof") or "")
            gain = row.get("mmPerUnit")
            scale = f" * {float(gain):g}" if isinstance(gain, int | float) and gain != 1 else ""
            term = f"inputs['{dof}'].value{scale}"
            offsets[leaf] = _affine_leaf(offsets.get(leaf), f"-{term}" if negated else term)
        child["pose"] = {"translation": {"offset-mm": offsets}}
        components[f"moving-{order}"] = child
        notes.append(
            f"{', '.join(str(r.get('dof')) for r in rows)}: "
            f"{len(nodes)} mesh subtree(s) split into {name} — the metal moves"
        )

    if not files:
        return {}
    try:
        files["static.glb"] = glb_extract_subtrees(mesh, moving, invert=True)
        components["static"] = {
            "kind": "primitive",
            "category": "mechanics",
            "primitive": {"static-models": {"gltf": "static.glb"}},
        }
    except ValueError as exc:
        notes.append(f"no static remainder ({exc}) — every subtree moves")
    return files

def decompose_moving_parts(
    component: Any,
    template: Any,
    moving_parts: list[dict[str, Any]],
    mesh: bytes | None = None,
) -> DecomposeResult:
    """Build the subdesign documents for a record's moving parts.

    Two shapes, one flat design (WP-229 + WP-235):

    - **surface-bound rotations** → one optics-only child per driven mirror,
      authored in CUBE axes off the template's as-mounted ports;
    - **whole-optic translations** (a stage) → the record's optics VERBATIM
      on one child, seated by the template's ``insert-pose``.

    Translation rows apply to every child either way, so a galvo on a stage
    is one design rather than a nesting Go does not allow.

    ``moving_parts`` rows are the wizard's spelling: ``dof``, ``motion``,
    ``axis`` (±letter, F3), ``surface``, ``rangeMin``/``rangeMax``,
    ``resolution``, ``unit``, ``actuation``.
    """
    notes: list[str] = []
    rows: dict[int, dict[str, Any]] = {}
    translations: list[dict[str, Any]] = []
    seen_axes: set[str] = set()
    for row in moving_parts:
        surface = row.get("surface")
        motion = row.get("motion")
        name = str(row.get("dof") or "")
        if motion == "translation" and surface is None:
            if not name:
                notes.append("a translation row with no name — skipped")
                continue
            axis = str(row.get("axis") or "")
            _axis_leaf(axis)  # refuse a free axis here, not halfway through
            if axis in seen_axes:
                notes.append(f"{name}: {axis} already driven — skipped")
                continue
            seen_axes.add(axis)
            translations.append(row)
            continue
        if motion != "rotation" or surface is None:
            notes.append(
                f"{name or '?'}: neither a surface-bound rotation nor a "
                "translation — split the MESH with `optikit-core library "
                "decompose` (the geometry road)"
            )
            continue
        if int(surface) in rows:
            notes.append(f"{name}: surface {surface} already driven — skipped")
            continue
        rows[int(surface)] = row
    # WP-238: the mesh subtrees each translation row moves, grouped — one
    # child per distinct pick, carrying the SUM of its rows' terms.
    mesh_groups: list[tuple[frozenset[str], list[dict[str, Any]]]] = []
    if mesh:
        by_nodes: dict[frozenset[str], list[dict[str, Any]]] = {}
        for row in translations:
            picked = frozenset(str(n) for n in (row.get("nodes") or []) if n)
            if picked:
                by_nodes.setdefault(picked, []).append(row)
        mesh_groups = list(by_nodes.items())

    if not rows and not translations:
        raise DecomposeError(
            "E_DECOMPOSE_NOTHING",
            "no surface-bound rotations and no translations — nothing this "
            "road can author",
        )

    surfaces = list(
        getattr(getattr(component.optics, "fragment", None), "surfaces", None) or []
    )
    reflective = [
        i for i, s in enumerate(surfaces)
        if (s.get("interaction_model") or {}).get("is_reflective")
    ]
    frames = dict(getattr(template, "frames", None) or {})
    inputs: dict[str, Any] = {}
    components: dict[str, Any] = {}

    if not rows:
        # WP-235, the stage: nothing splits the optic, so the child IS the
        # record — its optics ship verbatim (F2) and the template's
        # `insert-pose` is what seats them in the cube, exactly as it does
        # for the undecomposed module.
        components[_whole_optic_id(component)] = _whole_optic_child(component, template)
        # The optic rides every translation; the MESH subtrees ride their own
        # rows (WP-238) — so the sample and the metal move together.
        inputs.update(_apply_translations(components, translations, notes))
        files = _split_moving_mesh(mesh, mesh_groups, components, notes) if mesh_groups else {}
        return _result(component, template, inputs, components, notes, files)

    entry, exits = _surface_ports(template)

    # Walk the beam through the reflective chain in surface order; every
    # reflective surface must have its exit port or the chain is unknowable.
    beam = _FLIP[str(entry.direction)]  # entry port FACES the beam
    for i in reflective:
        port = exits.get(i)
        if port is None:
            raise DecomposeError(
                "E_DECOMPOSE_NO_EXIT",
                f"no port names after-surface {i} — the beam's leg off that "
                "mirror is undeclared, so its child cannot be authored",
            )
        exit_dir = str(port.direction)
        if exit_dir not in _FLIP or beam not in _FLIP:
            raise DecomposeError(
                "E_DECOMPOSE_DIRECTION",
                f"port direction {exit_dir!r} is not an axis literal — only the "
                "grid-aligned case is authored mechanically",
            )
        owner = frames.get(str(port.frame))
        pos = {
            "x": float(getattr(owner, "x_mm", 0.0) or 0.0) if owner else 0.0,
            "y": float(getattr(owner, "y_mm", 0.0) or 0.0) if owner else 0.0,
            "z": float(getattr(owner, "z_mm", 0.0) or 0.0) if owner else 0.0,
        }

        frag = {k: v for k, v in dict(surfaces[i]).items() if k != "thickness"}
        comp: dict[str, Any] = {
            "kind": "primitive",
            "category": "mirror",
            "optics": {
                "fragment": {"surfaces": [frag]},
                "frames": {"optical": {"x-mm": 0.0, "y-mm": 0.0, "z-mm": 0.0}},
                "ports": {
                    "front": {"frame": "optical", "direction": _FLIP[beam]},
                    "reflected": {"frame": "optical", "direction": exit_dir,
                                  "after-surface": 0},
                },
            },
        }
        offset = {k: v for k, v in pos.items() if v}
        pose: dict[str, Any] = {}
        if offset:
            pose["translation"] = {"offset-mm": offset}

        row = rows.get(i)
        if row is not None:
            name = str(row.get("dof") or f"tilt_{i}")
            leaf, negated = _axis_leaf(str(row.get("axis") or ""))
            expr = (f"~ -inputs['{name}'].value" if negated
                    else f"~ inputs['{name}'].value")
            pose["rotation"] = {"kind": "uc2", "offset-deg": {leaf: expr}}
            inputs[name] = _input_spec(row, "deg")
        if pose:
            comp["pose"] = pose
        components[f"mirror-{i}"] = comp
        beam = exit_dir

    # A galvo ON a stage: the tilts split the optic, the travel moves all of it.
    inputs.update(_apply_translations(components, translations, notes))
    files = _split_moving_mesh(mesh, mesh_groups, components, notes) if mesh_groups else {}
    return _result(component, template, inputs, components, notes, files)


def _whole_optic_id(component: Any) -> str:
    """A readable child id from the component id (`user.lens.tube` → `tube`)."""
    return str(component.id).rsplit(".", 1)[-1].replace("_", "-") or "optic"


def _whole_optic_child(component: Any, template: Any) -> dict[str, Any]:
    """The record itself as one child: optics verbatim, seated by insert-pose.

    Nothing is re-authored here — that is the point. The optics (fragment,
    frames, ports) are F2 exactly as published, and the template's
    ``insert-pose`` is the same record→cube hop the undecomposed module
    already used, so decomposing a stage moves nothing optically.
    """
    optics = component.optics.model_dump(
        by_alias=True, exclude_defaults=True, exclude_none=True
    )
    # The library loader inlined any sidecar into `fragment`; a design
    # component has no record directory to resolve a relative path against.
    optics.pop("fragment-file", None)
    child: dict[str, Any] = {
        "kind": "primitive",
        "category": str(getattr(component, "category", "") or ""),
        "optics": optics,
    }
    source = getattr(component, "source", None)
    if source is not None:
        child["source"] = source.model_dump(
            by_alias=True, exclude_defaults=True, exclude_none=True
        )
    pose = getattr(template, "insert_pose", None)
    if pose is not None:
        seated = pose.model_dump(by_alias=True, exclude_defaults=True,
                                 exclude_none=True)
        if seated:
            child["pose"] = seated
    return child


def _result(
    component: Any,
    template: Any,
    inputs: dict[str, Any],
    components: dict[str, Any],
    notes: list[str],
    files: dict[str, bytes] | None = None,
) -> DecomposeResult:
    """The two documents, validated before anything is written."""
    ns, _, slug = template.id.partition(".tpl.")
    if not slug:
        ns, slug = template.id.split(".", 1)[0], template.id.rsplit(".", 1)[-1]
    design_id = f"{ns}.subdesign.{slug}"
    design = {
        "optikit-version": "v0.0.0-alpha.1",
        "design": {
            "name": slug.replace("_", "-"),
            "version": "0.1.0",
            "description": f"{component.id}, decomposed (motion as inputs)",
        },
        "inputs": inputs,
        "components": components,
    }
    DesignDecl.model_validate(design)  # refuse before anything is written
    record = {
        "kind": "cube_subdesign",
        "id": design_id,
        "version": "0.1.0",
        "description": f"{component.id} decomposed — sliders ride inputs "
                       f"{', '.join(inputs)}",
        # Provenance, not an optical side (D2 binds the MODULE): which
        # component this was decomposed from. The index uses it to keep
        # serving the companion component block, so every editor join that
        # walks component.ref → module (mesh resolve, rehydrate, the
        # bound-set) survives the module's rewrite to `design:`.
        "component": f"{component.id}@^"
                     + ".".join(str(component.version).split(".")[:2]),
        "tags": ["subdesign", "decomposed"],
        "review": (
            []
            if files
            else [
                "optics-only children: the module's template still renders "
                "the monolithic mesh, so the beam moves while the CAD does "
                "not — pick the moving mesh subtrees in the wizard's moving-"
                "parts step and republish to split them (WP-238)",
            ]
        ),
    }
    return DecomposeResult(design_id=design_id, design=design, record=record,
                           inputs=list(inputs), notes=notes, files=files or {})


# --- WP-246: the seats an insert can take -------------------------------------------

#: A seat's variant id: the grid spelled with letters, so it is a legal key in
#: YAML, in Go and in a URL. `{z: -y, x: -x}` → `seat-my-mx`.
def seat_id(grid: tuple[str, str]) -> str:
    spell = {"+": "p", "-": "m"}
    return "seat-" + "-".join(f"{spell[a[0]]}{a[1]}" for a in grid)


def seat_variants(
    component: Any, template: Any, seats: list[tuple[str, str]],
) -> DecomposeResult:
    """WP-246: a component-backed cube module as a subdesign whose SEATS are variants.

    The insert-in-cube joint used to be a placement's ``mounting:`` — a key Go
    does not know, so Ethan's binary rendered every design carrying one with
    its optic un-rotated. The same joint as design ``variants:`` is Go-native:
    the placement selects with ``instantiation.variant``.

    One child, the optic, posed by the template's ``insert-pose`` (the
    record→cube hop). A seat variant replaces that child's rotation with
    ``R_seat · R_insert-pose`` — both grid rotations, so the product is again
    one of the 24 and the record stays a plain grid. That reproduces
    ``optic_poses``'s ``R = R_pose · R_mount`` exactly, which is the migration's
    whole acceptance.

    ``seats`` are the LEGAL seats, not all 24: a module records what its insert
    can actually take (WP-177's open ask). The identity seat is always first.
    """
    from ..geometry.rotations import compose, rot24_matrix
    from ..geometry.rotations import decompose as decompose_rot

    optic_id = _whole_optic_id(component)
    child = _whole_optic_child(component, template)
    notes: list[str] = []

    pose = getattr(template, "insert_pose", None)
    rot = pose.rotation if pose is not None else None
    base = rot24_matrix(rot.grid.z or "+z", rot.grid.x or "+x") if rot else rot24_matrix()
    if rot is not None and any(
        abs(float(getattr(rot.offset_deg, axis) or 0.0)) > 1e-9 for axis in "xyz"
    ):
        # A residual would not survive the grid round trip below; refusing beats
        # writing a seat that quietly drops the template's own tilt.
        raise ValueError(
            f"{template.id}: insert-pose carries an offset-deg residual — a seat "
            "variant is one of the 24 grid rotations (WP-246); author the residual "
            "on the component instead"
        )

    identity = ("+z", "+x")
    ordered = [identity] + [s for s in seats if tuple(s) != identity]
    variants: dict[str, Any] = {}
    for seat in ordered:
        seated = decompose_rot(compose(seat[0], seat[1]) @ base)
        if seated.residual_angle_deg > 1e-6:  # pragma: no cover — grid·grid is grid
            raise ValueError(f"seat {seat} does not land on the 24-grid")
        vid = seat_id(tuple(seat))
        if tuple(seat) == identity:
            # The base seat IS the child's own pose — an empty variant, the way
            # mirror-static.dsn spells its base.
            variants[vid] = {"description": "as authored — the insert's home seat"}
            continue
        variants[vid] = {
            "description": f"insert seated {seat[0]} / {seat[1]}",
            "components": {optic_id: {"pose": {"rotation": {
                "kind": "grid", "grid": {"z": seated.z, "x": seated.x}}}}},
        }

    result = _result(component, template, {}, {optic_id: child}, notes)
    result.design["variants"] = variants
    result.design["design"]["description"] = (
        f"{component.id} in a cube — {len(variants)} seat(s)")
    result.record["description"] = (
        f"{component.id}, seats as variants: {', '.join(variants)}")
    result.record["tags"] = ["subdesign", "seats"]
    result.record["review"] = []
    result.variants = list(variants)
    DesignDecl.model_validate(result.design)
    return result


def write_subdesign(root: Path, result: DecomposeResult) -> list[str]:
    """Write the subdesign folder; returns library-relative paths."""
    from ..io.yamlio import dump_document

    out_dir = root / "subdesigns" / result.design_id
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "subdesign.yml").write_text(dump_document(result.record))
    (out_dir / "optikit-design.yml").write_text(dump_document(result.design))
    rel = f"subdesigns/{result.design_id}"
    written = [f"{rel}/subdesign.yml", f"{rel}/optikit-design.yml"]
    # WP-238: the split meshes live beside the design that poses them, so a
    # `static-models` path resolves relative to the subdesign folder.
    for name, blob in sorted(result.files.items()):
        (out_dir / name).write_bytes(blob)
        written.append(f"{rel}/{name}")
    return written


def point_module_at_design(module_path: Path, design_id: str) -> None:
    """Rewrite the module's optical side: ``component:`` → ``design:`` (D2).

    Comment-preserving; the template ref stays — it is the mesh.
    """
    from ruamel.yaml import YAML

    yaml = YAML()
    yaml.preserve_quotes = True
    yaml.width = 100000
    doc = yaml.load(module_path.read_text())
    doc.pop("component", None)
    doc["design"] = f"{design_id}@^0.1"
    with module_path.open("w") as fh:
        yaml.dump(doc, fh)
