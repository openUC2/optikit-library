"""Merge posed GLBs into one file — a design folder's ``_objects.glb``.

Go's generator drops a flattened ``_objects.glb`` beside every design; ours
serves the same purpose for a published subdesign: ONE mesh for the palette
tile, the parts editor and anything that wants the whole assembly without
walking children. Each part becomes a named root node carrying its pose; the
triangle data, materials and accessors are carried over verbatim.

Content frame: the design frame, z-up, millimetres — every part must already
speak it (the runner normalizes its exports; a file stamped in metres is
scaled on its node). Textured or sparse inputs are refused, not mangled.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .mesh import _chunks, _write_glb

_UNIT_KEY = "optikit_length_unit"
_MM_PER_UNIT = {"": 1.0, "mm": 1.0, "millimeter": 1.0, "millimetre": 1.0,
                "m": 1000.0, "meter": 1000.0, "metre": 1000.0}


@dataclass(frozen=True)
class GlbPart:
    name: str
    data: bytes
    translation_mm: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation_xyzw: tuple[float, float, float, float] | None = None


def _shift(prim: dict[str, Any], accessors: int, materials: int) -> dict[str, Any]:
    out = dict(prim)
    out["attributes"] = {k: v + accessors for k, v in prim.get("attributes", {}).items()}
    if "indices" in out:
        out["indices"] += accessors
    if "material" in out:
        out["material"] += materials
    if "targets" in out:
        out["targets"] = [{k: v + accessors for k, v in t.items()} for t in prim["targets"]]
    return out


def assemble_glb(parts: list[GlbPart]) -> bytes:
    """One GLB from many, each under a posed root node named after its part."""
    if not parts:
        raise ValueError("nothing to assemble")
    out: dict[str, Any] = {
        "asset": {"version": "2.0", "generator": "optikit-core assemble_glb",
                  "extras": {_UNIT_KEY: "mm"}},
        "scene": 0, "scenes": [{"nodes": []}],
        "nodes": [], "meshes": [], "accessors": [], "bufferViews": [], "materials": [],
    }
    binary = bytearray()
    for part in parts:
        gltf, blob = _chunks(part.data)
        if gltf.get("textures") or gltf.get("images") or gltf.get("skins"):
            raise ValueError(f"{part.name}: textured or skinned meshes are not supported")
        if len(gltf.get("buffers", [])) > 1:
            raise ValueError(f"{part.name}: multi-buffer glTF is not supported")
        unit = str((gltf.get("asset") or {}).get("extras", {}).get(_UNIT_KEY, "")).lower()
        if unit not in _MM_PER_UNIT:
            raise ValueError(f"{part.name}: unknown length unit {unit!r}")
        binary.extend(b"\x00" * (-len(binary) % 4))
        base = len(binary)
        binary.extend(blob or b"")

        bv_off, acc_off = len(out["bufferViews"]), len(out["accessors"])
        mat_off, mesh_off, node_off = (len(out["materials"]), len(out["meshes"]),
                                       len(out["nodes"]))
        for bv in gltf.get("bufferViews", []):
            out["bufferViews"].append(
                {**bv, "buffer": 0, "byteOffset": bv.get("byteOffset", 0) + base})
        for acc in gltf.get("accessors", []):
            if "sparse" in acc:
                raise ValueError(f"{part.name}: sparse accessors are not supported")
            new = dict(acc)
            if "bufferView" in new:
                new["bufferView"] += bv_off
            out["accessors"].append(new)
        out["materials"].extend(dict(m) for m in gltf.get("materials", []))
        for mesh in gltf.get("meshes", []):
            out["meshes"].append({**mesh, "primitives": [
                _shift(p, acc_off, mat_off) for p in mesh.get("primitives", [])]})
        for node in gltf.get("nodes", []):
            new = {k: v for k, v in node.items() if k not in ("skin", "camera")}
            if "mesh" in new:
                new["mesh"] += mesh_off
            if "children" in new:
                new["children"] = [c + node_off for c in new["children"]]
            out["nodes"].append(new)
        scenes = gltf.get("scenes") or [{}]
        roots = [r + node_off for r in scenes[gltf.get("scene", 0)].get("nodes", [])]
        wrapper: dict[str, Any] = {"name": part.name, "children": roots}
        if any(abs(v) > 1e-9 for v in part.translation_mm):
            wrapper["translation"] = [float(v) for v in part.translation_mm]
        if part.rotation_xyzw is not None:
            wrapper["rotation"] = [float(v) for v in part.rotation_xyzw]
        scale = _MM_PER_UNIT[unit]
        if scale != 1.0:
            wrapper["scale"] = [scale, scale, scale]
        out["nodes"].append(wrapper)
        out["scenes"][0]["nodes"].append(len(out["nodes"]) - 1)

    binary.extend(b"\x00" * (-len(binary) % 4))
    out["buffers"] = [{"byteLength": len(binary)}]
    for key in ("meshes", "accessors", "bufferViews", "materials"):
        if not out[key]:  # glTF forbids empty top-level arrays
            del out[key]
    return _write_glb(out, bytes(binary))
