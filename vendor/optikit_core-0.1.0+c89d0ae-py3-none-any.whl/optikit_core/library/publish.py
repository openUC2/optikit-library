"""M2: get a record out of the service and into a review, without a bot.

`POST /v1/library/save` writes records to disk. When the library root is a
checkout of the library repo (R1), "to disk" is one `git push` away from being
a contribution — and this is that step.

**The PR is opened by a human, not by the service.** The service commits on a
new branch and pushes it; the response carries GitHub's compare URL, and a
person clicks it, sees the diff, and writes the description under their own
account. That is deliberately simpler than the API-opened PR the plan first
sketched, and better in three ways: no bot account to create, no
PR-creation token to scope and rotate, and the person who authored the part is
the person the review is addressed to.

**Safety is by refusal, not by care.** Publishing is off unless a remote is
explicitly configured, it never writes to the default branch, and it pushes
only the record tree. The existing `OPTIKIT_ALLOW_LIBRARY_WRITE` gate still
governs whether anything may be written at all; this adds a second gate on top
of it, because "may write a file locally" and "may push to the shared
catalogue" are different permissions and should not be one flag.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
import threading
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

#: Directories a publish may write. Copilot review (PR #15, publish.py:146):
#: the only check on a requested path was "does not escape the library root",
#: which still allowed `.github/workflows/*`, `README.md`, or anything else in
#: the checkout to be committed and pushed by request. This module's promise
#: is the RECORD TREE, so state it as an allowlist.
PUBLISHABLE_DIRS = ("components", "templates", "modules")

#: One publish at a time per library root. Copilot review (PR #15,
#: publish.py:155): `publish` moves one shared checkout's HEAD, index and
#: working tree from a request handler. Two concurrent calls could read each
#: other's base branch and each `finally` could force-checkout the other's,
#: mixing payloads or stranding the service on the wrong branch. This does not
#: make the operation safe against a second PROCESS on the same checkout —
#: that needs the isolated worktree tracked as a follow-up — but it removes
#: the race the service can actually cause on its own.
_ROOT_LOCKS: dict[str, threading.Lock] = {}
_ROOT_LOCKS_GUARD = threading.Lock()


def _root_lock(root: Path) -> threading.Lock:
    key = str(root.resolve())
    with _ROOT_LOCKS_GUARD:
        return _ROOT_LOCKS.setdefault(key, threading.Lock())

#: Set to the git remote to push to (usually `origin`). ABSENT DISABLES
#: PUBLISHING — there is no default, because a default here would mean an
#: unconfigured deployment could push to whatever remote its checkout happened
#: to have.
PUSH_REMOTE_ENV = "OPTIKIT_LIBRARY_PUSH_REMOTE"

#: Branches a publish may never target, whatever the caller asks for. A
#: contribution flow that can write the default branch is not a contribution
#: flow.
PROTECTED_BRANCHES = frozenset({"main", "master", "trunk", "HEAD"})

#: Branch names are built from a caller-supplied slug, so the slug is
#: constrained rather than trusted: git accepts a lot of punctuation that then
#: needs quoting everywhere downstream.
_SLUG_OK = re.compile(r"[^a-zA-Z0-9._-]+")


class PublishError(Exception):
    """Typed publish failure; `code` is stable API."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


@dataclass(frozen=True)
class Published:
    branch: str
    commit: str
    remote: str
    files: list[str]
    #: The URL a human opens to raise the PR — empty when the remote is not
    #: GitHub, in which case the branch is pushed and the rest is manual.
    compare_url: str


def _git(root: Path, *args: str, check: bool = True) -> str:
    """Run one git command in `root`. Fixed argv, never a shell."""
    result = subprocess.run(  # noqa: S603 — argv is fixed, input is validated
        ["git", "-C", str(root), *args],  # noqa: S607
        capture_output=True, text=True, timeout=60, check=False,
    )
    if check and result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip()
        raise PublishError("E_GIT", f"git {' '.join(args)} failed: {detail}")
    return result.stdout.strip()


def branch_name(slug: str, prefix: str = "part") -> str:
    """A safe branch name from a caller-supplied slug."""
    cleaned = _SLUG_OK.sub("-", slug).lower()
    cleaned = re.sub(r"-{2,}", "-", cleaned).strip("-.")[:60].strip("-.")
    return f"{prefix}/{cleaned or 'record'}"


def compare_url_for(remote_url: str, branch: str) -> str:
    """GitHub's "open a PR from this branch" URL, or "" for a non-GitHub remote.

    Handles both spellings a checkout can carry — `https://github.com/o/r.git`
    and `git@github.com:o/r.git` — because which one a machine has is an
    accident of how it was cloned.
    """
    m = re.match(r"(?:https://github\.com/|git@github\.com:)([^/]+)/(.+?)(?:\.git)?/?$",
                 remote_url.strip())
    if not m:
        return ""
    owner, repo = m.group(1), m.group(2)
    return f"https://github.com/{owner}/{repo}/compare/{branch}?expand=1"


def publish(root: Path, files: list[str], slug: str, message: str) -> Published:
    """Commit `files` on a fresh branch in `root` and push it.

    `files` are repo-relative paths already written by the caller — this does
    not write records, it only gets what was written into review. Nothing else
    in the working tree is committed: the add list is explicit, so a publish
    cannot sweep up unrelated edits an operator happened to have open.
    """
    remote = os.environ.get(PUSH_REMOTE_ENV)
    if not remote:
        raise PublishError(
            "E_PUBLISH_DISABLED",
            f"publishing is off: set {PUSH_REMOTE_ENV} to the git remote to push to. "
            "There is no default, because a default would let an unconfigured "
            "deployment push to whatever remote its checkout happens to have.")
    if not (root / ".git").exists():
        raise PublishError(
            "E_NOT_A_CHECKOUT",
            f"{root} is not a git checkout — publishing needs one (see R1: point "
            "OPTIKIT_LIBRARY_ROOT at a checkout of the library repo)")
    if not files:
        raise PublishError("E_NOTHING_TO_PUBLISH", "no files named")

    branch = branch_name(slug)
    # Case-insensitive: `branch_name` lowercases, so a literal "HEAD" would
    # otherwise sail past a set that spells it in caps.
    protected = {b.lower() for b in PROTECTED_BRANCHES}
    if branch.rsplit("/", 1)[-1].lower() in protected or branch.lower() in protected:
        raise PublishError("E_PROTECTED_BRANCH", f"refusing to publish to {branch!r}")

    # Branch off wherever the checkout is, and return there afterwards.
    # Read the records BEFORE touching the branch. Switching branches in a
    # tree that has these files untracked (or modified) is exactly the case
    # git refuses — "untracked working tree file would be overwritten" — and
    # it is the ordinary case here, because `/v1/library/save` just wrote them.
    # Carrying the bytes in memory sidesteps every working-tree conflict, and
    # makes republishing an open branch behave the way review actually works:
    # another commit on the same branch, not an error.
    payload: dict[str, bytes] = {}
    for rel in files:
        # `rel` comes from the request, so it is checked twice: it must name a
        # path INSIDE the record tree (not just inside the checkout), and it
        # must still resolve under the root once symlinks and `..` are folded.
        parts = PurePosixPath(rel).parts
        if not parts or parts[0] not in PUBLISHABLE_DIRS or ".." in parts:
            raise PublishError(
                "E_BAD_PATH",
                f"only {'/, '.join(PUBLISHABLE_DIRS)}/ may be published, not {rel!r}")
        target = (root / rel).resolve()
        if root.resolve() not in target.parents:
            raise PublishError("E_BAD_PATH", f"path escapes the library root: {rel}")
        if not target.is_file():
            raise PublishError("E_NOT_FOUND", f"no such file to publish: {rel}")
        payload[rel] = target.read_bytes()

    # Everything from here reads and MOVES shared checkout state, so it is one
    # critical section per root (see `_root_lock`). `base` in particular must
    # be read inside it: taken outside, a concurrent publish could already
    # have moved HEAD, and the `finally` would restore the wrong branch.
    with _root_lock(root):
        return _publish_locked(root, payload, branch, remote, message)


def _publish_locked(
    root: Path,
    payload: dict[str, bytes],
    branch: str,
    remote: str,
    message: str,
) -> Published:
    """Commit and push the payload from a throwaway worktree."""
    published_files: list[str] = []
    existed = _git(root, "rev-parse", "--verify", "--quiet", branch, check=False) != ""
    # Outside the library root on purpose: a worktree inside it would be
    # walked by `library build`/`validate` and served as duplicate records.
    tmp = Path(tempfile.mkdtemp(prefix="optikit-publish-"))
    tree = tmp / "wt"
    try:
        # Reuse an open branch (a review already in flight); otherwise cut a
        # fresh one from where the checkout is. `--force` covers the case of
        # the branch already being checked out somewhere — we only ever add
        # a commit to it, and the operator's own tree is not the one moving.
        add = ["worktree", "add", "--force", str(tree)]
        _git(root, *(add + [branch] if existed else add + ["-B", branch, "HEAD"]))

        for rel, data in payload.items():
            dest = tree / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        # Explicit add list — never `git add -A`. (In a fresh worktree there is
        # nothing else to sweep up, but the promise is the same either way.)
        _git(tree, "add", "--", *payload)
        staged = _git(tree, "diff", "--cached", "--name-only", "--", *payload)
        if not staged:
            raise PublishError(
                "E_NOTHING_TO_PUBLISH",
                f"nothing to commit: {branch} already holds these records unchanged")
        published_files = sorted(staged.splitlines())
        _git(tree, "commit", "--only", "-m", message, "--", *payload)
        commit = _git(tree, "rev-parse", "--short", "HEAD")
        _git(tree, "push", "--set-upstream", remote, branch)
    finally:
        # `--force` because the worktree is dirty by construction; `prune`
        # because a killed process leaves the administrative entry behind and
        # the next publish would then refuse the path as already registered.
        _git(root, "worktree", "remove", "--force", str(tree), check=False)
        _git(root, "worktree", "prune", check=False)
        shutil.rmtree(tmp, ignore_errors=True)

    return Published(
        branch=branch, commit=commit, remote=remote,
        files=published_files,
        compare_url=compare_url_for(_git(root, "remote", "get-url", remote, check=False), branch),
    )
