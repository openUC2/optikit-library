"""Resolve a DOF value to a firmware command (WP-26).

WP-42 made the actuation contract a record fact: a template DOF is bound to a
firmware object by the module's ``electronics.axis-map``. WP-26 is the runtime
end — turning a *value* on that DOF into the command a device actually runs.
This is the one canonical mapping (the frontend mirrors it for the live UI):

    dof value + axis-map entry + firmware-contract  →  command descriptor

The descriptor carries both a CANopen SDO view (object index/subindex/value)
and a UC2-REST view (the openUC2 controller's JSON task), so the caller sends
whichever the device speaks. Nothing here talks to hardware — it produces the
payload; the frontend (or a script) POSTs it.
"""

from __future__ import annotations

from typing import Any

from ..schema.library import ModuleRecord, TemplateRecord
from .build import Library, resolve


class ActuationError(Exception):
    """The DOF cannot be actuated (unknown, not actuatable, or unbound)."""


def _resolve_can_object(value: int | str) -> tuple[int, int]:
    """A CANopen SDO index+subindex from an axis-map ``can-object``.

    Accepts an integer object index (subindex 0) or an ``"index:sub"`` string.
    """
    if isinstance(value, int):
        return value, 0
    text = str(value)
    if ":" in text:
        index, sub = text.split(":", 1)
        return int(index, 0), int(sub, 0)
    return int(text, 0), 0


def firmware_command(
    library: Library, module_id: str, dof_name: str, value: float
) -> dict[str, Any]:
    """The command descriptor to drive ``module_id``'s DOF ``dof_name`` to ``value``.

    Raises :class:`ActuationError` when the DOF is unknown, not ``actuatable``,
    out of its declared range, or has no ``axis-map`` binding.
    """
    module_hit = next(
        (
            e for e in library.by_kind("cube_module")
            if isinstance(e.record, ModuleRecord) and e.record.id == module_id
        ),
        None,
    )
    if module_hit is None:
        raise ActuationError(f"module {module_id!r} not found")
    module = module_hit.record
    assert isinstance(module, ModuleRecord)

    tpl_hit = resolve(library, module.template)
    template = tpl_hit.record if tpl_hit else None
    if not isinstance(template, TemplateRecord):
        raise ActuationError(f"template of {module_id!r} does not resolve")

    # WP-230: a module's actuated motions are its subdesign's INPUT
    # variables — the only channel left. `actuation: firmware` (our
    # extension key on Go's InputVarSpec) is what makes one drivable;
    # min/max are Go's own fields; the kind follows the declared units.
    spec = _subdesign_input(library, module.design, dof_name) if module.design else None
    if spec is None:
        raise ActuationError(
            f"{module_id} declares no input {dof_name!r} "
            "(a module's actuated motions are its subdesign's inputs)"
        )
    if spec.actuation != "firmware":
        raise ActuationError(f"input {dof_name!r} is not firmware-actuated")
    if spec.min is not None and spec.max is not None:
        lo, hi = float(spec.min), float(spec.max)
        if not lo <= value <= hi:
            raise ActuationError(
                f"value {value} is outside input {dof_name!r} range "
                f"[{lo}, {hi}] {spec.units}"
            )
    kind = "translation" if spec.units == "mm" else "rotation"
    unit = spec.units or ""

    axis_map = module.electronics.axis_map if module.electronics else []
    entry = next((e for e in axis_map if e.dof == dof_name), None)
    if entry is None:
        raise ActuationError(
            f"DOF {dof_name!r} is actuatable but has no axis-map entry (WP-42)"
        )

    index, subindex = _resolve_can_object(entry.can_object)
    contract = module.electronics.firmware_contract if module.electronics else ""
    return {
        "module": module_id,
        "dof": dof_name,
        "kind": kind,
        "value": value,
        "unit": unit,
        "firmware-contract": contract,
        "can": {"object": entry.can_object, "index": index, "subindex": subindex, "value": value},
        # UC2-REST view (openUC2 controller JSON) — a motor move or a mirror set.
        "uc2rest": {
            "task": "/motor_act" if kind == "translation" else "/galvo_act",
            "axis": dof_name,
            "target": value,
            "unit": unit,
        },
    }

def _subdesign_input(library, ref: str, name: str):
    """The named InputVarSpec of a subdesign-backed module, or None."""
    from ..io.yamlio import load_design
    from .subdesigns import SubdesignError, subdesign_dir

    try:
        _record, design_file = subdesign_dir(library, ref)
        return load_design(design_file.parent).inputs.get(name)
    except (SubdesignError, ValueError, KeyError, OSError):
        return None
