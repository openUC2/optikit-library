"""Prescription-driven T2 pocket parameters (WP-35, amendment 3).

The MAS-2000 lens-holder pocket generator is the reference: edge thickness +
lens ⌀ + axis hole → "Generate Cut". Those inputs are all derivable from the
component record's fragment — so binding a lens record to a T2 template can
parameterize the pocket with no hand input:

- **diameter** — 2 × the largest surface ``semi_aperture``;
- **center thickness** — the first surface's ``thickness`` (the glass gap);
- **edge thickness** — center thickness − front sag + back sag at the edge
  (the standard conic sag equation, clamped at the aperture edge).

Values land in millimetres, ready for the Inventor fx parameters of the
master-insert pocket (or a CadQuery pocket generator).
"""

from __future__ import annotations

from ..schema.library import ComponentRecord

# The sag math lives in the stdlib-only ``sag`` module so the T3 generator
# scripts can load it by file path (WP-62); re-exported here for callers.
from .sag import sag_at, surface_sag

__all__ = ["pocket_params", "pocket_params_from_surfaces", "sag_at"]


def pocket_params_from_surfaces(
    surfaces: list[dict], where: str = "prescription"
) -> dict[str, float]:
    """The pocket numbers from a raw surface stack (WP-85: the T2 bridge
    derives fx parameters from a DESIGN component's inline fragment, where no
    library record exists to wrap it)."""
    if not surfaces:
        raise ValueError(f"{where} has no surfaces")
    semi = max(
        (float(s["semi_aperture"]) for s in surfaces if s.get("semi_aperture")),
        default=0.0,
    )
    if semi <= 0.0:
        raise ValueError(f"{where} declares no semi_aperture")
    center = sum(float(s.get("thickness") or 0.0) for s in surfaces[:-1])
    front = surfaces[0]
    back = surfaces[-1]
    front_sag = surface_sag(front, semi)
    back_sag = surface_sag(back, semi)
    edge = center - front_sag + back_sag
    return {
        "lens-diameter-mm": round(2.0 * semi, 6),
        "center-thickness-mm": round(center, 6),
        "edge-thickness-mm": round(edge, 6),
    }


def pocket_params(component: ComponentRecord) -> dict[str, float]:
    """MAS-2000-style pocket parameters from a lens record's surfaces.

    Raises ``ValueError`` when the record has no usable fragment (pockets are
    for real glass, not passthrough stubs).
    """
    fragment = component.optics.fragment
    if fragment is None or not fragment.surfaces:
        raise ValueError(f"component {component.id} has no fragment surfaces")
    return pocket_params_from_surfaces(fragment.surfaces, where=f"component {component.id}")
