"""WP-109: does a template's mesh actually agree with the record? (glTF only)

The library holds **two undeclared mesh conventions** and nothing in the schema
distinguishes them:

* the older exports ship a literal ``Rx(-90°)`` wrapper node (quaternion
  ``[-0.7071, 0, 0, 0.7071]``) that performs the document→three basis change
  *inside* the glTF, so their post-transform bounding box is y-up;
* the newer Open CASCADE exports (``__mm_scale__`` root, no rotation) leave the
  vertices in the document frame, z-up.

A renderer feeds mesh axes straight into its own frame, so the two families
only look the same because a placed part's default rotation happens to
compensate. That is folklore, not a contract — and the way it fails is a cube
lying on its side, which nobody notices until they look.

Rather than add a ``mesh-frame:`` field and institutionalise the ambiguity,
this checks the thing we actually care about: a template that declares a
``footprint_grid`` is a CUBE, so its mesh must measure roughly one grid cell —
50 × 50 × 55 mm — with the 55 mm extent on the stacking axis. Anything else is
either the wrong file, the wrong units, or a lost wrapper node, and all three
are worth failing loudly at ingest instead of discovering in the viewport.

Pure stdlib: a glTF binary is a 12-byte header plus length-prefixed JSON and
BIN chunks, and accessor ``min``/``max`` give the bounding box without touching
vertex data. No mesh library, no import cost when the check does not run.
"""

from __future__ import annotations

import json
import math
import re
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any

#: UC2 grid pitch (mm). A 1×1×1 cube mesh should measure about this.
UC2_CELL_MM = (50.0, 50.0, 55.0)
#: How far a real export may sit from the nominal cell before we complain.
#: The shipped TH1 cube measures 49.8 × 49.8 × 54.4 — joint clearance, not error.
CELL_TOL_MM = 3.0


@dataclass(frozen=True)
class MeshBox:
    """A glTF's world bounding box, after node transforms."""

    min: tuple[float, float, float]
    max: tuple[float, float, float]

    @property
    def size(self) -> tuple[float, float, float]:
        return tuple(hi - lo for lo, hi in zip(self.min, self.max, strict=True))  # type: ignore[return-value]

    @property
    def center(self) -> tuple[float, float, float]:
        return tuple((hi + lo) / 2 for lo, hi in zip(self.min, self.max, strict=True))  # type: ignore[return-value]


def _chunks(data: bytes) -> tuple[dict, bytes | None]:
    """Split a .glb into its JSON chunk and its BIN chunk."""
    if len(data) < 12 or data[:4] != b"glTF":
        raise ValueError("not a glTF binary (missing magic)")
    version, total = struct.unpack_from("<II", data, 4)
    if version != 2:
        raise ValueError(f"unsupported glTF version {version}")
    if total != len(data):
        raise ValueError(f"declared length {total} != file size {len(data)}")
    offset, gltf, binary = 12, None, None
    while offset + 8 <= len(data):
        length, kind = struct.unpack_from("<I4s", data, offset)
        payload = data[offset + 8 : offset + 8 + length]
        if kind == b"JSON":
            gltf = json.loads(payload)
        elif kind == b"BIN\x00":
            binary = payload
        offset += 8 + length + (-length % 4)
    if gltf is None:
        raise ValueError("glTF has no JSON chunk")
    return gltf, binary


def _matrix(node: dict) -> list[float]:
    """A node's local transform as a column-major 4×4, per the glTF spec."""
    if "matrix" in node:
        return list(node["matrix"])
    tx, ty, tz = node.get("translation", (0.0, 0.0, 0.0))
    qx, qy, qz, qw = node.get("rotation", (0.0, 0.0, 0.0, 1.0))
    sx, sy, sz = node.get("scale", (1.0, 1.0, 1.0))
    # rotation matrix from the quaternion
    r = [
        1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy + qz * qw), 2 * (qx * qz - qy * qw),
        2 * (qx * qy - qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz + qx * qw),
        2 * (qx * qz + qy * qw), 2 * (qy * qz - qx * qw), 1 - 2 * (qx * qx + qy * qy),
    ]
    return [
        r[0] * sx, r[1] * sx, r[2] * sx, 0.0,
        r[3] * sy, r[4] * sy, r[5] * sy, 0.0,
        r[6] * sz, r[7] * sz, r[8] * sz, 0.0,
        tx, ty, tz, 1.0,
    ]


def _mul(a: list[float], b: list[float]) -> list[float]:
    """Column-major 4×4 product a·b (apply b, then a)."""
    out = [0.0] * 16
    for col in range(4):
        for row in range(4):
            out[col * 4 + row] = sum(a[k * 4 + row] * b[col * 4 + k] for k in range(4))
    return out


def _apply(m: list[float], p: tuple[float, float, float]) -> tuple[float, float, float]:
    x, y, z = p
    return (
        m[0] * x + m[4] * y + m[8] * z + m[12],
        m[1] * x + m[5] * y + m[9] * z + m[13],
        m[2] * x + m[6] * y + m[10] * z + m[14],
    )


IDENTITY = [1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0]


#: glTF component types → (struct format, byte size). POSITION is VEC3 of
#: one of these; the quantized forms arrive with `normalized: true`.
_COMPONENT_FORMATS = {
    5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2), 5123: ("H", 2), 5126: ("f", 4),
}

#: glTF component types → the divisor that turns a NORMALIZED integer back
#: into its real value (KHR_mesh_quantization). Float accessors need none.
_NORMALIZED_DIVISOR = {5120: 127.0, 5121: 255.0, 5122: 32767.0, 5123: 65535.0}


def _dequantize(accessor: dict, values: list[float]) -> list[float]:
    """Undo a normalized-integer accessor's scaling.

    WP-147: `KHR_mesh_quantization` stores positions as normalized int16 and
    puts the real millimetres in the node's scale. Reading `min`/`max`
    verbatim therefore measured the FRAME body as 10 157 770 mm — a check
    that cannot be satisfied and a mesh that cannot be placed. three.js
    handles the extension natively, so only our own readers were blind.
    """
    if not accessor.get("normalized"):
        return values
    divisor = _NORMALIZED_DIVISOR.get(accessor.get("componentType", 5126))
    if divisor is None:
        return values
    return [max(-1.0, v / divisor) for v in values]


def _rotates(matrix: list[float]) -> bool:
    """True when a transform is not axis-aligned, so boxes must be exact.

    An axis-aligned matrix (identity, translation, scale, or a 90 deg
    multiple) maps the corners of a box onto the corners of a box, and the
    cheap eight-corner path is exact. Anything else shears the box.
    """
    for column in range(3):
        axis = [matrix[column * 4 + row] for row in range(3)]
        nonzero = [abs(v) > 1e-9 for v in axis]
        if sum(nonzero) != 1:
            return True
    return False


def _read_positions(gltf: dict, binary: bytes, index: int) -> list[tuple]:
    """One POSITION accessor's raw elements (pre-dequantization)."""
    acc = gltf["accessors"][index]
    code, size = _COMPONENT_FORMATS[acc["componentType"]]
    view = gltf["bufferViews"][acc["bufferView"]]
    stride = view.get("byteStride") or 3 * size
    base = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
    return [
        struct.unpack_from(f"<3{code}", binary, base + i * stride)
        for i in range(acc["count"])
    ]


def _mm_scale(gltf: dict, lo: list[float], hi: list[float]) -> float:
    """Millimetres per unit for this file, from its stamp or its own size.

    WP-237: what we write is spec metres and says so; the corpus predating
    that is millimetres and says nothing. Every measurement below is in mm
    either way, so nothing above these readers knows the question exists.
    """
    from ..units import mm_per_unit

    extent = max(hi_v - lo_v for lo_v, hi_v in zip(lo, hi, strict=True))
    return mm_per_unit(gltf, extent)


def glb_bounding_box(path: Path) -> MeshBox:
    """World bounding box of a .glb, honouring node transforms.

    Accessor min/max are per-primitive and pre-transform, so each mesh's box
    corners are pushed through its node chain — which is precisely what makes
    the wrapper-node family measurable at all.

    Under a ROTATING node that is only an approximation, and a loose one: the
    box of a rotated box is bigger than the rotated box. How much bigger
    depends on how many primitives the mesh happens to be split into, so the
    same geometry measures differently before and after WP-224's merge — the
    galvo mount read 21 mm taller with identical vertices. A number that
    changes when nothing physical changed is not a measurement, so a rotated
    node reads the actual POSITION data instead. Axis-aligned and
    translation-only nodes keep the cheap corner path, where it is exact.
    """
    gltf, binary = _chunks(path.read_bytes())
    nodes = gltf.get("nodes", [])
    meshes = gltf.get("meshes", [])
    accessors = gltf.get("accessors", [])
    scene = gltf.get("scenes", [{}])[gltf.get("scene", 0)]

    lo = [float("inf")] * 3
    hi = [float("-inf")] * 3

    def walk(index: int, parent: list[float]) -> None:
        node = nodes[index]
        world = _mul(parent, _matrix(node))
        mesh_index = node.get("mesh")
        if mesh_index is not None:
            exact = _rotates(world)
            for prim in meshes[mesh_index].get("primitives", []):
                index = prim.get("attributes", {}).get("POSITION")
                if index is None:
                    continue
                acc = accessors[index]
                if exact:
                    # The vertices themselves — the only measurement that does
                    # not depend on how the mesh is split into primitives.
                    points = [
                        _dequantize(acc, v)
                        for v in _read_positions(gltf, binary or b"", index)
                    ]
                else:
                    a_min, a_max = acc.get("min"), acc.get("max")
                    if not a_min or not a_max:
                        continue
                    a_min, a_max = _dequantize(acc, a_min), _dequantize(acc, a_max)
                    # Every corner, because a rotation turns a box into a box
                    # only if you transform all eight of them.
                    points = [
                        (
                            a_max[0] if i & 1 else a_min[0],
                            a_max[1] if i & 2 else a_min[1],
                            a_max[2] if i & 4 else a_min[2],
                        )
                        for i in range(8)
                    ]
                for point in points:
                    wx, wy, wz = _apply(world, point)
                    for axis, value in enumerate((wx, wy, wz)):
                        lo[axis] = min(lo[axis], value)
                        hi[axis] = max(hi[axis], value)
        for child in node.get("children", []):
            walk(child, world)

    for root in scene.get("nodes", []):
        walk(root, IDENTITY)
    if lo[0] == float("inf"):
        raise ValueError("glTF declares no positioned geometry")
    k = _mm_scale(gltf, lo, hi)
    return MeshBox(tuple(v * k for v in lo), tuple(v * k for v in hi))  # type: ignore[arg-type]


def glb_node_names(path: Path) -> set[str]:
    """Every named node in a .glb (the WP-192 kinematics existence check)."""
    gltf, _ = _chunks(path.read_bytes())
    return {node["name"] for node in gltf.get("nodes", []) if node.get("name")}


#: WP-192 UX: fasteners and the cube body — never the thing that moves alone,
#: hidden by default in the moving-parts picker. This is the NORMATIVE copy;
#: the frontend keeps a mirror only as its offline fallback
#: (src/components/bind/nodeFamilies.ts) and consumes /v1/mesh/nodes when the
#: service is reachable, so the two cannot drift in the connected case.
#: three.js's GLTFLoader renames nodes on load (PropertyBinding.
#: sanitizeNodeName: whitespace → ``_``, and ``[ ] . : /`` stripped), and the
#: workbench's pre-served-tree era stored THOSE spellings in kinematics
#: records. The raw GLB name is the contract; this mirrors the three rule so
#: the node check accepts both spellings instead of failing records the
#: editor itself authored.
_THREE_WS_RE = re.compile(r"\s")
_THREE_RESERVED_RE = re.compile(r"[\[\]\.:/]")


def three_sanitized_node_name(name: str) -> str:
    return _THREE_RESERVED_RE.sub("", _THREE_WS_RE.sub("_", name))


HARDWARE_NODE_RE = re.compile(
    r"CUBHLF|ISO[ _-]?4762|DIN[ _-]?\d|screw|washer|nut|(^|[ _-])M[1-6]([ _x-]|$)",
    re.IGNORECASE,
)


def glb_node_tree(data: bytes) -> list[dict[str, Any]]:
    """The NAMED node hierarchy of a .glb, with the hardware classification.

    Children of unnamed nodes hoist to the nearest named ancestor — the tree
    a viewer shows, and the pick list of the moving-parts step. Serving it
    from here keeps the list identical to what E_KIN_NODE_MISSING later
    checks the record against.
    """
    gltf, _ = _chunks(data)
    nodes = gltf.get("nodes", [])
    scene = gltf.get("scenes", [{}])[gltf.get("scene", 0)]

    def build(indices: list[int]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for i in indices:
            node = nodes[i]
            name = node.get("name")
            children = build(node.get("children", []))
            # Technical wrapper nodes (__mm_scale__ and kin) hoist like
            # unnamed ones — they are conversion artifacts, not parts.
            if name and name.startswith("__") and name.endswith("__"):
                name = None
            if name:
                out.append({
                    "name": name,
                    "hardware": bool(HARDWARE_NODE_RE.search(name)),
                    "children": children,
                })
            else:
                out.extend(children)
        return out

    return build(scene.get("nodes", []))


def glb_subtree_bounding_box(path: Path, names: set[str]) -> MeshBox | None:
    """World bounding box of the subtrees rooted at the named nodes.

    The same walk as :func:`glb_bounding_box`, but geometry accumulates only
    at or below a node whose name is in ``names`` — subtrees move whole
    (WP-192), so this box is exactly what a kinematics translation displaces.
    None when the named nodes hold no positioned geometry.
    """
    gltf, _ = _chunks(path.read_bytes())
    nodes = gltf.get("nodes", [])
    meshes = gltf.get("meshes", [])
    accessors = gltf.get("accessors", [])
    scene = gltf.get("scenes", [{}])[gltf.get("scene", 0)]

    lo = [float("inf")] * 3
    hi = [float("-inf")] * 3

    def walk(index: int, parent: list[float], active: bool) -> None:
        node = nodes[index]
        world = _mul(parent, _matrix(node))
        active = active or node.get("name") in names
        mesh_index = node.get("mesh")
        if active and mesh_index is not None:
            for prim in meshes[mesh_index].get("primitives", []):
                acc = accessors[prim["attributes"]["POSITION"]]
                a_min, a_max = acc.get("min"), acc.get("max")
                if not a_min or not a_max:
                    continue
                a_min, a_max = _dequantize(acc, a_min), _dequantize(acc, a_max)
                for i in range(8):
                    corner = (
                        a_max[0] if i & 1 else a_min[0],
                        a_max[1] if i & 2 else a_min[1],
                        a_max[2] if i & 4 else a_min[2],
                    )
                    wx, wy, wz = _apply(world, corner)
                    for axis, value in enumerate((wx, wy, wz)):
                        lo[axis] = min(lo[axis], value)
                        hi[axis] = max(hi[axis], value)
        for child in node.get("children", []):
            walk(child, world, active)

    for root in scene.get("nodes", []):
        walk(root, IDENTITY, False)
    if lo[0] == float("inf"):
        return None
    k = _mm_scale(gltf, lo, hi)
    return MeshBox(tuple(v * k for v in lo), tuple(v * k for v in hi))  # type: ignore[arg-type]


@dataclass(frozen=True)
class MeshPlate:
    """A flat, plate-like mesh measured in the file's own axes (F3).

    ``normal`` is a LINE, not an arrow: PCA cannot know which face is coated,
    so ±normal are the same plate and every comparison must use ``abs(dot)``.
    """

    node_name: str
    normal: tuple[float, float, float]
    thickness_mm: float
    size_mm: tuple[float, float]


def _positions(
    gltf: dict, blob: bytes | None, accessor_index: int
) -> list[tuple[float, float, float]]:
    """Decode a POSITION accessor to a list of vertices.

    Only the float32 VEC3 form glTF mandates for POSITION is handled; anything
    else returns nothing rather than guessing, because a wrong decode would
    silently produce a wrong plate normal — the exact class of error this
    module exists to catch.
    """
    if blob is None:
        return []
    acc = gltf.get("accessors", [])[accessor_index]
    if acc.get("type") != "VEC3":
        return []
    fmt, size = _COMPONENT_FORMATS.get(acc.get("componentType", 5126), (None, 0))
    if fmt is None:
        return []
    views = gltf.get("bufferViews", [])
    view_index = acc.get("bufferView")
    if view_index is None:
        return []
    view = views[view_index]
    start = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
    element = size * 3
    stride = view.get("byteStride") or element
    out: list[tuple[float, float, float]] = []
    for i in range(acc.get("count", 0)):
        offset = start + i * stride
        chunk = blob[offset : offset + element]
        if len(chunk) < element:
            break
        raw = struct.unpack(f"<{fmt * 3}", chunk)
        x, y, z = _dequantize(acc, list(raw))
        out.append((x, y, z))
    return out


Vec3 = tuple[float, float, float]


def _plate_of(points: list[Vec3]) -> tuple[Vec3, Vec3] | None:
    """Principal axes of a vertex cloud: (normal, extents along the 3 axes).

    Jacobi eigen-decomposition of the 3x3 covariance — small, exact enough,
    and it keeps this module dependency-free like the rest of the file.
    """
    n = len(points)
    if n < 4:
        return None
    cx = sum(p[0] for p in points) / n
    cy = sum(p[1] for p in points) / n
    cz = sum(p[2] for p in points) / n
    cov = [[0.0] * 3 for _ in range(3)]
    for px, py, pz in points:
        d = (px - cx, py - cy, pz - cz)
        for i in range(3):
            for j in range(3):
                cov[i][j] += d[i] * d[j]
    vectors = [[1.0 if i == j else 0.0 for j in range(3)] for i in range(3)]
    for _ in range(64):
        p_, q_ = max(
            ((i, j) for i in range(3) for j in range(3) if i < j),
            key=lambda ij: abs(cov[ij[0]][ij[1]]),
        )
        if abs(cov[p_][q_]) < 1e-14:
            break
        theta = 0.5 * math.atan2(2 * cov[p_][q_], cov[q_][q_] - cov[p_][p_])
        c, s = math.cos(theta), math.sin(theta)
        for k in range(3):
            akp, akq = cov[k][p_], cov[k][q_]
            cov[k][p_], cov[k][q_] = c * akp - s * akq, s * akp + c * akq
        for k in range(3):
            apk, aqk = cov[p_][k], cov[q_][k]
            cov[p_][k], cov[q_][k] = c * apk - s * aqk, s * apk + c * aqk
        for k in range(3):
            vkp, vkq = vectors[k][p_], vectors[k][q_]
            vectors[k][p_], vectors[k][q_] = c * vkp - s * vkq, s * vkp + c * vkq
    axes = sorted(
        ((cov[i][i], (vectors[0][i], vectors[1][i], vectors[2][i])) for i in range(3)),
        key=lambda item: item[0],
    )
    # Extent along each principal axis, in mm — variance alone cannot tell a
    # thin plate from a small one.
    extents: list[float] = []
    for _, axis in axes:
        projected = [
            (p[0] - cx) * axis[0] + (p[1] - cy) * axis[1] + (p[2] - cz) * axis[2]
            for p in points
        ]
        extents.append(max(projected) - min(projected))
    return axes[0][1], (extents[0], extents[1], extents[2])


#: A mesh counts as a plate when it is this much thinner than it is wide. A
#: 25.4 mm achromat measures 0.284 and must NOT be mistaken for a mirror.
PLATE_ASPECT_MAX = 0.15

#: How far the measured plate may sit from the declared one. Matches
#: derive.py's DIRECTION_TOL_DEG — one tolerance for one question.
FOLD_TOL_DEG = 2.0

#: Node names that suggest a reflective surface. The geometric test decides;
#: this only ranks candidates, because ``BUY - Mirror`` is one vendor's habit
#: and only 4 of 13 shipped template GLBs follow it.
_PLATE_HINT = re.compile(r"mirror|mir\d|reflect|beamsplit|dichro", re.I)


def glb_reflective_plate(path: Path) -> MeshPlate | None:
    """The reflective plate in a cube mesh, measured in file axes (F3).

    This is the only fact about a mount that the RECORD cannot state and the
    mesh can: which way the glass actually faces. Round 20 shipped a template
    declaring a fold its own mirror could not perform (plate normal
    (-0.707, +0.707, 0) folds x<->y; the record said the beam left along -z,
    the pin axis) and every check in both repos passed, because every check
    was record-level and the record was internally consistent.

    Returns the largest plate-like mesh, preferring name-hinted candidates.
    ``None`` when nothing qualifies — never a guess.
    """
    gltf, blob = _chunks(path.read_bytes())
    nodes = gltf.get("nodes", [])
    meshes = gltf.get("meshes", [])
    scene = gltf.get("scenes", [{}])[gltf.get("scene", 0)]
    best: tuple[float, int, MeshPlate] | None = None

    def walk(index: int, parent: list[float]) -> None:
        nonlocal best
        node = nodes[index]
        world = _mul(parent, _matrix(node))
        mesh_index = node.get("mesh")
        name = str(node.get("name", ""))
        if mesh_index is not None:
            for prim in meshes[mesh_index].get("primitives", []):
                attrs = prim.get("attributes", {})
                if "POSITION" not in attrs:
                    continue
                local = _positions(gltf, blob, attrs["POSITION"])
                if not local:
                    continue
                points = [_apply(world, p) for p in local]
                measured = _plate_of(points)
                if measured is None:
                    continue
                normal, extents = measured
                thin, mid, wide = extents
                if mid <= 0 or thin / mid > PLATE_ASPECT_MAX:
                    continue
                area = mid * wide
                hinted = 1 if _PLATE_HINT.search(name) else 0
                plate = MeshPlate(
                    node_name=name,
                    normal=normal,
                    thickness_mm=thin,
                    size_mm=(mid, wide),
                )
                if best is None or (hinted, area) > (best[1], best[0]):
                    best = (area, hinted, plate)
        for child in node.get("children", []):
            walk(child, world)

    for root in scene.get("nodes", []):
        walk(root, IDENTITY)
    if best is None:
        return None
    # WP-237: the extents above are in the FILE's units; the record is mm.
    # The plate's own width is the size proxy — a reflective plate under a
    # millimetre across does not exist, which is what makes it decidable.
    plate = best[2]
    from ..units import mm_per_unit

    k = mm_per_unit(gltf, max(plate.size_mm))
    if k == 1.0:
        return plate
    return MeshPlate(
        node_name=plate.node_name,
        normal=plate.normal,  # a direction: scale-free
        thickness_mm=plate.thickness_mm * k,
        size_mm=(plate.size_mm[0] * k, plate.size_mm[1] * k),
    )


def fold_normal_deviation_deg(
    plate: MeshPlate, entry: tuple[float, float, float], exit_: tuple[float, float, float]
) -> float | None:
    """Angle between the measured plate and the one the ports imply.

    The plate that turns ``entry`` into ``exit_`` has normal proportional to
    (exit - entry) — the bisector, the same law the editors draw. Compared as
    LINES, because PCA gives ±n. ``None`` when the ports are degenerate.
    """
    bisector = tuple(exit_[i] - entry[i] for i in range(3))
    length = math.sqrt(sum(v * v for v in bisector))
    if length < 1e-9:
        return None
    implied = tuple(v / length for v in bisector)
    measured = plate.normal
    m_len = math.sqrt(sum(v * v for v in measured))
    if m_len < 1e-9:
        return None
    dot = abs(sum(implied[i] * measured[i] / m_len for i in range(3)))
    return math.degrees(math.acos(max(0.0, min(1.0, dot))))


#: Axis literals, as F3 unit vectors.
_AXIS: dict[str, Vec3] = {
    "+x": (1.0, 0.0, 0.0), "-x": (-1.0, 0.0, 0.0),
    "+y": (0.0, 1.0, 0.0), "-y": (0.0, -1.0, 0.0),
    "+z": (0.0, 0.0, 1.0), "-z": (0.0, 0.0, -1.0),
}

#: An entry port states the face it PRESENTS, so the beam travels the other
#: way. The same six names the editors use — see DSN-CONTRACT §4.
_ENTRY_NAMES = frozenset({"front", "sensor", "in", "plane"})


def _fold_findings(
    template_id: str,
    glb_path: Path,
    optical_ports: dict[str, str] | None,
    mesh_frame: str = "",
    mesh_pose_grid: tuple[str, str] | None = None,
) -> list[tuple[str, str, str]]:
    """Compare the mesh's plate with the fold the template's ports declare."""
    if not optical_ports or len(optical_ports) < 2:
        return []
    entry_name = next(
        (n for n in optical_ports if n in _ENTRY_NAMES), None
    )
    exit_name = next(
        (n for n in optical_ports if n != entry_name and n not in _ENTRY_NAMES), None
    )
    if entry_name is None or exit_name is None:
        return []
    entry_face = _AXIS.get(str(optical_ports[entry_name]))
    exit_dir = _AXIS.get(str(optical_ports[exit_name]))
    if entry_face is None or exit_dir is None:
        return []
    entry_travel = tuple(-v for v in entry_face)
    # A straight-through pair is not a fold; nothing to check against a plate.
    if sum(entry_travel[i] * exit_dir[i] for i in range(3)) > 0.99:
        return []
    try:
        plate = glb_reflective_plate(glb_path)
    except (ValueError, KeyError, IndexError, struct.error):
        return []
    if plate is not None:
        # Measured in file axes; the ports speak cube axes — same map as the
        # envelope checks (identity unless a correction is declared).
        to_cube = _mesh_to_cube(mesh_frame, mesh_pose_grid)
        plate = MeshPlate(
            node_name=plate.node_name,
            normal=to_cube(plate.normal),
            thickness_mm=plate.thickness_mm,
            size_mm=plate.size_mm,
        )
    if plate is None:
        return [(
            "warning",
            "W_MESH_NO_PLATE",
            f"{template_id}: the ports declare a fold but no plate-like mesh was found "
            f"in {glb_path.name}, so the optics could not be checked against the glass",
        )]
    deviation = fold_normal_deviation_deg(plate, entry_travel, exit_dir)
    if deviation is None or deviation <= FOLD_TOL_DEG:
        return []
    return [(
        "error",
        "E_FOLD_MESH_MISMATCH",
        f"{template_id}: the mirror in {glb_path.name} ('{plate.node_name}') cannot perform "
        f"the declared fold. Its plate normal is "
        f"({', '.join(f'{v:+.3f}' for v in plate.normal)}) in the CUBE frame, which is "
        f"{deviation:.1f}° from the plate that would send {entry_name} "
        f"({optical_ports[entry_name]}) to {exit_name} ({optical_ports[exit_name]}). "
        f"The insert-pose is rotated about the entry axis — the ports and the pose agree "
        f"with each other and neither agrees with the glass.",
    )]


#: mesh-frame sugar as FILE->cube grid maps: where the FILE's +z and +x land.
_FRAME_GRIDS: dict[str, tuple[str, str]] = {
    "record": ("-y", "+x"),  # y-up glTF: file y = cube z, file z = cube -y
}


def _grid_matrix(z: str, x: str) -> list[Vec3] | None:
    """Rows of the FILE-to-cube rotation for a grid spelling (None = identity)."""
    zv = _AXIS.get(z)
    xv = _AXIS.get(x)
    if zv is None or xv is None:
        return None
    yv = (
        zv[1] * xv[2] - zv[2] * xv[1],
        zv[2] * xv[0] - zv[0] * xv[2],
        zv[0] * xv[1] - zv[1] * xv[0],
    )
    # Columns are the images of file x/y/z; rows give cube components.
    return [
        (xv[0], yv[0], zv[0]),
        (xv[1], yv[1], zv[1]),
        (xv[2], yv[2], zv[2]),
    ]


def _mesh_to_cube(mesh_frame: str, mesh_pose_grid: tuple[str, str] | None):
    """FILE-to-cube vector map from the declared correction (WP-137).

    ``mesh-pose`` wins over the ``mesh-frame`` sugar; both absent = identity.
    """
    grid = mesh_pose_grid or _FRAME_GRIDS.get(mesh_frame)
    if grid is None:
        return lambda v: (v[0], v[1], v[2])
    rows = _grid_matrix(*grid)
    if rows is None:
        return lambda v: (v[0], v[1], v[2])
    return lambda v: tuple(
        rows[i][0] * v[0] + rows[i][1] * v[1] + rows[i][2] * v[2] for i in range(3)
    )


def _abs3(v: tuple[float, float, float]) -> tuple[float, float, float]:
    return (abs(v[0]), abs(v[1]), abs(v[2]))


def check_template_mesh(
    template_id: str,
    envelope: tuple[float, float, float] | None,
    footprint_grid: list[int] | tuple[int, int, int] | None,
    provenance: str,
    glb_path: Path,
    mesh_frame: str = "",
    optical_ports: dict[str, str] | None = None,
    mesh_pose_grid: tuple[str, str] | None = None,
    mesh_pose_tilted: bool = False,
) -> list[tuple[str, str, str]]:
    """(level, code, message) findings for one template's mesh.

    Four questions, in order of how certain the answer is:

    1. Does the mesh FIT the declared envelope under ANY axis assignment? If
       not, wrong units or wrong file — the one failure with no legitimate
       reading.
    2. If it fits only after permuting axes, the mesh and record frames
       disagree (the wrapper-node split). A warning, not an error: both
       families ship today and both render correctly once a placement rotation
       is applied. The ambiguity made visible rather than official.
    3. ``provenance: whole-module`` ("this mesh IS the cube") must actually
       measure the cell it occupies.
    4. WP-134: if the template declares a FOLD, can the mirror in the mesh
       physically perform it? The only question here the record cannot fake —
       ports and pose are self-consistent statements, and round 20 shipped a
       trio where both agreed with each other and neither with the glass. Pass
       ``optical_ports`` (as-mounted name → direction) to enable it.
    """
    findings: list[tuple[str, str, str]] = []
    try:
        box = glb_bounding_box(glb_path)
    except (OSError, ValueError, KeyError, IndexError, struct.error) as exc:
        return [("error", "E_MESH_UNREADABLE", f"{template_id}: {glb_path.name}: {exc}")]

    # WP-135/137: measurements are compared in CUBE axes. A declared
    # record-frame file (or any mesh-pose grid) is un-rotated first, or a
    # perfectly correct converted STP fails its own cell check (testlens:
    # 49.8 × 53.8 × 49.8 against a 50 × 50 × 55 cell, which IS the cell once
    # y and z swap back). Declaring the frame used to change only the
    # SEVERITY of the axis check while the numbers stayed in file axes.
    to_cube = _mesh_to_cube(mesh_frame, mesh_pose_grid)
    size = _abs3(to_cube(box.size))
    center = to_cube(box.center)
    shown = f"{size[0]:.1f} × {size[1]:.1f} × {size[2]:.1f} mm"

    # WP-224 follow-on: a record may declare BOTH `mesh-frame` (the sugar)
    # and `mesh-pose` (the total file->cube map). The pose wins, so a
    # `mesh-frame` that disagrees with it is dead text — and misleading dead
    # text: six records in the shipped libraries say "this file is y-up"
    # while their pose says otherwise, which is why they read as
    # E_MESH_AXES_PERMUTED. Say so, rather than letting the reader trust a
    # line nothing consults.
    if mesh_frame and mesh_pose_grid is not None:
        sugar = _FRAME_GRIDS.get(mesh_frame)
        if sugar is not None and tuple(sugar) != tuple(mesh_pose_grid):
            findings.append((
                "warning",
                "W_MESH_FRAME_OVERRIDDEN",
                f"{template_id}: declares `mesh-frame: {mesh_frame}` (which means "
                f"{sugar[0]}/{sugar[1]}) AND `mesh-pose` {mesh_pose_grid[0]}/"
                f"{mesh_pose_grid[1]} — the pose wins, so the mesh-frame line is "
                "ignored. Drop it, or make the two agree.",
            ))

    if envelope:
        fits_sorted = all(
            m <= e + CELL_TOL_MM
            for m, e in zip(sorted(size), sorted(envelope), strict=True)
        )
        # WP-156: a mesh-pose with a residual tilt (a housing sitting at an
        # angle in its cell) has no axis-exact reading — the 24-fold
        # un-rotation only covers the grid part, so the per-axis comparison
        # would flag a perfectly correct record. The intrinsic (sorted) box
        # comparison stays exact regardless of orientation.
        fits_axes = mesh_pose_tilted or all(
            m <= e + CELL_TOL_MM for m, e in zip(size, envelope, strict=True)
        )
        if not fits_sorted:
            findings.append((
                "error",
                "E_MESH_EXCEEDS_ENVELOPE",
                f"{template_id}: {glb_path.name} measures {shown}, which does not fit the "
                f"declared envelope {envelope[0]:g} × {envelope[1]:g} × {envelope[2]:g} mm "
                "in any orientation — wrong units, or the wrong file.",
            ))
        elif not fits_axes:
            # WP-115: with `mesh-frame` DECLARED the axis assignment is no
            # longer ambiguous — a permuted fit stops being "two conventions
            # ship, tolerate both" and becomes a plain error.
            declared = bool(mesh_frame) or mesh_pose_grid is not None
            findings.append((
                "error" if declared else "warning",
                "E_MESH_AXES_PERMUTED" if declared else "W_MESH_AXES_PERMUTED",
                f"{template_id}: {glb_path.name} measures {shown}, which fits the declared "
                f"envelope {envelope[0]:g} × {envelope[1]:g} × {envelope[2]:g} mm only after "
                "permuting axes — the mesh frame and the record frame disagree. The library "
                "holds two glTF conventions: older exports ship an Rx(-90°) wrapper node "
                "that pre-applies the document→viewer basis change, newer OCCT exports do "
                "not. Both render today only because a placement rotation compensates.",
            ))

    if provenance == "whole-module" and footprint_grid:
        cell = tuple(UC2_CELL_MM[i] * max(1, int(footprint_grid[i])) for i in range(3))
        # WP-178: the check honours the DECLARED footprint the way the wizard
        # does. A module may occupy claimed cells without filling them (a 1×2
        # focus stage body measuring 95 mm), and a knob may rise above the
        # cells — the ERROR is reserved for a mesh that exceeds its claim in
        # x/y (declare a bigger footprint) or is far too small everywhere
        # (wrong units / an insert).
        if size[0] > cell[0] + CELL_TOL_MM or size[1] > cell[1] + CELL_TOL_MM:
            findings.append((
                "error",
                "E_MESH_CELL_MISMATCH",
                f"{template_id}: {glb_path.name} claims `provenance: whole-module` with "
                f"footprint_grid {list(footprint_grid)} "
                f"({cell[0]:.0f} × {cell[1]:.0f} × {cell[2]:.0f} mm) but measures {shown} — "
                "wider than the claimed cells. Declare the real footprint.",
            ))
        elif max(size) < 20.0:
            findings.append((
                "error",
                "E_MESH_CELL_MISMATCH",
                f"{template_id}: {glb_path.name} measures {shown} — far below one grid "
                "cell. Wrong units (cm/inch instead of mm)?",
            ))
        elif size[2] > cell[2] + CELL_TOL_MM:
            findings.append((
                "warning",
                "W_MESH_PROTRUDES",
                f"{template_id}: {glb_path.name} rises {size[2] - cell[2]:.1f} mm above its "
                f"{footprint_grid[2]}-cell height (a knob or handle) — placement and DRC "
                "use the declared footprint; the protrusion sticks out of the cell.",
            ))
        # A whole cube's origin is its ORIGIN CELL's centre (the DSN
        # contract's part origin). WP-178: a multi-cell module's bbox centre
        # legitimately sits between its cells — compare against the
        # footprint's centre ((f−1)·pitch/2 toward +x/+y/+z) — and a knob
        # protruding above pulls the z centre up, so z is skipped when the
        # protrusion warning fired.
        expected_center = tuple(
            UC2_CELL_MM[i] * (max(1, int(footprint_grid[i])) - 1) / 2.0 for i in range(3)
        )
        deltas = [center[i] - expected_center[i] for i in range(3)]
        if size[2] > cell[2] + CELL_TOL_MM:
            deltas[2] = 0.0
        if max(abs(d) for d in deltas) > CELL_TOL_MM:
            findings.append((
                "warning",
                "W_MESH_OFF_CENTRE",
                f"{template_id}: {glb_path.name} is centred at "
                f"({center[0]:.1f}, {center[1]:.1f}, {center[2]:.1f}) mm (cube axes), "
                f"not on its footprint's centre "
                f"({expected_center[0]:.1f}, {expected_center[1]:.1f}, "
                f"{expected_center[2]:.1f}) — a placed part will sit offset by the "
                "difference.",
            ))
    # ── 4. does the glass agree with the ports? (WP-134) ────────────────
    # WP-156: the plate math runs through the GRID map only, so a tilted
    # housing would false-flag its own mirror — say nothing rather than
    # guess (the same rule as W_MESH_NO_PLATE).
    if not mesh_pose_tilted:
        findings.extend(
            _fold_findings(template_id, glb_path, optical_ports, mesh_frame, mesh_pose_grid)
        )
    return findings


# --- WP-229: splitting a monolithic mesh into per-part files -----------------------

#: glTF componentType → bytes, and accessor type → component count (spec §5.1).
_COMPONENT_BYTES = {5120: 1, 5121: 1, 5122: 2, 5123: 2, 5125: 4, 5126: 4}
_TYPE_COUNTS = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4,
                "MAT2": 4, "MAT3": 9, "MAT4": 16}


def _write_glb(gltf: dict[str, Any], binary: bytes) -> bytes:
    """Serialize a glTF JSON + BIN pair back into a .glb container."""
    payload = json.dumps(gltf, separators=(",", ":")).encode()
    payload += b" " * (-len(payload) % 4)
    binary = binary + b"\x00" * (-len(binary) % 4)
    body = struct.pack("<I4s", len(payload), b"JSON") + payload
    if binary:
        body += struct.pack("<I4s", len(binary), b"BIN\x00") + binary
    return struct.pack("<I4s", 0x46546C67, b"") [:4] + struct.pack(
        "<II", 2, 12 + len(body)
    ) + body


def _reachable_nodes(nodes: list[dict], roots: list[int]) -> set[int]:
    seen: set[int] = set()
    stack = list(roots)
    while stack:
        i = stack.pop()
        if i in seen:
            continue
        seen.add(i)
        stack.extend(nodes[i].get("children", []))
    return seen


def glb_extract_subtrees(
    data: bytes, names: set[str], *, invert: bool = False
) -> bytes:
    """A new .glb holding only the named subtrees (or everything BUT them).

    WP-229. The scene graph is pruned to the wanted roots, then meshes,
    accessors, bufferViews, materials, textures and images are garbage-
    collected and renumbered, so the output carries no dead weight — a
    150 MB assembly does not become N copies of itself.

    Ancestors of a kept subtree are kept as pure transform nodes (their own
    mesh is dropped unless they are themselves wanted), because a glTF
    node's transform is relative to its parent: hoisting a child to the
    scene root would silently move it. Names survive so the record's
    ``kinematics`` node names still resolve against the split file.
    """
    gltf, binary = _chunks(data)
    binary = binary or b""
    nodes = gltf.get("nodes", [])
    scene_index = gltf.get("scene", 0)
    scene = gltf.get("scenes", [{}])[scene_index]

    # Records may store the three-sanitized spelling (the workbench's
    # pre-served-tree era did) — the node check accepts both, so must this.
    wanted = {
        i for i, n in enumerate(nodes)
        if n.get("name") in names
        or (n.get("name") and three_sanitized_node_name(n["name"]) in names)
    }
    if not wanted:
        raise ValueError(f"none of {sorted(names)} is a node in this mesh")
    keep_subtrees = _reachable_nodes(nodes, sorted(wanted))

    # Ancestors: needed for the transform chain, and (when inverting) they
    # are themselves content unless they are inside a wanted subtree.
    parent_of: dict[int, int] = {}
    for i, node in enumerate(nodes):
        for child in node.get("children", []):
            parent_of[child] = i

    def ancestors(index: int) -> list[int]:
        out, cur = [], parent_of.get(index)
        while cur is not None:
            out.append(cur)
            cur = parent_of.get(cur)
        return out

    chain = {a for i in wanted for a in ancestors(i)}
    if invert:
        keep = (set(range(len(nodes))) - keep_subtrees) | chain
        mesh_bearing = keep - keep_subtrees
    else:
        keep = keep_subtrees | chain
        mesh_bearing = keep_subtrees

    # Renumber the kept nodes, dropping meshes off transform-only ancestors.
    order = sorted(keep)
    remap = {old: new for new, old in enumerate(order)}
    new_nodes: list[dict[str, Any]] = []
    for old in order:
        node = dict(nodes[old])
        node["children"] = [remap[c] for c in node.get("children", []) if c in remap]
        if not node["children"]:
            node.pop("children")
        if old not in mesh_bearing:
            node.pop("mesh", None)
        new_nodes.append(node)

    roots = [remap[i] for i in scene.get("nodes", []) if i in remap]
    # A wanted subtree whose ancestors were dropped becomes a root itself.
    roots += [remap[i] for i in sorted(keep) if parent_of.get(i) not in keep
              and remap[i] not in roots]

    out: dict[str, Any] = {
        "asset": gltf.get("asset", {"version": "2.0"}),
        "scene": 0,
        "scenes": [{"nodes": sorted(set(roots))}],
        "nodes": new_nodes,
    }
    for key in ("extensionsUsed", "extensionsRequired"):
        if key in gltf:
            out[key] = gltf[key]

    # --- garbage-collect the payload, in dependency order --------------------
    used_meshes = sorted({n["mesh"] for n in new_nodes if "mesh" in n})
    mesh_remap = {old: new for new, old in enumerate(used_meshes)}
    for node in new_nodes:
        if "mesh" in node:
            node["mesh"] = mesh_remap[node["mesh"]]

    meshes = [dict(gltf["meshes"][i]) for i in used_meshes] if used_meshes else []
    used_accessors: set[int] = set()
    used_materials: set[int] = set()
    for mesh in meshes:
        prims = []
        for prim in mesh.get("primitives", []):
            prim = dict(prim)
            used_accessors.update(prim.get("attributes", {}).values())
            if "indices" in prim:
                used_accessors.add(prim["indices"])
            if "material" in prim:
                used_materials.add(prim["material"])
            prims.append(prim)
        mesh["primitives"] = prims

    acc_order = sorted(used_accessors)
    acc_remap = {old: new for new, old in enumerate(acc_order)}
    for mesh in meshes:
        for prim in mesh["primitives"]:
            prim["attributes"] = {
                k: acc_remap[v] for k, v in prim.get("attributes", {}).items()
            }
            if "indices" in prim:
                prim["indices"] = acc_remap[prim["indices"]]

    mat_order = sorted(used_materials)
    mat_remap = {old: new for new, old in enumerate(mat_order)}
    for mesh in meshes:
        for prim in mesh["primitives"]:
            if "material" in prim:
                prim["material"] = mat_remap[prim["material"]]

    accessors = [dict(gltf["accessors"][i]) for i in acc_order]

    # Repack the binary. These exports put MANY accessors in a handful of big
    # bufferViews, so keeping a whole view whenever one accessor survives
    # copies the entire mesh into every split half. Copy the byte SPAN the
    # surviving accessors actually occupy instead, and rebase their offsets.
    views = gltf.get("bufferViews", [])
    spans: dict[int, tuple[int, int]] = {}
    for acc in accessors:
        vi = acc.get("bufferView")
        if vi is None:
            continue
        view = views[vi]
        elem = _COMPONENT_BYTES[acc["componentType"]] * _TYPE_COUNTS[acc["type"]]
        stride = view.get("byteStride")
        start = acc.get("byteOffset", 0)
        end = start + ((acc["count"] - 1) * stride + elem if stride else acc["count"] * elem)
        lo, hi = spans.get(vi, (start, end))
        spans[vi] = (min(lo, start), max(hi, end))

    view_remap = {old: new for new, old in enumerate(sorted(spans))}
    new_views: list[dict[str, Any]] = []
    blob = bytearray()
    for old in sorted(spans):
        view = dict(views[old])
        lo, hi = spans[old]
        blob += b"\x00" * (-len(blob) % 4)
        base = view.get("byteOffset", 0)
        view["byteOffset"] = len(blob)
        view["byteLength"] = hi - lo
        view["buffer"] = 0
        blob += binary[base + lo : base + hi]
        new_views.append(view)
        for acc in accessors:
            if acc.get("bufferView") == old:
                acc["_rebase"] = lo
    for acc in accessors:
        if "bufferView" in acc:
            acc["byteOffset"] = acc.get("byteOffset", 0) - acc.pop("_rebase", 0)
            if not acc["byteOffset"]:
                acc.pop("byteOffset")
            acc["bufferView"] = view_remap[acc["bufferView"]]

    if meshes:
        out["meshes"] = meshes
    if accessors:
        out["accessors"] = accessors
    if new_views:
        out["bufferViews"] = new_views
        out["buffers"] = [{"byteLength": len(blob)}]
    if mat_order:
        out["materials"] = [dict(gltf["materials"][i]) for i in mat_order]
        # Textures/images are rare in these exports; carry them wholesale
        # rather than half-GC-ing an index space we do not fully model.
        for key in ("textures", "images", "samplers"):
            if key in gltf:
                out[key] = gltf[key]
    return _write_glb(out, bytes(blob))
