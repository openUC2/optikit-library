"""Where the record library lives.

`OPTIKIT_LIBRARY_ROOT` wins; otherwise the sibling checkout of the standard
two-repo layout (`optikit-core/` and `optikit-library/` side by side). The
core repo ships no records of its own.
"""

from __future__ import annotations

import os
from pathlib import Path

LIBRARY_ROOT_ENV = "OPTIKIT_LIBRARY_ROOT"

#: This checkout — `generators/` and `golden/` ship with the core, not with the records.
CORE_ROOT = Path(__file__).resolve().parents[3]
SIBLING_LIBRARY = CORE_ROOT.parent / "optikit-library" / "library"


def library_root() -> Path:
    """The record root: the env var (resolved), else the sibling checkout."""
    configured = os.environ.get(LIBRARY_ROOT_ENV)
    if configured:
        return Path(configured).expanduser().resolve()
    return SIBLING_LIBRARY
