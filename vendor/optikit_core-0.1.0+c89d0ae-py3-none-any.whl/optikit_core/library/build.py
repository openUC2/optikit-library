"""Load, validate, and index the library of git-versioned records.

The library lives under ``library/`` as one directory per record, each holding
a ``component.yml`` / ``template.yml`` / ``module.yml``. ``build_index`` resolves
every module's semver references to concrete latest-matching versions and emits
``library/dist/index.json`` — the flat catalog the frontend sidebar consumes.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from ..io.yamlio import (
    _to_plain,  # noqa: PLC2701 — internal helper reuse
    load_design,
    load_document,
)
from ..schema.common import ContinuousXYZ
from ..schema.design import PoseSpec
from ..schema.library import (
    COMPONENT_FILE,
    GROUP_FILE,
    MODULE_FILE,
    SUBDESIGN_FILE,
    TEMPLATE_FILE,
    ComponentRecord,
    GroupRecord,
    ModuleRecord,
    RecordBase,
    TemplateRecord,
    inline_fragment_sidecar,
    load_record,
    parse_ref,
)
from .semver import Version, satisfies

RECORD_FILES = (COMPONENT_FILE, TEMPLATE_FILE, MODULE_FILE, GROUP_FILE, SUBDESIGN_FILE)


@dataclass
class LoadedRecord:
    record: RecordBase
    path: Path


@dataclass
class LibraryError:
    path: str
    message: str

    def __str__(self) -> str:
        return f"{self.path}: {self.message}"


@dataclass
class Library:
    records: list[LoadedRecord] = field(default_factory=list)
    errors: list[LibraryError] = field(default_factory=list)
    #: The directory the records were loaded from (None for hand-built
    #: libraries). check_references peeks at ``root/archive`` through this.
    root: Path | None = None

    def by_kind(self, kind: str) -> list[LoadedRecord]:
        return [r for r in self.records if r.record.kind == kind]

    def versions_of(self, record_id: str) -> list[LoadedRecord]:
        return [r for r in self.records if r.record.id == record_id]


def load_library(root: Path) -> Library:
    """Load and validate every record file under ``root`` (recursively).

    ``dist/`` (the built index) and ``archive/`` (retired records, WP-68) are
    skipped — an archived record is invisible until ``library restore`` moves
    it back. Both names are matched RELATIVE to ``root``, so pointing the
    loader AT an archive directory still works.
    """
    library = Library(root=root)
    seen: dict[tuple[str, str], Path] = {}
    for file in sorted(root.rglob("*.yml")):
        rel_parts = file.relative_to(root).parts
        if file.name not in RECORD_FILES or {"dist", "archive"} & set(rel_parts):
            continue
        # POSIX separators: the index is a wire artifact (asset URLs, the
        # tracked dist/ file CI diffs) and must not vary by build platform.
        rel = file.relative_to(root).as_posix()
        try:
            data = _to_plain(load_document(file)) or {}
            record = load_record(data)
            # WP-232: a record may keep its prescription in a SIDECAR beside
            # it (a standalone Optiland file). Inline it here, once, so every
            # consumer below sees an ordinary `optics.fragment` and nothing
            # else has to know the sidecar exists.
            inline_fragment_sidecar(record, file)
        except ValidationError as exc:
            for err in exc.errors():
                loc = ".".join(str(p) for p in err["loc"])
                library.errors.append(LibraryError(rel, f"{loc}: {err['msg']}"))
            continue
        except (ValueError, KeyError) as exc:
            library.errors.append(LibraryError(rel, str(exc)))
            continue
        key = (record.id, record.version)
        if key in seen:
            library.errors.append(
                LibraryError(rel, f"duplicate {record.id}@{record.version} "
                                  f"(also {seen[key]})")
            )
            continue
        seen[key] = file
        library.records.append(LoadedRecord(record=record, path=file))
    return library


def resolve(library: Library, ref: str) -> LoadedRecord | None:
    """Highest version of ``<id>`` satisfying the range in ``<id>@<range>``."""
    record_id, spec = parse_ref(ref)
    candidates = [
        r for r in library.versions_of(record_id)
        if satisfies(r.record.version, spec)
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda r: Version.parse(r.record.version))


def archived_ids(root: Path | None) -> set[str]:
    """Record ids parked under ``root/archive`` (WP-68) — cheap id-only scan."""
    ids: set[str] = set()
    if root is None:
        return ids
    archive = root / "archive"
    if not archive.is_dir():
        return ids
    for file in archive.rglob("*.yml"):
        if file.name not in RECORD_FILES:
            continue
        try:
            data = _to_plain(load_document(file)) or {}
        except Exception:  # noqa: BLE001 — an unreadable archived file is just not restorable
            continue
        record_id = data.get("id")
        if isinstance(record_id, str):
            ids.add(record_id)
    return ids


def _check_subdesign_side(
    library: Library, module: ModuleRecord, rel: str
) -> list[LibraryError]:
    """A subdesign-backed module's `design:` side, checked at validate time.

    Deliberately loads and instantiates the design: a subdesign that does not
    parse, names a variant it does not declare, or nests another library
    subdesign is a broken PART, and the library is where parts are judged.
    """
    from .subdesigns import SubdesignError, load_subdesign

    try:
        load_subdesign(library, module.design)
    except SubdesignError as exc:
        return [LibraryError(rel, f"{exc.code}: {exc.args[0]}")]
    except (ValueError, KeyError, OSError) as exc:
        return [LibraryError(
            rel, f"E_SUBDESIGN_INVALID: design {module.design!r} does not load ({exc})"
        )]
    return []


def check_references(library: Library) -> list[LibraryError]:
    """Every module's component/template references must resolve.

    A reference that misses the live library but names a record parked under
    ``archive/`` gets the actionable ``E_ARCHIVED`` message (WP-68) instead of
    the plain dangling-ref one.
    """
    errors: list[LibraryError] = []
    archived: set[str] | None = None  # lazily scanned on the first miss

    def missing(rel: str, what: str, ref: str) -> None:
        nonlocal archived
        if archived is None:
            archived = archived_ids(library.root)
        record_id = ref.split("@", 1)[0]
        if record_id in archived:
            errors.append(LibraryError(
                rel,
                f"E_ARCHIVED: {ref} is archived — restore with: "
                f"optikit-core library restore {record_id}",
            ))
        else:
            errors.append(LibraryError(rel, f"{what} ref {ref!r} does not resolve"))

    for loaded in library.by_kind("cube_module"):
        module = loaded.record
        assert isinstance(module, ModuleRecord)
        rel = str(loaded.path)
        optical = ("component", module.component) if module.component \
            else ("design", module.design)
        for label, ref in (optical, ("template", module.template)):
            if resolve(library, ref) is None:
                missing(rel, label, ref)
        # WP-198: the `design:` side must be a cube_subdesign whose design file
        # is actually there and one level deep — a dangling or mis-kinded
        # reference must fail at `library validate`, not at first placement.
        if module.design:
            errors.extend(_check_subdesign_side(library, module, rel))
        # WP-67: a housing (footprint_grid: null) is NOT cube-mounted — a
        # module referencing one contradicts the template's own declaration.
        tpl = resolve(library, module.template)
        if tpl is not None and isinstance(tpl.record, TemplateRecord) \
                and tpl.record.footprint_grid is None:
            errors.append(LibraryError(
                rel,
                f"template ref {module.template!r} resolves to a HOUSING "
                "(footprint_grid: null) — a housing is not cube-mounted; "
                "package it as a cube (T3) instead of referencing it from a module",
            ))
    # WP-67: a housing's own component ref must resolve (no module carries it).
    for loaded in library.by_kind("mechanical_template"):
        template = loaded.record
        assert isinstance(template, TemplateRecord)
        if template.component and resolve(library, template.component) is None:
            missing(str(loaded.path), "component", template.component)
    # WP-53: group members and structure plates reference cube modules.
    for loaded in library.by_kind("cube_group"):
        group = loaded.record
        assert isinstance(group, GroupRecord)
        rel = str(loaded.path)
        for key, member in group.members.items():
            if resolve(library, member.module) is None:
                missing(rel, f"member {key!r}", member.module)
        for face, plate in (group.structure.plates if group.structure else {}).items():
            if resolve(library, plate.module) is None:
                missing(rel, f"plate {face!r}", plate.module)
    return errors


def _thumbnail_rel(loaded: LoadedRecord, root: Path) -> str | None:
    thumb = loaded.record.thumbnail
    if not thumb:
        return None
    candidate = (loaded.path.parent / thumb).resolve()
    try:
        return candidate.relative_to(root.resolve()).as_posix()
    except ValueError:
        return thumb


def _asset_url(rel: str | None) -> str | None:
    """Service asset URL for a library-root-relative file path (WP-34).

    The palette resolves these against the index origin, so entries work both
    from the live service (``/v1/library/assets/...``) and stay harmless in
    the bundled offline snapshot.
    """
    if not rel:
        return None
    return f"/v1/library/assets/{rel}"


def _xyz(v: ContinuousXYZ) -> list[float]:
    return [float(v.x or 0.0), float(v.y or 0.0), float(v.z or 0.0)]


def _pose_grid(pose: PoseSpec | None) -> list[str] | None:
    """[z, x] of the pose's grid rotation, or None without a pose."""
    if pose is None:
        return None
    grid = pose.rotation.grid
    return [grid.z or "+z", grid.x or "+x"]


def _pose_offset_mm(pose: PoseSpec | None) -> list[float] | None:
    """The translation (mm, from the cell centre); None when absent/zero."""
    if pose is None:
        return None
    off = _xyz(pose.translation.offset_mm)
    return off if any(abs(v) > 1e-9 for v in off) else None


def _pose_offset_deg(pose: PoseSpec | None) -> list[float] | None:
    """The residual rotation (extrinsic Z-X-Y degrees, right-multiplied onto
    the grid); None when absent/zero."""
    if pose is None:
        return None
    off = _xyz(pose.rotation.offset_deg)
    return off if any(abs(v) > 1e-9 for v in off) else None


def _bays_view(template: TemplateRecord | None) -> dict[str, Any]:
    """Docking regions for cube arrays: origin cell, extent in cells, axis constraint."""
    return {
        name: {"origin_cell": list(bay.origin_cell), "size": list(bay.size), "axis": bay.axis}
        for name, bay in (template.bays if template else {}).items()
    }


def _mounts_view(template: TemplateRecord | None) -> dict[str, Any]:
    """Docking poses for non-cube parts: mm translation (always 3 numbers),
    [z, x] grid, residual (None when zero), accepted interface key."""
    return {
        name: {
            "offset_mm": _xyz(mount.pose.translation.offset_mm),
            "grid": _pose_grid(mount.pose),
            "offset_deg": _pose_offset_deg(mount.pose),
            "accepts": mount.accepts,
        }
        for name, mount in (template.mounts if template else {}).items()
    }


def _module_assets(
    tpl: LoadedRecord | None,
    module_thumb: str | None,
    comp: LoadedRecord | None = None,
    glb_override: str | None = None,
) -> dict[str, str | None]:
    """Thumbnail + mesh asset URLs a palette tile and the assembly view need.

    ``glb_override`` is a design-backed module's merged `_objects.glb`: the
    whole assembly, not the shared cube template it borrows its shell from.
    """
    template = tpl.record if tpl else None
    glb = step = None
    if tpl and isinstance(template, TemplateRecord):
        tpl_dir = tpl.path.parent.name
        # The GLB is advertised only when it is actually THERE. 64 migrated
        # records name a mesh they do not ship (their real source is a remote
        # `glb-url`), and an unguarded URL here made the index promise an
        # asset that 404s. `library vendor-assets` pulls those in; until it
        # has run, the honest answer is null. Same rule as step/symbol below.
        if template.glb and (tpl.path.parent / template.glb).is_file():
            glb = _asset_url(f"templates/{tpl_dir}/{template.glb}")
        step_file = template.step or (
            template.glb.rsplit(".", 1)[0] + ".step" if template.glb else ""
        )
        if step_file and (tpl.path.parent / step_file).is_file():
            step = _asset_url(f"templates/{tpl_dir}/{step_file}")
    if glb_override:
        glb = glb_override
    thumb = _asset_url(module_thumb)
    if thumb is None and tpl:
        thumb = _asset_url(_thumbnail_rel(tpl, tpl.path.parents[2]))
    mesh_pose = getattr(template, "mesh_pose", None)
    # WP-48: an authored schematic symbol, when the component ships one.
    symbol = None
    component = comp.record if comp else None
    if (
        comp
        and isinstance(component, ComponentRecord)
        and component.symbol
        and (comp.path.parent / component.symbol).is_file()
    ):
        symbol = _asset_url(f"components/{comp.path.parent.name}/{component.symbol}")
    return {"thumbnail": thumb, "glb": glb, "step": step, "symbol": symbol,
            "mesh_frame": (
                template.mesh_frame
                if isinstance(template, TemplateRecord)
                else ""
            ),
            # WP-137: the FILE->cube correction grid, when declared. The
            # renderer composes it under the basis so a wrongly exported
            # file draws corrected everywhere it appears.
            "mesh_pose_grid": _pose_grid(mesh_pose),
            # WP-156: the translation half — where the mesh sits in the cell —
            # and the residual rotation (a housing's orientation in it).
            "mesh_pose_offset_mm": _pose_offset_mm(mesh_pose),
            "mesh_pose_offset_deg": _pose_offset_deg(mesh_pose)}


def _component_ports(component: ComponentRecord | None) -> list[dict[str, Any]]:
    """Record ports with frame offsets resolved to local mm (WP-34).

    The same resolution the frontend applies to a retained source design —
    shipping it in the index means the palette needs no per-record requests.
    """
    if component is None:
        return []
    optics = component.optics
    out: list[dict[str, Any]] = []
    for name, port in optics.ports.items():
        frame = optics.frames.get(port.frame)
        position = [
            float(v) if isinstance(v, (int, float)) else 0.0
            for v in (
                (frame.x_mm, frame.y_mm, frame.z_mm) if frame else (0.0, 0.0, 0.0)
            )
        ]
        entry: dict[str, Any] = {
            "name": name,
            "direction": port.direction or "+z",
            "position_mm": position,
            "after_surface": port.after_surface,
            # WP-46: "fiber" ports take a patch cord, "" is free space.
            "coupling": port.coupling,
        }
        # WP-79: a tilted datum frame tilts the beam — ship the quaternion so a
        # gizmo-placed 45° mirror simulates folded, not axis-aligned. And the
        # frame's measured clear aperture, so DRC can check beam vs aperture.
        if frame is not None and frame.rotation is not None:
            entry["rotation"] = [float(v) for v in frame.rotation]
        if (
            frame is not None
            and frame.clear_aperture_mm is not None
            and isinstance(frame.clear_aperture_mm, int | float)
        ):
            entry["clear_aperture_mm"] = float(frame.clear_aperture_mm)
        out.append(entry)
    return out


def _child_rest_transform(child: Any) -> tuple[Any, tuple[float, float, float]]:
    """A subdesign child's authored pose at REST as (R, t) in the cube frame.

    Numeric leaves only — an expression leaf reads as its rest value 0, the
    same state `_subdesign_view` inlines nested designs at.
    """
    from ..constants import UC2_GRID_MM
    from ..geometry.rotations import compose

    def num(value: Any) -> float:
        return (float(value) if isinstance(value, int | float)
                and not isinstance(value, bool) else 0.0)

    rot = child.pose.rotation.normalized()
    off = rot.offset_deg
    r = compose(rot.grid.z or "+z", rot.grid.x or "+x",
                {"x": num(off.x), "y": num(off.y), "z": num(off.z)})
    tr = child.pose.translation
    t = tuple(
        num(getattr(tr.offset_grid, axis)) * pitch + num(getattr(tr.offset_mm, axis))
        for axis, pitch in zip("xyz", UC2_GRID_MM, strict=True)
    )
    return r, t  # type: ignore[return-value]


def _matrix_to_xyzw(r: Any) -> list[float]:
    """3×3 rotation → [x, y, z, w] quaternion (Shepperd's method)."""
    m00, m01, m02 = float(r[0][0]), float(r[0][1]), float(r[0][2])
    m10, m11, m12 = float(r[1][0]), float(r[1][1]), float(r[1][2])
    m20, m21, m22 = float(r[2][0]), float(r[2][1]), float(r[2][2])
    trace = m00 + m11 + m22
    if trace > 0:
        s_ = 2.0 * (trace + 1.0) ** 0.5
        q = ((m21 - m12) / s_, (m02 - m20) / s_, (m10 - m01) / s_, 0.25 * s_)
    elif m00 > m11 and m00 > m22:
        s_ = 2.0 * (1.0 + m00 - m11 - m22) ** 0.5
        q = (0.25 * s_, (m01 + m10) / s_, (m02 + m20) / s_, (m21 - m12) / s_)
    elif m11 > m22:
        s_ = 2.0 * (1.0 + m11 - m00 - m22) ** 0.5
        q = ((m01 + m10) / s_, 0.25 * s_, (m12 + m21) / s_, (m02 - m20) / s_)
    else:
        s_ = 2.0 * (1.0 + m22 - m00 - m11) ** 0.5
        q = ((m02 + m20) / s_, (m12 + m21) / s_, 0.25 * s_, (m10 - m01) / s_)
    return [round(float(c), 6) + 0.0 for c in q]


def _child_rotation(decl: Any, variant: str) -> Any | None:
    """The single optical child's rotation matrix under ``variant``, or None."""
    from ..geometry.rotations import compose
    from ..schema.design import InstSpec
    from ..schema.merge import instantiate

    try:
        comps = instantiate(decl, InstSpec(variant=variant))
    except (KeyError, ValueError):
        return None
    optical = [c for c in comps.values() if c.optics is not None and c.optics.ports]
    if len(optical) != 1:
        return None
    rot = optical[0].pose.rotation.normalized()
    off = rot.offset_deg
    return compose(rot.grid.z or "+z", rot.grid.x or "+x", {
        axis: float(getattr(off, axis) or 0.0) if isinstance(
            getattr(off, axis), int | float) else 0.0 for axis in "xyz"})


def _variant_seat(decl: Any, variant: str) -> list[str] | None:
    """The RE-MOUNT ``variant`` applies, as a [z, x] grid — or None.

    Relative to the base variant, so it is exactly what the retired
    ``mounting:`` said: the extra turn the insert takes inside its cube, with
    the record→cube hop divided out. The editor multiplies it onto the part's
    pose the way it used to multiply `mountGrid`.

    None when the design's optics are not one child (the galvo), or when the
    variant turns something the grid cannot spell — the seat picker then
    offers the variant without claiming to know which way it points.
    """
    from ..geometry.rotations import decompose

    here = _child_rotation(decl, variant)
    base = _child_rotation(decl, "")
    if here is None or base is None:
        return None
    seated = decompose(here @ base.T)
    if seated.residual_angle_deg > 1e-6:
        return None
    return [seated.z, seated.x]


def _subdesign_optics(library: Library, module: ModuleRecord) -> dict[str, Any] | None:
    """A subdesign-backed module's optical boundary, AS MOUNTED (cube frame).

    Exact for one optical child: its record ports and frames carried through
    its own pose — the seat the cubify road writes, the insert-pose the
    decompose road copies. Multiple optical children (the galvo) have no
    single boundary a record can state, so this is None and the linker's
    chain inference owns the question (unchanged since WP-198).
    """
    from ..geometry.rotations import direction_vector
    from .subdesigns import SubdesignError, subdesign_dir

    if not module.design:
        return None
    try:
        _, design_file = subdesign_dir(library, module.design)
        decl = load_design(design_file.parent)
    except (SubdesignError, ValueError, KeyError, OSError):
        return None
    optical = [
        (cid, c) for cid, c in decl.components.items()
        if c.optics is not None and c.optics.ports
    ]
    if len(optical) != 1:
        return None
    child_id, child = optical[0]
    r, t = _child_rest_transform(child)

    def posed(point: tuple[float, float, float]) -> list[float]:
        return [round(float(sum(r[i][j] * point[j] for j in range(3)) + t[i]), 6) + 0.0
                for i in range(3)]

    def turned(direction: Any) -> Any:
        vec = direction_vector(direction)
        if vec is None:
            return direction
        out = [float(sum(r[i][j] * vec[j] for j in range(3))) for i in range(3)]
        for i, axis in enumerate("xyz"):  # an axis literal stays a literal
            if abs(abs(out[i]) - 1.0) < 1e-9:
                return f"{'+' if out[i] > 0 else '-'}{axis}"
        return [round(v, 9) + 0.0 for v in out]

    frames = child.optics.frames or {}

    def origin(name: str) -> tuple[float, float, float]:
        f = frames.get(name)
        if f is None:
            return (0.0, 0.0, 0.0)
        x, y, z = (float(v) if isinstance(v, int | float) else 0.0
                   for v in (f.x_mm, f.y_mm, f.z_mm))
        return (x, y, z)

    ports: list[dict[str, Any]] = []
    for name, port in child.optics.ports.items():
        frame = frames.get(port.frame)
        entry: dict[str, Any] = {
            "name": name,
            "direction": turned(port.direction or "+z"),
            "position_mm": posed(origin(port.frame)),
            "after_surface": port.after_surface,
            "coupling": port.coupling,
        }
        if (
            frame is not None
            and frame.clear_aperture_mm is not None
            and isinstance(frame.clear_aperture_mm, int | float)
        ):
            entry["clear_aperture_mm"] = float(frame.clear_aperture_mm)
        ports.append(entry)
    return {
        "child": child_id,
        "ports": ports,
        "frames": {name: posed(origin(name)) for name in frames},
        "rot_xyzw": _matrix_to_xyzw(r),
    }



def _subdesign_mirror_elements(
    library: Library, module: ModuleRecord, template: TemplateRecord | None
) -> list[dict[str, Any]] | None:
    """WP-229 tail: a DECOMPOSED module's glyph plates, from its children.

    Each optical child with an entry + reflected pair is one plate: position =
    its rest pose translation, normal = the fold bisector its own ports
    declare (n ∝ d_out − d_in, facing the beam). Children are authored
    as-mounted (cube axes) while this field's contract is RECORD axes — the
    viewers re-mount through ``insert_rot_xyzw`` — so both are un-rotated
    through the insert-pose first. None below two plates.
    """
    from ..geometry.rotations import direction_vector
    from .subdesigns import SubdesignError, subdesign_dir

    if not module.design:
        return None
    try:
        _, design_file = subdesign_dir(library, module.design)
        decl = load_design(design_file.parent)
    except (SubdesignError, ValueError, KeyError, OSError):
        return None

    unmount = None
    if template is not None and getattr(template, "insert_pose", None) is not None:
        from .verify import _insert_pose_transform  # noqa: PLC2701 — shared law

        r, _ = _insert_pose_transform(template)
        unmount = [[float(r[j][i]) for j in range(3)] for i in range(3)]  # Rᵀ

    def _unrot(v: tuple[float, float, float]) -> tuple[float, float, float]:
        if unmount is None:
            return v
        return tuple(sum(unmount[i][j] * v[j] for j in range(3)) for i in range(3))

    out: list[dict[str, Any]] = []
    for child in decl.components.values():
        optics = child.optics
        if optics is None or not optics.ports or optics.fragment is None:
            continue
        entry = next((p for n, p in optics.ports.items()
                      if n in ("front", "sensor", "in", "plane")), None)
        exit_ = next((p for n, p in optics.ports.items()
                      if n not in ("front", "sensor", "in", "plane")
                      and p.after_surface is not None), None)
        d_in = direction_vector(entry.direction) if entry is not None else None
        d_out = direction_vector(exit_.direction) if exit_ is not None else None
        if d_in is None or d_out is None:
            continue
        # the entry port FACES the beam, so the beam travels −entry
        n = (float(d_out[0]) + float(d_in[0]),
             float(d_out[1]) + float(d_in[1]),
             float(d_out[2]) + float(d_in[2]))
        length = (n[0] ** 2 + n[1] ** 2 + n[2] ** 2) ** 0.5
        if length < 1e-9:
            continue
        n = (n[0] / length, n[1] / length, n[2] / length)
        transl = child.pose.translation.offset_mm
        pos = tuple(
            float(v) if isinstance(v, int | float) else 0.0
            for v in (transl.x, transl.y, transl.z)
        )
        surface = next(
            (s for s in optics.fragment.surfaces
             if isinstance(s, dict)
             and (s.get("interaction_model") or {}).get("is_reflective")),
            None,
        )
        semi = (surface or {}).get("semi_aperture")
        out.append({
            "surface": len(out),
            "pos_mm": [round(c, 6) for c in _unrot(pos)],
            "normal": [round(c, 6) for c in _unrot(n)],
            "semi_aperture_mm": float(semi) if isinstance(semi, int | float) else None,
        })
    return out if len(out) >= 2 else None


def _as_mounted_ports(
    template: TemplateRecord | None, component: ComponentRecord | None
) -> list[dict[str, Any]]:
    """WP-122: the PLACED part's pins — as mounted, not as authored.

    A placed cube module's local frame is the CUBE (F3); the component's
    ports are record-frame (F2). Since WP-116 the template precomposes the
    insert-pose into ``optical_ports`` (directions) and ``frames`` (posed
    positions) — serving THOSE here is what makes the canvas fold, the
    assembly glyph and the inspector agree with the binding the parts
    editor showed. Round 17's field report: the editor said
    "front faces -y" while the placed part's pins said "front faces -z".

    Only a template WITH an ``insert-pose`` gets this treatment: its
    optical_ports were authored by the binding machinery and are complete by
    construction. Legacy templates (no pose) may carry a hand-written,
    PARTIAL optical_ports block — openuc2.tpl.mirror_mount_1x1 declares only
    ``front`` while the component folds through ``reflected`` — so they fall
    back to the component's record ports, which under the identity pose ARE
    the as-mounted ports.
    """
    if (
        template is None
        or getattr(template, "insert_pose", None) is None
        or not template.optical_ports
    ):
        return _component_ports(component)
    comp_frames = component.optics.frames if component is not None else {}
    out: list[dict[str, Any]] = []
    for name, port in template.optical_ports.items():
        tpl_frame = template.frames.get(port.frame)
        position = [
            float(v) if isinstance(v, (int, float)) else 0.0
            for v in (
                (tpl_frame.x_mm, tpl_frame.y_mm, tpl_frame.z_mm)
                if tpl_frame
                else (0.0, 0.0, 0.0)
            )
        ]
        entry: dict[str, Any] = {
            "name": name,
            "direction": port.direction or "+z",
            "position_mm": position,
            "after_surface": port.after_surface,
            "coupling": port.coupling,
        }
        # Clear aperture is an OPTICAL fact — it travels from the component's
        # frame of the same name (the pose does not change a diameter).
        comp_frame = comp_frames.get(port.frame) if comp_frames else None
        if (
            comp_frame is not None
            and comp_frame.clear_aperture_mm is not None
            and isinstance(comp_frame.clear_aperture_mm, int | float)
        ):
            entry["clear_aperture_mm"] = float(comp_frame.clear_aperture_mm)
        out.append(entry)
    return out


def _source_view(component: ComponentRecord | None) -> dict[str, Any]:
    """Normalized source facts for the palette: the WP-47 ``source:`` block
    when the record has one, else derived from the §9.5 ``optics.emission``
    block (spectrum → line list; cone half-angle ×2 → full divergence; disc
    radius ×2 → 1/e² beam diameter). The library holds both source dialects;
    without this the emission-dialect records (laser_488) index with an empty
    line list and the picker — and the exported emission — go blind."""
    empty: dict[str, Any] = {
        "wavelengths_um": [], "divergence_deg": 0.0, "beam_diameter_mm": None,
    }
    if component is None:
        return empty
    # Fact sheets ride the same merge point, only where the record has one —
    # the per-slot objective list and the Nyquist check read these.
    facts = {
        **({"objective": component.objective.model_dump()} if component.objective else {}),
        **({"detector": component.detector.model_dump()} if component.detector else {}),
    }
    if component.source is not None:
        return {
            "wavelengths_um": list(component.source.wavelengths_um),
            "divergence_deg": float(component.source.divergence_deg),
            "beam_diameter_mm": component.source.beam_diameter_mm,
            **facts,
        }
    emission = component.optics.emission if component.optics else None
    if emission is None:
        return {**empty, **facts}
    divergence = 0.0
    if emission.angular.type == "cone" and isinstance(
        emission.angular.half_angle_deg, int | float
    ):
        divergence = 2.0 * float(emission.angular.half_angle_deg)
    beam = None
    if emission.spatial.type == "disc" and isinstance(
        emission.spatial.radius_mm, int | float
    ):
        beam = 2.0 * float(emission.spatial.radius_mm)
    return {
        "wavelengths_um": [float(line.wavelength_um) for line in emission.spectrum],
        "divergence_deg": divergence,
        "beam_diameter_mm": beam,
        **facts,
    }


def _quat_rot_xyzw(q: list[float], v: tuple[float, float, float]) -> tuple[float, float, float]:
    """Rotate ``v`` by an [x, y, z, w] quaternion (plain math, no numpy)."""
    x, y, z, w = (float(c) for c in q)
    # t = 2 * (u × v); v' = v + w*t + u × t
    tx = 2.0 * (y * v[2] - z * v[1])
    ty = 2.0 * (z * v[0] - x * v[2])
    tz = 2.0 * (x * v[1] - y * v[0])
    return (
        v[0] + w * tx + (y * tz - z * ty),
        v[1] + w * ty + (z * tx - x * tz),
        v[2] + w * tz + (x * ty - y * tx),
    )


def _insert_rot_xyzw(template: TemplateRecord | None) -> list[float] | None:
    """WP-193: the binding's record→cube (F2→F3) ROTATION as an [x,y,z,w]
    quaternion — None without an insert-pose (identity: record IS the frame).

    Serving it lets viewers carry any record-frame geometry (the
    ``mirror_elements`` poses) into the mounted frame the ports already
    speak, instead of guessing with a shortest-arc — which is how a 90°-
    mounted galvo drew its plates 90° off the trace."""
    if template is None or getattr(template, "insert_pose", None) is None:
        return None
    from .verify import _insert_pose_transform  # noqa: PLC2701 — shared law

    r, _ = _insert_pose_transform(template)
    return _matrix_to_xyzw(r)


def _mirror_elements(component: ComponentRecord | None) -> list[dict[str, Any]] | None:
    """WP-193: the per-element poses of a MULTI-mirror record (the dual
    galvo), served so viewers draw the real plates instead of a symbol.

    Positions are relative to the ENTRY port's frame (record axes, mm);
    normals face the incoming beam. The normal law mirrors the
    materializer's fold chain: an owner frame with a rotation states the
    element's orientation outright (R·−beam); otherwise the in/out bisector,
    with the leg to the next element as the intermediate-hop fallback.
    None for records with fewer than two reflective surfaces.
    """
    if component is None:
        return None
    optics = component.optics
    frag = optics.fragment
    if frag is None or not frag.surfaces:
        return None
    surfaces = [s for s in frag.surfaces if isinstance(s, dict)]
    refl = [i for i, s in enumerate(surfaces)
            if (s.get("interaction_model") or {}).get("is_reflective")]
    if len(refl) < 2:
        return None
    from ..geometry.rotations import direction_vector

    ports = optics.ports
    frames = optics.frames
    entry = next(
        (p for n, p in ports.items() if n in ("front", "sensor", "in", "plane")),
        next(iter(ports.values()), None),
    )
    entry_dir = direction_vector(entry.direction) if entry is not None else None
    if entry_dir is None:
        return None
    beam = (-float(entry_dir[0]), -float(entry_dir[1]), -float(entry_dir[2]))

    def fxyz(name: str) -> tuple[float, float, float]:
        f = frames[name]
        return (float(f.x_mm), float(f.y_mm), float(f.z_mm))

    owner = {p.after_surface: p.frame for p in ports.values()
             if p.after_surface is not None and p.frame in frames}
    origin = fxyz(entry.frame) if entry.frame in frames else (0.0, 0.0, 0.0)

    def spos(i: int) -> tuple[float, float, float]:
        name = owner.get(i)
        if name is not None:
            return fxyz(name)
        axial = sum(float(s.get("thickness") or 0.0) for s in surfaces[:i])
        base = fxyz("optical") if "optical" in frames else (0.0, 0.0, 0.0)
        return (base[0], base[1], base[2] + axial)

    exits: dict[int, list[tuple[str, tuple[float, float, float]]]] = {}
    for n, p in ports.items():
        if p.after_surface is None:
            continue
        v = direction_vector(p.direction)
        if v is not None:
            exits.setdefault(p.after_surface, []).append(
                (n, (float(v[0]), float(v[1]), float(v[2]))))

    def _norm(v: tuple[float, float, float]) -> tuple[float, float, float] | None:
        n = (v[0] ** 2 + v[1] ** 2 + v[2] ** 2) ** 0.5
        return None if n < 1e-9 else (v[0] / n, v[1] / n, v[2] / n)

    def _close(a: tuple[float, float, float], b: tuple[float, float, float]) -> bool:
        return abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2]) < 1e-6

    out: list[dict[str, Any]] = []
    d_in = beam
    for pos_i, i in enumerate(refl):
        frame = frames.get(owner.get(i, ""))
        rot = getattr(frame, "rotation", None) if frame is not None else None
        if rot is not None and len(rot) == 4:
            normal = _quat_rot_xyzw(list(rot), (-beam[0], -beam[1], -beam[2]))
            dot = d_in[0] * normal[0] + d_in[1] * normal[1] + d_in[2] * normal[2]
            d_out = (d_in[0] - 2 * dot * normal[0],
                     d_in[1] - 2 * dot * normal[1],
                     d_in[2] - 2 * dot * normal[2])
        else:
            cands = exits.get(i, [])
            named = [v for n_, v in cands if n_ == "reflected"]
            d_out = named[0] if named else None
            if d_out is None:
                folds = [v for _n, v in cands if not _close(v, d_in)]
                d_out = folds[0] if len(folds) == 1 else None
            if d_out is None and pos_i + 1 < len(refl):
                a, b = spos(i), spos(refl[pos_i + 1])
                d_out = _norm((b[0] - a[0], b[1] - a[1], b[2] - a[2]))
            if d_out is None or _close(d_out, d_in):
                normal = (-d_in[0], -d_in[1], -d_in[2])
                d_out = normal
            else:
                normal = _norm((d_out[0] - d_in[0], d_out[1] - d_in[1],
                                d_out[2] - d_in[2])) or (-d_in[0], -d_in[1], -d_in[2])
        p_i = spos(i)
        # Serve the normal FACING the incoming beam (viewers put the coated
        # face there); the two derivation laws disagree on sign and a disc
        # cannot care, but the served contract should.
        if normal[0] * d_in[0] + normal[1] * d_in[1] + normal[2] * d_in[2] > 0:
            normal = (-normal[0], -normal[1], -normal[2])
        aperture = surfaces[i].get("semi_aperture")
        out.append({
            "surface": i,
            "pos_mm": [round(p_i[k] - origin[k], 3) for k in range(3)],
            "normal": [round(float(c), 6) for c in normal],
            "semi_aperture_mm": float(aperture) if aperture is not None else None,
        })
        d_in = d_out
    return out


def _mirror_rect_mm(component: ComponentRecord | None) -> list[float] | None:
    """WP-125: the reflective surface's rectangular clear aperture, [w, h] mm.

    The parts editor draws a rectangular mirror as the plate the record
    declares; the assembly glyph renders off the module INDEX entry, which
    (unlike bare-component entries) does not ship fragment surfaces — so the
    one fact the glyph needs travels as a field. None = round (semi-aperture
    disc), the default."""
    if component is None or component.optics.fragment is None:
        return None
    surfaces = [dict(s) for s in component.optics.fragment.surfaces]
    reflective = [
        s for s in surfaces
        if isinstance(s.get("interaction_model"), dict)
        and s["interaction_model"].get("is_reflective")
    ] or surfaces
    for surf in reflective:
        ap = surf.get("aperture")
        if isinstance(ap, dict) and ap.get("type") == "RectangularAperture":
            try:
                w = float(ap["x_max"]) - float(ap["x_min"])
                h = float(ap["y_max"]) - float(ap["y_min"])
            except (KeyError, TypeError, ValueError):
                continue
            if w > 0 and h > 0:
                return [w, h]
    return None


def _component_entries(library: Library) -> list[dict[str, Any]]:
    """Latest version of every optical component — the WP-14 editor browses
    these, and since WP-60 the palette places the UNBOUND ones directly, so
    each entry ships its ports (resolved to local mm) and source facts."""
    latest: dict[str, LoadedRecord] = {}
    for loaded in library.by_kind("optical_component"):
        record = loaded.record
        assert isinstance(record, ComponentRecord)
        held = latest.get(record.id)
        if held is None or Version.parse(record.version) > Version.parse(
            held.record.version
        ):
            latest[record.id] = loaded
    out: list[dict[str, Any]] = []
    for loaded in sorted(latest.values(), key=lambda x: x.record.id):
        record = loaded.record
        assert isinstance(record, ComponentRecord)
        # WP-48/WP-60: an authored symbol, when the record ships one on disk.
        symbol = None
        if record.symbol and (loaded.path.parent / record.symbol).is_file():
            symbol = _asset_url(f"components/{loaded.path.parent.name}/{record.symbol}")
        out.append(
            {
                "id": record.id,
                "version": record.version,
                "kind": "optical_component",
                "category": record.category,
                "description": record.description,
                "tags": record.tags,
                "vendor": record.vendor.model_dump(),
                "efl_mm": record.effective_focal_length_mm,
                "n_surfaces": len(record.optics.fragment.surfaces)
                if record.optics.fragment
                else 0,
                "review": bool(record.review),
                "locked": record.locked,
                # WP-60: enough to PLACE a bare symbol — its ports and, for
                # sources, the emission lines the wavelength picker offers.
                "ports": _component_ports(record),
                # WP-145: the beam width the trace must use (from either source
                # dialect). Without it the compiler fell back to a hardcoded
                # 10 mm entrance pupil, so a 2 mm laser drew 2 mm on the canvas
                # and traced 10 mm.
                **_source_view(record),
                "symbol": symbol,
                # WP-60: the record's own surface stack, verbatim — a placed
                # unbound part exports (and simulates) the REAL prescription,
                # not a thin-lens approximation. May carry .inf radii; every
                # index dump goes through dump_index_json for that reason.
                "fragment_surfaces": (
                    [dict(s) for s in record.optics.fragment.surfaces]
                    if record.optics.fragment
                    else []
                ),
                # WP-193: real per-element plates of a multi-mirror record —
                # same field the module entries carry.
                "mirror_elements": _mirror_elements(record),
            }
        )
    return out


def _git_dir(root: Path) -> Path | None:
    """The `.git` directory governing `root`, walking up. None if untracked.

    Handles the worktree/submodule spelling where `.git` is a FILE containing
    `gitdir: <path>` rather than a directory.
    """
    for base in (root, *root.parents):
        candidate = base / ".git"
        if candidate.is_dir():
            return candidate
        if candidate.is_file():
            try:
                line = candidate.read_text(encoding="utf-8").strip()
            except OSError:
                return None
            if line.startswith("gitdir:"):
                target = Path(line.partition(":")[2].strip())
                resolved = target if target.is_absolute() else (base / target)
                return resolved if resolved.is_dir() else None
            return None
    return None


def _repo_dir(git_dir: Path) -> Path:
    """The working-tree root a gitdir belongs to.

    For an ordinary checkout that is simply `.git`'s parent. For a LINKED
    WORKTREE the gitdir is `<repo>/.git/worktrees/<name>`, and for a submodule
    `<super>/.git/modules/<path>`; in both cases git writes a `commondir`
    file pointing at the real `.git`, which is the only reliable way back.
    """
    commondir = git_dir / "commondir"
    if commondir.is_file():
        try:
            rel = commondir.read_text(encoding="utf-8").strip()
        except OSError:
            return git_dir.parent
        if rel:
            common = Path(rel)
            common = common if common.is_absolute() else (git_dir / common)
            # `commondir` names the shared `.git`; its parent is the repo.
            return common.resolve().parent
    return git_dir.parent


def serving_provenance(root: Path) -> dict[str, Any]:
    """``{source, source_commit}`` for the library a SERVICE is serving right now.

    Response-only, and that restriction IS the design (M4). Both fields are
    environment-derived, while the committed index artifacts are held
    byte-reproducible by CI (``library build && git diff --exit-code``). An
    environment field inside the artifact is self-invalidating: bake HEAD in,
    commit, and the next rebuild is at a different HEAD, so the equality check
    fails forever and the "commit index if changed" loop churns on every push.

    HEAD is read straight from ``.git``, not via ``git rev-parse``: this runs
    on every index request, and two subprocess spawns per warm request cost
    more than the cache hit they sit behind (WP-51's ``warm_ms < 100`` gate
    caught exactly that). Two file reads need no git on PATH and still reflect
    a commit the instant it lands.

    ``source`` is the repository directory name — ``optikit-core`` vs
    ``optikit-library``, the distinction a confused palette needs.
    """
    # Resolved first: a relative root has no useful `.parents` to walk, so
    # `Path("library")` would find the CWD's .git and report an empty repo
    # name instead of `optikit-core`.
    root = root.resolve()
    out: dict[str, Any] = {"source": root.name}
    git_dir = _git_dir(root)
    if git_dir is None:
        return out
    # The repo directory is .git's parent — but for a linked worktree the
    # gitdir is `<repo>/.git/worktrees/<name>`, whose parent is literally
    # "worktrees". Copilot review (PR #15, build.py:591): the old comment
    # claimed that name "still identifies the repo well enough"; it does not,
    # it misidentifies EVERY worktree-backed library as `worktrees`.
    # `commondir` is git's own answer to "where is the real .git", so use it.
    out["source"] = _repo_dir(git_dir).name or root.name
    try:
        head = (git_dir / "HEAD").read_text(encoding="utf-8").strip()
    except OSError:
        return out
    if not head.startswith("ref:"):
        out["source_commit"] = head[:7]          # detached HEAD: a raw sha
        return out
    ref = head.partition(":")[2].strip()
    try:
        out["source_commit"] = (git_dir / ref).read_text(encoding="utf-8").strip()[:7]
        return out
    except OSError:
        pass  # loose ref absent — it is packed
    try:
        for line in (git_dir / "packed-refs").read_text(encoding="utf-8").splitlines():
            if line.endswith(f" {ref}"):
                out["source_commit"] = line.split(" ", 1)[0][:7]
                break
    except OSError:
        pass  # a fresh repo with no commit yet: the name still answers "which"
    return out


def _companion_component(library: Library, design_ref: str):
    """The component a decomposed subdesign records as its provenance.

    ``None`` for hand-authored subdesigns (mounted_galvo carries no
    provenance) and for any resolution failure — the caller then serves the
    design-only view exactly as before.
    """
    from .subdesigns import SubdesignError, subdesign_dir

    try:
        record, _ = subdesign_dir(library, design_ref)
    except (SubdesignError, ValueError, KeyError, OSError):
        return None
    ref = getattr(record, "component", None)
    if not isinstance(ref, str) or not ref:
        return None
    return resolve(library, ref)


def _subdesign_view(library: Library, module: ModuleRecord) -> dict[str, Any] | None:
    """What a subdesign-backed module publishes about its optical side.

    Variants and declared inputs come from the DESIGN FILE — the one source of
    truth for them (decision D4) — so the editor's seat picker and the record
    can never drift apart. A subdesign that fails to load is reported by
    `check_references`; here it simply publishes nothing beyond its ref.
    """
    if not module.design:
        return None
    from .subdesigns import SubdesignError, subdesign_dir

    view: dict[str, Any] = {"ref": module.design, "resolved": None,
                            "variants": [], "inputs": {}, "children": []}
    try:
        record, design_file = subdesign_dir(library, module.design)
        decl = load_design(design_file.parent)
    except (SubdesignError, ValueError, KeyError, OSError):
        return view
    view["resolved"] = record.version
    # WP-246: each variant's SEAT — the grid the optic child ends up in when
    # that variant is selected. The editor's 90° buttons cycle these and the
    # glyph follows, which is what `mounting:` used to do; without it the
    # picker could name a seat but nothing would turn.
    view["variants"] = [
        {"id": vid, "description": v.description, "seat": _variant_seat(decl, vid)}
        for vid, v in sorted(decl.variants.items())
    ]
    view["inputs"] = {
        name: spec.dump() for name, spec in sorted(decl.inputs.items())
    }
    # WP-229 tail: which input rotates which optical child, read off the pose
    # expressions (schema/motion.py) — the schematic glyph tilts its plates
    # from this. Served only for the exactly-derivable shape (identity seat +
    # `offset-deg`, the decompose spelling): under a seat the leaf letter is
    # not the world axis, and a wrong tilt is worse than a still plate.
    # `plate` is the child's ordinal among optical children in declaration
    # order — the same order the served plates use.
    from ..schema.motion import design_motion_axes

    optical_order = [cid for cid, c in decl.components.items()
                     if c.optics is not None and c.optics.ports]
    view["motions"] = [
        {"input": a.input_name, "child": a.comp_id,
         "plate": optical_order.index(a.comp_id),
         "axis": a.axis, "gain": a.gain}
        for a in design_motion_axes(decl)
        if a.kind == "rotation"
        and a.comp_id in optical_order
        and decl.components[a.comp_id].pose.rotation.kind in ("", "uc2")
        and not decl.components[a.comp_id].pose.rotation.grid.z
        and not decl.components[a.comp_id].pose.rotation.grid.x
    ]
    # WP-227: everything the VIEWER needs to render the children live — the
    # mesh URL and the RAW pose (expressions intact; the client evaluates
    # them against the slider values with the twin evaluator). A WP-228
    # record nests further designs (mirror-static's shape), so the tree is
    # inlined at its REST state first — nested children arrive with baked
    # poses and path-joined ids; only same-level expression poses stay
    # parametric. Mesh paths from nested levels keep their relative dirs.
    from ..geometry.flatten import inline_subassemblies
    from ..io.yamlio import design_dir_loader
    from ..schema.design import InstSpec
    from ..schema.merge import instantiate

    sub_dir = design_file.parent.name
    try:
        comps, _notes = inline_subassemblies(
            instantiate(decl, InstSpec()),
            design_dir_loader(design_file.parent),
        )
    except (ValueError, KeyError, OSError):
        # A broken nested ref is check_references' finding; the view just
        # serves what it can (the top level's own primitives).
        comps = {
            cid: c for cid, c in decl.components.items() if c.kind != "design"
        }
    # Inlined children keep their ORIGINAL model paths; a nested child's
    # mesh lives under its parent's design folder, so rebuild the relative
    # dir from the id path and the parents' `design:` values.
    nested_dirs = {
        cid: c.design for cid, c in decl.components.items()
        if c.kind == "design" and c.design and "/" not in c.design.rstrip("/")
    }

    def _mesh_rel(cid: str, gltf: str) -> str:
        parent = cid.split("/", 1)[0] if "/" in cid else ""
        prefix = nested_dirs.get(parent, "")
        return f"{prefix}/{gltf}" if prefix else gltf

    def _child_pose(cid: str, c: Any) -> dict[str, Any]:
        # The comment above promises the RAW pose, expressions intact — but
        # `comps` went through instantiate(), which EVALUATES every leaf at
        # the rest inputs; exclude_defaults then drops the resulting zeros,
        # so the served pose was the baked rest state and the twin evaluator
        # had nothing parametric to evaluate. Serve the authored pose for
        # top-level children (nested ones stay baked, as documented).
        raw = decl.components.get(cid)
        pose = raw.pose if raw is not None and "/" not in cid else c.pose
        return pose.model_dump(by_alias=True, exclude_defaults=True, exclude_none=True)

    def _moving_nodes(cid: str) -> list[str]:
        # WP-239: the mesh subtrees a split child was cut from (WP-238
        # provenance, an extra key) — the wizard needs them to rebuild the
        # moving-part rows when the pair is re-opened.
        raw = decl.components.get(cid)
        extra = getattr(raw, "model_extra", None) or {}
        nodes = extra.get("moving-nodes")
        return [str(n) for n in nodes] if isinstance(nodes, list) else []

    view["children"] = [
        {
            "id": cid,
            "category": c.category,
            "glb": _asset_url(
                f"subdesigns/{sub_dir}/{_mesh_rel(cid, c.primitive.static_models.gltf)}"
            ) if c.primitive.static_models.gltf else None,
            "pose": _child_pose(cid, c),
            "moving_nodes": _moving_nodes(cid),
            # which child the editors treat as THE optic (its pose is the
            # module's record→cube hop, the way insert-pose was)
            "optical": bool(c.optics is not None and c.optics.ports),
        }
        for cid, c in sorted(comps.items())
        if c.kind != "design"
    ]
    return view


def _subdesign_objects_glb(library: Library, module: ModuleRecord) -> str | None:
    """The design folder's merged `_objects.glb` (Go's convention), when it ships one."""
    from .subdesigns import SubdesignError, subdesign_dir

    if not module.design:
        return None
    try:
        _, design_file = subdesign_dir(library, module.design)
    except (SubdesignError, ValueError, KeyError, OSError):
        return None
    if not (design_file.parent / "_objects.glb").is_file():
        return None
    return _asset_url(f"subdesigns/{design_file.parent.name}/_objects.glb")


def build_index(library: Library, root: Path) -> dict[str, Any]:
    """Flat catalog with modules resolved to concrete component/template versions."""
    entries: list[dict[str, Any]] = []
    for loaded in library.by_kind("cube_module"):
        module = loaded.record
        assert isinstance(module, ModuleRecord)
        # WP-198: a module has ONE optical side. `component:` resolves an
        # optical_component; `design:` resolves a cube_subdesign, whose optics
        # live in its child components. A DECOMPOSED subdesign (WP-229 tail)
        # records which component it came from, and the index keeps serving
        # that companion's component block: the editors join component.ref →
        # module for the mesh, the binding rehydrate and the bound-set, and
        # every one of those broke the moment the module was rewritten to
        # `design:`. The module's optical TRUTH stays the design — the trace
        # inlines the children — the companion is authoring provenance.
        comp = resolve(library, module.component) if module.component else None
        if comp is None and module.design:
            comp = _companion_component(library, module.design)
        tpl = resolve(library, module.template)
        component = comp.record if comp else None
        template = tpl.record if tpl else None
        sub_optics = _subdesign_optics(library, module) if module.design else None
        assert component is None or isinstance(component, ComponentRecord)
        assert template is None or isinstance(template, TemplateRecord)
        design_view = _subdesign_view(library, module)
        # A design-backed module's category comes from its optical children
        # (the dominant non-mechanics one) — `component` is None by the
        # WP-198 XOR, and "other" made every subdesign module unfilterable.
        category = component.category if component else next(
            (c["category"] for c in (design_view or {}).get("children", [])
             if c.get("category") not in ("", "mechanics", "other")),
            "other",
        )
        entries.append(
            {
                "id": module.id,
                "version": module.version,
                "kind": "cube_module",
                "description": module.description,
                "tags": module.tags,
                "category": category,
                "thumbnail": _thumbnail_rel(loaded, root),
                "footprint_grid": list(module.footprint_grid),
                "price": module.price,
                "locked": module.locked,
                "review": bool(module.review or (component and component.review)
                               or (template and template.review)),
                # WP-108: the review NOTES, not just the boolean. A flag alone
                # cannot distinguish "placeholder CAD, do not print" from
                # "confirm the glass name", so the editor badged a curated,
                # priced, shipping part as a "draft" and users learned to
                # ignore it. Carrying the text makes the badge actionable —
                # and names which of the three records it came from.
                "review_notes": [
                    *(f"module: {n}" for n in (module.review or [])),
                    *(f"component: {n}" for n in ((component.review if component else None) or [])),
                    *(f"template: {n}" for n in ((template.review if template else None) or [])),
                ],
                # WP-198: the subdesign side — present only for a
                # subdesign-backed module. `variants` and `inputs` are read
                # from the design file, never restated in the record (D4), so
                # this is where the editor learns which seats a part offers.
                "design": design_view,
                "component": {
                    # A decomposed module's record names no component (D2) —
                    # the ref served here is then the COMPANION's, so the
                    # editors' component.ref → module joins keep working.
                    "ref": module.component or (
                        f"{component.id}@^"
                        + ".".join(str(component.version).split(".")[:2])
                        if component else module.component
                    ),
                    "resolved": component.version if component else None,
                    "vendor": component.vendor.model_dump() if component else None,
                    "efl_mm": component.effective_focal_length_mm if component else None,
                    # WP-47: the source's emission lines drive the panel's
                    # wavelength picker and the ray tint; divergence + beam
                    # diameter feed the exported §9.5 emission block.
                    **_source_view(component),
                    # WP-125: rectangular reflective aperture, for the
                    # assembly/schematic mirror glyph ([w, h] mm; None=round).
                    "mirror_rect_mm": _mirror_rect_mm(component),
                    # WP-193: the real per-element plates of a multi-mirror
                    # record — viewers draw these instead of a symbol. A
                    # DECOMPOSED module (WP-229 tail) has no component; its
                    # plates come from the subdesign's children instead.
                    "mirror_elements": (
                        _mirror_elements(component)
                        or _subdesign_mirror_elements(library, module, template)
                    ),
                    # WP-174: the surface stack, so a BOUND part's glyph draws
                    # the real element — radii, thickness, clear aperture,
                    # element count. The components section has carried this
                    # since WP-60 for unbound symbols; a module resolved only
                    # `efl_mm`, which is why every cube-mounted lens drew as
                    # the same blob. Same verbatim dicts (may carry .inf
                    # radii — dump_index_json handles that).
                    "fragment_surfaces": (
                        [dict(s) for s in component.optics.fragment.surfaces]
                        if component and component.optics.fragment
                        else []
                    ),
                    # WP-47: pixel facts for slm/display parts.
                    "programmable": (
                        component.programmable.model_dump(by_alias=True)
                        if component and component.programmable
                        else None
                    ),
                },
                "template": {
                    "ref": module.template,
                    "id": template.id if template else None,
                    "resolved": template.version if template else None,
                    "class": template.class_ if template else None,
                    # WP-230: actuatable iff the backing subdesign declares a
                    # firmware-actuated input.
                    "actuatable": any(
                        spec.get("actuation") == "firmware"
                        for spec in (design_view or {}).get("inputs", {}).values()
                    ),
                    # WP-45: carriers host cubes; bays are their docking regions.
                    # Mounts dock non-cube parts (housings that `fits` their key).
                    "carrier": bool(template.carrier) if template else False,
                    "bays": _bays_view(template),
                    "mounts": _mounts_view(template),
                    "fits": template.fits if template else "",
                },
                # WP-34: palette tiles + assembly renders straight off the index.
                "assets": _module_assets(
                    tpl, _thumbnail_rel(loaded, root), comp,
                    glb_override=_subdesign_objects_glb(library, module)),
                # WP-122: pins as MOUNTED (template optical_ports, posed
                # frames) — the record ports fold in the record frame, which
                # is not where the cube points them. A multi-optical-child
                # subdesign has no single child to borrow pins from, but its
                # TEMPLATE still states the boundary as-mounted (the binding
                # wrote optical_ports before the decompose) — serve those
                # rather than [] and a pinless part.
                # WP-251: a design-backed module's optic is its CHILD, posed —
                # the cubify road seats a lens along the beam in a subdesign
                # whose module shares the bare cube template, so the template
                # path would serve the record's own ±z and a glyph 90° off.
                "ports": (sub_optics["ports"] if sub_optics
                          else _as_mounted_ports(template, component)),
                # WP-180: the template's MOUNTED frame origins (cube frame),
                # name → [x, y, z] mm. The OPTIC of a module need not sit at
                # the module origin — a 1×2 focus stage holds its objective a
                # whole cell away — and the editors anchor the glyph AND the
                # fragment surfaces at `optical`, so pins, glass and symbol
                # agree. Empty = optic at the origin (every 1×1 cube).
                "frames": (
                    sub_optics["frames"] if sub_optics
                    else {
                        name: [float(f.x_mm), float(f.y_mm), float(f.z_mm)]
                        for name, f in template.frames.items()
                    }
                    if template is not None and template.frames
                    else {}
                ),
                # WP-124: WHICH frame those ports speak. 'mounted' = cube
                # frame F3, already in-plane — placement may only YAW the
                # cube (pins stay +z, the T-rule). 'record' = component F2
                # fallback — placement still tips the optics into the plane.
                "ports_frame": (
                    "mounted"
                    if sub_optics or (
                        template is not None
                        and getattr(template, "insert_pose", None) is not None
                        and template.optical_ports)
                    else "record"
                ),
                # WP-193: the binding's F2→F3 rotation, for carrying record-
                # frame geometry (mirror_elements) into the mounted frame.
                "insert_rot_xyzw": (sub_optics["rot_xyzw"] if sub_optics
                                    else _insert_rot_xyzw(template)),
                "electronics": module.electronics.model_dump(by_alias=True)
                if module.electronics
                else None,
            }
        )
    entries.sort(key=lambda e: e["id"])
    components = _component_entries(library)
    return {
        "schema": "optikit-library-index/v0",
        "count": len(entries),
        # Deliberately NO provenance and NO timestamp here. This dict becomes
        # the committed artifact (`library/dist/index.json`, the template's
        # `library-index.json`), and CI holds that artifact byte-reproducible
        # from the tree — so every field must be a function of the records
        # alone. Serve-time identity lives in `serving_provenance`, which the
        # service adds to its RESPONSE only.
        "modules": entries,
        "components": components,
        # WP-44: groups — placeable arrangements (the OPM). The palette
        # places their members as one rigid unit.
        "groups": _group_entries(library),
        # WP-67: bare housings (footprint_grid: null) — mechanics with no
        # cube. The frontend joins these onto the unbound component entries
        # by component id, so a housed part's mesh travels with it and the
        # three states (bare symbol / symbol+housing / cube module) are
        # distinguishable.
        "housings": _housing_entries(library),
        # WP-182: SETUPS — whole designs the library ships (`setups/*.dsn`).
        # The setup browser used to read a GitHub repo over the network,
        # which meant the library the service serves and the setups a user
        # could open were two different worlds. A setup is a design, and the
        # library is where designs live.
        "setups": _setup_entries(root),
    }


#: WP-182: where the library keeps whole designs.
SETUPS_DIR = "setups"

#: WP-185: the saved viewport screenshot beside a setup's design. Stored in
#: the setup's own `.dsn` directory so a setup stays one self-contained thing
#: to copy, zip or delete. Both extensions are read; the writer picks one from
#: the posted image's own media type.
SETUP_PREVIEWS = ("preview.jpg", "preview.png")


def setup_preview_path(setup_dir: Path) -> Path | None:
    """The preview image inside a setup directory, or None if it has none."""
    for name in SETUP_PREVIEWS:
        candidate = setup_dir / name
        if candidate.is_file():
            return candidate
    return None


def _setup_entries(root: Path) -> list[dict[str, Any]]:
    """Designs under ``<root>/setups/*.dsn`` — id, metadata, part count.

    Deliberately shallow: enough for a browser card, without parsing every
    design's optics. The design itself is fetched on open, through
    ``/v1/library/setups/<id>``.

    WP-185: a card also gets `thumbnail` — the screenshot taken of the live
    viewport when the setup was saved. A gallery that has one never has to
    load a design's meshes and render it just to show a picture of it.
    """
    from ..io.yamlio import DESIGN_DECL_FILE, load_document

    setups_dir = root / SETUPS_DIR
    if not setups_dir.is_dir():
        return []
    out: list[dict[str, Any]] = []
    for entry in sorted(setups_dir.iterdir()):
        decl_path = entry / DESIGN_DECL_FILE
        if not entry.is_dir() or not decl_path.is_file():
            continue
        try:
            data = load_document(decl_path) or {}
        except Exception:  # noqa: BLE001 — a broken setup must not blank the index
            continue
        design = data.get("design") or {}
        components = data.get("components") or {}
        # `foo.dsn` → `foo`: the id a URL and a card both use.
        setup_id = entry.name[:-4] if entry.name.endswith(".dsn") else entry.name
        preview = setup_preview_path(entry)
        out.append({
            "id": setup_id,
            "name": str(design.get("name") or setup_id),
            "description": str(design.get("description") or ""),
            "tags": list(design.get("tags") or []),
            "parts": len(components) if isinstance(components, dict) else 0,
            "paths": len(data.get("paths") or {}),
            "thumbnail": (
                f"/v1/library/setups/{setup_id}/preview" if preview else None
            ),
        })
    return out


def _housing_entries(library: Library) -> list[dict[str, Any]]:
    """Housing templates (WP-67): footprint_grid null, component ref carried
    on the template itself because no module exists to carry the pair."""
    out: list[dict[str, Any]] = []
    for loaded in library.by_kind("mechanical_template"):
        template = loaded.record
        assert isinstance(template, TemplateRecord)
        if template.footprint_grid is not None:
            continue
        comp = resolve(library, template.component) if template.component else None
        component = comp.record if comp else None
        assert component is None or isinstance(component, ComponentRecord)
        tpl_dir = loaded.path.parent.name
        glb = step = None
        if template.glb and (loaded.path.parent / template.glb).is_file():
            glb = _asset_url(f"templates/{tpl_dir}/{template.glb}")
        step_file = template.step or (
            template.glb.rsplit(".", 1)[0] + ".step" if template.glb else ""
        )
        if step_file and (loaded.path.parent / step_file).is_file():
            step = _asset_url(f"templates/{tpl_dir}/{step_file}")
        out.append(
            {
                "id": template.id,
                "version": template.version,
                "kind": "mechanical_template",
                "class": template.class_,
                "description": template.description,
                "review": bool(template.review or (component and component.review)),
                "locked": template.locked,
                "tags": template.tags,
                # A housing has no module to carry a kit price; its vendor price is the one.
                "price": component.vendor.price if component else None,
                "component": {
                    "ref": template.component or None,
                    "resolved": component.version if component else None,
                    "id": component.id if component else None,
                },
                # Same docking surface as a module's template block: a housing
                # may itself be a carrier (an illumination arm) or fill a mount.
                "carrier": template.carrier,
                "bays": _bays_view(template),
                "mounts": _mounts_view(template),
                "fits": template.fits,
                "assets": {
                    "thumbnail": _asset_url(
                        _thumbnail_rel(loaded, loaded.path.parents[2])
                    ),
                    # WP-137: housings render through the same content-basis
                    # rule as modules — this block used to drop the frame
                    # fields entirely, leaving the assembly to sniff.
                    "mesh_frame": template.mesh_frame,
                    "mesh_pose_grid": _pose_grid(template.mesh_pose),
                    "mesh_pose_offset_mm": _pose_offset_mm(template.mesh_pose),
                    "mesh_pose_offset_deg": _pose_offset_deg(template.mesh_pose),
                    "glb": glb,
                    "step": step,
                },
                # WP-156: pins as MOUNTED, exactly like modules (WP-122) — a
                # housed laser aligned to look +x used to serve its record
                # ports (+z) because this block never shipped the template's
                # as-mounted spelling, so the alignment was silently identity.
                "ports": _as_mounted_ports(template, component),
                "ports_frame": (
                    "mounted"
                    if getattr(template, "insert_pose", None) is not None
                    and template.optical_ports
                    else "record"
                ),
            }
        )
    out.sort(key=lambda e: e["id"])
    return out


def _group_entries(library: Library) -> list[dict[str, Any]]:
    """Cube groups for the palette (WP-44): members + structure, verbatim."""
    out: list[dict[str, Any]] = []
    for loaded in library.by_kind("cube_group"):
        group = loaded.record
        assert isinstance(group, GroupRecord)
        structure = group.structure
        out.append(
            {
                "id": group.id,
                "version": group.version,
                "kind": "cube_group",
                "description": group.description,
                "tags": group.tags,
                "review": bool(group.review),
                "locked": group.locked,
                "envelope_grid": list(group.envelope_grid),
                # The member a carrier bay puts on its optical axis (`interface.axis`).
                "axis_cell": (
                    list(group.members[axis.member].cell)
                    if (axis := group.interface.get("axis")) and axis.member in group.members
                    else None
                ),
                "members": [
                    {
                        "key": key,
                        "module": member.module_id,
                        "cell": list(member.cell),
                        "rotation": member.rotation.model_dump(exclude_defaults=True),
                        "overhang": member.overhang,
                    }
                    for key, member in group.members.items()
                ],
                "structure": {
                    "plates": {
                        face: {
                            "module": plate.module_id,
                            "origin": list(plate.origin),
                            "size": list(plate.size),
                        }
                        for face, plate in (structure.plates if structure else {}).items()
                    },
                    "joints": structure.joints if structure else "",
                    "joint_cells": [list(c) for c in structure.joint_cells]
                    if structure
                    else [],
                    "joint_module": "openuc2.cube.puzzle_1x1",
                },
                "interface": {
                    name: {"member": port.member, "port": port.port}
                    for name, port in group.interface.items()
                },
            }
        )
    out.sort(key=lambda e: e["id"])
    return out


def dump_index_json(index: dict[str, Any], **kwargs: Any) -> str:
    """Strict-JSON dump of a built index: ±inf → ±1e999 (JSON.parse overflows
    back to ±Infinity), NaN → null — the FiniteJSONResponse convention. Needed
    since WP-60: component fragment surfaces carry real radii, and a flat is
    ``.inf``."""
    text = json.dumps(index, allow_nan=True, **kwargs)
    return text.replace("Infinity", "1e999").replace("NaN", "null")


def write_index(library: Library, root: Path) -> Path:
    dist = root / "dist"
    dist.mkdir(parents=True, exist_ok=True)
    index = build_index(library, root)
    out = dist / "index.json"
    # newline pinned: a Windows build must produce the same bytes CI diffs.
    out.write_text(dump_index_json(index, indent=2) + "\n", encoding="utf-8", newline="\n")
    return out
