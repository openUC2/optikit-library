"""The actuation contract: template DOFs ↔ module firmware axis-map (WP-42).

A moving surface and the firmware that moves it are ONE named fact spread
across two records: the mechanical template declares the DOF (``kind:
rotation`` for a galvo mirror, ``translation`` for a motorized stage — with a
``pivot-frame`` and the fragment ``surface`` it drives), and the cube module's
``electronics.axis-map`` binds each actuatable DOF to its firmware object. The
name is the same everywhere — the DOF name IS the fx parameter name (WP-35) IS
the axis-map ``dof`` — so this check keeps the three in agreement:

- **E_AXIS_MAP_UNKNOWN_DOF** — an axis-map entry names a DOF the template does
  not declare (a dangling firmware binding);
- **W_ACTUATABLE_UNBOUND** — an ``actuatable`` DOF has no axis-map entry (the
  mechanism moves but nothing drives it — a motor/firmware gap, WP-26);
- **E_DOF_SURFACE_RANGE** — a DOF's ``surface`` index is out of the bound
  component's fragment;
- **W_DOF_PIVOT_UNKNOWN** — a DOF's ``pivot-frame`` names no component frame.
"""

from __future__ import annotations

from ..schema.library import ModuleRecord, TemplateRecord
from .build import Library, resolve


def _subdesign_input_names(library, ref: str) -> set[str]:
    """The input variables a subdesign-backed module exposes to firmware."""
    from ..io.yamlio import load_design
    from .subdesigns import SubdesignError, subdesign_dir

    try:
        _record, design_file = subdesign_dir(library, ref)
        return set(load_design(design_file.parent).inputs)
    except (SubdesignError, ValueError, KeyError, OSError):
        return set()  # a broken ref is check_references' finding, not ours


def check_actuation(library: Library) -> list[tuple[str, str, str]]:
    """Return ``(level, code, message)`` for every actuation-contract issue.

    ``level`` is ``"error"`` or ``"warning"``. Modules without electronics or
    template DOFs are silently fine.
    """
    findings: list[tuple[str, str, str]] = []
    for loaded in library.by_kind("cube_module"):
        module = loaded.record
        assert isinstance(module, ModuleRecord)
        tpl_hit = resolve(library, module.template)
        template = tpl_hit.record if tpl_hit else None
        if not isinstance(template, TemplateRecord):
            continue
        # WP-198: a subdesign-backed module has no component ref — its
        # optics live in the subdesign's children (checked there).
        # WP-202: what a firmware axis may bind depends on the module's shape.
        # A component-backed module drives its TEMPLATE's DOFs. A
        # subdesign-backed one drives the DESIGN's declared input variables —
        # that is the name the user turns (a slider, a CAN object), and the
        # subdesign binds it onward to whichever child DOFs it moves, which
        # may be several (decision D2). Binding the child DOF directly would
        # reach past the part's own interface.
        # WP-230: a module's actuatable motions are its subdesign's declared
        # INPUT variables — that is the name the user turns (a slider, a CAN
        # object), and the subdesign binds it onward to whichever children it
        # moves, which may be several (decision D2). There is no template
        # `dof:` to bind any more.
        input_names = (
            _subdesign_input_names(library, module.design) if module.design else set()
        )
        axis_map = module.electronics.axis_map if module.electronics else []

        for entry in axis_map:
            if entry.dof not in input_names:
                findings.append((
                    "error", "E_AXIS_MAP_UNKNOWN_DOF",
                    f"{module.id}: axis-map binds {entry.dof!r} but its design "
                    f"declares no such input"
                    + ("" if module.design else " (the module is not subdesign-backed)"),
                ))
    return findings
