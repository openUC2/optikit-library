"""Conic sag math shared by the pocket derivation and the T3 generators.

Deliberately stdlib-only: the generator scripts in ``generators/`` load this
module **by file path** (``importlib.util.spec_from_file_location``) because
the harness's fallback interpreter (``uv run --no-project --with cadquery``)
has no optikit_core package installed. Keep it free of package-relative
imports — anything pydantic- or record-shaped belongs in ``pocket.py``.
"""

from __future__ import annotations

import math
from typing import Any


def sag_at(
    radius_mm: float, conic: float, r_mm: float, coefficients: tuple[float, ...] = ()
) -> float:
    """Conic sag z(r) = c·r²/(1+√(1−(1+k)c²r²)) plus Optiland's even-asphere
    terms (``coefficients[i]``·r^(2i+2), r² first); 0 for plano; the conic is
    clamped at its geometric extent for steep surfaces (matches the
    frontend's sagAt)."""
    z = 0.0
    if radius_mm and not math.isinf(radius_mm):
        c = 1.0 / radius_mm
        term = 1.0 - (1.0 + conic) * c * c * r_mm * r_mm
        # Beyond the surface's geometric extent — clamp to the pole depth.
        z = radius_mm if term < 0.0 else (c * r_mm * r_mm) / (1.0 + math.sqrt(term))
    rr = r_mm * r_mm
    power = rr
    for a in coefficients:
        z += a * power
        power *= rr
    return z


def surface_radius(surface: dict[str, Any]) -> float:
    """Radius of a record surface dict; plano spellings (absent, ``.inf``) → inf."""
    geometry = surface.get("geometry") or {}
    radius = geometry.get("radius", math.inf)
    if radius is None or isinstance(radius, str):  # ".inf" spelling in records
        return math.inf
    return float(radius)


def surface_conic(surface: dict[str, Any]) -> float:
    """Conic constant of a record surface dict (0 when undeclared)."""
    return float((surface.get("geometry") or {}).get("conic") or 0.0)


def surface_coefficients(surface: dict[str, Any]) -> tuple[float, ...]:
    """Even-asphere terms of a record surface dict, Optiland's order (r² first)."""
    raw = (surface.get("geometry") or {}).get("coefficients") or ()
    return tuple(float(a) for a in raw)


def surface_sag(surface: dict[str, Any], r_mm: float) -> float:
    """Sag of a record surface dict at radial height ``r_mm``."""
    return sag_at(
        surface_radius(surface), surface_conic(surface), r_mm, surface_coefficients(surface)
    )
