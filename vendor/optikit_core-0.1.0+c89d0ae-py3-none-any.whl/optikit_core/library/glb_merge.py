"""WP-224: merge a glTF's primitives by material — the draw-call fix.

Measured across the two shipped libraries: **62,624 primitives in 47 GLBs**,
and every one is a draw call. `user.tpl.electronic_galvo` alone is 11,275
primitives against 20 materials, so the assembly view spends its frame
issuing eleven thousand calls to draw one cube. That is why it runs at 2–3
fps, and it is a CONVERTER artifact, not a renderer one: OCCT emits one glTF
primitive per B-rep face, and a machined bracket has thousands of faces.

The merge is the whole fix. Primitives inside ONE mesh share that mesh's node
transform, so concatenating those that also share a material, a mode and an
attribute set is exact — the same triangles, the same shading, one draw call
instead of hundreds. Nothing is merged ACROSS meshes: that would need each
node's transform baked in, which changes what the file means (and breaks the
per-part subtree names `kinematics` used to bind to).

What it does not do: reduce triangles. The mesh is the same size on disk plus
or minus the index widening; it is the per-primitive overhead that goes. Cap
the tessellation (`library retessellate`) for the triangle count.
"""

from __future__ import annotations

import base64
import json
import struct
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

#: glTF component types we can concatenate, and their struct codes.
_COMPONENT = {
    5120: ("b", 1),  # BYTE
    5121: ("B", 1),  # UNSIGNED_BYTE
    5122: ("h", 2),  # SHORT
    5123: ("H", 2),  # UNSIGNED_SHORT
    5125: ("I", 4),  # UNSIGNED_INT
    5126: ("f", 4),  # FLOAT
}
_COUNTS = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}

#: Only plain triangle soup is merged. A stripped/fanned primitive would need
#: re-indexing into triangles first, and none of our corpus uses them.
_TRIANGLES = 4


@dataclass
class MergeResult:
    """What a merge did, for the caller's report."""

    before: int
    after: int
    meshes: int

    @property
    def saved(self) -> int:
        return self.before - self.after


def _read_accessor(gltf: dict, binary: bytes, index: int) -> list[tuple]:
    """One accessor's elements as a list of tuples (no numpy dependency)."""
    acc = gltf["accessors"][index]
    code, size = _COMPONENT[acc["componentType"]]
    per = _COUNTS[acc["type"]]
    view = gltf["bufferViews"][acc["bufferView"]]
    base = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
    stride = view.get("byteStride") or per * size
    out: list[tuple] = []
    for i in range(acc["count"]):
        out.append(struct.unpack_from(f"<{per}{code}", binary, base + i * stride))
    return out


def _pad4(data: bytearray) -> None:
    while len(data) % 4:
        data.append(0)


def merge_by_material(gltf: dict, binary: bytes) -> tuple[dict, bytes, MergeResult]:
    """Concatenate each mesh's primitives that share material/mode/attributes.

    Returns the rewritten glTF, a fresh BIN chunk, and what changed. The
    result is a SELF-CONTAINED buffer: every accessor is rewritten, so the
    old buffer views (and any accessor nothing references any more) are
    dropped rather than carried along dead.
    """
    before = sum(len(m.get("primitives", [])) for m in gltf.get("meshes", []))
    out_bin = bytearray()
    new_views: list[dict] = []
    new_accessors: list[dict] = []

    def emit(values: list[tuple], component: int, kind: str,
             target: int | None, template: dict | None = None) -> int:
        """Write one accessor's worth of data, return its new index.

        ``template`` is the accessor the values came from: flags that change
        how the numbers are READ travel with them. `normalized: true`
        (KHR_mesh_quantization) is the one that bit — dropping it turns
        quantized shorts into raw millimetres and the part explodes to
        thousands of times its size.
        """
        code, size = _COMPONENT[component]
        per = _COUNTS[kind]
        _pad4(out_bin)
        offset = len(out_bin)
        for value in values:
            out_bin.extend(struct.pack(f"<{per}{code}", *value))
        view: dict[str, Any] = {
            "buffer": 0,
            "byteOffset": offset,
            "byteLength": len(out_bin) - offset,
        }
        if target is not None:
            view["target"] = target
        new_views.append(view)
        accessor: dict[str, Any] = {
            "bufferView": len(new_views) - 1,
            "componentType": component,
            "count": len(values),
            "type": kind,
        }
        # POSITION must carry min/max — the spec requires it, viewers cull
        # with it (half the point of merging), and our own bounding-box
        # reader needs it. Quantized positions are SHORT, not FLOAT, so
        # keying this on the component type dropped them and the mesh read
        # as "no positioned geometry".
        if kind == "VEC3" and values:
            cols = list(zip(*values, strict=True))
            accessor["min"] = [min(c) for c in cols]
            accessor["max"] = [max(c) for c in cols]
        if template is not None and template.get("normalized"):
            accessor["normalized"] = True
        new_accessors.append(accessor)
        return len(new_accessors) - 1

    merged_meshes: list[dict] = []
    for mesh in gltf.get("meshes", []):
        groups: dict[tuple, list[dict]] = defaultdict(list)
        order: list[tuple] = []
        for prim in mesh.get("primitives", []):
            key = (
                prim.get("material"),
                prim.get("mode", _TRIANGLES),
                tuple(sorted(prim.get("attributes", {}))),
            )
            if key not in groups:
                order.append(key)
            groups[key].append(prim)

        primitives: list[dict] = []
        for key in order:
            batch = groups[key]
            material, mode, attribute_names = key
            # Anything that is not indexed triangle soup is passed through
            # untouched: re-indexing a strip is a different job, and being
            # wrong here means silently corrupted geometry.
            if mode != _TRIANGLES or len(batch) == 1 or any(
                "indices" not in p for p in batch
            ):
                for prim in batch:
                    primitives.append(_carry(prim, gltf, binary, emit))
                continue

            attributes: dict[str, list[tuple]] = {n: [] for n in attribute_names}
            indices: list[tuple] = []
            base = 0
            for prim in batch:
                counts = set()
                for name in attribute_names:
                    values = _read_accessor(gltf, binary, prim["attributes"][name])
                    attributes[name].extend(values)
                    counts.add(len(values))
                # Each primitive's attributes must agree on a vertex count, or
                # the concatenation would silently shear them apart.
                if len(counts) != 1:
                    raise ValueError(
                        f"primitive attributes disagree on vertex count: {counts}"
                    )
                for (i,) in _read_accessor(gltf, binary, prim["indices"]):
                    indices.append((i + base,))
                base += counts.pop()

            merged: dict[str, Any] = {
                "attributes": {
                    name: emit(
                        values,
                        gltf["accessors"][batch[0]["attributes"][name]]["componentType"],
                        gltf["accessors"][batch[0]["attributes"][name]]["type"],
                        34962,  # ARRAY_BUFFER
                        gltf["accessors"][batch[0]["attributes"][name]],
                    )
                    for name, values in attributes.items()
                },
                # Widen to UNSIGNED_INT only when the merged run actually
                # exceeds what a short addresses. A silent wrap is scrambled
                # geometry; widening everything costs 2 bytes per index on
                # runs that never needed it (measured: +35% on the galvo).
                "indices": emit(
                    indices,
                    5125 if base > 0xFFFF else 5123,
                    "SCALAR",
                    34963,  # ELEMENT_ARRAY_BUFFER
                ),
                "mode": mode,
            }
            if material is not None:
                merged["material"] = material
            primitives.append(merged)

        merged_meshes.append({**mesh, "primitives": primitives})

    out = dict(gltf)
    out["meshes"] = merged_meshes
    out["bufferViews"] = new_views
    out["accessors"] = new_accessors
    out["buffers"] = [{"byteLength": len(out_bin)}]
    # Images/skins/animations would reference the accessors we just replaced.
    # None of our corpus has them; refuse rather than emit a broken file.
    for unsupported in ("skins", "animations"):
        if out.get(unsupported):
            raise ValueError(f"cannot merge a glTF with {unsupported}")
    if any(a.get("sparse") for a in gltf.get("accessors", [])):
        raise ValueError("cannot merge a glTF with sparse accessors")
    after = sum(len(m["primitives"]) for m in merged_meshes)
    return out, bytes(out_bin), MergeResult(before, after, len(merged_meshes))


def _carry(prim: dict, gltf: dict, binary: bytes, emit) -> dict:
    """Re-emit a primitive we did not merge, so it survives the rebuild."""
    out = dict(prim)
    out["attributes"] = {
        name: emit(
            _read_accessor(gltf, binary, index),
            gltf["accessors"][index]["componentType"],
            gltf["accessors"][index]["type"],
            34962,
            gltf["accessors"][index],
        )
        for name, index in prim.get("attributes", {}).items()
    }
    if "indices" in prim:
        values = _read_accessor(gltf, binary, prim["indices"])
        widest = max((v[0] for v in values), default=0)
        out["indices"] = emit(
            values, 5125 if widest > 0xFFFF else 5123, "SCALAR", 34963
        )
    return out


def _embedded_binary(gltf: dict, binary: bytes | None) -> bytes:
    """The BIN chunk, or a base64 data: buffer decoded (a .gltf sidecar)."""
    if binary is not None:
        return binary
    uri = (gltf.get("buffers") or [{}])[0].get("uri", "")
    if uri.startswith("data:"):
        return base64.b64decode(uri.split(",", 1)[1])
    raise ValueError("glTF has no embedded buffer to merge")


def _mesh_fingerprints(gltf: dict, binary: bytes) -> list[tuple]:
    """Per mesh: vertex count and the UNTRANSFORMED position extent.

    This is what a merge must not change. The node-transformed bounding box
    is NOT: it is built by rotating each primitive's axis-aligned box and
    re-axis-aligning the result, so its tightness depends on how many boxes
    there are. Merge 1,592 small boxes into 22 big ones under a 45 deg node
    rotation and the reported box legitimately grows ~21 mm while every
    vertex stays exactly where it was — which is precisely the false alarm
    that made this refuse a good merge, and then failed a STEP import.
    """
    out: list[tuple] = []
    for mesh in gltf.get("meshes", []):
        lo = [float("inf")] * 3
        hi = [float("-inf")] * 3
        count = 0
        for prim in mesh.get("primitives", []):
            index = prim.get("attributes", {}).get("POSITION")
            if index is None:
                continue
            for value in _read_accessor(gltf, binary, index):
                count += 1
                for axis in range(3):
                    lo[axis] = min(lo[axis], value[axis])
                    hi[axis] = max(hi[axis], value[axis])
        out.append((count, tuple(lo), tuple(hi)))
    return out


class MergeRefused(ValueError):
    """The merge would have changed geometry, so nothing was written."""


def merge_glb_file(path: Path, tolerance_mm: float = 1e-3) -> MergeResult:
    """Merge one .glb in place, atomically and self-verifying.

    The candidate is checked BEFORE it replaces the file: every mesh must
    keep its vertex count and its untransformed extent, or nothing is written
    and :class:`MergeRefused` is raised. Checking after writing cannot undo
    anything, which is how two shipped assets were once damaged.

    ``tolerance_mm`` is a thousandth of a millimetre — float32 coordinates
    round at ~1e-6 of magnitude, so a 300 mm part legitimately differs by
    ~1e-4 mm, while anything a person could see is orders larger.
    """
    from .mesh import _chunks

    gltf, binary = _chunks(path.read_bytes())
    source = _embedded_binary(gltf, binary)
    merged, out_bin, result = merge_by_material(gltf, source)

    before = _mesh_fingerprints(gltf, source)
    after = _mesh_fingerprints(merged, out_bin)
    if len(before) != len(after):
        raise MergeRefused(
            f"mesh count changed ({len(before)} -> {len(after)}) — file left unchanged"
        )
    for index, (was, now) in enumerate(zip(before, after, strict=True)):
        if was[0] != now[0]:
            raise MergeRefused(
                f"mesh[{index}] vertex count changed ({was[0]} -> {now[0]}) "
                "— file left unchanged"
            )
        moved = max(
            (abs(a - b) for a, b in zip(was[1] + was[2], now[1] + now[2], strict=True)),
            default=0.0,
        )
        if moved > tolerance_mm:
            raise MergeRefused(
                f"mesh[{index}] geometry moved {moved:.4g} mm — file left unchanged"
            )

    path.write_bytes(write_glb(merged, out_bin))
    return result


def write_glb(gltf: dict, binary: bytes) -> bytes:
    """Pack a glTF dict + BIN payload into a .glb container."""
    text = json.dumps(gltf, separators=(",", ":")).encode()
    text += b" " * (-len(text) % 4)
    payload = binary + b"\0" * (-len(binary) % 4)
    total = 12 + 8 + len(text) + 8 + len(payload)
    out = bytearray()
    out.extend(struct.pack("<4sII", b"glTF", 2, total))
    out.extend(struct.pack("<I4s", len(text), b"JSON"))
    out.extend(text)
    out.extend(struct.pack("<I4s", len(payload), b"BIN\0"))
    out.extend(payload)
    return bytes(out)
