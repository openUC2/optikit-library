"""WP-243/249/251: a generated holder becomes a published cube module — a subdesign.

The shape is Go's own `mounted-mirror.dsn`: one `static-models` child per
physical part, tagged by how you get it (`procurement/3d-print` for the
printed halves, `procurement/buy` for the molded master inserts and the cube
shell), plus the optic as a posed child carrying its record's optics
verbatim. The module points at the design (D2) and shares the cube's own
template for the shell.

Frames: the generator seats every part in the CUBE frame (z = pins; meshes
z-up, the way Ethan's ship), so the part children carry identity poses and no
`mesh-frame`. The optic's pose is derived from the SAME params the cavity was
cut with — `SEAT_GRID` mirrors `generators/lens_cartridge_v4.py`, pinned equal
by `test_cube_offset_follows_the_same_turn_as_the_meshes`.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from ..geometry.rotations import decompose, rot24_matrix
from ..schema.design import DesignDecl
from .glb_assemble import GlbPart, assemble_glb

_SLUG_RE = re.compile(r"^[a-z][a-z0-9_]*$")

#: Generator part name → (subdesign child id, how you get it).
_PARTS = {
    "front": ("cartridge-front", ["procurement/3d-print"]),
    "back": ("cartridge-back", ["procurement/3d-print"]),
    "master_notched": ("master-insert-notched", ["procurement/buy", "in/kit/qbox"]),
    "master_smooth": ("master-insert-smooth", ["procurement/buy", "in/kit/qbox"]),
}

#: Where a horizontal beam puts the generator's axes in the cube: the part
#: stands up (its y → cube +z, into the plate tracks) and yaws to the beam.
#: A vertical beam has no seat in a V4 cube — nothing holds an insert flat.
SEAT_GRID: dict[str, tuple[str, str]] = {
    "-y": ("-y", "+x"), "+x": ("+x", "+y"), "+y": ("+y", "-x"), "-x": ("-x", "-y"),
}

#: The shell's own notch tracks run along y. An x beam turns the shell a
#: quarter turn about the pins so the sandwich slides in along the beam.
_SHELL_GRID: dict[str, tuple[str, str] | None] = {
    "+y": None, "-y": None, "+x": ("+z", "+y"), "-x": ("+z", "+y"),
}
_SHELL_QUAT_XYZW = (0.0, 0.0, math.sqrt(0.5), math.sqrt(0.5))  # Rz(+90°)


class CubifyError(Exception):
    """A refusal, with the reason the caller shows verbatim."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass
class CubifyResult:
    design_id: str
    module_id: str
    design: dict[str, Any]  #: optikit-design.yml of the subdesign
    record: dict[str, Any]  #: subdesign.yml
    module: dict[str, Any]  #: module.yml of the NEW module
    #: mesh files to write beside the design, name → bytes
    files: dict[str, bytes] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)


def _model_name(artifact: str) -> str | None:
    """`model.front.glb` → `front`; the fused `model.glb` → None."""
    stem = artifact.rsplit(".", 1)[0]
    if stem == "model":
        return None
    return stem.removeprefix("model.")


def _seat_matrix(beam: str) -> np.ndarray:
    return rot24_matrix(*SEAT_GRID[beam])


def _cube_offset(params: dict[str, Any], beam: str) -> dict[str, float]:
    """The optic's `offset-mm` in CUBE axes from the generator's own frame.

    `part_position_mm` is where the cavity was cut, with z along the optical
    axis; the seat that turned the meshes into the cube frame turns this
    vector the same way, so the optic child lands in the cavity.
    """
    pos = params.get("part_position_mm") or {}
    vector = np.array([float(pos.get(axis) or 0.0) for axis in "xyz"])
    turned = _seat_matrix(beam) @ vector
    return {axis: round(float(v), 6) + 0.0 for axis, v in zip("xyz", turned, strict=True)
            if abs(v) > 1e-9}


def _optic_rotation(params: dict[str, Any], beam: str) -> dict[str, Any]:
    """The optic child's `rotation`: the seat composed with the cavity's tilt.

    The generator applies `part_rotation_deg` as successive turns about its
    fixed x, y, z axes (R = Rz·Ry·Rx); the record spells the product as the
    nearest grid seat plus the extrinsic-ZXY residual `offset-deg` (§4).
    """
    rot = params.get("part_rotation_deg") or {}
    rx, ry, rz = (math.radians(float(rot.get(axis) or 0.0)) for axis in "xyz")
    cx, sx, cy, sy, cz, sz = (math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry),
                              math.cos(rz), math.sin(rz))
    tilt = (np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
            @ np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
            @ np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]]))
    dec = decompose(_seat_matrix(beam) @ tilt)
    block: dict[str, Any] = {"kind": "grid", "grid": {"z": dec.z, "x": dec.x}}
    residual = {axis: round(float(v), 6) + 0.0 for axis, v in dec.offset_deg.items()
                if abs(v) > 1e-6}
    if residual:
        block["offset-deg"] = residual
    return block


def _static_child(models: dict[str, str], tags: list[str],
                  grid: tuple[str, str] | None = None) -> dict[str, Any]:
    rotation: dict[str, Any] = {"kind": "grid"}
    if grid is not None:
        rotation["grid"] = {"z": grid[0], "x": grid[1]}
    return {
        "kind": "primitive",
        "category": "mechanics",
        "primitive": {"static-models": models},
        "pose": {"rotation": rotation},
        "tags": tags,
    }


def cubify_generated(
    component: Any,
    *,
    slug: str,
    generator_script: str,
    params: dict[str, Any],
    artifacts: dict[str, bytes],
    shell_template: str,
    shell_mesh: tuple[str, bytes] | None = None,
    footprint_grid: tuple[int, int, int] = (1, 1, 1),
) -> CubifyResult:
    """Build the subdesign + module documents for a generated holder.

    ``artifacts`` are the harness's outputs keyed by file name; each
    `model.<part>.{glb,step}` becomes one child. ``shell_template`` is the
    cube's own template ref (the module shares it); ``shell_mesh`` is that
    template's GLB, copied in as a `cube-shell` child so the folder stands
    alone the way Go wants it. A merged `_objects.glb` rides along when the
    meshes parse.
    """
    if not _SLUG_RE.match(slug):
        raise CubifyError(
            "E_CUBIFY_SLUG",
            f"slug {slug!r} — lowercase letters, digits, _ only (it becomes "
            "record ids and directory names)",
        )
    if not generator_script:
        raise CubifyError(
            "E_CUBIFY_NO_GENERATOR",
            "no generator script — the design's provenance IS the generator "
            "plus its params; without it the parts cannot be regenerated",
        )

    # Per-part meshes only. The fused `model.*` is a convenience for a single
    # download; a design names its pieces.
    by_part: dict[str, dict[str, str]] = {}
    files: dict[str, bytes] = {}
    for name, blob in artifacts.items():
        if not name.endswith((".glb", ".step", ".stp")):
            continue
        part = _model_name(name)
        if part is None:
            continue
        fmt = "gltf" if name.endswith(".glb") else "step"
        by_part.setdefault(part, {})[fmt] = name
        files[name] = blob
    if not by_part:
        raise CubifyError(
            "E_CUBIFY_NO_MESH",
            "the generator produced no per-part STEP or GLB — a design with no "
            "geometry renders as a ghost cube and cannot be manufactured",
        )

    ns = str(component.id).split(".", 1)[0]
    design_id = f"{ns}.subdesign.{slug}"
    module_id = f"{ns}.cube.{slug}"
    notes: list[str] = []
    beam = str(params.get("beam_axis", "+x"))  # `beam` is the harness's bores key
    if beam not in SEAT_GRID:
        raise CubifyError(
            "E_CUBIFY_BEAM",
            f"beam_axis {beam!r}: the V4 cube holds an insert standing up, so the "
            "beam must be horizontal (±x or ±y)",
        )

    components: dict[str, Any] = {}

    # The optic: F2 verbatim, seated where the cavity was cut. The generator
    # got the SAME numbers (in its own frame); deriving the pose from them is
    # what keeps mesh and record from drifting.
    optics = component.optics.model_dump(
        by_alias=True, exclude_defaults=True, exclude_none=True)
    optics.pop("fragment-file", None)
    optic_id = str(component.id).rsplit(".", 1)[-1].replace("_", "-") or "optic"
    optic: dict[str, Any] = {
        "kind": "primitive",
        "category": str(getattr(component, "category", "") or ""),
        "optics": optics,
        "pose": {"rotation": _optic_rotation(params, beam)},
        "tags": ["procurement/buy"],
    }
    offset = _cube_offset(params, beam)
    if offset:
        optic["pose"]["translation"] = {"offset-mm": offset}
    components[optic_id] = optic

    # The parts, one child each — geometry already in the cube frame (the
    # generator seated it), so the pose is identity and the mesh IS the truth.
    merged: list[GlbPart] = []
    for part, formats in sorted(by_part.items()):
        child_id, tags = _PARTS.get(part, (part.replace("_", "-"), []))
        models = {k: formats[k] for k in ("gltf", "step") if k in formats}
        components[child_id] = _static_child(models, tags)
        if "gltf" in formats:
            merged.append(GlbPart(child_id, files[formats["gltf"]]))

    # The cube shell, so the folder stands alone (and the assembly, which
    # draws children INSTEAD of the module mesh once one has geometry, still
    # shows the cube). Ethan nests `cube-skeleton.dsn`; we have one mesh,
    # turned so its notch tracks run along the beam.
    if shell_mesh is not None:
        shell_name, shell_blob = shell_mesh
        files[shell_name] = shell_blob
        shell_grid = _SHELL_GRID[beam]
        components["cube-shell"] = _static_child(
            {"gltf": shell_name}, ["procurement/buy", "in/kit/qbox"], shell_grid)
        merged.append(GlbPart("cube-shell", shell_blob,
                              rotation_xyzw=_SHELL_QUAT_XYZW if shell_grid else None))
    else:
        notes.append("no cube shell mesh available — the module shares the "
                     f"template {shell_template} but the design folder does not "
                     "carry the cube")

    # One mesh of the whole assembly (Go's `_objects.glb`): what the palette
    # tile and the parts editor show — the children stay the truth.
    try:
        files["_objects.glb"] = assemble_glb(merged)
    except ValueError as exc:
        notes.append(f"no _objects.glb — {exc}")

    design = {
        "optikit-version": "v0.0.0-alpha.1",
        "design": {
            "name": slug.replace("_", "-"),
            "version": "0.1.0",
            "description": f"{component.id} in a generated holder, beam along {beam}",
            "tags": ["composition/cube-mounted"],
        },
        "components": components,
    }
    DesignDecl.model_validate(design)  # refuse before anything is written

    record = {
        "kind": "cube_subdesign",
        "id": design_id,
        "version": "0.1.0",
        "description": f"{component.id} held by a generated {generator_script}",
        # Provenance, not an optical side (D2 binds the MODULE): the source
        # component, for the editor joins that walk component.ref → module.
        "component": f"{component.id}@^"
                     + ".".join(str(component.version).split(".")[:2]),
        # The provenance the wizard exists to keep: re-running this script
        # with these params reproduces every mesh beside it.
        "generator": {"script": generator_script, "params": dict(params)},
        "tags": ["subdesign", "generated"],
        "review": [
            "generated by the cubify road — the meshes are the generator's "
            "output, not a measured export; check the fit before printing a "
            "batch",
        ],
    }

    module: dict[str, Any] = {
        "kind": "cube_module",
        "id": module_id,
        "version": "0.1.0",
        "description": f"{component.id} in a generated holder",
        "tags": ["generated"],
        "design": f"{design_id}@^0.1",
        "template": shell_template,  # the cube's own — shared, never copied
        "footprint_grid": list(footprint_grid),
    }

    return CubifyResult(design_id=design_id, module_id=module_id, design=design,
                        record=record, module=module, files=files, notes=notes)


def write_cubified(root: Path, result: CubifyResult) -> list[str]:
    """Write the subdesign folder (meshes beside it) + the module; library-relative paths."""
    from ..io.yamlio import dump_document

    sub_dir = root / "subdesigns" / result.design_id
    sub_dir.mkdir(parents=True, exist_ok=True)
    (sub_dir / "subdesign.yml").write_text(dump_document(result.record))
    (sub_dir / "optikit-design.yml").write_text(dump_document(result.design))
    rel = f"subdesigns/{result.design_id}"
    written = [f"{rel}/subdesign.yml", f"{rel}/optikit-design.yml"]
    for name, blob in sorted(result.files.items()):
        (sub_dir / name).write_bytes(blob)
        written.append(f"{rel}/{name}")

    mod_dir = root / "modules" / result.module_id
    mod_dir.mkdir(parents=True, exist_ok=True)
    (mod_dir / "module.yml").write_text(dump_document(result.module))
    written.append(f"modules/{result.module_id}/module.yml")
    return written
