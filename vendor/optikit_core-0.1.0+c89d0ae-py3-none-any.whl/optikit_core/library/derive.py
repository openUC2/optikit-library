"""Derive port beam directions from the surfaces (WP-40).

Surfaces + datum frames are the geometric truth; a port's authored
``direction`` is a *statement about* that truth. Where a record's fragment
and frame rotations allow it, this module computes what the direction MUST
be — the mirror's reflected arm via the reflection law, the refractive
chain's transmitted axis — and ``library validate`` warns when the authored
value disagrees by more than :data:`DIRECTION_TOL_DEG` (the same MATCH
philosophy as ``verify-t1``, applied to directions).

Nothing is derived when nothing is stated: a record without frame rotations
carries no continuous geometry, so the authored enum stands alone.
"""

from __future__ import annotations

import math

import numpy as np

from ..geometry.rotations import direction_vector
from ..schema.library import ComponentRecord

#: Authored-vs-derived disagreement beyond this is warned about (degrees).
DIRECTION_TOL_DEG = 2.0

#: Port names whose beam ENTERS the component (mirrors the frontend/chain).
_ENTRY_NAMES = ("front", "sensor", "in", "plane")


def _quat_matrix(q: list[float]) -> np.ndarray:
    """[x, y, z, w] quaternion → 3×3 rotation matrix."""
    x, y, z, w = (float(v) for v in q)
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def _is_reflective(surface: dict) -> bool:
    return bool((surface.get("interaction_model") or {}).get("is_reflective"))


def derive_port_directions(component: ComponentRecord) -> dict[str, np.ndarray]:
    """Beam directions the surfaces IMPLY, per exit port (unit vectors).

    Requires (a) a fragment and (b) a frame ROTATION on the port's frame —
    the marker-stated continuous geometry. Ports whose frame is axis-aligned
    (no rotation) derive nothing: the authored enum is the only statement.
    """
    optics = component.optics
    if optics.fragment is None or not optics.fragment.surfaces:
        return {}
    # WP-193: a MULTI-element record (two reflective surfaces — the dual
    # galvo) folds the beam in a CHAIN: each element's incoming beam is the
    # previous element's exit, which this single-bounce derivation cannot
    # express — it reflected every port off the original entry beam and
    # flagged correct galvo records as 90° off. The materializer's
    # fold-normal chain is the authority for those records.
    reflective = [
        s for s in optics.fragment.surfaces
        if isinstance(s, dict)
        and (s.get("interaction_model") or {}).get("is_reflective")
    ]
    if len(reflective) >= 2:
        return {}
    ports = optics.ports
    entry = next(
        (p for n, p in ports.items() if n in _ENTRY_NAMES),
        next(iter(ports.values()), None),
    )
    if entry is None:
        return {}
    entry_dir = direction_vector(entry.direction)
    if entry_dir is None:
        return {}
    beam = -entry_dir  # travel direction into the component

    derived: dict[str, np.ndarray] = {}
    for name, port in ports.items():
        if name in _ENTRY_NAMES:
            continue
        frame = optics.frames.get(port.frame)
        if frame is None or frame.rotation is None:
            continue  # axis-aligned frame: nothing stated beyond the enum
        rot = _quat_matrix(frame.rotation)
        surface_idx = port.after_surface if port.after_surface is not None else -1
        try:
            surface = optics.fragment.surfaces[surface_idx]
        except IndexError:
            continue
        if _is_reflective(surface):
            # Mirror: default normal opposes the beam (retro); the frame
            # rotation tilts it, the reflection law does the rest.
            normal = rot @ entry_dir
            derived[name] = beam - 2.0 * float(np.dot(beam, normal)) * normal
        else:
            # Refractive chain: transmitted axis = the frame-rotated beam.
            derived[name] = rot @ beam
    return derived


def check_port_directions(component: ComponentRecord) -> list[str]:
    """Warnings where the authored direction disagrees with the surfaces —
    plus the schema-v0.1 note for continuous vector directions (WP-39)."""
    warnings: list[str] = []
    for name, port in component.optics.ports.items():
        if isinstance(port.direction, list):
            warnings.append(
                f"port '{name}' uses a continuous direction vector — needs "
                "schema-v0.1 ratification (E2 ask #8)"
            )
    for name, implied in derive_port_directions(component).items():
        authored = direction_vector(component.optics.ports[name].direction)
        if authored is None:
            continue
        dot = float(np.clip(np.dot(authored, implied), -1.0, 1.0))
        deviation = math.degrees(math.acos(dot))
        if deviation > DIRECTION_TOL_DEG:
            ix, iy, iz = (round(float(v), 3) for v in implied)
            warnings.append(
                f"port '{name}': authored direction {component.optics.ports[name].direction!r} "
                f"is {deviation:.1f}° off what the surfaces imply "
                f"([{ix}, {iy}, {iz}]) — the fragment + frame rotation are the truth"
            )
    return warnings
