"""One-shot corpus migrations, runnable over any library or design tree.

Each migration is idempotent and comment-preserving (ruamel round trip), so
running the command twice is a no-op and a migrated file keeps its authoring
notes. `library migrate` runs them all in order; new migrations append here.

Migrations, oldest first:

- ``kind``: ``type:`` → ``kind:`` on the Go-modeled fields (openUC2/optikit#20
  @9eb701e). Renamed positions: ``components.<id>.type`` (also inside
  ``variants.<vid>.components``), ``components.<id>.primitive.type``, any
  ``rotation.type`` at any depth (pose, mounting, insert-pose, mesh-pose),
  design-level ``inputs.<name>.type``, and flat-report entries. NOT renamed:
  everything under ``optics``/``fragment``/``simulation``, plus ``source``,
  ``emission`` and ``fibers`` — those are ours (or Optiland's), not Go's.

- ``motion``: DELETE the WP-219/WP-230-retired motion keys — ``dof:`` on any
  component (design and variant overlays alike), ``dof:``/``kinematics:`` on a
  ``mechanical_template`` record, and ``instantiation.dof_values`` wherever it
  sits. The schema dropped every one of these fields, so they load as inert
  ``extra="allow"`` baggage: values that nothing reads and sliders that move
  nothing. The motion itself is re-authored as a design input read by a
  component pose (``library decompose`` for monolithic meshes;
  ``openuc2.subdesign.mounted_galvo`` is the worked example) — which is why
  this migration REPORTS every key it drops rather than pretending the file
  said nothing. ORDER MATTERS: the retired keys are exactly what ``library
  decompose`` consumes, so decompose a template you still want the motion of
  BEFORE migrating its tree (git has the keys afterwards, but the tool won't).

``archive/`` subtrees are never touched: a tombstone's whole value is that it
preserves the spelling of its era.
"""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

#: Subtrees whose ``type:`` belongs to us or Optiland and must NOT be renamed.
OPTICS_SUBTREES = frozenset(
    {"optics", "fragment", "simulation", "source", "emission", "fibers"}
)


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    y.width = 100000
    return y


def _rename_key(mapping: Any, key_from: str = "type", key_to: str = "kind") -> int:
    """Rename in place, keeping insertion order AND the key's own comments.

    ruamel attaches per-key comments to ``ca.items`` under the key NAME, so a
    naive rebuild silently drops the trailing comment on the very line being
    renamed — the one most likely to explain why the value is what it is.
    """
    if key_from not in mapping or key_to in mapping:
        return 0
    comments = getattr(mapping, "ca", None)
    token = comments.items.pop(key_from, None) if comments is not None else None
    items = [(key_to if k == key_from else k, v) for k, v in mapping.items()]
    mapping.clear()
    for k, v in items:
        mapping[k] = v
    if token is not None:
        comments.items[key_to] = token
    return 1


def _walk_kind(node: Any, path: tuple[str, ...]) -> int:
    renamed = 0
    if isinstance(node, dict):
        last = path[-1] if path else ""
        parent = path[-2] if len(path) > 1 else ""
        if last == "rotation":
            renamed += _rename_key(node)
        if parent == "components":
            renamed += _rename_key(node)
        if last == "primitive" and len(path) > 2 and path[-3] == "components":
            renamed += _rename_key(node)
        if parent == "inputs" and "instantiation" not in path:
            renamed += _rename_key(node)
        for key, value in list(node.items()):
            if key in OPTICS_SUBTREES:
                continue
            renamed += _walk_kind(value, (*path, str(key)))
    elif isinstance(node, list):
        for item in node:
            # Flat-report shape: a list of {id, kind, static-models, position}.
            if isinstance(item, dict) and "id" in item and "position" in item:
                renamed += _rename_key(item)
            renamed += _walk_kind(item, path)
    return renamed


def migrate_kind(path: Path) -> int:
    """Apply the ``type`` → ``kind`` rename to one YAML file; count renames."""
    yaml = _yaml()
    try:
        docs = [d for d in yaml.load_all(path.read_text()) if d is not None]
    except Exception:
        return 0  # not YAML we own — leave it alone
    renamed = sum(_walk_kind(doc, ()) for doc in docs)
    if renamed:
        with path.open("w") as fh:
            yaml.dump_all(docs, fh)
    return renamed


def _strip_motion(node: Any, path: tuple[str, ...]) -> int:
    """Delete retired motion keys in place; count deletions."""
    removed = 0
    if isinstance(node, dict):
        last = path[-1] if path else ""
        parent = path[-2] if len(path) > 1 else ""
        if parent == "components" and "dof" in node:
            del node["dof"]
            removed += 1
        if last == "instantiation" and "dof_values" in node:
            del node["dof_values"]
            removed += 1
        if not path and node.get("kind") == "mechanical_template":
            for key in ("dof", "kinematics"):
                if key in node:
                    del node[key]
                    removed += 1
        for key, value in list(node.items()):
            if key in OPTICS_SUBTREES:
                continue
            removed += _strip_motion(value, (*path, str(key)))
    elif isinstance(node, list):
        for item in node:
            removed += _strip_motion(item, path)
    return removed


def migrate_motion(path: Path) -> int:
    """Strip retired ``dof``/``kinematics``/``dof_values`` keys from one file."""
    yaml = _yaml()
    try:
        docs = [d for d in yaml.load_all(path.read_text()) if d is not None]
    except Exception:
        return 0  # not YAML we own — leave it alone
    removed = sum(_strip_motion(doc, ()) for doc in docs)
    if removed:
        with path.open("w") as fh:
            yaml.dump_all(docs, fh)
    return removed


class MigrateError(Exception):
    """A migration that refuses rather than guessing."""


def _module_variants(root: Path, module_id: str) -> set[str]:
    """The variant ids the design behind ``module_id`` declares (WP-246)."""
    from ..io.yamlio import load_document_text_fast

    # The record root is either the tree itself or its `library/` (WP-189 has
    # not picked one); a setup can sit a level above the records it places.
    module_file = root / "modules" / module_id / "module.yml"
    if not module_file.is_file():
        module_file = root / "library" / "modules" / module_id / "module.yml"
    if not module_file.is_file():
        return set()
    records = module_file.parents[2]
    module = load_document_text_fast(module_file.read_text(encoding="utf-8")) or {}
    design_id = str(module.get("design") or "").split("@")[0]
    if not design_id:
        return set()
    design_file = records / "subdesigns" / design_id / "optikit-design.yml"
    if not design_file.is_file():
        return set()
    design = load_document_text_fast(design_file.read_text(encoding="utf-8")) or {}
    return set(design.get("variants") or {})


def _fold_yaw(pose: Any, grid: dict) -> None:
    """Fold a pure-yaw mounting into the placement's own rotation, in place.

    A mounting that leaves +z alone turns the optic about the pin axis — which
    for a 1×1 cube is the same as turning the whole cube, and THAT is a pose
    the wire already has a word for. `R_pose · R_mount`, decomposed back to a
    grid (both are grid rotations, so it lands exactly).
    """
    from ..geometry.rotations import compose, decompose

    rot = pose.setdefault("rotation", {})
    have = rot.get("grid") or {}
    total = compose(str(have.get("z") or "+z"), str(have.get("x") or "+x")) @ compose(
        str(grid.get("z") or "+z"), str(grid.get("x") or "+x"))
    seated = decompose(total)
    rot["kind"] = "grid"
    folded = {}
    if seated.z != "+z":
        folded["z"] = seated.z
    if seated.x != "+x":
        folded["x"] = seated.x
    if folded:
        rot["grid"] = folded
    else:
        rot.pop("grid", None)


def _retire_mounting(node: Any, root: Path, path: tuple[str, ...]) -> int:
    """Rewrite each placement's ``mounting:`` as a variant selection; count them."""
    from .decompose import seat_id

    changed = 0
    if isinstance(node, dict):
        parent = path[-2] if len(path) > 1 else ""
        if parent == "components" and isinstance(node.get("mounting"), dict):
            grid = ((node["mounting"].get("rotation") or {}).get("grid") or {})
            module_id = str(
                ((node.get("primitive") or {}).get("static-models") or {})
                .get("gltf", "")).split("@")[0]
            if not grid:
                del node["mounting"]          # identity — it said nothing
                changed += 1
            elif str(grid.get("z") or "+z") == "+z":
                # Pure yaw about the pins: the cube itself turns (WP-246).
                _fold_yaw(node.setdefault("pose", {}), grid)
                del node["mounting"]
                changed += 1
            else:
                variant = seat_id((str(grid.get("z") or "+z"),
                                   str(grid.get("x") or "+x")))
                if variant not in _module_variants(root, module_id):
                    raise MigrateError(
                        f"{path[-1]}: mounting {dict(grid)} has no matching seat on "
                        f"{module_id or '<no module>'} — re-author the module with "
                        f"`library seats {module_id} --seat="
                        f"{grid.get('z') or '+z'}/{grid.get('x') or '+x'} --apply` "
                        "first (WP-246 refuses rather than guessing)")
                node.setdefault("instantiation", {})["variant"] = variant
                del node["mounting"]
                changed += 1
        for key, value in list(node.items()):
            changed += _retire_mounting(value, root, (*path, str(key)))
    elif isinstance(node, list):
        for item in node:
            changed += _retire_mounting(item, root, path)
    return changed


def migrate_mounting(path: Path, root: Path) -> int:
    """WP-246: `mounting:` → `instantiation.variant` (or a folded yaw)."""
    yaml = _yaml()
    try:
        docs = [d for d in yaml.load_all(path.read_text()) if d is not None]
    except Exception:
        return 0  # not YAML we own — leave it alone
    changed = sum(_retire_mounting(doc, root, ()) for doc in docs)
    if changed:
        with path.open("w") as fh:
            yaml.dump_all(docs, fh)
    return changed


#: name → (callable, one-line description), applied in order. Each callable
#: takes (path, library root) — the root is what a migration needs to resolve
#: a placement's module against the library it lives in.
MIGRATIONS: tuple[tuple[str, Any, str], ...] = (
    ("kind", lambda path, _root: migrate_kind(path),
     "type: → kind: (Go schema rename, openUC2/optikit#20)"),
    ("motion", lambda path, _root: migrate_motion(path),
     "drop retired dof:/kinematics:/dof_values (WP-219/WP-230 — motion is a "
     "design input a pose reads; re-author via `library decompose`)"),
    ("mounting", migrate_mounting,
     "mounting: → instantiation.variant (WP-246 — Go has no `mounting`, so "
     "every design carrying one rendered its optic un-rotated; re-author the "
     "module with `library seats` first)"),
)


def yaml_files(root: Path) -> Iterable[Path]:
    """Every YAML file under ``root``, excluding build output and tombstones."""
    for path in sorted([*root.rglob("*.yml"), *root.rglob("*.yaml")]):
        if "dist" in path.parts or "archive" in path.parts or path.name.startswith("."):
            continue
        yield path


def migrate_tree(root: Path) -> dict[str, dict[str, int]]:
    """Run every migration over ``root``; ``{migration: {file: renames}}``."""
    report: dict[str, dict[str, int]] = {}
    for name, run, _desc in MIGRATIONS:
        touched: dict[str, int] = {}
        for path in yaml_files(root):
            count = run(path, root)
            if count:
                touched[str(path.relative_to(root))] = count
        report[name] = touched
    return report
