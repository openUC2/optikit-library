"""Folded emission: a trace-derived sequence → a pose-true Optiland optic dict.

The successor of :mod:`.compiler`'s unfolding for real-ray consumers. Where
``compile_path`` PREDICTS the path from the chain declaration and forces it
onto a straight axis (folds neutralized, residuals squeezed into decenter/tilt,
curved folds unsupported), this stamps each surface the kernel actually TRACED
(:mod:`..canvas.sequence`) at its real world pose:

- each surface's ``cs`` is its absolute world position + orientation
  (``Surface.from_dict`` restores these verbatim — the dict format was always
  pose-true; the unfolded compiler merely chose one line);
- a hit whose action is ``reflect`` is emitted ``is_reflective``, so mirrors
  genuinely fold;
- a splitter's branch is baked per path: the same dichroic is reflective on the
  path that reflected and plain on the one that transmitted — the sequence IS
  the branch decision;
- reverse traversal needs no radius negation or material shifting: the entered
  medium comes from the kernel-reported index across each crossing.

No alignment tolerances, no fold idealizations. What cannot be expressed goes
in ``notes`` (the ``SeqSystem`` rule); geometry the sequence resolver already
rejected (rim strikes, unknown objects) never arrives here.

Scope (v0): consumers that trace explicit rays through ``surface_group``.
Paraxial machinery (pupil aiming, EFL) still assumes a straight axis.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..canvas.dialect import parse_fragment
from ..canvas.materialize import (
    DEFAULT_SEMI_APERTURE_MM,
    _fold_normals,
    _Placer,
    _port_pose,
)
from ..canvas.materials import is_ambient
from ..canvas.sequence import ResolvedHit, ResolvedSequence, SequenceUnavailable
from ..geometry.flatten import flatten
from ..schema.design import DesignDecl
from ..schema.merge import instantiate
from .compiler import (
    _AIR,
    _SUPPORTED_GEOMETRIES,
    CompileError,
    _default_fields,
    _normalize_material,
    _normalize_wavelengths,
    _radius_float,
)

#: Media within this of 1.0 read as ambient when choosing the entered glass.
_AMBIENT_TOL = 1e-6


@dataclass(frozen=True)
class FoldedManifestEntry:
    surface_index: int
    component_id: str
    fragment_surface_index: int | None
    action: str | None
    #: World pose of the surface: position (mm) + optiland euler (rad).
    world: dict[str, Any]

    def dump(self) -> dict[str, Any]:
        return {
            "surface_index": self.surface_index,
            "component_id": self.component_id,
            "fragment_surface_index": self.fragment_surface_index,
            "action": self.action,
            "world": self.world,
        }


@dataclass
class FoldedResult:
    optic: dict[str, Any]
    manifest: list[FoldedManifestEntry]
    path_name: str
    notes: list[str] = field(default_factory=list)


def emit_folded(decl: DesignDecl, seq: ResolvedSequence) -> FoldedResult:
    """Emit the pose-true Optiland optic dict for one resolved sequence.

    Poses are re-derived from the document (``instantiate`` + ``flatten``), not
    read from the prescription: a frozen sequence stays valid across DOF edits
    and re-emission simply restamps the new poses.
    """
    path = decl.paths.get(seq.path_name)
    if path is None:
        raise CompileError(
            "E_BAD_PATH", f"paths.{seq.path_name}",
            f"design declares no path {seq.path_name!r}",
        )
    # WP-230: instantiate FIRST — a pose leaf may be an expression over the
    # design's inputs, and flatten refuses unresolved ones (E_TEMPLATED).
    poses = flatten(instantiate(decl))
    dof_warnings: list[str] = []  # WP-230: motion is the pose
    notes = list(seq.notes) + [f"dof: {w}" for w in dof_warnings]

    frames = _SurfaceFrames(decl, poses)
    surfaces_out: list[dict[str, Any]] = []
    manifest: list[FoldedManifestEntry] = []

    # Object plane facing along the launch direction: at the launch point for
    # a finite object, at infinity behind it for a collimated source device
    # (`compile_path`'s rule, so the two compilers conjugate a design the same
    # way). The manifest keeps the emitter's real position either way.
    launch = np.asarray(seq.launch_point, dtype=float)
    launch_dir = np.asarray(seq.launch_dir, dtype=float)
    object_pos = launch
    if _object_at_infinity(decl, seq.source[0]):
        # Infinity goes in whichever axes the beam runs along, so the object
        # is behind the launch point however the source is posed. Written
        # component-wise because `inf * 0` is a nan, not the 0 it means here.
        object_pos = launch.copy()
        along = launch_dir != 0.0
        object_pos[along] = -math.inf * np.sign(launch_dir[along])
    surfaces_out.append({
        "type": "ObjectSurface",
        "geometry": {
            "type": "Plane",
            "cs": _cs_world(object_pos, _facing_rotation(launch_dir)),
            "radius": math.inf,
        },
        "material_post": dict(_AIR),
        "comment": f"object: {seq.source[0]}.{seq.source[1]}",
    })
    manifest.append(FoldedManifestEntry(
        0, seq.source[0], None, None,
        world=_world(launch, _facing_rotation(launch_dir))))

    stop_taken = False
    for hit in seq.hits:
        pos, rot = frames.frame_of(hit)
        raw = frames.raw_surface(hit)
        geometry = dict(raw.get("geometry") or {})
        gtype = geometry.get("type", "StandardGeometry")
        if gtype not in _SUPPORTED_GEOMETRIES:
            raise CompileError(
                "E_UNSUPPORTED", f"{hit.component} [{hit.fragment_index}]",
                f"geometry type {gtype!r} is not supported",
            )
        geometry.setdefault("type", "StandardGeometry")
        geometry["radius"] = _radius_float(
            geometry.get("radius", math.inf), f"{hit.component} [{hit.fragment_index}]")
        if geometry["type"] == "StandardGeometry":
            geometry.setdefault("conic", 0.0)
        geometry["cs"] = _cs_world(pos, rot)

        is_stop = bool(raw.get("is_stop", False)) and not stop_taken
        stop_taken = stop_taken or is_stop

        surfaces_out.append({
            "type": "Surface",
            "thickness": 0.0,
            "geometry": geometry,
            "material_post": _medium_after(frames, hit, notes),
            "is_stop": is_stop,
            "aperture": _clear_aperture(frames, hit, raw),
            "comment": raw.get("comment", "")
            or f"{hit.component} [{hit.fragment_index}] ({hit.action})",
            "interaction_model": _interaction(raw, hit, notes),
        })
        manifest.append(FoldedManifestEntry(
            len(surfaces_out) - 1, hit.component, hit.fragment_index,
            hit.action, world=_world(pos, rot)))

    # Image plane at the detector's sensor port, facing the arriving beam.
    det_comp, det_port = seq.detector
    det_pose = _port_pose(decl, poses, det_comp, det_port)
    if det_pose is not None:
        image_pos, det_facing = det_pose
        image_rot = _facing_rotation(-np.asarray(det_facing, dtype=float))
    else:
        image_pos = np.asarray(seq.terminal_point, dtype=float)
        prev = np.asarray(seq.hits[-1].point if seq.hits else seq.launch_point, dtype=float)
        image_rot = _facing_rotation(image_pos - prev)
        notes.append(
            f"detector port {det_comp}.{det_port} did not resolve; image plane "
            "placed at the traced terminal point")
    surfaces_out.append({
        "type": "Surface",
        "thickness": 0.0,
        "geometry": {
            "type": "Plane",
            "cs": _cs_world(np.asarray(image_pos, dtype=float), image_rot),
            "radius": math.inf,
        },
        "material_post": dict(_AIR),
        "is_stop": False,
        "aperture": None,
        "comment": f"image: {det_comp}.{det_port}",
        "interaction_model": {"type": "RefractiveReflectiveModel",
                              "is_reflective": False, "coating": None, "bsdf": None},
    })
    manifest.append(FoldedManifestEntry(
        len(surfaces_out) - 1, det_comp, None, None,
        world=_world(np.asarray(image_pos, dtype=float), image_rot)))

    real = [s for s in surfaces_out if s["type"] == "Surface"][:-1]  # not the image
    if real and not any(s.get("is_stop") for s in real):
        real[0]["is_stop"] = True

    simulation = path.simulation or {}
    optic = {
        "version": 1.0,
        "name": f"{decl.design.name or decl.design.path or 'design'}.{seq.path_name}.folded",
        "aperture": dict(simulation.get("aperture") or {"type": "EPD", "value": 10.0}),
        "fields": dict(simulation.get("fields") or _default_fields()),
        "wavelengths": _normalize_wavelengths(simulation.get("wavelengths")),
        "apodization": None,
        "pickups": [],
        "solves": {"solves": []},
        "surface_group": {"surfaces": surfaces_out},
    }
    return FoldedResult(optic=optic, manifest=manifest,
                        path_name=seq.path_name, notes=notes)


# --- per-component world frames -------------------------------------------------


class _SurfaceFrames:
    """World frames of fragment surfaces, lazily parsed per component.

    Shares the materializer's placement math (`_Placer`, `_fold_normals`), so
    the emitted optic and the traced scene agree by construction about where
    every surface sits.
    """

    def __init__(self, decl: DesignDecl, poses: dict[str, Any]) -> None:
        self._decl = decl
        self._poses = poses
        self._cache: dict[str, tuple[_Placer, dict[int, np.ndarray], list[dict], list]] = {}

    def _entry(self, comp_id: str) -> tuple[_Placer, dict[int, np.ndarray], list[dict], list]:
        cached = self._cache.get(comp_id)
        if cached is not None:
            return cached
        comp = self._decl.components.get(comp_id)
        if comp is None or comp.optics is None or comp.optics.fragment is None:
            raise CompileError(
                "E_SEQ_RESOLVE", comp_id,
                "sequence names a component with no optics fragment")
        where = f"components.{comp_id}.optics.fragment.surfaces"
        frag = parse_fragment(comp.optics.fragment.surfaces, where)
        if not frag.ok:
            raise CompileError(
                "E_SEQ_RESOLVE", comp_id,
                "sequence names a component whose fragment is outside dialect v0")
        placer = _Placer(self._poses[comp_id], comp.optics, frag.surfaces)
        # PR #20 fed `_fold_normals` per-surface tilts read off `comp.dof` +
        # `instantiation.dof_values`. WP-219/WP-230 removed both spellings, so
        # there is nothing left to read: a monolithic multi-mirror record holds
        # no motion until `library decompose` splits it into one component per
        # mirror, whose poses ARE the motion. `_fold_normals` keeps its
        # `surface_tilts` parameter for that migration.
        normals, _ = _fold_normals(placer, comp.optics, frag.surfaces, where)
        raw = [dict(s) for s in comp.optics.fragment.surfaces]
        entry = (placer, normals, raw, frag.surfaces)
        self._cache[comp_id] = entry
        return entry

    def frame_of(self, hit: ResolvedHit) -> tuple[np.ndarray, np.ndarray]:
        """(world position, world rotation) of the hit surface. The rotation's
        local ``+z`` is the surface axis: the record's optical axis for bodies
        and thin lenses, the port-derived fold bisector for mirrors."""
        placer, normals, _, _ = self._entry(hit.component)
        pos = np.asarray(placer.world_pos(placer.local_pos(hit.fragment_index)), dtype=float)
        if hit.kind == "mirror":
            local_n = normals.get(hit.fragment_index, np.array([0.0, 0.0, -1.0]))
            return pos, _facing_rotation(placer.world_normal(local_n))
        # The body axis is the PORT-declared beam axis (placer.A), not the
        # component's local +z. Composing R@A is what keeps the emitted optic
        # square with the traced scene for an as-mounted (non-+z) record.
        return pos, placer.R @ placer.A

    def raw_surface(self, hit: ResolvedHit) -> dict[str, Any]:
        _, _, raw, _ = self._entry(hit.component)
        return raw[hit.fragment_index]

    def clear_semi_aperture(self, hit: ResolvedHit) -> float:
        """Clear semi-aperture of the hit surface, as the materializer sized it.

        A glass span is one solid in the scene, so both of its caps carry the
        smallest semi-aperture the span authors, with the materializer's
        default standing in where the record is silent (`_lens_body`); a mirror
        or thin lens carries its own (`_mirror`). Re-deriving it here rather
        than reading it back keeps the emitter's existing contract of taking
        only `(decl, seq)`.

        One deliberate gap: this does not replay `_clamp_semi_aperture`, the
        cap-collision shrink `_lens_body` applies to steep records. That clamp
        can only reduce the radius, and it already warns as
        W_SEMI_APERTURE_CLAMPED when the scene is built.
        """
        _, _, _, dialect = self._entry(hit.component)
        span = (hit.fragment_index,)
        if hit.kind == "body":
            glass = self.glass_names(hit.component)
            i = hit.fragment_index
            if i < len(glass) and glass[i] is not None:
                span = (i, i + 1)  # front cap of the span
            elif i > 0 and glass[i - 1] is not None:
                span = (i - 1, i)  # back cap of the same span
        authored = [
            dialect[k].semi_aperture for k in span
            if k < len(dialect) and dialect[k].semi_aperture is not None
        ]
        return min([*authored, DEFAULT_SEMI_APERTURE_MM])

    def raw_surfaces(self, comp_id: str) -> list[dict[str, Any]]:
        _, _, raw, _ = self._entry(comp_id)
        return raw

    def glass_names(self, comp_id: str) -> list[str | None]:
        """Per-surface ``material_post`` glass names (None = ambient), from the
        parsed dialect — the same read the materializer bakes glass from."""
        _, _, _, dialect = self._entry(comp_id)
        return [s.material_post for s in dialect]


def _clear_aperture(frames: _SurfaceFrames, hit: ResolvedHit,
                    raw: dict[str, Any]) -> dict[str, Any] | None:
    """The surface's physical clear aperture, as an Optiland aperture dict.

    An authored Optiland ``aperture`` block wins verbatim. Otherwise the
    dialect's ``semi_aperture`` becomes a radial clip at the radius the
    materializer gave the same surface, so Optiland clips where the mesh the
    kernel traced clips. Emitting nothing here left consumers with no physical
    extent at all: layout views fall back to the traced beam footprint, and
    rays that miss the glass in the kernel keep going in Optiland.
    """
    authored = raw.get("aperture")
    if authored:
        return dict(authored)
    return {
        "type": "RadialAperture",
        "r_max": float(frames.clear_semi_aperture(hit)),
        "r_min": 0.0,
    }


def _object_at_infinity(decl: DesignDecl, comp_id: str) -> bool:
    """Whether the path's source collimates, putting its object conjugate at infinity.

    A record that declares an emission model is taken at its word: only
    ``collimated`` images from infinity. Otherwise this is ``compile_path``'s
    rule, so both compilers conjugate a design the same way — a source device
    with no optics fragment (a laser, a fiber collimator) emits a beam, while
    a ``type: location`` marker (the sample plane an objective images) is a
    finite object sitting where it says it sits.

    It matters beyond bookkeeping: the paraxial layer launches the marginal
    ray parallel to the axis for an infinite object and from an axial point
    for a finite one, and only the first is the beam the kernel traced.
    """
    comp = decl.components.get(comp_id)
    if comp is None:
        return False
    emission = comp.optics.emission if comp.optics is not None else None
    if emission is not None:
        return emission.angular.type == "collimated"
    has_fragment = bool(comp.optics is not None and comp.optics.fragment)
    return not has_fragment and comp.kind != "location"


# --- media + interaction selection ----------------------------------------------


def _medium_after(frames: _SurfaceFrames, hit: ResolvedHit, notes: list[str]) -> dict[str, Any]:
    """The medium the beam enters after this hit, as an Optiland material dict.

    The kernel already resolved media physically (containment + priority), so
    ``n_after`` is the arbiter: ambient → air; glass → the authored material of
    the adjacent span, direction-free. A hit exiting into glass on BOTH sides
    (a cemented interface crossed mid-sequence) picks the far span and says so.
    """
    if abs(hit.n_after - 1.0) <= _AMBIENT_TOL:
        return dict(_AIR)
    # Non-ambient after the crossing: entered glass, or (reflect/TIR) bounced
    # back into the glass the beam was already in.
    return _entered_glass(frames, hit, notes)


def _entered_glass(frames: _SurfaceFrames, hit: ResolvedHit, notes: list[str]) -> dict[str, Any]:
    raw = frames.raw_surfaces(hit.component)
    names = frames.glass_names(hit.component)
    f = hit.fragment_index
    # A glass span runs from surface i (whose material_post names the glass) to
    # i+1: crossing cap f forward enters span f, crossing it backward enters
    # span f-1. The dialect names decide which side actually holds glass.
    candidates = [
        (i, raw[i].get("material_post"))
        for i in (f, f - 1)
        if 0 <= i < len(names) and not is_ambient(names[i])
    ]
    if not candidates:
        notes.append(
            f"{hit.component} [{f}]: kernel reports n={hit.n_after:.4f} after the "
            "crossing but the fragment authors no adjacent glass; air emitted")
        return dict(_AIR)
    if len(candidates) == 2 and names[candidates[0][0]] != names[candidates[1][0]]:
        notes.append(
            f"{hit.component} [{f}]: glass on both sides (cemented interface); "
            "forward-span material emitted by authored order")
    index, chosen = candidates[0]
    return _normalize_material(chosen, hit.component, index)


#: Interaction classes the folded emitter recognizes (a subset of the
#: sequential compiler's table; the action decides reflectivity, not the
#: authored flag — that is the whole point of a per-path sequence).
_RR = {"type": "RefractiveReflectiveModel", "coating": None, "bsdf": None}


def _interaction(raw: dict[str, Any], hit: ResolvedHit, notes: list[str]) -> dict[str, Any]:
    if hit.action == "thin_lens":
        authored = raw.get("interaction_model") or {}
        f = authored.get("focal_length")
        if not isinstance(f, (int, float)) or isinstance(f, bool):
            raise CompileError(
                "E_INTERACTION", f"{hit.component} [{hit.fragment_index}]",
                f"thin-lens hit but the fragment authors no numeric focal_length "
                f"(got {f!r})")
        notes.append(
            f"{hit.component} [{hit.fragment_index}]: ThinLens emitted with the "
            "authored focal length; the folded-trace sign convention is "
            "validated only by explicit-ray tests")
        return {**authored, "type": "ThinLensInteractionModel",
                "focal_length": float(f), "is_reflective": False,
                "coating": authored.get("coating"), "bsdf": authored.get("bsdf")}
    return {**_RR, "is_reflective": hit.action in ("reflect", "tir")}


# --- rotation helpers ------------------------------------------------------------


def _facing_rotation(axis: np.ndarray) -> np.ndarray:
    """The minimal rotation taking local ``+z`` onto ``axis`` (Rodrigues)."""
    n = np.asarray(axis, dtype=float)
    norm = float(np.linalg.norm(n))
    if norm < 1e-12:
        return np.eye(3)
    n = n / norm
    ez = np.array([0.0, 0.0, 1.0])
    c = float(ez @ n)
    if c > 1.0 - 1e-15:
        return np.eye(3)
    if c < -1.0 + 1e-15:
        # 180°: any axis ⊥ z; pick x for determinism.
        return np.diag([1.0, -1.0, -1.0])
    k = np.cross(ez, n)
    s = float(np.linalg.norm(k))
    k = k / s
    kx = np.array([[0.0, -k[2], k[1]], [k[2], 0.0, -k[0]], [-k[1], k[0], 0.0]])
    return np.eye(3) + s * kx + (1.0 - c) * (kx @ kx)


def _euler_optiland(rot: np.ndarray) -> tuple[float, float, float]:
    """Decompose a world rotation as Optiland's ``R = Rz(rz)·Ry(ry)·Rx(rx)``
    (``CoordinateSystem.globalize`` applies rx, then ry, then rz)."""
    r20 = float(np.clip(rot[2, 0], -1.0, 1.0))
    ry = math.asin(-r20)
    if abs(r20) < 1.0 - 1e-12:
        rx = math.atan2(float(rot[2, 1]), float(rot[2, 2]))
        rz = math.atan2(float(rot[1, 0]), float(rot[0, 0]))
    else:
        # Gimbal lock (surface axis along ±world-x): fold everything into rz.
        rx = 0.0
        rz = math.atan2(-float(rot[0, 1]), float(rot[1, 1]))
    return rx, ry, rz


def _cs_world(pos: np.ndarray, rot: np.ndarray) -> dict[str, Any]:
    rx, ry, rz = _euler_optiland(rot)
    return {
        "x": float(pos[0]), "y": float(pos[1]), "z": float(pos[2]),
        "rx": float(rx), "ry": float(ry), "rz": float(rz),
        "reference_cs": None,
    }


def _world(pos: np.ndarray, rot: np.ndarray) -> dict[str, Any]:
    rx, ry, rz = _euler_optiland(rot)
    return {"pos": [float(v) for v in pos], "euler_xyz": [rx, ry, rz]}


__all__ = [
    "FoldedManifestEntry",
    "FoldedResult",
    "emit_folded",
    "SequenceUnavailable",
]
