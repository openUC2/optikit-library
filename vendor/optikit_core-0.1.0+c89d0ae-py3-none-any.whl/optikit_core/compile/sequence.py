"""WP-153 (B1): the sequential projection — one table row per surface.

The compiler already unfolds a path into the Optiland optic + a manifest
naming each surface's component; this joins the two into the row shape an
optical designer reads (# / component / type / radius / gap / material /
semi-aperture), plus the fact the editable phase needs: WHICH design input
moves a row (`driven_by`, off the same pose-expression recovery motion.py
serves). Read-only here — the write-back is the D1 channel and lives with
the editor.

Units: mm, unfolded axial coordinate (`z_mm` = the surface's cs.z along the
straightened path; a fold changes direction in world, not in z).
"""

from __future__ import annotations

import math
from typing import Any

from ..schema.common import is_expr
from ..schema.design import DesignDecl
from ..schema.motion import _leaf_gain, design_motion_axes
from .compiler import CompileResult, compile_path


def _radius(geometry: dict[str, Any]) -> float | None:
    r = geometry.get("radius")
    if r is None:
        return None
    r = float(r)
    return None if math.isinf(r) else r


def _material(surface: dict[str, Any]) -> str:
    mat = surface.get("material_post") or {}
    name = mat.get("name")
    if name:
        return str(name)
    index = mat.get("index")
    if index is None:
        return ""
    return "air" if abs(float(index) - 1.0) < 1e-9 else f"n={float(index):g}"


def _driven_map(decl: DesignDecl) -> dict[str, list[dict[str, Any]]]:
    """component id → the design inputs that move it.

    TWO channels, because a design says it two ways. A top-level component
    states motion in its POSE (`offset-mm.z: ~ … inputs['dz'] …`) — the
    golden design's objective, and Go's own idiom. A component the EDITOR
    placed states it on the D1 channel instead (`instantiation.inputs.<dof>`
    as an expression), which is where the linker and every subdesign-backed
    part put it. Reading only the first left every editor-authored row
    marked fixed.
    """
    driven: dict[str, list[dict[str, Any]]] = {}
    for axis in design_motion_axes(decl):
        driven.setdefault(axis.comp_id, []).append({
            "input": axis.input_name,
            "kind": axis.kind,
            "axis": axis.axis,
            "gain": axis.gain,
        })

    declared = dict(decl.inputs or {})
    for comp_id, comp in (decl.components or {}).items():
        for dof, value in (comp.instantiation.inputs or {}).items():
            if not is_expr(value):
                continue
            for name in declared:
                if f"'{name}'" not in value and f'"{name}"' not in value:
                    continue
                gain = _leaf_gain(value, name, declared)
                if gain is None or abs(gain) < 1e-12:
                    continue
                driven.setdefault(comp_id, []).append({
                    "input": name,
                    # The DOF's own kind is the record's, not the pose's; the
                    # table only needs to know WHICH input and how much.
                    "kind": "input",
                    "axis": dof,
                    "gain": gain,
                })
    return driven


def sequence_rows(decl: DesignDecl, result: CompileResult) -> list[dict[str, Any]]:
    """The table for one compiled path, in surface order."""
    driven = _driven_map(decl)

    surfaces = result.optic["surface_group"]["surfaces"]
    by_index = {e.surface_index: e for e in result.manifest}
    rows: list[dict[str, Any]] = []
    for i, surface in enumerate(surfaces):
        entry = by_index.get(i)
        cs = surface.get("geometry", {}).get("cs", {})
        z = float(cs.get("z", 0.0)) if cs else 0.0
        interaction = surface.get("interaction_model") or {}
        rows.append({
            "index": i,
            "component_id": entry.component_id if entry else "",
            "traversal": entry.port_traversal if entry else "",
            "fragment_surface": entry.fragment_surface_index if entry else None,
            "type": str(surface.get("type", "")),
            "reflective": bool(interaction.get("is_reflective")),
            "radius_mm": _radius(surface.get("geometry", {})),
            "conic": surface.get("geometry", {}).get("conic"),
            "z_mm": None if math.isinf(z) else z,
            "material": _material(surface),
            "semi_aperture_mm": surface.get("semi_aperture"),
            "is_stop": bool(surface.get("is_stop")),
            "comment": surface.get("comment", ""),
            # WP-153 editability groundwork: the design inputs whose pose
            # expressions move this surface's component. Empty = a T1 row.
            # An inlined subdesign child is named "<parent>/<child>"; the
            # parent is the component the design can actually move.
            "driven_by": _drivers_for(driven, entry.component_id) if entry else [],
        })

    # The gap is BETWEEN rows, but designers read it on the upstream row (the
    # Zemax convention): distance to the next surface along the unfolded axis.
    for row, nxt in zip(rows, rows[1:], strict=False):
        a, b = row["z_mm"], nxt["z_mm"]
        row["gap_after_mm"] = None if a is None or b is None else round(b - a, 6)
    if rows:
        rows[-1]["gap_after_mm"] = None
    return rows


def _drivers_for(
    driven: dict[str, list[dict[str, Any]]], comp_id: str
) -> list[dict[str, Any]]:
    if comp_id in driven:
        return driven[comp_id]
    parent = comp_id.split("/", 1)[0]
    return driven.get(parent, [])


def sequence_tables(
    decl: DesignDecl, path_name: str | None = None
) -> dict[str, dict[str, Any]]:
    """`{path: {rows, warnings}}` for one declared path or all of them."""
    names = [path_name] if path_name else list(decl.paths or {})
    out: dict[str, dict[str, Any]] = {}
    for name in names:
        result = compile_path(decl, name)
        out[name] = {
            "rows": sequence_rows(decl, result),
            "warnings": result.warnings,
        }
    return out
