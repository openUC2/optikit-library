"""Compile a design's optical path into a native Optiland optic dict + manifest.

The deterministic forward direction of the round trip (unification doc §6.1):
instantiate (variant overlay + DOF values) → flatten anchor chains to world
poses (WP-2) → walk ``paths.<name>.chain`` port by port, UNFOLDING the beam
into straight-line arc length (port-frame gaps become surface spacing, pose
residuals become per-surface ``cs`` decenter/tilt) → emit each ``optics
.fragment`` verbatim with the computed coordinate systems, bracketed by object
and image planes and prefixed with the path's ``simulation`` section.

Unfolding limitations (v0):

- Redirecting elements (mirrors, dichroic reflections) are folded out, emitted
  as NON-reflective planes on the straight axis. Flat folds are first-order
  neutral; a CURVED reflective surface in a folded path cannot be unfolded
  this way → ``E_UNSUPPORTED``. (:mod:`.folded` is the pose-true successor.)
- Reverse traversal (``back>front``, double-pass) re-emits the fragment with
  reversed surface order, negated radii and shifted media.
- The object plane sits at arc 0: at infinity for fragment-less PRIMITIVE
  first elements (collimated sources), at the first port for ``location``
  ones (e.g. a sample plane).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..geometry.flatten import FlatPose, flatten
from ..geometry.rotations import direction_vector
from ..schema.common import is_expr
from ..schema.design import (
    CompSpec,
    DesignDecl,
    FiberSpec,
    PortSpec,
    parse_chain_entry,
)
from ..schema.merge import instantiate

#: Hard geometric limits: beyond these, misalignment is a design error rather
#: than a residual to absorb into cs decenter/tilt.
ANGLE_TOL_DEG = 20.0
TRANSVERSE_TOL_MM = 25.0

_SUPPORTED_GEOMETRIES = {"StandardGeometry", "Plane", "EvenAsphere", ""}

_AIR = {
    "type": "IdealMaterial",
    "propagation_model": {"class": "HomogeneousPropagation"},
    "index": 1.0,
    "absorp": 0.0,
}


def _normalize_material(
    material: dict | None, comp_id: str, frag_index: int
) -> dict:
    """Materials must speak optiland's OWN registry dialect (WP-63).

    Optiland's material registry keys on class names (``Material``,
    ``IdealMaterial``, ``AbbeMaterial``, …), but the WP-43 CSV migration
    invented ``{type: "ideal", name: <glass>}`` — baked into 315 records and
    only detonating inside ``Optic.from_dict`` as an unreadable 500. The
    compiler is the safety net: legacy shapes are rewritten, registry-valid
    dicts pass untouched (zmx imports are already correct), and anything
    else is a typed E_MATERIAL naming the component + surface — never a
    downstream ValueError.
    """
    where = f"{comp_id} surface [{frag_index}]"
    if material is None:
        return dict(_AIR)
    if not isinstance(material, dict) or not isinstance(material.get("type"), str):
        raise CompileError(
            "E_MATERIAL", where, f"material_post is not a typed mapping: {material!r}"
        )
    if material["type"] != "ideal":
        return dict(material)  # registry vocabulary (Material, IdealMaterial, …)
    if material.get("name"):
        return {"type": "Material", "name": material["name"]}
    if isinstance(material.get("index"), int | float):
        return {"type": "IdealMaterial", "index": float(material["index"])}
    raise CompileError(
        "E_MATERIAL",
        where,
        "legacy {type: 'ideal'} material carries neither a glass name nor an "
        "index — nothing to normalize onto optiland's registry",
    )


#: Snake-case authoring names → optiland's interaction-model registry classes.
_INTERACTION_CLASSES = {
    "refractive_reflective": "RefractiveReflectiveModel",
    "refractivereflectivemodel": "RefractiveReflectiveModel",
    "thin_lens": "ThinLensInteractionModel",
    "thinlensinteractionmodel": "ThinLensInteractionModel",
    "diffractive": "DiffractiveInteractionModel",
    "diffractiveinteractionmodel": "DiffractiveInteractionModel",
}


def _normalize_interaction(surf: dict, comp_id: str, frag_index: int) -> dict:
    """An authored interaction model must SURVIVE compilation (WP-79).

    The compiler used to hardcode ``RefractiveReflectiveModel`` on every
    emitted surface, silently discarding an authored ``ThinLensInteractionModel``
    (a paraxial black-box objective) and any coating/BSDF. Now the authored
    model is carried through, its ``type`` normalized onto optiland's registry
    (like WP-63 does for materials), with a typed ``E_INTERACTION`` for an
    unrecognized model rather than a downstream ``Optic.from_dict`` crash.

    ``is_reflective`` stays False on the emitted surface: the compiler unfolds
    a flat fold onto the straight optical axis, so a reflective fold is emitted
    non-reflective (that behavior is unchanged).
    """
    authored = surf.get("interaction_model")
    if not authored:
        return {"type": "RefractiveReflectiveModel", "is_reflective": False,
                "coating": None, "bsdf": None}
    if not isinstance(authored, dict):
        raise CompileError(
            "E_INTERACTION", f"{comp_id} surface [{frag_index}]",
            f"interaction_model is not a mapping: {authored!r}",
        )
    raw_type = str(authored.get("type") or "refractive_reflective")
    cls = _INTERACTION_CLASSES.get(raw_type.lower())
    if cls is None:
        raise CompileError(
            "E_INTERACTION", f"{comp_id} surface [{frag_index}]",
            f"unknown interaction model {raw_type!r} — expected one of "
            f"{sorted(set(_INTERACTION_CLASSES.values()))}",
        )
    out = {**authored, "type": cls, "is_reflective": False}
    if cls == "ThinLensInteractionModel" and "focal_length" in out:
        # Sign compensation for optiland's direction-naive slope law. Compiled
        # systems trace with N < 0 forward (the harness's uniform exit-dir
        # negation relies on it), while ThinLensInteractionModel's
        # ``u' = u − h/f`` assumes N > 0 forward — fed our rays verbatim, a
        # converging lens diverges. Negating f restores the physical bend;
        # cross-checked at machine precision against the kernel's ThinLens
        # in the KIT-05 paraxial probe.
        out = {**out, "focal_length": -float(out["focal_length"])}
    out.setdefault("coating", None)
    out.setdefault("bsdf", None)
    return out


class CompileError(Exception):
    """Typed compile failure; ``code`` is stable API."""

    def __init__(self, code: str, where: str, message: str) -> None:
        super().__init__(f"{code} at {where}: {message}")
        self.code = code
        self.where = where


@dataclass
class ManifestEntry:
    surface_index: int
    component_id: str
    port_traversal: str
    fragment_surface_index: int | None
    #: Fold map: how this surface's unfolded cs coordinates map back to world.
    #: ``world = axis_point + cs_x·u + cs_y·v + (z − cs_z)·direction``.
    #: Absent for the object plane of an infinite-conjugate source.
    world: dict[str, Any] | None = None

    def dump(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "surface_index": self.surface_index,
            "component_id": self.component_id,
            "port_traversal": self.port_traversal,
            "fragment_surface_index": self.fragment_surface_index,
        }
        if self.world is not None:
            out["world"] = self.world
        return out


def _world_map(
    axis_point: np.ndarray, direction: np.ndarray, u: np.ndarray, v: np.ndarray, cs_z: float
) -> dict[str, Any]:
    return {
        "axis_point": [float(x) for x in axis_point],
        "direction": [float(x) for x in direction],
        "u": [float(x) for x in u],
        "v": [float(x) for x in v],
        "cs_z": float(cs_z),
    }


@dataclass
class CompileResult:
    optic: dict[str, Any]
    manifest: list[ManifestEntry]
    path_name: str
    warnings: list[str] = field(default_factory=list)


# --- world-frame helpers -------------------------------------------------------------


@dataclass
class PortFrame:
    """A port resolved into world coordinates."""

    comp_id: str
    port_name: str
    position: np.ndarray  # mm
    direction: np.ndarray  # unit vector, the direction the port *faces*

    def describe(self) -> str:
        p = ", ".join(f"{v:.3f}" for v in self.position)
        d = ", ".join(f"{v:.3f}" for v in self.direction)
        return f"{self.comp_id}.{self.port_name} @ ({p}) mm facing ({d})"


def _frame_offset_mm(comp: CompSpec, frame_name: str, where: str) -> np.ndarray:
    if not frame_name:
        return np.zeros(3)
    frames = comp.optics.frames if comp.optics else {}
    frame = frames.get(frame_name)
    if frame is None:
        raise CompileError("E_BAD_PORT", where, f"port references unknown frame {frame_name!r}")
    values = []
    for axis_value in (frame.x_mm, frame.y_mm, frame.z_mm):
        if is_expr(axis_value):
            raise CompileError("E_BAD_PORT", where, f"frame {frame_name!r} holds a template value")
        values.append(float(axis_value))
    return np.array(values)


def _frame_rotation(comp: CompSpec, frame_name: str, where: str) -> np.ndarray:
    """The frame's own 3×3 rotation, or identity when it is axis-aligned.

    A ``PLN`` datum marker that is not square to the component (a tilted pickoff,
    a wedged window) records its normal here; the port ``direction`` literal is
    then read in the frame's axes rather than the component's.
    """
    if not frame_name:
        return np.eye(3)
    frames = comp.optics.frames if comp.optics else {}
    frame = frames.get(frame_name)
    if frame is None or frame.rotation is None:
        return np.eye(3)
    x, y, z, w = (float(v) for v in frame.rotation)
    norm = math.sqrt(x * x + y * y + z * z + w * w)
    if norm == 0.0:
        raise CompileError("E_BAD_PORT", where, f"frame {frame_name!r} holds a zero quaternion")
    x, y, z, w = x / norm, y / norm, z / norm, w / norm
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def _port_frame(
    comp_id: str, comp: CompSpec, port_name: str, pose: FlatPose
) -> PortFrame:
    where = f"{comp_id}.{port_name}"
    ports = comp.optics.ports if comp.optics else {}
    port: PortSpec | None = ports.get(port_name)
    if port is None:
        raise CompileError("E_BAD_PORT", where, f"component declares no port {port_name!r}")
    # WP-39: axis literal or continuous [x, y, z] unit vector, one resolver.
    local_dir = direction_vector(port.direction)
    if local_dir is None:
        raise CompileError("E_BAD_PORT", where, f"invalid port direction {port.direction!r}")
    r = pose.rotation
    position = np.array(pose.position_mm) + r @ _frame_offset_mm(comp, port.frame, where)
    direction = r @ _frame_rotation(comp, port.frame, where) @ local_dir
    return PortFrame(comp_id, port_name, position, direction)


# --- fragment traversal ----------------------------------------------------------------

_INF_SPELLINGS = {".inf": math.inf, "+.inf": math.inf, "-.inf": -math.inf,
                  "inf": math.inf, "-inf": -math.inf}


def _radius_float(value: Any, where: str) -> float:
    """Radius as float. The WP-43 CSV importer quotes infinities
    (``radius: '.inf'``) and the canvas dialect accepts the YAML string
    spellings, so compile must too. Anything else non-numeric raises a typed
    E_GEOMETRY instead of a ``float()`` traceback through the service."""
    if isinstance(value, str):
        spelled = _INF_SPELLINGS.get(value.strip().lower())
        if spelled is not None:
            return spelled
    if isinstance(value, int | float) and not isinstance(value, bool):
        return float(value)
    raise CompileError("E_GEOMETRY", where, f"radius must be a number or .inf, got {value!r}")


def _traversal_surfaces(
    comp_id: str,
    comp: CompSpec,
    port_in: str,
    port_out: str | None,
    where: str,
) -> list[tuple[int, dict[str, Any]]]:
    """Fragment surfaces in traversal order as (fragment_index, surface_dict).

    Reverse traversal (entry port sits after the exit port) reverses the order,
    negates radii, and shifts ``material_post`` one surface back.
    """
    assert comp.optics is not None and comp.optics.fragment is not None
    surfaces = comp.optics.fragment.surfaces
    ports = comp.optics.ports

    def order_index(name: str) -> int:
        # A port without `after-surface` sits at the front vertex (before
        # fragment surface 0).
        port = ports.get(name)
        if port is None or port.after_surface is None:
            return -1
        return port.after_surface

    forward = port_out is None or order_index(port_out) >= order_index(port_in)

    indexed = list(enumerate(surfaces))
    if forward:
        return [(i, dict(s)) for i, s in indexed]

    reversed_out: list[tuple[int, dict[str, Any]]] = []
    n = len(surfaces)
    for k, (i, s) in enumerate(reversed(indexed)):
        surf = dict(s)
        geometry = dict(surf.get("geometry") or {})
        if "radius" in geometry:
            radius = _radius_float(geometry["radius"], where)
            geometry["radius"] = -radius if math.isfinite(radius) else radius
        surf["geometry"] = geometry
        # Media and spacing shift one step back in reverse: the glass (and the
        # gap) between forward surfaces j−1 and j is traversed after crossing
        # reversed surface j' = surfaces[n-1-k].
        j = n - 1 - k  # original index of this reversed surface
        prev_original = surfaces[j - 1] if j - 1 >= 0 else None
        surf["material_post"] = (
            dict(prev_original["material_post"])
            if prev_original and prev_original.get("material_post")
            else dict(_AIR)
        )
        surf["thickness"] = (prev_original or {}).get("thickness", 0.0)
        reversed_out.append((i, surf))
    return reversed_out


def _surface_thickness(surface: dict[str, Any], where: str) -> float:
    value = surface.get("thickness", 0.0)
    if is_expr(value):
        raise CompileError("E_UNSUPPORTED", where, "templated surface thickness")
    return float(value or 0.0)


# --- simulation-section defaults ----------------------------------------------------------


def _default_fields() -> dict[str, Any]:
    return {
        "fields": [{"x": 0.0, "y": 0.0, "vx": 0.0, "vy": 0.0, "weight": 1.0}],
        "telecentric": False,
        "field_definition": {"field_type": "AngleField"},
    }


def _normalize_wavelengths(section: dict[str, Any] | None) -> dict[str, Any]:
    data = dict(section or {})
    wavelengths = []
    for w in data.get("wavelengths") or [{"value": 0.532, "is_primary": True}]:
        entry = {"unit": "um", "weight": 1.0, "is_primary": False, **w}
        wavelengths.append(entry)
    if not any(w.get("is_primary") for w in wavelengths):
        wavelengths[0]["is_primary"] = True
    data["wavelengths"] = wavelengths
    data.setdefault("polarization", "ignore")
    return data


# --- the compiler -------------------------------------------------------------------------


def compile_path(decl: DesignDecl, path_name: str) -> CompileResult:  # noqa: C901
    """Compile one named path of an instantiated design (see module docstring)."""
    if path_name not in decl.paths:
        raise CompileError(
            "E_BAD_PATH", f"paths.{path_name}", f"design declares no path {path_name!r}"
        )
    path = decl.paths[path_name]
    if len(path.chain) < 2:
        raise CompileError(
            "E_BAD_PATH", f"paths.{path_name}", "a path needs at least two chain entries"
        )

    warnings: list[str] = []
    components = instantiate(decl)
    poses = flatten(components)
    # WP-230: motion is the pose (instantiate() already evaluated it).
    # WP-46: fiber links keyed by BOTH traversal orders — a fiber carries light
    # either way, and the chain decides which direction this path runs.
    fibers: dict[tuple[str, str], tuple[str, FiberSpec]] = {}
    for fiber_name, fiber in decl.fibers.items():
        if not fiber.from_port or not fiber.to_port:
            continue
        fibers[(fiber.from_port, fiber.to_port)] = (fiber_name, fiber)
        fibers[(fiber.to_port, fiber.from_port)] = (fiber_name, fiber)

    # Resolve every chain entry to (comp, ports, world frames).
    entries: list[dict[str, Any]] = []
    for raw in path.chain:
        try:
            comp_id, port_in, port_out = parse_chain_entry(raw)
        except ValueError as exc:
            raise CompileError("E_BAD_PORT", raw, str(exc)) from exc
        comp = components.get(comp_id)
        if comp is None:
            raise CompileError("E_BAD_PORT", raw, f"unknown component {comp_id!r}")
        pose = poses[comp_id]
        f_in = _port_frame(comp_id, comp, port_in, pose)
        f_out = _port_frame(comp_id, comp, port_out, pose) if port_out else f_in
        entries.append(
            {
                "raw": raw,
                "comp_id": comp_id,
                "comp": comp,
                "port_in": port_in,
                "port_out": port_out,
                "f_in": f_in,
                "f_out": f_out,
            }
        )

    # Middle elements must contribute surfaces or be explicit passthroughs.
    for entry in entries[1:-1]:
        comp: CompSpec = entry["comp"]
        has_fragment = bool(comp.optics and comp.optics.fragment)
        passthrough = bool(comp.optics and comp.optics.passthrough)
        if not has_fragment and not passthrough:
            raise CompileError(
                "E_NO_OPTICS",
                entry["raw"],
                "chain component has no optics.fragment (declare `optics.passthrough: true` "
                "if it deliberately contributes no surfaces)",
            )

    # Walk the chain, unfolding into arc length.
    surfaces_out: list[dict[str, Any]] = []
    manifest: list[ManifestEntry] = []
    angle_tol = math.radians(ANGLE_TOL_DEG)

    arc = 0.0
    prev_exit: PortFrame = entries[0]["f_out"]
    # Propagation direction leaving the first element = the direction its port faces.
    prev_dir = prev_exit.direction.copy()

    # Object plane at arc 0 (or infinity for collimated source devices).
    first_comp: CompSpec = entries[0]["comp"]
    first_has_fragment = bool(first_comp.optics and first_comp.optics.fragment)
    object_at_infinity = (not first_has_fragment) and first_comp.kind != "location"
    surfaces_out.append(
        {
            "type": "ObjectSurface",
            "geometry": {
                "type": "Plane",
                "cs": _cs(z=(-math.inf if object_at_infinity else 0.0)),
                "radius": math.inf,
            },
            "material_post": dict(_AIR),
            "comment": f"object: {entries[0]['raw']}",
        }
    )
    u0, v0 = _transverse_basis(prev_dir)
    # The world transverse frame is *transported* through folds, not recomputed
    # per surface. A mirror is unfolded onto a straight axis as a non-reflective
    # surface (Optiland's own frame runs straight through it), so the world refold
    # must carry the reflection the beam physically undergoes; otherwise a fresh
    # `_transverse_basis` for the post-fold direction is rotated differently than
    # the transported frame and swaps two transverse axes (a y/z swap for one 45°
    # fold). This is load-bearing for `_world_polylines` too.
    frame_u, frame_v, frame_dir = u0.copy(), v0.copy(), prev_dir.copy()
    manifest.append(
        ManifestEntry(
            0,
            entries[0]["comp_id"],
            entries[0]["raw"],
            None,
            world=None
            if object_at_infinity
            else _world_map(prev_exit.position, prev_dir, u0, v0, 0.0),
        )
    )

    def advance_to(target: PortFrame) -> tuple[float, np.ndarray, np.ndarray]:
        """Advance the unfolded axis to ``target``; returns (arc, lateral u/v)."""
        nonlocal arc, prev_exit, prev_dir
        seg = target.position - prev_exit.position
        length = float(np.linalg.norm(seg))
        if length < 1e-12:
            return arc, np.zeros(3), prev_dir
        s_hat = seg / length
        axial = float(seg @ prev_dir)
        if axial < -1e-9:
            raise CompileError(
                "E_GEOMETRY",
                target.comp_id,
                "next port lies behind the beam:\n"
                f"  from {prev_exit.describe()}\n  to   {target.describe()}",
            )
        kink = _angle_between(s_hat, prev_dir)
        if kink > angle_tol:
            raise CompileError(
                "E_GEOMETRY",
                target.comp_id,
                f"ports are not mutually facing (segment deviates {math.degrees(kink):.1f}° "
                f"from the beam):\n  from {prev_exit.describe()}\n  to   {target.describe()}",
            )
        facing = _angle_between(-target.direction, prev_dir)
        if facing > angle_tol:
            raise CompileError(
                "E_GEOMETRY",
                target.comp_id,
                f"entry port faces {math.degrees(facing):.1f}° away from the incoming beam:\n"
                f"  from {prev_exit.describe()}\n  to   {target.describe()}",
            )
        lateral_vec = seg - axial * prev_dir
        offset = float(np.linalg.norm(lateral_vec))
        if offset > TRANSVERSE_TOL_MM:
            # WP-142: say WHICH segment, HOW FAR off in document axes, and
            # what to move. The bare norm sent round 23 hunting a compiler
            # bug for a design whose camera simply sat a grid cell north of
            # the beam — the drift is per-hop and accumulates silently until
            # one segment trips the clamp.
            raise CompileError(
                "E_GEOMETRY",
                target.comp_id,
                f"the beam misses {target.comp_id}.{target.port_name} sideways by "
                f"{offset:.2f} mm (limit {TRANSVERSE_TOL_MM} mm).\n"
                f"  segment: {prev_exit.comp_id}.{prev_exit.port_name} → "
                f"{target.comp_id}.{target.port_name}\n"
                f"  off-axis by {_offset_words(lateral_vec)} in document axes\n"
                f"  move {target.comp_id} by {_offset_words(-lateral_vec)} — or move "
                f"{prev_exit.comp_id} the other way\n"
                f"  from {prev_exit.describe()}\n  to   {target.describe()}",
            )
        arc += axial
        return arc, lateral_vec, prev_dir

    def fiber_advance(
        target: PortFrame, fiber: FiberSpec, name: str
    ) -> tuple[float, np.ndarray, np.ndarray]:
        """Hop a fiber (WP-46): advance by the FIBER's length, not the gap.

        A fiber imposes no geometric constraint — the connectors may sit
        anywhere, at any angle — so none of ``advance_to``'s facing/kink/
        transverse checks apply. The unfolded axis simply grows by the fiber's
        own optical length and resumes along the far port's normal.
        """
        nonlocal arc, prev_exit, prev_dir
        arc += float(fiber.length_m) * 1000.0
        prev_exit = target
        # An entry port faces AGAINST the beam; the beam leaves along -normal.
        prev_dir = -target.direction.copy()
        warnings.append(
            f"fiber {name!r}: {fiber.type} hop of {fiber.length_m:g} m "
            f"(core {fiber.core_um or '?'} um, NA {fiber.na or '?'}) — the geometry "
            "between the connectors is not constrained"
        )
        return arc, np.zeros(3), prev_dir

    stop_taken = False  # one aperture stop per path; later is_stop flags demote
    for index, e in enumerate(entries[1:], start=1):
        comp = e["comp"]
        comp_id: str = e["comp_id"]
        is_last = e is entries[-1]
        prev = entries[index - 1]
        prev_ref = f"{prev['comp_id']}.{prev['port_out'] or prev['port_in']}"
        fiber_hit = fibers.get((prev_ref, f"{comp_id}.{e['port_in']}"))
        if fiber_hit is not None:
            entry_arc, lateral_vec, axis_dir = fiber_advance(
                e["f_in"], fiber_hit[1], fiber_hit[0]
            )
            # A fiber hop constrains no geometry; restart from the canonical
            # basis rather than pretending the direction change was a fold.
            frame_u, frame_v = _transverse_basis(axis_dir)
            frame_dir = axis_dir.copy()
        else:
            entry_arc, lateral_vec, axis_dir = advance_to(e["f_in"])
            # WP-144: transport the transverse frame across any fold the beam
            # just took. A mirror REFLECTS the frame (handedness flips), where
            # parallel transport would rotate it (handedness preserved) — the
            # two differ by a sign on the in-plane axis. The reflection is
            # right here because the fold is unfolded onto a straight axis and
            # optiland carries its own frame through the emitted non-reflective
            # surface unchanged, so the world map must apply it explicitly.
            # Pinned cross-engine by KIT-05.
            if not np.allclose(axis_dir, frame_dir):
                frame_u, frame_v = _reflect_transverse(frame_u, frame_v, frame_dir, axis_dir)
                frame_dir = axis_dir.copy()
        u, v = frame_u, frame_v
        cx, cy = float(lateral_vec @ u), float(lateral_vec @ v)
        # Small-angle tilt between the beam axis and the port normal.
        tilt = np.cross(axis_dir, -e["f_in"].direction)
        rx, ry = float(tilt @ u), float(tilt @ v)

        has_fragment = bool(comp.optics and comp.optics.fragment)
        if has_fragment:
            traversal = _traversal_surfaces(
                comp_id, comp, e["port_in"], e["port_out"], e["raw"]
            )
            local_z = 0.0
            for frag_index, surf in traversal:
                geometry = dict(surf.get("geometry") or {})
                gtype = geometry.get("type", "StandardGeometry")
                if gtype not in _SUPPORTED_GEOMETRIES:
                    raise CompileError(
                        "E_UNSUPPORTED", e["raw"], f"geometry type {gtype!r} is not supported"
                    )
                interaction = dict(surf.get("interaction_model") or {})
                reflective = bool(interaction.get("is_reflective")) or bool(
                    surf.get("is_reflective")
                )
                radius = _radius_float(geometry.get("radius", math.inf), e["raw"])
                if reflective and math.isfinite(radius):
                    raise CompileError(
                        "E_UNSUPPORTED",
                        e["raw"],
                        "curved reflective surfaces cannot be unfolded onto a straight "
                        "axis yet",
                    )
                if reflective:
                    warnings.append(
                        f"{e['raw']}: flat fold surface unfolded (emitted non-reflective)"
                    )

                geometry.setdefault("type", "StandardGeometry")
                geometry["radius"] = radius
                if geometry["type"] == "StandardGeometry":
                    geometry.setdefault("conic", 0.0)
                geometry["cs"] = _cs(x=cx, y=cy, z=entry_arc + local_z, rx=rx, ry=ry)

                # One aperture stop per compiled system. Records author is_stop
                # as their OWN stop, so a relay of stock doublets declares
                # several; the first along the path wins, the rest demote.
                is_stop = bool(surf.get("is_stop", False))
                if is_stop and stop_taken:
                    warnings.append(
                        f"{e['raw']} [{frag_index}]: is_stop demoted — the path already "
                        "carries its aperture stop"
                    )
                    is_stop = False
                stop_taken = stop_taken or is_stop

                out = {
                    "type": "Surface",
                    "thickness": 0.0,
                    "geometry": geometry,
                    "material_post": _normalize_material(
                        surf.get("material_post"), comp_id, frag_index
                    ),
                    "is_stop": is_stop,
                    "aperture": surf.get("aperture"),
                    "comment": surf.get("comment", "") or f"{comp_id} [{frag_index}]",
                    "interaction_model": _normalize_interaction(surf, comp_id, frag_index),
                }
                surfaces_out.append(out)
                axis_point = e["f_in"].position - lateral_vec + local_z * axis_dir
                manifest.append(
                    ManifestEntry(
                        len(surfaces_out) - 1,
                        comp_id,
                        e["raw"],
                        frag_index,
                        world=_world_map(axis_point, axis_dir, u, v, entry_arc + local_z),
                    )
                )
                local_z += _surface_thickness(surf, e["raw"])
            arc = entry_arc + max(local_z - _surface_thickness(traversal[-1][1], e["raw"]), 0.0)
        elif is_last:
            surfaces_out.append(
                {
                    "type": "Surface",
                    "thickness": 0.0,
                    "geometry": {
                        "type": "Plane",
                        "cs": _cs(x=cx, y=cy, z=entry_arc, rx=rx, ry=ry),
                        "radius": math.inf,
                    },
                    "material_post": dict(_AIR),
                    "is_stop": False,
                    "aperture": None,
                    "comment": f"image: {e['raw']}",
                    "interaction_model": {
                        "type": "RefractiveReflectiveModel",
                        "is_reflective": False,
                        "coating": None,
                        "bsdf": None,
                    },
                }
            )
            manifest.append(
                ManifestEntry(
                    len(surfaces_out) - 1,
                    comp_id,
                    e["raw"],
                    None,
                    world=_world_map(
                        e["f_in"].position - lateral_vec, axis_dir, u, v, entry_arc
                    ),
                )
            )

        prev_exit = e["f_out"]
        prev_dir = e["f_out"].direction.copy() if not is_last else prev_dir

    # Exactly one stop: default to the first real surface if none declared.
    real = [s for s in surfaces_out if s["type"] == "Surface"]
    if real and not any(s.get("is_stop") for s in real):
        real[0]["is_stop"] = True

    simulation = path.simulation or {}
    optic = {
        "version": 1.0,
        "name": f"{decl.design.name or decl.design.path or 'design'}.{path_name}",
        "aperture": dict(
            simulation.get("aperture") or _source_aperture(entries[0]["comp"])
        ),
        "fields": dict(simulation.get("fields") or _default_fields()),
        "wavelengths": _normalize_wavelengths(simulation.get("wavelengths")),
        "apodization": None,
        "pickups": [],
        "solves": {"solves": []},
        "surface_group": {"surfaces": surfaces_out},
    }
    return CompileResult(optic=optic, manifest=manifest, path_name=path_name, warnings=warnings)


#: Entrance pupil for a path whose source declares no beam width. Only ever
#: reached when the chain does not start at a source record.
DEFAULT_EPD_MM = 10.0


def _source_aperture(first: CompSpec) -> dict[str, Any]:
    """The entrance pupil, from the SOURCE record that starts the path.

    WP-145: this was a hardcoded 10 mm EPD, so a 2 mm laser was drawn 2 mm
    wide on the canvas and traced 10 mm wide by optiland — the same record,
    two different beams. The record's `source.beam_diameter_mm` is the one
    field that means "how wide is the beam leaving this device"; an explicit
    `simulation.aperture` on the path still wins over it.
    """
    source = first.source or (getattr(first.optics, "source", None) if first.optics else None)
    diameter = getattr(source, "beam_diameter_mm", None) if source else None
    value = float(diameter) if diameter else DEFAULT_EPD_MM
    return {"type": "EPD", "value": value}


def _cs(
    x: float = 0.0, y: float = 0.0, z: float = 0.0, rx: float = 0.0, ry: float = 0.0
) -> dict[str, Any]:
    return {
        "x": float(x),
        "y": float(y),
        "z": float(z),
        "rx": float(rx),
        "ry": float(ry),
        "rz": 0.0,
        "reference_cs": None,
    }


def _angle_between(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(np.linalg.norm(a) * np.linalg.norm(b))
    if denom < 1e-12:
        return 0.0
    return math.acos(float(np.clip((a @ b) / denom, -1.0, 1.0)))


def _reflect_transverse(
    u: np.ndarray, v: np.ndarray, d_from: np.ndarray, d_to: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Reflect a transverse frame across the fold plane that bends ``d_from`` into
    ``d_to``. The mirror reflects the beam and its transverse frame; since the
    fold is unfolded onto a straight axis (Optiland carries its own frame through
    unchanged), the world frame must apply that reflection explicitly. The plane
    normal is ``d_from - d_to`` (its reflection maps ``d_from`` onto ``d_to``),
    which is the physical mirror plane."""
    m = d_from - d_to
    norm = float(np.linalg.norm(m))
    if norm < 1e-12:
        return u, v
    m = m / norm
    return u - 2.0 * float(u @ m) * m, v - 2.0 * float(v @ m) * m


def _offset_words(vec: np.ndarray) -> str:
    """'x −0.00 mm, y +37.27 mm' — only the axes that actually contribute."""
    parts = [
        f"{axis} {value:+.2f} mm"
        for axis, value in zip("xyz", (float(v) for v in vec), strict=True)
        if abs(value) > 1e-6
    ]
    return ", ".join(parts) if parts else "nothing (the ports are coaxial)"


def _transverse_basis(s_hat: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Stable (u, v) ⊥ ŝ: cs.x along u, cs.y along v.

    Only used to SEED a frame where none is carried (the restart after a
    fiber hop) — folded hops reflect the running frame across the fold plane
    instead (see ``_reflect_transverse``); re-deriving from a world axis
    would roll the frame at every fold.
    """
    candidate = np.array([1.0, 0.0, 0.0])
    if abs(float(candidate @ s_hat)) > 0.9:
        candidate = np.array([0.0, 1.0, 0.0])
    u = candidate - float(candidate @ s_hat) * s_hat
    u /= np.linalg.norm(u)
    v = np.cross(s_hat, u)
    return u, v


def _transport_basis(
    u: np.ndarray, s_prev: np.ndarray, s_next: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Parallel-transport (u, v) from one beam direction to the next.

    NOT CALLED by the emission loop since the canvas merge — ``_reflect_
    transverse`` does the fold there, because a mirror reflects the frame
    rather than rotating it. Kept, with ``tests/test_transverse_transport.py``,
    because WP-144 part 2 (folds as REFLECTIVE surfaces with real ``cs``
    rotations, where optiland transports its own frame) needs exactly this. Do
    not read the passing tests as evidence that the fold path uses it.

    WP-144: the basis was re-derived per hop from a fixed world axis, so it
    ROLLED at every fold — measured at 90°. Since the manifest maps ``cs.x``/
    ``cs.y`` back into world coordinates for the ray overlay, a ray 5 mm above
    the axis IN the plane of incidence was drawn 5 mm OUT of it, which a flat
    mirror cannot do. Rotating the old basis by the minimal rotation carrying
    ŝ_prev onto ŝ_next keeps "up" meaning the same thing along the chain.
    """
    axis = np.cross(s_prev, s_next)
    sin_a = float(np.linalg.norm(axis))
    cos_a = float(np.clip(s_prev @ s_next, -1.0, 1.0))
    if sin_a < 1e-12:
        # Parallel (no fold) or antiparallel (a retro, where the roll is
        # genuinely undefined) — keep the basis we have, orthonormalized.
        u_next = u - float(u @ s_next) * s_next
        norm = float(np.linalg.norm(u_next))
        if norm < 1e-12:
            return _transverse_basis(s_next)
        u_next /= norm
        return u_next, np.cross(s_next, u_next)
    axis = axis / sin_a
    angle = math.atan2(sin_a, cos_a)
    # Rodrigues, applied to u.
    u_next = (
        u * math.cos(angle)
        + np.cross(axis, u) * math.sin(angle)
        + axis * float(axis @ u) * (1.0 - math.cos(angle))
    )
    u_next -= float(u_next @ s_next) * s_next
    u_next /= float(np.linalg.norm(u_next))
    return u_next, np.cross(s_next, u_next)
