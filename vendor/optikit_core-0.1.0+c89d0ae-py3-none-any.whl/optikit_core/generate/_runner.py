"""Headless generator runner — executed inside the CadQuery environment.

Deliberately dependency-free apart from cadquery itself (stdlib + cadquery),
because the harness may run it as a standalone script in a *separate*
interpreter (``uv run --no-project --with cadquery``) when cadquery has no
wheel for the interpreter optikit-core runs on.

Usage (as a script):

    python _runner.py <generator.py> <params.json> <out-dir>

Writes into ``<out-dir>``: ``model.step``, ``model.stl``, ``model.glb``,
``meta.json`` (bounding box + envelope verdict). The exit code is non-zero on
any failure, with the error on stderr.
"""

from __future__ import annotations

import importlib.util
import json
import math
import struct
import sys
from pathlib import Path

#: The UC2 1x1 cube envelope every generated insert must fit (mm).
ENVELOPE_MM = (50.0, 50.0, 50.0)

STL_LINEAR_TOL = 0.05
STL_ANGULAR_TOL_DEG = 5.0


def _load_module(generator_path: Path):  # noqa: ANN202
    spec = importlib.util.spec_from_file_location(generator_path.stem, generator_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load generator module {generator_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Either single-part `build` or multi-part `build_parts` satisfies the
    # contract — run() prefers the latter. Demanding `build` alone rejected
    # a parts-only generator (the cartridge pair) at load time.
    if not (callable(getattr(module, "build", None))
            or callable(getattr(module, "build_parts", None))):
        raise RuntimeError(
            f"{generator_path.name} exposes neither build(params) nor "
            "build_parts(params)"
        )
    return module


def _bbox_of(part) -> dict:  # noqa: ANN001
    bb = part.val().BoundingBox()
    return {
        "min": [bb.xmin, bb.ymin, bb.zmin],
        "max": [bb.xmax, bb.ymax, bb.zmax],
        "size": [bb.xmax - bb.xmin, bb.ymax - bb.ymin, bb.zmax - bb.zmin],
    }


def _export_part(part, out_dir: Path, basename: str, label: str) -> None:  # noqa: ANN001
    import cadquery as cq

    cq.exporters.export(part, str(out_dir / f"{basename}.step"))
    cq.exporters.export(
        part,
        str(out_dir / f"{basename}.stl"),
        tolerance=STL_LINEAR_TOL,
        angularTolerance=math.radians(STL_ANGULAR_TOL_DEG),
    )
    assembly = cq.Assembly(part, name=label)
    exporter = getattr(assembly, "export", None) or assembly.save  # save: cq<=2.8
    exporter(str(out_dir / f"{basename}.glb"))
    _normalize_glb(out_dir / f"{basename}.glb")


def _is_quarter_turn_about_x(q: list) -> bool:
    x, y, z, w = (float(v) for v in q)
    h = math.sqrt(0.5)
    return abs(abs(x) - h) < 1e-3 and abs(abs(w) - h) < 1e-3 and abs(y) < 1e-3 and abs(z) < 1e-3


def _normalize_glb(path: Path) -> None:
    """Rewrite an OCC glTF export into the document frame: z-up, millimetres.

    OCC's writer turns its z-up shape into glTF y-up by hanging the geometry
    under a node rotated −90° about x. The `static-models` files Go ships
    (Ethan's cube half) carry no such wrapper — their vertices ARE the design
    frame — so the wrapper comes off and the unit is stamped; the triangle
    data is untouched. Stdlib only: this file runs standalone.
    """
    data = path.read_bytes()
    if len(data) < 12 or data[:4] != b"glTF":
        return
    total = struct.unpack_from("<I", data, 8)[0]
    offset, gltf, binary = 12, None, b""
    while offset + 8 <= min(total, len(data)):
        length, kind = struct.unpack_from("<I4s", data, offset)
        payload = data[offset + 8 : offset + 8 + length]
        if kind == b"JSON":
            gltf = json.loads(payload)
        elif kind == b"BIN\x00":
            binary = payload
        offset += 8 + length + (-length % 4)
    if gltf is None:
        return
    nodes = gltf.get("nodes", [])
    scenes = gltf.get("scenes") or [{}]
    roots = list(scenes[gltf.get("scene", 0)].get("nodes", []))

    def strip(index: int) -> None:
        node = nodes[index]
        rotation = node.get("rotation")
        if rotation is not None:
            # The wrapper is the FIRST rotation on a mesh-less chain from the
            # root, and it is a pure quarter turn; anything else is authoring.
            if (_is_quarter_turn_about_x(rotation) and "translation" not in node
                    and "scale" not in node and "matrix" not in node):
                del node["rotation"]
            return
        if "mesh" in node:
            return
        for child in node.get("children", []):
            strip(child)

    for root in roots:
        strip(root)
    gltf.setdefault("asset", {}).setdefault("extras", {})["optikit_length_unit"] = "mm"
    payload = json.dumps(gltf, separators=(",", ":")).encode()
    payload += b" " * (-len(payload) % 4)
    binary = binary + b"\x00" * (-len(binary) % 4)
    body = struct.pack("<I4s", len(payload), b"JSON") + payload
    if binary:
        body += struct.pack("<I4s", len(binary), b"BIN\x00") + binary
    path.write_bytes(b"glTF" + struct.pack("<II", 2, 12 + len(body)) + body)


def run(
    generator_path: Path,
    params: dict,
    out_dir: Path,
    envelope_mm: tuple[float, float, float] | None = None,
) -> dict:
    """Build and export STEP + STL + GLB + meta.json into ``out_dir``.

    Generators exposing ``build_parts(params) -> dict[str, Workplane]`` (e.g.
    the two halves of a printable holder) get one artifact set per part
    (``model.<name>.step`` …); the envelope check runs on the union bbox.
    ``envelope_mm`` is the template's declared envelope — a multi-cell carrier
    (a 3x4 sandwich plate, WP-53) is bigger than one cube on purpose. Default:
    the 1x1 cube.
    """
    envelope = tuple(envelope_mm) if envelope_mm else ENVELOPE_MM
    module = _load_module(generator_path)
    out_dir.mkdir(parents=True, exist_ok=True)

    build_parts = getattr(module, "build_parts", None)
    if callable(build_parts):
        parts: dict = build_parts(params)
    else:
        parts = {"": module.build(params)}

    part_meta: dict[str, dict] = {}
    lo = [float("inf")] * 3
    hi = [float("-inf")] * 3
    for name, part in parts.items():
        basename = f"model.{name}" if name else "model"
        # bbox BEFORE export: STL tessellation attaches a triangulation that
        # OCC's bound computation then prefers, inflating the box by the mesh
        # deflection (several mm on a coarse spherical face, WP-62).
        bbox = _bbox_of(part)
        _export_part(part, out_dir, basename, name or generator_path.stem)
        part_meta[name or "model"] = bbox
        lo = [min(a, b) for a, b in zip(lo, bbox["min"], strict=True)]
        hi = [max(a, b) for a, b in zip(hi, bbox["max"], strict=True)]

    # WP-61: multi-part generators additionally export the UNION as the plain
    # model.{step,glb} pair — the render mesh + mechanical source a
    # materialized template ships (the per-half files stay the print files).
    if callable(build_parts) and len(parts) > 1:
        it = iter(parts.values())
        union = next(it)
        for part in it:
            union = union.union(part)
        import cadquery as cq

        cq.exporters.export(union, str(out_dir / "model.step"))
        assembly = cq.Assembly(union, name=generator_path.stem)
        exporter = getattr(assembly, "export", None) or assembly.save  # save: cq<=2.8
        exporter(str(out_dir / "model.glb"))
        _normalize_glb(out_dir / "model.glb")

    size = [b - a for a, b in zip(lo, hi, strict=True)]
    meta = {
        "generator": generator_path.name,
        "params": params,
        "parts": part_meta,
        "bbox_mm": {"min": lo, "max": hi, "size": size},
        "envelope_mm": list(envelope),
        # 10 µm slop: OCC bounding boxes of filleted shapes overshoot the
        # nominal size by ~1 µm-scale artifacts; mechanically meaningless.
        "fits_envelope": all(s <= e + 1e-2 for s, e in zip(size, envelope, strict=True)),
    }
    (out_dir / "meta.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    return meta


def main(argv: list[str]) -> int:
    if len(argv) not in (3, 4):
        print(
            "usage: _runner.py <generator.py> <params.json> <out-dir> [envelope-json]",
            file=sys.stderr,
        )
        return 2
    generator_path = Path(argv[0])
    params = json.loads(Path(argv[1]).read_text(encoding="utf-8"))
    envelope = tuple(json.loads(argv[3])) if len(argv) == 4 else None
    try:
        meta = run(generator_path, params, Path(argv[2]), envelope_mm=envelope)
    except Exception as exc:  # noqa: BLE001 — boundary: report and fail the process
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(meta))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
