"""T3 harness: resolve a generative template's generator, run it, key the output.

The output directory of one generation run is keyed by the sha256 of the
**canonicalized** parameters (sorted keys, numbers as floats, no whitespace)
plus the generator script's own digest, so identical parameters land in the
same directory regardless of ordering or ``25`` vs ``25.0`` spelling — and
any parameter OR generator change regenerates into a new key. Layout::

    out/<template-id>/<key12>/
        params.json     canonical parameters of this run
        model.step      exact BREP
        model.stl       tessellated mesh
        model.glb       binary glTF (three.js-loadable)
        meta.json       bbox + envelope verdict (from the runner)

Parameters are validated against the generator's JSON Schema
(``<generator>.params.json`` next to the script) before anything heavy runs.
Only the subset of JSON Schema the generators actually use is implemented —
enough to reject wrong shapes loudly, not a general validator.

CadQuery is optional: if it imports in-process the runner is called directly;
otherwise the harness shells out to ``uv run --no-project --with cadquery``,
letting uv provision an interpreter that has wheels.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..library.root import library_root as default_library_root
from ..schema.library import TemplateRecord

#: Default artifact root, relative to the repo/library root's parent.
DEFAULT_OUT = "out"
KEY_LENGTH = 12


class GenerateError(Exception):
    """Typed harness failure (bad template, bad params, runner failure)."""


# --- canonical parameter keys -----------------------------------------------------------


def canonicalize(params: dict[str, Any]) -> dict[str, Any]:
    """Numbers become floats so ``25`` and ``25.0`` key identically."""

    def canon(v: Any) -> Any:
        if isinstance(v, bool):
            return v
        if isinstance(v, int | float):
            return float(v)
        if isinstance(v, dict):
            return {k: canon(x) for k, x in v.items()}
        if isinstance(v, list):
            return [canon(x) for x in v]
        return v

    return canon(params)


def params_key(params: dict[str, Any], generator_digest: str = "") -> str:
    """sha256 of the canonical JSON, truncated to a filesystem-friendly key.

    ``generator_digest`` folds the script's own bytes in: a fixed generator
    must never serve the parts its old self cut for the same params.
    """
    canonical = json.dumps(canonicalize(params), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256((canonical + generator_digest).encode("utf-8")).hexdigest()[:KEY_LENGTH]


def generator_digest(script: Path) -> str:
    """sha256 of the generator script — part of the artifact key."""
    return hashlib.sha256(script.read_bytes()).hexdigest()


# --- params JSON Schema (the subset our generators declare) -----------------------------


def validate_params(params: dict[str, Any], schema: dict[str, Any]) -> list[str]:
    """Return human-readable violations (empty = valid)."""
    errors: list[str] = []
    properties: dict[str, Any] = schema.get("properties", {})
    for name in schema.get("required", []):
        if name not in params:
            errors.append(f"missing required parameter {name!r}")
    # Top-level oneOf over `required` variants: exactly one alternative's
    # required names may be present (boolean_holder's part_step vs
    # part_prescription, WP-62). Deliberately no general oneOf semantics.
    variants: list[dict[str, Any]] = schema.get("oneOf", [])
    if variants:
        satisfied = [
            v for v in variants
            if all(name in params for name in v.get("required", []))
        ]
        if len(satisfied) != 1:
            names = " / ".join(
                sorted({n for v in variants for n in v.get("required", [])})
            )
            errors.append(f"exactly one of {names} must be given")
    if not schema.get("additionalProperties", True):
        for name in params:
            if name not in properties:
                errors.append(f"unknown parameter {name!r}")
    for name, value in params.items():
        rules = properties.get(name)
        if rules is None:
            continue
        if "enum" in rules and value not in rules["enum"]:
            errors.append(f"{name} must be one of {rules['enum']}, got {value!r}")
            continue
        expected = rules.get("type")
        if expected == "number" and (isinstance(value, bool) or not isinstance(value, int | float)):
            errors.append(f"{name} must be a number, got {value!r}")
            continue
        if expected == "string" and not isinstance(value, str):
            errors.append(f"{name} must be a string, got {value!r}")
            continue
        if isinstance(value, int | float) and not isinstance(value, bool):
            v = float(value)
            if "minimum" in rules and v < rules["minimum"]:
                errors.append(f"{name} = {v} below minimum {rules['minimum']}")
            if "exclusiveMinimum" in rules and v <= rules["exclusiveMinimum"]:
                errors.append(f"{name} = {v} not above {rules['exclusiveMinimum']}")
            if "maximum" in rules and v > rules["maximum"]:
                errors.append(f"{name} = {v} above maximum {rules['maximum']}")
            if "exclusiveMaximum" in rules and v >= rules["exclusiveMaximum"]:
                errors.append(f"{name} = {v} not below {rules['exclusiveMaximum']}")
    return errors


# --- template → generator resolution ----------------------------------------------------


def resolve_generator(record: TemplateRecord, repo_root: Path) -> tuple[Path, dict]:
    """A generative template's script path + its params schema."""
    if record.class_ != "generative":
        raise GenerateError(f"{record.id} is class {record.class_!r}, not generative (T3)")
    if record.generator is None or not record.generator.script:
        raise GenerateError(f"{record.id} declares no generator.script")
    script = repo_root / record.generator.script
    if not script.is_file():
        raise GenerateError(f"generator script not found: {script}")
    schema_file = script.with_suffix("").with_suffix(".params.json")
    if not schema_file.is_file():
        raise GenerateError(f"generator has no params schema: {schema_file}")
    schema = json.loads(schema_file.read_text(encoding="utf-8"))
    return script, schema


# --- running ----------------------------------------------------------------------------


def _cadquery_importable() -> bool:
    try:
        import cadquery  # noqa: F401

        return True
    except ImportError:
        return False


@dataclass
class GenerateResult:
    template_id: str
    key: str
    out_dir: Path
    meta: dict[str, Any]
    regenerated: bool  # False = artifacts for this key already existed


def _resolve_record_assets(params: dict[str, Any], library_root: Path | None) -> dict[str, Any]:
    """`part_step: library/...` names a record's asset: absolute under the records' root.

    Applied after keying, so the cache key stays machine-independent.
    """
    step = params.get("part_step")
    if isinstance(step, str) and step.startswith("library/") and not Path(step).is_absolute():
        root = library_root or default_library_root()
        return {**params, "part_step": str(root / step[len("library/"):])}
    return params


def generate(
    record: TemplateRecord,
    params_override: dict[str, Any] | None = None,
    out_root: str | Path = DEFAULT_OUT,
    repo_root: str | Path | None = None,
    force: bool = False,
    library_root: str | Path | None = None,
) -> GenerateResult:
    """Generate (or reuse) the artifacts for one T3 template instance.

    A ``part_prescription: {component: <id>}`` reference is expanded to the
    record's inline fragment surfaces HERE — the harness always runs with the
    full package (yaml + pydantic), while the generator script may run in the
    bare ``uv run --no-project`` interpreter. Expansion happens before keying
    and validation, so the params key and meta digest cover the actual
    surface stack: editing the component record regenerates the holder.
    """
    repo_root = Path(repo_root) if repo_root else Path.cwd()
    script, schema = resolve_generator(record, repo_root)

    params = dict(record.generator.params)
    params.update(params_override or {})
    # WP-81: derive the optical-axis bore(s) from the record's own ports +
    # apertures when the request does not name them — BEFORE prescription
    # expansion (the {component: id} reference is the derivation's best
    # source) and before keying, so cutting a bore changes the cache key.
    # Only for generators that declare the param (plates cut their own).
    if "beam" not in params and "beam" in schema.get("properties", {}):
        from .beam import derive_beam_params

        beam = derive_beam_params(record, params, repo_root)
        if beam is not None:
            params["beam"] = beam
    params = _expand_part_prescription(
        params, repo_root, Path(library_root) if library_root else None)
    params = canonicalize(params)
    violations = validate_params(params, schema)
    if violations:
        raise GenerateError(
            f"{record.id}: invalid parameters:\n  " + "\n  ".join(violations)
        )

    key = params_key(params, generator_digest(script))
    out_dir = Path(out_root) / record.id / key
    meta_file = out_dir / "meta.json"
    if meta_file.is_file() and not force:
        return GenerateResult(
            record.id, key, out_dir, json.loads(meta_file.read_text("utf-8")), False
        )

    out_dir.mkdir(parents=True, exist_ok=True)
    run_params = _resolve_record_assets(params, Path(library_root) if library_root else None)
    params_json = out_dir / "params.json"
    params_json.write_text(
        json.dumps(run_params, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    envelope = _record_envelope_mm(record)
    if _cadquery_importable():
        from . import _runner

        try:
            meta = _runner.run(script, run_params, out_dir, envelope_mm=envelope)
        except GenerateError:
            raise
        except Exception as exc:  # noqa: BLE001 — the generator's own refusal
            # A generator refusing its inputs (`_check_fit`: "lens Ø25.4 mm
            # offset 8.94 mm needs 22.59 mm of radius") is the RIGHT message
            # for the user — it was arriving as a 500 traceback because only
            # the subprocess path had a boundary. Same error type the rest of
            # the road speaks, so the service turns it into a 422.
            raise GenerateError(f"{record.id}: {type(exc).__name__}: {exc}") from exc
    else:
        meta = _run_via_uv(script, params_json, out_dir, envelope)
    meta = _annotate_prescription_meta(meta, params, meta_file)
    meta = _annotate_beam_meta(meta, params, meta_file)

    if not meta.get("fits_envelope", False):
        size = meta.get("bbox_mm", {}).get("size")
        raise GenerateError(
            f"{record.id}@{key}: generated part {size} mm exceeds the "
            f"{meta.get('envelope_mm')} mm cube envelope"
        )
    return GenerateResult(record.id, key, out_dir, meta, True)


def _record_envelope_mm(record: TemplateRecord) -> tuple[float, float, float] | None:
    """The template's declared envelope, when fully numeric (else the 1x1 default).

    A multi-cell carrier (a 3x4 sandwich plate) is legitimately bigger than
    one cube — its record says so, and the fit check should hold it to ITS
    declaration, not the 50 mm cube (WP-53).
    """
    values = (record.envelope.x_mm, record.envelope.y_mm, record.envelope.z_mm)
    numeric = [float(v) for v in values if isinstance(v, int | float)]
    if len(numeric) != 3:
        return None
    return (numeric[0], numeric[1], numeric[2])


#: WP-62 guard rail: a prescription-derived cavity is a model, not a
#: measurement — the artifact says so.
PRESCRIPTION_REVIEW = (
    "cavity derived from the optical prescription — verify against the "
    "physical optic before printing"
)


def _expand_part_prescription(
    params: dict[str, Any], repo_root: Path, library_root: Path | None = None
) -> dict[str, Any]:
    """Inline a ``part_prescription: {component: <id>}`` reference (WP-62).

    ``library_root`` is the RECORD library, which since R1 is its own repo and
    is NOT ``repo_root/library`` — reading the built-in one made every
    prescription reference to a user's own component fail with "not in the
    library" (reported live on `user.lens.test_lens_unmounted`). Callers that
    know the configured root pass it; the fallback stays the dev checkout's.
    """
    prescription = params.get("part_prescription")
    if not isinstance(prescription, dict) or "component" not in prescription:
        return params
    from ..library import load_library, resolve
    from ..schema.library import ComponentRecord

    ref = str(prescription["component"])
    library = load_library(library_root or default_library_root())
    try:
        loaded = resolve(library, ref if "@" in ref else f"{ref}@*")
    except ValueError as exc:
        raise GenerateError(f"part_prescription component {ref!r}: {exc}") from exc
    if loaded is None or not isinstance(loaded.record, ComponentRecord):
        raise GenerateError(f"part_prescription component {ref!r} is not in the library")
    fragment = loaded.record.optics.fragment
    if fragment is None or not fragment.surfaces:
        raise GenerateError(
            f"part_prescription component {ref!r} has no fragment surfaces"
        )
    expanded = {k: v for k, v in prescription.items() if k != "component"}
    expanded["surfaces"] = [dict(s) for s in fragment.surfaces]
    return dict(params, part_prescription=expanded)


def _prescription_surfaces(params: dict[str, Any]) -> list | None:
    """The surface stack a run's geometry derives from, if any (WP-62)."""
    prescription = params.get("part_prescription")
    if isinstance(prescription, dict) and isinstance(prescription.get("surfaces"), list):
        return prescription["surfaces"]
    surfaces = params.get("surfaces")  # optic_solid's positive role
    return surfaces if isinstance(surfaces, list) else None


def _annotate_prescription_meta(
    meta: dict[str, Any], params: dict[str, Any], meta_file: Path
) -> dict[str, Any]:
    """Record provenance when the geometry came from a prescription (WP-62):
    ``derived_from: prescription``, the sha256 surface digest, and the
    verify-before-printing review flag."""
    surfaces = _prescription_surfaces(params)
    if surfaces is None:
        return meta
    canonical = json.dumps(
        canonicalize({"surfaces": surfaces}), sort_keys=True, separators=(",", ":")
    )
    meta["derived_from"] = "prescription"
    meta["prescription_digest"] = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    review = meta.setdefault("review", [])
    if PRESCRIPTION_REVIEW not in review:
        review.append(PRESCRIPTION_REVIEW)
    meta_file.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    return meta


def _annotate_beam_meta(
    meta: dict[str, Any], params: dict[str, Any], meta_file: Path
) -> dict[str, Any]:
    """Record what the run's beam block cut (WP-81): ``beam_bores`` in the
    meta, so the review flag can say the beam path was opened — and a run
    WITHOUT one is visibly bore-less."""
    beam = params.get("beam")
    if not isinstance(beam, dict):
        return meta
    bores = beam.get("bores") if isinstance(beam.get("bores"), list) else [beam]
    meta["beam_bores"] = bores
    meta_file.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    return meta


#: uc2v4 for a provisioned interpreter without the sibling checkout.
UC2V4_ARCHIVE = (
    "openuc2-cadquery @ "
    "https://github.com/openUC2/openuc2-cadquery/archive/refs/heads/main.zip"
)


def _run_via_uv(
    script: Path,
    params_json: Path,
    out_dir: Path,
    envelope: tuple[float, float, float] | None = None,
) -> dict:
    """Run the generator in a uv-provisioned interpreter that has cadquery wheels."""
    runner = Path(__file__).parent / "_runner.py"
    cmd = ["uv", "run", "--no-project", "--with", "cadquery"]
    # The cartridge generator imports the sibling openuc2-cadquery checkout
    # (uc2v4); a provisioned interpreter has no editable installs, so hand
    # the checkout over when it is where the monorepo layout puts it.
    sibling = Path(__file__).resolve().parents[3].parent / "openuc2_cadquery"
    if (sibling / "pyproject.toml").is_file():
        cmd += ["--with-editable", str(sibling)]
    else:
        # ponytail: floating `main` — the params key covers the generator
        # script but not uc2v4, so a change there reuses cached parts. Pin a
        # tag (or a PyPI release) once uc2v4 versions.
        cmd += ["--with", UC2V4_ARCHIVE]
    cmd += ["python", str(runner), str(script), str(params_json), str(out_dir)]
    if envelope is not None:
        cmd.append(json.dumps(list(envelope)))
    proc = subprocess.run(cmd, capture_output=True, text=True)  # noqa: S603
    if proc.returncode != 0:
        raise GenerateError(
            f"generator runner failed (exit {proc.returncode}):\n{proc.stderr.strip()}"
        )
    return json.loads((out_dir / "meta.json").read_text(encoding="utf-8"))


def pose_params_from_component(
    comp: Any, base_params: dict[str, Any] | None = None
) -> dict[str, Any]:
    """Generator pose override from a placed component's intra-cube pose (WP-35 T3).

    The design's continuous residual (``offset-mm`` δ inside the cube, plus
    the ``offset-deg`` residual tilt) shifts the template's bound part pose —
    so a lens placed 3 mm off-center regenerates a holder whose cavity is
    3 mm off-center. Values ADD to the template's own ``part_position_mm``
    (the optic's bound pose inside the insert body).
    """
    base = dict((base_params or {}).get("part_position_mm") or {})
    off = comp.pose.translation.offset_mm
    tilt = comp.pose.rotation.offset_deg
    position = {
        axis: float(base.get(axis, 0.0)) + float(getattr(off, axis) or 0.0)
        for axis in ("x", "y", "z")
    }
    override: dict[str, Any] = {
        "part_position_mm": {k: v for k, v in position.items() if v != 0.0}
    }
    rotation = {
        axis: float(getattr(tilt, axis) or 0.0) for axis in ("x", "y", "z")
    }
    if any(rotation.values()):
        override["part_rotation_deg"] = {k: v for k, v in rotation.items() if v != 0.0}
    return override


def generate_all(
    library_root: str | Path,
    out_root: str | Path = DEFAULT_OUT,
    repo_root: str | Path | None = None,
    force: bool = False,
) -> list[GenerateResult]:
    """Regenerate artifacts for every T3 template in the library (the CI job)."""
    from ..library import load_library

    library = load_library(Path(library_root))
    if library.errors:
        raise GenerateError("library does not validate:\n  " + "\n  ".join(
            str(e) for e in library.errors
        ))
    results = []
    for entry in library.records:
        record = entry.record
        if isinstance(record, TemplateRecord) and record.class_ == "generative":
            results.append(
                generate(record, out_root=out_root, repo_root=repo_root, force=force)
            )
    return results


__all__ = [
    "GenerateError",
    "GenerateResult",
    "canonicalize",
    "generate",
    "generate_all",
    "params_key",
    "pose_params_from_component",
    "resolve_generator",
    "validate_params",
]
