"""WP-81: derive the optical-axis bore(s) a generated holder must cut.

Round 9 asked for "the optical axis as an additional boolean subtraction" —
``boolean_holder_1x1`` subtracted the part cavity and the M3 features but no
bore, so the printed holder sealed its own beam path. The geometry lives in
the generator (which must stay standalone); THIS module is the plumbing: it
turns a record's own ports + frames + clear apertures (WP-79 made the
aperture travel) into a ``beam: {bores: [...]}`` generator param block, so
the bore is derived from what the record already declares rather than typed
in by hand.

Rules, in record-frame coordinates (the same frame the cavity is carved in —
the generator applies the part pose to bores and cavity alike):

- ports whose directions are collinear (a through lens's front/back) merge
  into ONE through-bore (``both_ways``) along their shared axis;
- every other port (a fold mirror's arms) gets its own one-way bore from its
  frame origin outward along the port direction;
- the diameter is the port frame's ``clear-aperture-mm`` when declared,
  else ``CLEAR_FRACTION`` × the prescription's clear diameter (2 × the
  smallest declared ``semi_aperture``) so a seat lip remains, else
  ``DEFAULT_BORE_DIAMETER_MM``.

Every value is plain JSON so the bores land in the canonical params — cutting
a bore changes the cache key, as it must (the geometry changed).
"""

from __future__ import annotations

import math
from typing import Any

#: Bore diameter when neither an aperture nor a prescription is available.
DEFAULT_BORE_DIAMETER_MM = 10.0
#: Fallback fraction of the optic's full diameter — leaves a seat lip.
CLEAR_FRACTION = 0.9
#: |dot| above which two port directions count as one through-axis.
COLLINEAR_DOT = 0.999
#: Ports on a shared axis must agree transversely within this to merge (mm).
COLLINEAR_OFFSET_MM = 0.5

_AXIS_VECTORS: dict[str, tuple[float, float, float]] = {
    "+x": (1.0, 0.0, 0.0), "-x": (-1.0, 0.0, 0.0),
    "+y": (0.0, 1.0, 0.0), "-y": (0.0, -1.0, 0.0),
    "+z": (0.0, 0.0, 1.0), "-z": (0.0, 0.0, -1.0),
}


def _direction_vector(direction: Any) -> tuple[float, float, float] | None:
    """A port direction (axis literal or [x, y, z]) as a unit vector."""
    if isinstance(direction, str):
        return _AXIS_VECTORS.get(direction)
    if isinstance(direction, (list, tuple)) and len(direction) == 3:
        x, y, z = (float(c) for c in direction)
        norm = math.hypot(x, y, z)
        if norm < 1e-9:
            return None
        return (x / norm, y / norm, z / norm)
    return None


def _numeric(value: Any) -> float | None:
    """A float, or None for templated/absent values (``{fx}`` strings)."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def _frame_origin(frame: Any) -> tuple[float, float, float]:
    return (
        _numeric(getattr(frame, "x_mm", 0.0)) or 0.0,
        _numeric(getattr(frame, "y_mm", 0.0)) or 0.0,
        _numeric(getattr(frame, "z_mm", 0.0)) or 0.0,
    )


def prescription_bore_diameter_mm(surfaces: list[dict[str, Any]] | None) -> float | None:
    """``CLEAR_FRACTION`` × the stack's clear diameter, or None without one."""
    if not surfaces:
        return None
    semis = [
        s.get("semi_aperture")
        for s in surfaces
        if _numeric(s.get("semi_aperture")) is not None and float(s["semi_aperture"]) > 0
    ]
    if not semis:
        return None
    return round(CLEAR_FRACTION * 2.0 * min(float(s) for s in semis), 3)


def bores_from_ports(
    ports: dict[str, Any],
    frames: dict[str, Any],
    fallback_diameter_mm: float | None = None,
) -> list[dict[str, Any]]:
    """Derive the bore list from record-style ports + frames.

    ``ports`` maps name → PortSpec-like (``.frame``, ``.direction``);
    ``frames`` maps name → FrameSpec-like (``.x_mm``…, ``.clear_aperture_mm``).
    """
    default = fallback_diameter_mm or DEFAULT_BORE_DIAMETER_MM

    entries: list[dict[str, Any]] = []
    for name, port in ports.items():
        axis = _direction_vector(getattr(port, "direction", None))
        if axis is None:
            continue
        frame = frames.get(getattr(port, "frame", "") or "")
        point = _frame_origin(frame) if frame is not None else (0.0, 0.0, 0.0)
        aperture = (
            _numeric(getattr(frame, "clear_aperture_mm", None)) if frame is not None else None
        )
        entries.append({
            "port": name,
            "axis": list(axis),
            "point": list(point),
            "diameter": aperture if aperture and aperture > 0 else default,
        })

    bores: list[dict[str, Any]] = []
    used: set[int] = set()
    for i, a in enumerate(entries):
        if i in used:
            continue
        merged = None
        for j in range(i + 1, len(entries)):
            if j in used:
                continue
            b = entries[j]
            dot = sum(a["axis"][k] * b["axis"][k] for k in range(3))
            if abs(dot) < COLLINEAR_DOT:
                continue
            # Same line? The frame offset must be along the shared axis.
            delta = [b["point"][k] - a["point"][k] for k in range(3)]
            along = sum(delta[k] * a["axis"][k] for k in range(3))
            transverse = math.sqrt(
                max(0.0, sum(d * d for d in delta) - along * along)
            )
            if transverse > COLLINEAR_OFFSET_MM:
                continue
            merged = j
            break
        if merged is not None:
            b = entries[merged]
            used.update((i, merged))
            bores.append({
                "port": f"{a['port']}·{b['port']}",
                "axis": a["axis"],
                "through_point_mm": [
                    (a["point"][k] + b["point"][k]) / 2.0 for k in range(3)
                ],
                "diameter_mm": max(a["diameter"], b["diameter"]),
                "both_ways": True,
            })
        else:
            used.add(i)
            bores.append({
                "port": a["port"],
                "axis": a["axis"],
                "through_point_mm": a["point"],
                "diameter_mm": a["diameter"],
                "both_ways": False,
            })
    return bores


def _prescription_component_id(params: dict[str, Any]) -> str | None:
    """The library component a run's cut body refers to, if any.

    Covers both spellings: ``part_prescription: {component: id}`` and a
    ``part_step`` under ``library/components/<id>/``.
    """
    prescription = params.get("part_prescription")
    if isinstance(prescription, dict) and isinstance(prescription.get("component"), str):
        return prescription["component"]
    step = params.get("part_step")
    if isinstance(step, str):
        parts = step.replace("\\", "/").split("/")
        if "components" in parts:
            i = parts.index("components")
            if i + 1 < len(parts):
                return parts[i + 1]
    return None


def _inline_surfaces(params: dict[str, Any]) -> list[dict[str, Any]] | None:
    prescription = params.get("part_prescription")
    if isinstance(prescription, dict) and isinstance(prescription.get("surfaces"), list):
        return prescription["surfaces"]
    return None


def derive_beam_params(
    record: Any,
    params: dict[str, Any],
    repo_root: Any,
) -> dict[str, Any] | None:
    """The ``beam:`` block a run should cut, derived from what it knows.

    Priority: the cut-body component's own ports/frames/apertures (the record
    is the truth) → the template's ``optical_ports`` (directions only) → a
    plain z through-bore for an inline prescription (the WP-77 draft flow,
    where no ports travel). None when nothing is derivable — the generator
    then cuts no bore, which keeps port-less templates (plates) unchanged.
    """

    component = None
    component_id = _prescription_component_id(params)
    if component_id is not None:
        from ..library import load_library, resolve
        from ..library.root import library_root as default_library_root
        from ..schema.library import ComponentRecord

        library_root = default_library_root()
        if library_root.is_dir():
            try:
                loaded = resolve(load_library(library_root), f"{component_id}@*")
            except ValueError:
                loaded = None
            if loaded is not None and isinstance(loaded.record, ComponentRecord):
                component = loaded.record

    fallback = None
    if component is not None and component.optics.fragment is not None:
        fallback = prescription_bore_diameter_mm(component.optics.fragment.surfaces)
    if fallback is None:
        fallback = prescription_bore_diameter_mm(_inline_surfaces(params))

    if component is not None and component.optics.ports:
        bores = bores_from_ports(component.optics.ports, component.optics.frames, fallback)
        return {"bores": bores} if bores else None

    optical_ports = getattr(record, "optical_ports", None) or {}
    if optical_ports:
        frames = getattr(record, "frames", None) or {}
        bores = bores_from_ports(optical_ports, frames, fallback)
        return {"bores": bores} if bores else None

    surfaces = _inline_surfaces(params)
    if surfaces:
        # No ports anywhere (an inline draft prescription): the record
        # convention is ±z as the optical axis — one through-bore.
        center = sum(float(s.get("thickness") or 0.0) for s in surfaces[:-1])
        return {
            "bores": [{
                "port": "optical",
                "axis": [0.0, 0.0, 1.0],
                "through_point_mm": [0.0, 0.0, center / 2.0],
                "diameter_mm": fallback or DEFAULT_BORE_DIAMETER_MM,
                "both_ways": True,
            }]
        }
    return None


__all__ = [
    "CLEAR_FRACTION",
    "DEFAULT_BORE_DIAMETER_MM",
    "bores_from_ports",
    "derive_beam_params",
    "prescription_bore_diameter_mm",
]
