"""Back-annotation: classify an optimized optic.json against the design record.

The narrow, typed reverse direction of the round trip (unification doc §6.2):
every diff between the freshly-compiled baseline and the optimizer's output is
classified — nothing is merged blindly, and only instance data
(the components' ``instantiation.inputs``, ``provenance``) is ever written.

| Optimizer changed…                       | Classification      |
|------------------------------------------|---------------------|
| rigid part position (cs z/x/y together)  | ``POSE_UPDATE``     |
| part tilt (cs rx/ry)                     | ``TILT_UPDATE``     |
| intra-part spacing, radius/conic         | ``PART_PARAM``      |
| material, param without a matching DOF   | ``PART_SUBSTITUTION`` (report only) |
| surface count / type / order             | ``E_TOPOLOGY`` — whole file rejected |

``POSE_UPDATE`` deltas are projected onto the component's declared translation
DOFs (in its local frame); a delta with no DOF to carry it, or one that pushes
a DOF outside its declared range, is reported as a ``DRC_RANGE`` finding
instead of applied — the optimizer does not get to move what the mechanics
cannot.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..compile import CompileResult, compile_path
from ..geometry.cubify import DrcFinding
from ..geometry.flatten import flatten
from ..geometry.rotations import AXIS_DIRS  # noqa: F401  (re-exported convention)
from ..schema.design import CompSpec, DesignDecl, collect_input_values, parse_input_key
from ..schema.merge import instantiate
from ..schema.motion import MotionAxis, axes_for_component

POS_TOL_MM = 1e-6
TILT_TOL_RAD = 1e-9
PARAM_TOL = 1e-9

_LOCAL_AXES = {"x": np.array([1.0, 0, 0]), "y": np.array([0, 1.0, 0]), "z": np.array([0, 0, 1.0])}


class AnnotateError(Exception):
    """Typed back-annotation failure; ``code`` is stable API."""

    def __init__(self, code: str, where: str, message: str) -> None:
        super().__init__(f"{code} at {where}: {message}")
        self.code = code
        self.where = where


@dataclass
class Delta:
    component: str
    classification: str  # POSE_UPDATE | TILT_UPDATE | PART_PARAM | PART_SUBSTITUTION
    param: str  # dof key ("comp.dz"), or a description ("radius[1]", "offset-deg")
    old: Any
    new: Any
    applied: bool
    note: str = ""

    def row(self) -> str:
        mark = "✓" if self.applied else "·"
        return (
            f"{mark} {self.component:<18} {self.classification:<18} {self.param:<22} "
            f"{_fmt(self.old):>12} → {_fmt(self.new):<12} {self.note}"
        )


def _fmt(v: Any) -> str:
    if isinstance(v, float):
        return f"{v:.4g}"
    return str(v)


@dataclass
class AnnotateResult:
    path_name: str
    deltas: list[Delta] = field(default_factory=list)
    findings: list[DrcFinding] = field(default_factory=list)

    @property
    def dof_updates(self) -> dict[str, float]:
        """The applied dof_values (absolute new values), ready to merge."""
        return {
            d.param: float(d.new)
            for d in self.deltas
            if d.applied and d.classification in ("POSE_UPDATE", "TILT_UPDATE")
        }

    def table(self) -> str:
        header = (
            f"  {'component':<18} {'classification':<18} {'param':<22} "
            f"{'old':>12}   {'new':<12}"
        )
        lines = [header, "  " + "-" * len(header)]
        lines += [d.row() for d in self.deltas] or ["  (no differences)"]
        lines += [f"  ! {f}" for f in self.findings]
        return "\n".join(lines)


# --- topology guard ---------------------------------------------------------------------


def _check_topology(base: list[dict], opt: list[dict], where: str) -> None:
    if len(base) != len(opt):
        raise AnnotateError(
            "E_TOPOLOGY", where,
            f"surface count changed ({len(base)} → {len(opt)}) — topology belongs to the "
            "design, not the optimizer",
        )
    for i, (b, o) in enumerate(zip(base, opt, strict=True)):
        if b.get("type") != o.get("type") or (
            (b.get("geometry") or {}).get("type") != (o.get("geometry") or {}).get("type")
        ):
            raise AnnotateError(
                "E_TOPOLOGY", where, f"surface {i} changed type — rejected"
            )

    def order(surfaces: list[dict]) -> list[int]:
        zs = [
            (s.get("geometry", {}).get("cs", {}).get("z", 0.0) or 0.0, i)
            for i, s in enumerate(surfaces)
            if not math.isinf(s.get("geometry", {}).get("cs", {}).get("z", 0.0) or 0.0)
        ]
        return [i for _, i in sorted(zs, key=lambda t: t[0])]

    if order(base) != order(opt):
        raise AnnotateError(
            "E_TOPOLOGY", where,
            "surface order along the axis changed (elements moved past each other) — rejected",
        )


# --- classification -----------------------------------------------------------------------


def back_annotate(
    decl: DesignDecl, path_name: str, optimized_optic: dict[str, Any]
) -> AnnotateResult:
    """Classify every surface diff of ``optimized_optic`` against a fresh compile."""
    baseline: CompileResult = compile_path(decl, path_name)
    base_surfaces = baseline.optic["surface_group"]["surfaces"]
    opt_surfaces = (optimized_optic.get("surface_group") or {}).get("surfaces")
    if not isinstance(opt_surfaces, list):
        raise AnnotateError("E_TOPOLOGY", path_name, "optimized file has no surface_group")
    _check_topology(base_surfaces, opt_surfaces, path_name)

    components = instantiate(decl)
    # WP-177: optimizer deltas are interpreted along the OPTIC's local axes
    poses = flatten(components)
    result = AnnotateResult(path_name=path_name)

    # Group manifest entries into per-traversal blocks (a part may appear twice).
    blocks: list[list[int]] = []
    for i, entry in enumerate(baseline.manifest):
        if blocks and (
            baseline.manifest[i - 1].port_traversal == entry.port_traversal
        ):
            blocks[-1].append(i)
        else:
            blocks.append([i])

    for block in blocks:
        entries = [baseline.manifest[i] for i in block]
        comp_id = entries[0].component_id
        comp = components.get(comp_id)
        world = entries[0].world
        if world is None:
            continue  # infinite-conjugate object plane — nothing to annotate

        dz_list, dx_list, dy_list, drx_list, dry_list = [], [], [], [], []
        for entry in entries:
            b = base_surfaces[entry.surface_index]["geometry"]["cs"]
            o = opt_surfaces[entry.surface_index]["geometry"]["cs"]
            dz_list.append(float(o.get("z", 0) - b.get("z", 0)))
            dx_list.append(float(o.get("x", 0) - b.get("x", 0)))
            dy_list.append(float(o.get("y", 0) - b.get("y", 0)))
            drx_list.append(float(o.get("rx", 0) - b.get("rx", 0)))
            dry_list.append(float(o.get("ry", 0) - b.get("ry", 0)))
            _classify_params(
                result, comp, comp_id, entry,
                base_surfaces[entry.surface_index], opt_surfaces[entry.surface_index],
            )

        # Intra-part spacing change = a part parameter, not a pose.
        if max(dz_list) - min(dz_list) > POS_TOL_MM:
            result.deltas.append(
                Delta(comp_id, "PART_PARAM", "spacing", 0.0,
                      round(max(dz_list) - min(dz_list), 9), False,
                      "intra-part surface spacing changed"))
        rigid = np.array([np.mean(dx_list), np.mean(dy_list), np.mean(dz_list)])
        if float(np.linalg.norm(rigid)) > POS_TOL_MM:
            _classify_pose(result, decl, comp, comp_id, poses, world, rigid)

        tilt = np.array([float(np.mean(drx_list)), float(np.mean(dry_list))])
        if float(np.linalg.norm(tilt)) > TILT_TOL_RAD:
            _classify_tilt(result, decl, comp, comp_id, poses, world, tilt)

    return result


def _classify_params(
    result: AnnotateResult,
    comp: CompSpec | None,
    comp_id: str,
    entry: Any,
    base: dict[str, Any],
    opt: dict[str, Any],
) -> None:
    bg, og = base.get("geometry") or {}, opt.get("geometry") or {}
    frag = entry.fragment_surface_index
    for key in ("radius", "conic"):
        old, new = float(bg.get(key, 0) or 0), float(og.get(key, 0) or 0)
        if math.isinf(old) and math.isinf(new):
            continue
        if abs(new - old) > PARAM_TOL:
            # WP-230: parameter DOFs are gone; a prescription change is a
            # part substitution unless a design input drives it.
            result.deltas.append(
                Delta(comp_id, "PART_SUBSTITUTION", f"{key}[{frag}]", old, new, False,
                      "prescription changed — propose the closest catalog part"))
    b_mat = (base.get("material_post") or {}).get("name") or (
        base.get("material_post") or {}).get("index")
    o_mat = (opt.get("material_post") or {}).get("name") or (
        opt.get("material_post") or {}).get("index")
    if b_mat != o_mat:
        result.deltas.append(
            Delta(comp_id, "PART_SUBSTITUTION", f"material[{frag}]", b_mat, o_mat, False,
                  "material changes are library substitutions"))




def _classify_pose(
    result: AnnotateResult,
    decl: DesignDecl,
    comp: CompSpec | None,
    comp_id: str,
    poses: dict[str, Any],
    world: dict[str, Any],
    rigid: np.ndarray,
) -> None:
    """Rigid (dx, dy, dz in path coords) → world delta → translation DOFs."""
    world_delta = (
        rigid[0] * np.array(world["u"])
        + rigid[1] * np.array(world["v"])
        + rigid[2] * np.array(world["direction"])
    )
    if comp is None or comp_id not in poses:
        result.findings.append(DrcFinding(
            "DRC_RANGE", comp_id, "", f"pose delta {world_delta.round(4).tolist()} mm on an "
            "unknown component"))
        return
    # WP-233: the axes come from the POSE EXPRESSIONS now. A leaf like
    # `offset-mm.z: ~ -5.0 + inputs['dz'].value` says, exactly, "input dz
    # moves this component along its local z at 1 mm per unit" — the same
    # fact `dof:` used to declare, written where the motion actually is.
    rotation = poses[comp_id].rotation
    residual = world_delta.copy()
    for motion in axes_for_component(decl, comp_id):
        if motion.kind != "translation" or motion.axis not in _LOCAL_AXES:
            continue
        axis_world = rotation @ _LOCAL_AXES[motion.axis]
        coeff = float(world_delta @ axis_world)
        if abs(coeff) < POS_TOL_MM:
            continue
        residual -= coeff * axis_world
        # The delta is in MILLIMETRES; the input moves `gain` mm per unit.
        step = coeff / motion.gain
        current = collect_input_values(decl.components, decl.instantiation)
        old = float(current.get(motion.key, 0.0) or 0.0)
        new = old + step
        spec = decl.inputs.get(motion.input_name)
        lo = None if spec is None else spec.min
        hi = None if spec is None else spec.max
        in_range = lo is None or hi is None or float(lo) <= new <= float(hi)
        result.deltas.append(Delta(
            comp_id, "POSE_UPDATE", motion.key, old, new, in_range,
            "" if in_range else f"outside range [{lo}, {hi}] {spec.units if spec else ''}"))
        if not in_range:
            result.findings.append(DrcFinding(
                "DRC_RANGE", comp_id, motion.axis,
                f"optimized {motion.key} = {new:.4g} outside declared range "
                f"[{lo}, {hi}]"))
    if float(np.linalg.norm(residual)) > POS_TOL_MM:
        axis = "xyz"[int(np.argmax(np.abs(residual)))]
        result.deltas.append(Delta(
            comp_id, "POSE_UPDATE", f"offset-mm.{axis}", 0.0,
            round(float(residual[int(np.argmax(np.abs(residual)))]), 9), False,
            "place as pose.translation.offset-mm, or bind it to a design input"))
        result.findings.append(DrcFinding(
            "DRC_RANGE", comp_id, axis,
            f"pose delta {residual.round(4).tolist()} mm — no design input moves "
            "this component in that direction"))


def _rotation_axis_of(
    decl: DesignDecl, comp_id: str, motion: MotionAxis
) -> np.ndarray | None:
    """The WORLD axis one unit of ``motion.input_name`` turns about.

    Measured rather than derived: instantiate the design at input 0 and at
    input 1, and take the rotation axis of ``R1 · R0ᵀ``. A seat-baked euler
    triple puts the tilt on whichever extrinsic leaf the seat maps it onto,
    so the leaf's NAME is not the axis — but the difference of the two
    composed rotations is, whatever the convention.
    """
    from ..geometry.flatten import flatten

    def rotation_at(value: float) -> np.ndarray | None:
        probe = decl.model_copy(deep=True)
        probe.instantiation.inputs[motion.input_name] = value
        try:
            return flatten(instantiate(probe))[comp_id].rotation
        except Exception:
            return None

    r0, r1 = rotation_at(0.0), rotation_at(1.0)
    if r0 is None or r1 is None:
        return None
    delta = r1 @ r0.T
    # The axis of a rotation matrix, from its skew part. A near-identity
    # delta (the input moves nothing here) has no axis to report.
    vec = np.array([
        delta[2, 1] - delta[1, 2],
        delta[0, 2] - delta[2, 0],
        delta[1, 0] - delta[0, 1],
    ])
    norm = float(np.linalg.norm(vec))
    if norm < 1e-9:
        return None
    return vec / norm


def _classify_tilt(
    result: AnnotateResult,
    decl: DesignDecl,
    comp: CompSpec | None,
    comp_id: str,
    poses: dict[str, Any],
    world: dict[str, Any],
    tilt_rad: np.ndarray,
) -> None:
    """Part tilt (rx about u, ry about v) → a rotating input, or a residual.

    WP-233: the input's WORLD axis is measured, not derived from the euler
    leaf — a seat-baked triple carries the tilt on whichever extrinsic leaf
    the seat maps it onto, so reading the leaf name would name the wrong
    axis. Rotating the component's own pose by one unit of the input and
    taking the axis of the difference is exact and convention-free.
    """
    tilt_world = tilt_rad[0] * np.array(world["u"]) + tilt_rad[1] * np.array(world["v"])
    tilt_deg = math.degrees(float(np.linalg.norm(tilt_world)))
    if comp is not None and comp_id in poses:
        for motion in axes_for_component(decl, comp_id):
            if motion.kind != "rotation":
                continue
            axis_world = _rotation_axis_of(decl, comp_id, motion)
            if axis_world is None:
                continue
            coeff_deg = math.degrees(float(tilt_world @ axis_world))
            if abs(coeff_deg) < 1e-9:
                continue
            current = collect_input_values(decl.components, decl.instantiation)
            old = float(current.get(motion.key, 0.0) or 0.0)
            new = old + coeff_deg / motion.gain
            spec = decl.inputs.get(motion.input_name)
            lo = None if spec is None else spec.min
            hi = None if spec is None else spec.max
            in_range = lo is None or hi is None or float(lo) <= new <= float(hi)
            result.deltas.append(Delta(
                comp_id, "TILT_UPDATE", motion.key, old, new, in_range,
                "" if in_range else f"outside range [{lo}, {hi}]"))
            if not in_range:
                result.findings.append(DrcFinding(
                    "DRC_RANGE", comp_id, motion.axis,
                    f"optimized {motion.key} = {new:.4g}° outside declared range"))
            return
    result.deltas.append(Delta(
        comp_id, "TILT_UPDATE", "rotation.offset-deg", 0.0, round(tilt_deg, 6), False,
        "apply as pose.rotation.offset-deg, or bind it to a design input"))


# --- apply ---------------------------------------------------------------------------------


def write_dof_value(doc: Any, key: str, value: float) -> None:
    """Write one input value into a ruamel document tree, at its own level.

    Both levels Go defines: a BARE ``<name>`` the design declares is the
    design's own ``instantiation.inputs`` — the values a caller supplies,
    which every expression in the design reads (WP-233's classifier reports
    these, because that is where a parametric design's motion lives). A
    dotted ``<comp>.<name>`` lands on the component, which is what a child
    design consumes.

    Works on plain dicts and ruamel trees alike, so comments elsewhere in the
    file survive.
    """
    if "." not in key:
        inst = doc.setdefault("instantiation", {})
        if inst.get("inputs") is None:
            inst["inputs"] = {}
        inst["inputs"][key] = value
        return
    comp_id, dof_name = parse_input_key(key)
    comps = doc.get("components") or {}
    comp = comps.get(comp_id)
    if comp is None:
        inst = doc.setdefault("instantiation", {})
        inst.setdefault("dof_values", {})[key] = value
        return
    if comp.get("instantiation") is None:
        comp["instantiation"] = {}
    inst = comp["instantiation"]
    if inst.get("inputs") is None:
        inst["inputs"] = {}
    inst["inputs"][dof_name] = value
    legacy = (doc.get("instantiation") or {}).get("dof_values")
    if legacy and key in legacy:
        del legacy[key]


def apply_to_document(
    doc: Any, result: AnnotateResult, *, optimized_by: str, run: str, merit: dict[str, Any]
) -> int:
    """Write applied deltas + provenance into a ruamel document tree (instance
    data only: the components' ``instantiation.inputs`` and ``provenance``)."""
    updates = result.dof_updates
    for key, value in updates.items():
        write_dof_value(doc, key, round(value, 9))
    prov = doc.setdefault("provenance", {})
    prov["optimized_by"] = optimized_by
    prov["run"] = run
    prov["merit"] = merit
    return len(updates)
