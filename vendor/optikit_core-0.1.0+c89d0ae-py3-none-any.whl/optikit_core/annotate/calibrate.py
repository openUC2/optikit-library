"""WP-86: calibration write-back — a design's DOF values from a RUNNING instrument.

``back_annotate.py`` closes the loop for the simulator (an optimizer result
becomes a value). This closes the other leg, the one that makes OptiKit not a
pure CAD/EDA tool: an axis position read back over the WP-26 UC2-REST link is a
measurement of the instrument BUILT FROM THIS DESIGN, and belongs in it.

    design → CAD → printed/assembled → running instrument → measured axis
       ↑                                                          │
       └────────────────── calibrate_from_instrument ─────────────┘

Deliberately the SAME classified-delta path as the optimizer leg — same
``Delta``, ``AnnotateResult``, range gate and ``DRC_RANGE`` findings, so both
land in ``instantiation.inputs`` through one reviewed table. Only the
provenance differs: ``{source: instrument, instrument: …, run: …}``.

Measurements are ABSOLUTE axis positions in the DOF's own unit (mm / degrees),
what a controller reports; the old value is whatever the design declares, so
the table reads "the design said 1.85, the instrument is at 2.10".

| The instrument reported…                    | Result                     |
|---------------------------------------------|----------------------------|
| a declared axis, value in range              | applied (POSE/TILT_UPDATE) |
| a value outside the declared range           | reported, NOT applied      |
| a DOF the component does not declare         | ``E_UNKNOWN_DOF``          |
| a component the design does not have         | ``E_UNKNOWN_DOF``          |
| an axis nobody declared ``actuatable``       | applied + a W finding      |
"""

from __future__ import annotations

import math
from typing import Any

from ..geometry.cubify import DrcFinding
from ..schema.design import DesignDecl, collect_input_values, parse_input_key
from ..schema.merge import instantiate
from .back_annotate import AnnotateResult, Delta, write_dof_value

#: Below this the reading agrees with the design — no delta worth writing.
MEASURE_TOL = 1e-9

#: A measured axis whose kind has no pose meaning (a `parameter` DOF) is
#: reported rather than applied: the design's geometry does not move with it.
_KIND_CLASSIFICATION = {"translation": "POSE_UPDATE", "rotation": "TILT_UPDATE"}


def _find_input(
    declared: dict[str, dict[str, Any]] | None, comp_id: str, name: str
) -> dict[str, Any] | None:
    """The declaration for ``<comp>.<name>``, if the caller supplied one.

    WP-230/233: a component no longer declares `dof:` — its motions are
    input variables. The DESIGN's own `inputs:` are used by default (that is
    where a parametric design declares them, and no library is needed to
    read them); a caller holding a library may pass a wider set in for
    subdesign-backed parts. Without either, the measurement is still
    applied — only the range and actuation checks are skipped, and the delta
    SAYS so rather than pretending it was verified.
    """
    if not declared:
        return None
    return declared.get(f"{comp_id}.{name}") or declared.get(name)


def calibrate_from_instrument(
    decl: DesignDecl,
    measurements: dict[str, float],
    *,
    instrument: str = "",
    declared_inputs: dict[str, dict[str, Any]] | None = None,
) -> AnnotateResult:
    """Classify measured instrument axis positions against the design.

    ``measurements`` maps ``"<component>.<dof>"`` → the ABSOLUTE measured
    position in the DOF's unit. Returns the same reviewed table the optimizer
    leg produces; ``result.dof_updates`` are the values ready to merge.
    """
    components = instantiate(decl)
    # WP-233: the design's own declarations, so the range and actuation
    # checks work without a library handle for the common (parametric
    # design) case; a caller with a library may widen them.
    from ..schema.motion import declared_inputs_for

    design_inputs = declared_inputs_for(decl)
    result = AnnotateResult(path_name=instrument or "instrument")

    for key in sorted(measurements):
        raw = measurements[key]
        try:
            value = float(raw)
        except (TypeError, ValueError):
            result.findings.append(DrcFinding(
                "E_BAD_MEASUREMENT", key, "",
                f"measured value {raw!r} is not a number",
            ))
            continue
        if not math.isfinite(value):
            result.findings.append(DrcFinding(
                "E_BAD_MEASUREMENT", key, "",
                f"measured value {value} is not finite",
            ))
            continue

        try:
            comp_id, dof_name = parse_input_key(key)
        except ValueError:
            result.findings.append(DrcFinding(
                "E_UNKNOWN_DOF", key, "",
                "measurement key is not '<component>.<dof>'",
            ))
            continue

        comp = components.get(comp_id)
        if comp is None:
            result.findings.append(DrcFinding(
                "E_UNKNOWN_DOF", comp_id, "",
                f"the design has no component {comp_id!r} — the instrument "
                "reported an axis this design does not contain",
            ))
            continue

        spec = _find_input(declared_inputs or design_inputs, comp_id, dof_name)
        units = (spec or {}).get("units", "")
        classification = "TILT_UPDATE" if units == "deg" else "POSE_UPDATE"
        old = float(collect_input_values(decl.components, decl.instantiation).get(key, 0.0) or 0.0)

        if abs(value - old) <= MEASURE_TOL:
            result.deltas.append(Delta(
                comp_id, classification, key, old, value, False,
                "instrument agrees with the design",
            ))
            continue

        lo, hi = (spec or {}).get("min"), (spec or {}).get("max")
        in_range = lo is None or hi is None or float(lo) <= value <= float(hi)
        note = ""
        if spec is None:
            note = "no declaration resolved — range and actuation unchecked"
        elif not in_range:
            note = f"outside range [{lo}, {hi}] {units}"
            result.findings.append(DrcFinding(
                "DRC_RANGE", comp_id, "",
                f"measured {key} = {value:.4g} {units} outside declared range "
                f"[{lo}, {hi}] — the instrument moved further than the design declares",
            ))
        elif spec.get("actuation") != "firmware":
            note = "input is not declared firmware-actuated"
            result.findings.append(DrcFinding(
                "W_NOT_ACTUATABLE", comp_id, "",
                f"the instrument reports {key} but its input does not declare "
                "`actuation: firmware` (WP-42 axis-map)",
            ))
        result.deltas.append(
            Delta(comp_id, classification, key, old, value, in_range, note)
        )

    return result


def apply_calibration_to_document(
    doc: Any,
    result: AnnotateResult,
    *,
    instrument: str,
    run: str,
    note: str = "",
) -> int:
    """Write measured dof values + instrument provenance into a ruamel tree.

    Instance data only, exactly like the optimizer leg — but the provenance
    says where the numbers came from: ``source: instrument`` is what makes a
    calibrated design distinguishable from an optimized one.
    """
    updates = result.dof_updates
    for key, value in updates.items():
        write_dof_value(doc, key, round(value, 9))
    prov = doc.setdefault("provenance", {})
    prov["source"] = "instrument"
    prov["instrument"] = instrument
    prov["run"] = run
    if note:
        prov["note"] = note
    return len(updates)


__all__ = ["apply_calibration_to_document", "calibrate_from_instrument"]
