"""Back-annotation: a result → classified design deltas.

Two legs, one reviewed table: the SIMULATOR's (an optimized optic.json,
``back_annotate``) and the INSTRUMENT's (measured axis positions,
``calibrate_from_instrument`` — WP-86).
"""

from .back_annotate import (
    AnnotateError,
    AnnotateResult,
    Delta,
    apply_to_document,
    back_annotate,
)
from .calibrate import apply_calibration_to_document, calibrate_from_instrument

__all__ = [
    "AnnotateError",
    "AnnotateResult",
    "Delta",
    "apply_calibration_to_document",
    "apply_to_document",
    "back_annotate",
    "calibrate_from_instrument",
]
