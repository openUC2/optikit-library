"""optikit-core: normative datamodel and engine for the openUC2 Optikit toolchain."""

from .constants import SCHEMA_VERSION, UC2_GRID_MM

__version__ = "0.1.0"

__all__ = ["SCHEMA_VERSION", "UC2_GRID_MM", "__version__"]
