"""Command-line interface: ``optikit-core validate <design-dir-or-file> ...``"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic import ValidationError

from . import __version__
from .io import load_design, resolve_design_file
from .library.root import CORE_ROOT
from .library.root import library_root as default_library_root
from .schema import DESIGN_DECL_FILE, check
from .schema.design import collect_input_values

if TYPE_CHECKING:
    from .generate.harness import GenerateResult


def _iter_design_files(paths: list[Path]) -> list[Path]:
    """Expand arguments: design files, design dirs, or trees containing designs."""
    files: list[Path] = []
    for path in paths:
        if path.is_file():
            files.append(path)
        elif (path / DESIGN_DECL_FILE).is_file():
            files.append(path / DESIGN_DECL_FILE)
        elif path.is_dir():
            files.extend(sorted(path.rglob(DESIGN_DECL_FILE)))
        else:
            raise FileNotFoundError(f"no design found at {path}")
    return files


def cmd_validate(args: argparse.Namespace) -> int:
    files = _iter_design_files([Path(p) for p in args.paths])
    if not files:
        print("no optikit-design.yml files found", file=sys.stderr)
        return 2

    n_errors = 0
    for file in files:
        try:
            decl = load_design(file)
        except ValidationError as exc:
            n_errors += exc.error_count()
            print(f"{file}: STRUCTURAL ERRORS")
            for err in exc.errors():
                loc = ".".join(str(part) for part in err["loc"])
                print(f"  ERROR E_STRUCTURE at {loc}: {err['msg']}")
            continue
        findings = check(decl)
        errors = [f for f in findings if f.severity == "error"]
        warnings = [f for f in findings if f.severity == "warning"]
        n_errors += len(errors)
        status = "FAIL" if errors else "OK"
        suffix = f" ({len(warnings)} warning(s))" if warnings else ""
        print(f"{file}: {status}{suffix}")
        shown = findings if args.warnings else errors
        for finding in shown:
            print(f"  {finding}")
    return 1 if n_errors else 0


def cmd_flatten(args: argparse.Namespace) -> int:
    import json

    from .geometry import FlattenError, flat_report
    from .io.yamlio import dump_document
    from .schema.merge import instantiate

    decl = load_design(Path(args.path))
    try:
        entries = [e.dump() for e in flat_report(instantiate(decl))]
    except FlattenError as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1
    if args.format == "json":
        print(json.dumps(entries, indent=2))
    else:
        print(dump_document(entries), end="")
    return 0


def cmd_go_dsn(args: argparse.Namespace) -> int:
    """WP-172: write the design as a Go-composable nested .dsn folder."""
    from .export.go_dsn import design_to_go_dsn
    from .library import load_library

    source = Path(args.path)
    decl = load_design(source)
    root = Path(args.library) if args.library else default_library_root()
    library = load_library(root)
    # WP-187: the design's own folder, so relative `*.dsn` subassemblies
    # travel with the export instead of dangling.
    result = design_to_go_dsn(
        decl, library, source_dir=source if source.is_dir() else source.parent
    )
    out_dir = Path(args.out)
    for rel, content in result.files.items():
        target = out_dir / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, bytes):
            target.write_bytes(content)
        else:
            target.write_text(content, encoding="utf-8")
    for w in result.warnings:
        print(f"WARNING: {w}", file=sys.stderr)
    print(
        f"wrote {len(result.files)} files "
        f"({len(result.fragments)} module fragments) to {out_dir}"
    )
    return 0


def cmd_cubify(args: argparse.Namespace) -> int:
    from .geometry import FlattenError, cubify
    from .io.yamlio import dump_document
    from .schema.merge import instantiate

    decl = load_design(Path(args.path))
    dof_values = {
        k: v
        for k, v in collect_input_values(decl.components, decl.instantiation).items()
        if isinstance(v, int | float)
    }
    try:
        result = cubify(instantiate(decl), dof_values=dof_values)
    except FlattenError as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1
    out = {comp_id: pose.pose_dict() for comp_id, pose in sorted(result.poses.items())}
    print(dump_document({"poses": out}), end="")
    for finding in result.findings:
        print(f"  {finding}")
    return 1 if result.findings else 0


def cmd_chain(args: argparse.Namespace) -> int:
    from .chain import ChainError, infer_paths
    from .geometry import FlattenError
    from .io.yamlio import dump_document, load_document

    file = resolve_design_file(Path(args.design))
    decl = load_design(file)
    try:
        result = infer_paths(decl)
    except (ChainError, FlattenError) as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1

    existing_chains = {tuple(p.chain) for p in decl.paths.values()}
    new_paths = {
        name: spec
        for name, spec in result.paths.items()
        if tuple(spec["chain"]) not in existing_chains
    }

    print(dump_document({"paths": result.paths}), end="")
    for warning in result.warnings:
        print(f"  note: {warning}")

    if args.write:
        if not new_paths:
            print("nothing to write: every inferred chain is already declared")
            return 0
        doc = load_document(file)
        doc.setdefault("paths", {})
        for name, spec in new_paths.items():
            key = name
            while key in doc["paths"]:
                key += "-inferred"
            doc["paths"][key] = spec
        file.write_text(dump_document(doc), encoding="utf-8")
        print(f"wrote {len(new_paths)} path(s) into {file}")
    return 0


def cmd_compile(args: argparse.Namespace) -> int:
    import json

    from .compile import CompileError, compile_path
    from .geometry import FlattenError
    from .io.yamlio import dump_document

    decl = load_design(Path(args.design))
    path_names = [args.path_name] if args.path_name else sorted(decl.paths)
    if not path_names:
        print("design declares no paths", file=sys.stderr)
        return 2
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    summaries: list[dict] = []
    for path_name in path_names:
        try:
            result = compile_path(decl, path_name)
        except (CompileError, FlattenError) as exc:
            print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
            return 1
        optic_file = out_dir / f"optic.{path_name}.json"
        optic_file.write_text(json.dumps(result.optic, indent=2) + "\n", encoding="utf-8")
        manifest_file = out_dir / f"optic.{path_name}.manifest.yml"
        manifest_file.write_text(
            dump_document([m.dump() for m in result.manifest]), encoding="utf-8"
        )
        print(f"wrote {optic_file} + {manifest_file.name}")
        for warning in result.warnings:
            print(f"  note: {warning}")
        if args.summary:
            summaries.append(_paraxial_summary(result))

    if args.summary:
        summary_file = out_dir / "summary.json"
        summary_file.write_text(json.dumps(summaries, indent=2) + "\n", encoding="utf-8")
        print(f"wrote {summary_file}")
    return 0


def cmd_export_scene3(args: argparse.Namespace) -> int:
    import json

    from .canvas import materialize
    from .io.yamlio import design_dir_loader

    design_path = Path(args.design)
    decl = load_design(design_path)
    if args.path_name:
        if args.path_name not in decl.paths:
            print(f"design declares no path {args.path_name!r}", file=sys.stderr)
            return 2
        decl.paths = {args.path_name: decl.paths[args.path_name]}

    # WP-175: resolve `type: design` subassemblies relative to the design dir.
    # WP-198: …and a placed subdesign-backed module's LIBRARY ref before that.
    design_dir = design_path if design_path.is_dir() else design_path.parent
    loader = design_dir_loader(design_dir)
    library_root = default_library_root()
    if library_root.is_dir():
        from .library import load_library
        from .library.subdesigns import library_subdesign_loader

        loader = library_subdesign_loader(load_library(library_root), fallback=loader)
    result = materialize(decl, subdesign_loader=loader)
    errors = [f for f in result.findings if f.severity == "error"]
    if errors:
        for f in errors:
            print(f"ERROR {f}", file=sys.stderr)
        return 1

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    indent = 2 if args.pretty else None
    scene_file = out_dir / "scene3.ocanvas"
    manifest_file = out_dir / "scene3-manifest.json"
    scene_file.write_text(json.dumps(result.scene, indent=indent) + "\n", encoding="utf-8")
    manifest_file.write_text(json.dumps(result.manifest, indent=indent) + "\n", encoding="utf-8")
    print(f"wrote {scene_file} + {manifest_file.name}")
    for f in result.findings:
        if f.severity == "warning":
            print(f"  note: {f}")
    return 0


def _paraxial_summary(result) -> dict:  # noqa: ANN001
    """Paraxial report per compiled path (optiland required, like the old
    exporter's summary.json)."""
    info: dict = {
        "path": result.path_name,
        "n_surfaces": len(result.optic["surface_group"]["surfaces"]),
        "wavelengths_um": [
            w["value"] for w in result.optic["wavelengths"]["wavelengths"]
        ],
        "warnings": list(result.warnings),
    }
    try:
        from optiland.optic import Optic

        optic = Optic.from_dict(result.optic)
        info["efl_mm"] = float(optic.paraxial.f2())
    except ImportError:
        info["paraxial_error"] = "optiland not installed"
    except Exception as exc:  # noqa: BLE001 — diagnostic only
        info["paraxial_error"] = str(exc)
    return info


def cmd_back_annotate(args: argparse.Namespace) -> int:
    import datetime
    import json

    from .annotate import AnnotateError, apply_to_document, back_annotate
    from .compile import CompileError
    from .geometry import FlattenError
    from .io.yamlio import dump_document, load_document

    file = resolve_design_file(Path(args.design))
    decl = load_design(file)
    optimized = json.loads(Path(args.optimized).read_text(encoding="utf-8"))
    try:
        result = back_annotate(decl, args.path_name, optimized)
    except (AnnotateError, CompileError, FlattenError) as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1

    print(result.table())
    if not args.apply:
        return 1 if result.findings else 0

    doc = load_document(file)
    n = apply_to_document(
        doc,
        result,
        optimized_by=args.optimized_by,
        run=datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds"),
        merit={},
    )
    file.write_text(dump_document(doc), encoding="utf-8")
    print(f"applied {n} dof value(s) to {file}")
    return 1 if result.findings else 0


def cmd_calibrate(args: argparse.Namespace) -> int:
    """WP-86: measured instrument axes → classified dof_value updates."""
    import datetime
    import json

    from .annotate import apply_calibration_to_document, calibrate_from_instrument
    from .io.yamlio import dump_document, load_document

    file = resolve_design_file(Path(args.design))
    decl = load_design(file)
    raw = json.loads(Path(args.measurements).read_text(encoding="utf-8"))
    # Accept both the bare mapping and the {"measurements": {...}} envelope a
    # device-side script may wrap it in.
    measurements = raw.get("measurements", raw) if isinstance(raw, dict) else {}
    if not isinstance(measurements, dict) or not measurements:
        print(
            "no measurements: expected {'<component>.<dof>': <value>, …} "
            "(optionally under a 'measurements' key)",
            file=sys.stderr,
        )
        return 2
    instrument = args.instrument or (
        raw.get("instrument", "") if isinstance(raw, dict) else ""
    )

    result = calibrate_from_instrument(decl, measurements, instrument=instrument)
    print(result.table())
    if not args.apply:
        return 1 if result.findings else 0

    doc = load_document(file)
    n = apply_calibration_to_document(
        doc,
        result,
        instrument=instrument,
        run=datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds"),
        note=args.note,
    )
    file.write_text(dump_document(doc), encoding="utf-8")
    print(f"applied {n} measured dof value(s) to {file} (provenance: instrument)")
    return 1 if result.findings else 0


def serve_exposure_warning(host: str) -> str:
    """The off-loopback warning, or "" (loopback bind, or writes off).

    The service authenticates nothing itself — the deployment model is in
    ARCHITECTURE.md §10.5.
    """

    if host in ("127.0.0.1", "localhost", "::1"):
        return ""
    env = os.environ.get("OPTIKIT_ALLOW_LIBRARY_WRITE")
    dev_checkout = (Path(__file__).resolve().parents[2] / ".git").exists()
    if not (env != "0" if env is not None else dev_checkout):
        return ""
    return (
        f"WARNING: serving on {host} with library WRITES enabled and no "
        "authentication.\n"
        "         Anyone who can reach this port can save and delete records.\n"
        "         Put a proxy in front (deploy/tailscale/ does), or use the\n"
        "         default --host 127.0.0.1, or set "
        "OPTIKIT_ALLOW_LIBRARY_WRITE=0."
    )


def cmd_serve(args: argparse.Namespace) -> int:

    import uvicorn

    warning = serve_exposure_warning(args.host)
    if warning:
        print(warning, file=sys.stderr)
    if args.library_root:
        # Same knob as the env var, spelled where a person will find it. Set
        # BEFORE uvicorn imports the app: library_root_path() reads it per
        # request, but making the flag win over an inherited stale env var
        # requires writing it, not just defaulting it.
        os.environ["OPTIKIT_LIBRARY_ROOT"] = str(Path(args.library_root).expanduser())
    uvicorn.run("optikit_core.service:app", host=args.host, port=args.port)
    return 0


def cmd_import_glb(args: argparse.Namespace) -> int:
    from .importers import import_glb_file
    from .importers.glb2template import bbox_thumbnail_svg
    from .io.yamlio import dump_document

    catalog = None
    if not args.no_catalog:
        # A BUY part number in the export resolves to the vendor's prescription
        # when a snapshot is there; without one the name tokens decide, quietly.
        from .catalog.snapshot import latest_snapshot_path, load_snapshot

        path = latest_snapshot_path(_catalog_dir(args))
        catalog = load_snapshot(path) if path is not None else None
    try:
        result = import_glb_file(
            Path(args.glb), namespace=args.namespace, catalog=catalog,
            catalog_road=args.catalog_road,
            cache_dir=_catalog_dir(args) / "files" if catalog is not None else None,
        )
    except ImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    root = Path(args.out) if args.out else default_library_root()
    written: list[Path] = []
    kinds = {
        "optical_component": ("components", result.component),
        "mechanical_template": ("templates", result.template),
        "cube_module": ("modules", result.module),
    }
    for kind, (folder, record) in kinds.items():
        rec_dir = root / folder / record["id"]
        rec_dir.mkdir(parents=True, exist_ok=True)
        file = rec_dir / {"optical_component": "component.yml",
                          "mechanical_template": "template.yml",
                          "cube_module": "module.yml"}[kind]
        if record.get("review"):
            record["thumbnail"] = "thumbnail.svg" if kind == "cube_module" else record.get(
                "thumbnail", "")
        if kind == "cube_module":
            thumb = rec_dir / "thumbnail.svg"
            thumb.write_text(
                bbox_thumbnail_svg(result.envelope_mm, record["id"].rsplit(".", 1)[-1]),
                encoding="utf-8",
            )
            record["thumbnail"] = "thumbnail.svg"
        file.write_text(dump_document(record), encoding="utf-8")
        written.append(file)

    for file in written:
        print(f"wrote {file}")
    if result.review:
        print(f"\n⚠ {len(result.review)} item(s) need review:", file=sys.stderr)
        for item in result.review:
            print(f"  - {item}", file=sys.stderr)
    return 0


def cmd_import_assembly(args: argparse.Namespace) -> int:
    import tempfile

    from .importers.assembly import import_assembly, load_spec
    from .importers.step_glb import StepGlbError, step_file_to_glb

    spec_path = Path(args.spec)
    spec = load_spec(spec_path)
    root = Path(args.out) if args.out else default_library_root()
    if args.glb:
        glb = Path(args.glb).read_bytes()
    else:
        step = Path(args.step) if args.step else spec_path.parent / spec.source
        if not step.is_file():
            print(f"ERROR: STEP not found: {step} (pass --step or --glb)", file=sys.stderr)
            return 2
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "assembly.glb"
            try:
                protect = tuple(
                    [p.node for p in spec.parts] + [p.seat_node for p in spec.parts if p.seat_node]
                    + [s["node"] for p in spec.parts for s in p.seats.values() if "node" in s]
                    + [n for g in spec.groups for n in g.nodes]
                    + [prefix for g in spec.groups for prefix in g.members]
                )
                step_file_to_glb(step, out, linear=args.linear, angular=args.angular,
                                 prune=args.prune, protect=protect)
            except StepGlbError as exc:
                print(f"ERROR: {exc.code}: {exc}", file=sys.stderr)
                return 2
            glb = out.read_bytes()
    for file in import_assembly(spec, glb, root):
        print(f"wrote {file}")
    return 0


def cmd_actuate(args: argparse.Namespace) -> int:
    import json

    from .library import load_library
    from .library.actuate import ActuationError, firmware_command

    if "=" not in args.assignment:
        print("assignment must be <dof>=<value>", file=sys.stderr)
        return 2
    dof, raw = args.assignment.split("=", 1)
    try:
        value = float(raw)
    except ValueError:
        print(f"not a number: {raw!r}", file=sys.stderr)
        return 2

    root = Path(args.root) if args.root else default_library_root()
    try:
        command = firmware_command(load_library(root), args.module_id, dof.strip(), value)
    except ActuationError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(command, indent=2))
    return 0


def cmd_import_csv(args: argparse.Namespace) -> int:
    from .importers.csv_palette import import_csv
    from .io.yamlio import dump_document

    result = import_csv(Path(args.csv), namespace=args.namespace)
    root = Path(args.out) if args.out else default_library_root()

    counts: dict[str, int] = {}
    for rr in result.rows:
        counts[rr.category] = counts.get(rr.category, 0) + 1
        for folder, fname, record in (
            ("components", "component.yml", rr.component),
            ("templates", "template.yml", rr.template),
            ("modules", "module.yml", rr.module),
        ):
            if record is None:
                continue
            rec_dir = root / folder / record["id"]
            rec_dir.mkdir(parents=True, exist_ok=True)
            (rec_dir / fname).write_text(dump_document(record), encoding="utf-8")

    print(f"migrated {len(result.rows)} row(s) → record trios in {root}")
    for cat, n in sorted(counts.items()):
        print(f"  {cat}: {n}")
    for skip in result.skipped:
        print(f"  skipped {skip}", file=sys.stderr)
    print("\n⚠ every migrated record is review-flagged — run `library validate` and confirm")
    return 0


def _write_component_record(record: dict, root: Path) -> Path:
    from .io.yamlio import dump_document

    rec_dir = root / "components" / record["id"]
    rec_dir.mkdir(parents=True, exist_ok=True)
    file = rec_dir / "component.yml"
    file.write_text(dump_document(record), encoding="utf-8")
    return file


def _report_zmx_results(results: list, root: Path) -> int:  # noqa: ANN001
    n_review = 0
    for result in results:
        file = _write_component_record(result.component, root)
        efl = f"  EFL {result.efl_mm:.2f} mm" if result.efl_mm is not None else ""
        print(f"wrote {file}{efl}")
        if result.review:
            n_review += 1
            print(f"  ⚠ {len(result.review)} item(s) need review:", file=sys.stderr)
            for item in result.review:
                print(f"    - {item}", file=sys.stderr)
    return 0


def cmd_import_zmx(args: argparse.Namespace) -> int:
    from .importers.thorlabs import ZmxImportError, zmx_to_component

    try:
        result = zmx_to_component(
            Path(args.zmx), mpn=args.mpn, namespace=args.namespace, vendor_name=args.vendor
        )
    except ImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except ZmxImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    root = Path(args.out) if args.out else default_library_root()
    return _report_zmx_results([result], root)


def cmd_import_objective(args: argparse.Namespace) -> int:
    from .importers.objective import ObjectiveFacts, mint_objective

    facts = ObjectiveFacts(
        slug=args.slug,
        display=args.name or args.slug.replace("_", " "),
        manufacturer=args.manufacturer,
        magnification=args.mag,
        numerical_aperture=args.na,
        efl_mm=args.efl if args.efl is not None else args.tube_lens_f / args.mag,
        working_distance_mm=args.wd,
        tube_lens_f_mm=args.tube_lens_f,
        immersion=args.immersion,
        thread=args.thread,
        parfocal_distance_mm=args.parfocal,
        field_number_mm=args.field_number,
        correction=args.correction,
        price_eur=args.price,
        mpn=args.mpn,
        docs=[args.docs] if args.docs else [],
    )
    root = Path(args.out) if args.out else default_library_root()
    try:
        written = mint_objective(
            root, facts, namespace=args.namespace,
            zmx=Path(args.zmx) if args.zmx else None,
            step=Path(args.step) if args.step else None,
            front_axis=args.step_axis,
        )
    except (ValueError, ValidationError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    for file in written:
        print(f"wrote {file}")
    return 0


def cmd_import_thorlabs(args: argparse.Namespace) -> int:
    from .importers.thorlabs import ZmxImportError, import_thorlabs_mpns

    try:
        results = import_thorlabs_mpns(args.mpns, args.zmx_dir, namespace=args.namespace)
    except ImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except ZmxImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    root = Path(args.out) if args.out else default_library_root()
    return _report_zmx_results(results, root)


# --- catalog (WP-225/255) -------------------------------------------------------------------


def _catalog_dir(args: argparse.Namespace) -> Path:
    from .catalog.snapshot import default_catalog_dir

    if getattr(args, "catalog", None):
        return Path(args.catalog).expanduser().resolve()
    return default_catalog_dir(default_library_root())


def _load_catalog(args: argparse.Namespace):  # noqa: ANN202
    from .catalog.snapshot import latest_snapshot_path, load_snapshot

    directory = _catalog_dir(args)
    path = latest_snapshot_path(directory)
    if path is None:
        print(f"ERROR: no catalog snapshot in {directory} — "
              "run `optikit-core catalog convert-bomb` or `catalog crawl` first",
              "or `catalog crawl` first", file=sys.stderr)
        return None
    return load_snapshot(path)


def cmd_catalog_convert_bomb(args: argparse.Namespace) -> int:
    from .catalog.bomb import convert_bomb
    from .catalog.snapshot import snapshot_path, write_snapshot

    try:
        snapshot = convert_bomb(Path(args.repo))
    except (OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    out = write_snapshot(snapshot, snapshot_path(_catalog_dir(args), snapshot.version))
    summary = snapshot.summary()
    print(f"wrote {out}: {summary['count']} rows, snapshot {summary['version']}")
    for kind, n in summary["kinds"].items():
        print(f"  {kind}: {n}")
    return 0


def cmd_catalog_from_library(args: argparse.Namespace) -> int:
    from .catalog.from_library import library_rows, merged_snapshot
    from .catalog.snapshot import (
        latest_snapshot_path,
        load_snapshot,
        snapshot_path,
        today,
        write_snapshot,
    )
    from .library import load_library

    root = Path(args.library) if args.library else default_library_root()
    library = load_library(root)
    if library.errors:
        for err in library.errors:
            print(f"ERROR: {err}", file=sys.stderr)
        return 1
    rows = library_rows(library, namespace=args.namespace)
    if not rows:
        print(f"no {args.namespace}.* components with a row kind in {root}", file=sys.stderr)
        return 1

    directory = _catalog_dir(args)
    base = None
    if not args.standalone:
        latest = latest_snapshot_path(directory)
        if latest is not None:
            base = load_snapshot(latest)
    version = args.version or f"optics-catalog-{today()}"
    snapshot = merged_snapshot(rows, base, version)
    out = write_snapshot(snapshot, snapshot_path(directory, version))
    summary = snapshot.summary()
    print(f"wrote {out}: {summary['count']} rows "
          f"({len(rows)} from the library, {summary['count'] - len(rows)} kept), "
          f"snapshot {summary['version']}")
    for kind, n in summary["kinds"].items():
        print(f"  {kind}: {n}")
    return 0


def cmd_catalog_crawl(args: argparse.Namespace) -> int:
    from .catalog.crawl import SCOPES, ThorlabsClient, crawl_snapshot
    from .catalog.snapshot import snapshot_path, write_snapshot

    directory = _catalog_dir(args)
    client = ThorlabsClient(directory / "cache", delay_s=args.delay)
    scopes = tuple(args.scope) if args.scope else tuple(SCOPES)
    print(f"crawling Thorlabs — {args.delay:.0f} s between requests (robots.txt: Crawl-delay 30); "
          "pages are cached, a re-run is free", file=sys.stderr)
    snapshot, reports = crawl_snapshot(
        client, scopes=scopes, slugs=args.slug or None, max_depth=args.max_depth,
        version=args.version, log=lambda m: print("  " + m, file=sys.stderr),
    )
    out = write_snapshot(snapshot, snapshot_path(directory, snapshot.version))
    pages = sum(r.pages for r in reports)
    print(f"wrote {out}: {len(snapshot.parts)} rows from {pages} pages, {client.requests} requests")
    for r in reports:
        for d in r.diagnostics:
            if "error" in d or "skipped" in d:
                print(f"  ! {d}", file=sys.stderr)
    return 0


def cmd_catalog_fpbase(args: argparse.Namespace) -> int:
    from .catalog.fpbase import default_spectra_dir, fetch_fpbase, spectra_path, write_spectra

    if args.spectra_dir:
        directory = Path(args.spectra_dir).expanduser().resolve()
    else:
        directory = default_spectra_dir(default_library_root())
    try:
        snapshot = fetch_fpbase()
    except (OSError, ValueError) as exc:
        print(f"ERROR: fpbase fetch failed: {exc}", file=sys.stderr)
        return 1
    out = write_spectra(snapshot, spectra_path(directory, snapshot.version))
    summary = snapshot.summary()
    print(f"wrote {out}: {summary['count']} fluorophores, snapshot {summary['version']}")
    for kind, n in summary["kinds"].items():
        print(f"  {kind}: {n}")
    return 0


def cmd_catalog_search(args: argparse.Namespace) -> int:
    from .catalog.snapshot import query

    snapshot = _load_catalog(args)
    if snapshot is None:
        return 1
    cased = None if args.cased == "any" else args.cased == "yes"
    hits = query(snapshot.parts, kind=args.kind, q=" ".join(args.query), cased=cased)
    print(f"{len(hits)} row(s) in {snapshot.version}")
    for p in hits[: args.limit]:
        print(f"  {p.id:28s} {p.kind:22s} {p.confidence:8s} {p.title}")
    return 0


def cmd_catalog_show(args: argparse.Namespace) -> int:
    snapshot = _load_catalog(args)
    if snapshot is None:
        return 1
    part = snapshot.by_id(args.part_id)
    if part is None:
        print(f"ERROR: no row {args.part_id!r}", file=sys.stderr)
        return 1
    print(json.dumps(part.to_json(), indent=2, ensure_ascii=False))
    return 0


def cmd_catalog_fetch(args: argparse.Namespace) -> int:
    from .catalog.fetch import CatalogFetchError, fetch_prescription

    snapshot = _load_catalog(args)
    if snapshot is None:
        return 1
    part = snapshot.by_id(args.part_id)
    if part is None:
        print(f"ERROR: no row {args.part_id!r}", file=sys.stderr)
        return 1
    try:
        fetched = fetch_prescription(part, _catalog_dir(args) / "files")
    except CatalogFetchError as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1
    state = "cached" if fetched.from_cache else "fetched"
    print(f"{fetched.path}  sha256 {fetched.sha256[:12]}…  {state} {fetched.retrieved_at}")
    return 0


def cmd_catalog_import(args: argparse.Namespace) -> int:
    from .catalog.importer import CatalogImportError, import_part

    snapshot = _load_catalog(args)
    if snapshot is None:
        return 1
    try:
        outcome = import_part(snapshot, args.part_id, road=args.road, namespace=args.namespace,
                              cache_dir=_catalog_dir(args) / "files")
    except CatalogImportError as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1
    root = Path(args.out) if args.out else default_library_root()
    file = _write_component_record(outcome.component, root)
    efl = f"  EFL {outcome.efl_mm:.2f} mm" if outcome.efl_mm is not None else ""
    print(f"wrote {file} (road: {outcome.road}){efl}")
    if outcome.review:
        print(f"  ⚠ {len(outcome.review)} item(s) need review:", file=sys.stderr)
        for item in outcome.review:
            print(f"    - {item}", file=sys.stderr)
    return 0


def _parse_param_overrides(pairs: list[str]) -> dict:
    overrides = {}
    for pair in pairs:
        key, sep, raw = pair.partition("=")
        if not sep or not key:
            raise SystemExit(f"--param expects key=value, got {pair!r}")
        try:
            overrides[key] = float(raw)
        except ValueError:
            overrides[key] = raw
    return overrides


def cmd_generate(args: argparse.Namespace) -> int:
    import json

    from .generate import GenerateError, generate, generate_all, pose_params_from_component
    from .library import load_library
    from .schema.library import TemplateRecord

    root = Path(args.library) if args.library else default_library_root()
    repo_root = CORE_ROOT  # the generator scripts ship with the core

    try:
        if args.all:
            results = generate_all(
                root, out_root=args.out, repo_root=repo_root, force=args.force
            )
        else:
            if not args.template_id:
                print("give a <template-id> or --all", file=sys.stderr)
                return 2
            library = load_library(root)
            candidates = [
                e.record
                for e in library.records
                if isinstance(e.record, TemplateRecord) and e.record.id == args.template_id
            ]
            if not candidates:
                print(f"no template {args.template_id!r} in {root}", file=sys.stderr)
                return 2
            overrides = _parse_param_overrides(args.param)
            if args.params_json:
                overrides.update(
                    json.loads(Path(args.params_json).read_text(encoding="utf-8"))
                )
            if args.design and args.component:
                # WP-35 T3: regenerate around the part's ACTUAL placed pose —
                # the design component's intra-cube δ shifts the cavity.
                from .io import load_design

                decl = load_design(Path(args.design))
                comp = decl.components.get(args.component)
                if comp is None:
                    print(f"no component {args.component!r} in {args.design}", file=sys.stderr)
                    return 2
                overrides.update(
                    pose_params_from_component(comp, candidates[0].generator.params
                                               if candidates[0].generator else {})
                )
            elif args.design or args.component:
                print("--design and --component go together", file=sys.stderr)
                return 2
            results = [
                generate(
                    candidates[0],
                    params_override=overrides,
                    out_root=args.out,
                    repo_root=repo_root,
                    force=args.force,
                )
            ]
    except GenerateError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    for result in results:
        verb = "generated" if result.regenerated else "up-to-date"
        size = result.meta.get("bbox_mm", {}).get("size", [])
        dims = "x".join(f"{s:.1f}" for s in size)
        print(f"{verb} {result.template_id}@{result.key} -> {result.out_dir} ({dims} mm)")
        if args.install:
            for line in _install_generated(root, result):
                print(f"  installed {line}")
    return 0


def _install_generated(root: Path, result: GenerateResult) -> list[str]:
    """Copy a generated STEP/GLB into its template's record dir and declare them.

    The generator stays the source of truth: re-running with --install
    overwrites both files and bumps the record's patch version.
    """
    import shutil

    from .generate import GenerateError
    from .io.yamlio import _to_plain, dump_document, load_document
    from .library import load_library
    from .schema.library import TemplateRecord

    template_id = result.template_id
    out_dir = Path(result.out_dir)
    loaded = next(
        (
            e for e in load_library(root).records
            if isinstance(e.record, TemplateRecord) and e.record.id == template_id
        ),
        None,
    )
    if loaded is None:
        raise GenerateError(f"no template {template_id!r} in {root}")

    written: list[str] = []
    record_dir = loaded.path.parent
    for name in ("model.glb", "model.step"):
        source = out_dir / name
        if source.is_file():
            shutil.copyfile(source, record_dir / name)
            written.append(str(record_dir / name))

    record = _to_plain(load_document(loaded.path)) or {}
    major, minor, patch = str(record.get("version", "0.1.0")).split(".")[:3]
    record["version"] = f"{major}.{minor}.{int(patch.split('-')[0]) + 1}"
    record["glb"] = "model.glb"
    record["step"] = "model.step"
    record["mesh-frame"] = "cube"
    loaded.path.write_text(dump_document(record), encoding="utf-8")
    return [*written, str(loaded.path)]


def cmd_rebuild(args: argparse.Namespace) -> int:
    from .release import RebuildError, rebuild

    try:
        report = rebuild(Path(args.bundle))
    except RebuildError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(report.table())
    print(f"\nresult: {'REPRODUCIBLE' if report.ok else 'MISMATCH'}")
    return 0 if report.ok else 1


def cmd_export_step(args: argparse.Namespace) -> int:
    """WP-57: a design → one grouped STEP assembly.
    WP-84 (``--component``): ONE part, posed w.r.t. its CUBE frame — the
    Inventor round-trip's outbound leg."""
    from .export import ExportError, export_step, export_step_part
    from .io import load_design

    design_path = Path(args.design)
    if not design_path.exists():
        print(f"no design at {design_path}", file=sys.stderr)
        return 2
    component = getattr(args, "component", None)
    default_name = (
        design_path.with_suffix(".step")
        if component is None
        else design_path.parent / f"{component}-in-cube.step"
    )
    out = Path(args.out) if args.out else default_name
    library_root = Path(args.library) if args.library else default_library_root()

    try:
        decl = load_design(design_path)
        if component is not None:
            report = export_step_part(
                decl,
                component,
                out,
                library_root=library_root if library_root.is_dir() else None,
            )
        else:
            report = export_step(
                decl,
                out,
                library_root=library_root if library_root.is_dir() else None,
                beam=args.beam,
                **({"beam_radius_mm": args.beam_radius} if args.beam_radius else {}),
            )
    except ExportError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    for warning in report.warnings:
        print(f"warning: {warning}", file=sys.stderr)
    print(
        f"wrote {out} — {len(report.modules)} module STEP(s), "
        f"{len(report.optics)} optic(s), {report.beam_segments} beam segment(s)"
    )
    return 0


def _library_lock(root: Path, selector: str, *, lock: bool) -> int:
    """Set `locked:` on live records — one id, or every record of a `namespace.*`.

    A locked record is what the service refuses to overwrite or archive
    (`E_RECORD_LOCKED`); locking is a content change, so the patch bumps.
    """
    from .io.yamlio import dump_document, load_document
    from .library.build import RECORD_FILES

    def _bump(version: str) -> str:
        major, minor, patch = version.split(".")
        return f"{major}.{minor}.{int(patch) + 1}"

    prefix = selector[:-2] + "." if selector.endswith(".*") else None
    changed = 0
    for folder in ("components", "templates", "modules", "groups"):
        for rec_dir in sorted((root / folder).glob("*")):
            rid = rec_dir.name
            if not (rid == selector or (prefix and rid.startswith(prefix))):
                continue
            for file in RECORD_FILES:
                path = rec_dir / file
                if not path.is_file():
                    continue
                doc = load_document(path)
                if bool(doc.get("locked", False)) == lock:
                    continue
                if lock:
                    doc["locked"] = True
                else:
                    del doc["locked"]
                doc["version"] = _bump(str(doc.get("version", "0.1.0")))
                path.write_text(dump_document(doc), encoding="utf-8")
                changed += 1
                print(f"{'locked' if lock else 'unlocked'} {rid}@{doc['version']}")
    if changed == 0:
        print(f"nothing to {'lock' if lock else 'unlock'} for {selector!r}", file=sys.stderr)
        return 1
    print(f"{changed} record(s) {'locked' if lock else 'unlocked'} — run "
          "`optikit-core library build` to refresh the index")
    return 0


def _library_restore(root: Path, record_id: str) -> int:
    """WP-68: move an archived record trio back into the live library.

    Restores the directory whose record carries ``record_id``; when that
    record is a cube module, the component and template it references are
    pulled out of the archive with it (if they are archived).
    """
    import shutil

    from .io.yamlio import (
        _to_plain,  # noqa: PLC2701 — internal helper reuse
        load_document,
    )
    from .library.build import RECORD_FILES

    archive = root / "archive"
    if not archive.is_dir():
        print(f"no archive directory at {archive}", file=sys.stderr)
        return 2

    def find(rid: str) -> tuple[Path, dict] | None:
        for file in sorted(archive.rglob("*.yml")):
            if file.name not in RECORD_FILES:
                continue
            try:
                data = _to_plain(load_document(file)) or {}
            except Exception:  # noqa: BLE001 — skip unreadable archived files
                continue
            if data.get("id") == rid:
                return file, data
        return None

    restored: list[str] = []

    def restore(rid: str) -> None:
        hit = find(rid)
        if hit is None:
            return
        file, data = hit
        src_dir = file.parent
        target = root / src_dir.relative_to(archive)
        if target.exists():
            print(f"skip {rid}: {target.relative_to(root)} already exists "
                  "in the live library", file=sys.stderr)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src_dir), str(target))
            restored.append(rid)
            print(f"restored {rid} -> {target.relative_to(root)}")
        # A module drags the component + template it references back out too.
        for ref in (data.get("component"), data.get("template")):
            if isinstance(ref, str) and "@" in ref:
                dep = ref.split("@", 1)[0]
                if dep not in restored and not any(
                    (root / kind / dep).is_dir()
                    for kind in ("components", "templates", "modules", "groups")
                ):
                    restore(dep)

    if find(record_id) is None:
        live = any(
            (root / kind / record_id).is_dir()
            for kind in ("components", "templates", "modules", "groups")
        )
        hint = " (it is already in the live library)" if live else ""
        print(f"{record_id} is not in the archive{hint}", file=sys.stderr)
        return 1

    restore(record_id)
    print(f"{len(restored)} record(s) restored — run `optikit-core library build` "
          "to refresh the index")
    return 0


#: Stamped onto every record that survives a `library reset`. It rides the
#: EXISTING `review:` machinery on purpose rather than inventing a second flag:
#: `review` already propagates module → component → template in the index, and
#: already badges the part in the palette, the library browser, the BOM and the
#: cubify dialog. So a carried-over part is visibly unconfirmed everywhere it
#: appears, and the only way to clear it is to open the record and delete the
#: note — which is exactly the "you must re-author this through the editor"
#: gate R0 asks for. A parallel flag would have needed all five surfaces
#: taught about it, and would have let someone clear one without the other.
CARRY_OVER_NOTE = (
    "carried over from the pre-reset library — the prescription has NOT been "
    "confirmed against a real part. Verify it in the component editor and "
    "delete this note before using it in a design you intend to build."
)

#: The one set the carry-over stamp does NOT touch.
#:
#: `test_the_seed_records_are_flag_free` enforces "WP-68: the starter set is
#: the quality bar — no review flags, ever", and it is right to. The starters
#: are the exemplar trio somebody copies when authoring their own part, so a
#: review flag on them would mean the thing being copied is itself unconfirmed.
#: Stamping them would also destroy what the flag MEANS: if every record is
#: flagged, "flagged" stops distinguishing importer-drafted from curated and
#: starts meaning "exists".
STARTER_TAG = "starter"


def _norm_note(text: str) -> str:
    """Collapse whitespace, so a line-wrapped YAML note compares equal.

    The carry-over note is long enough that the round-trip writer folds it
    across lines; YAML folds it back to single spaces on read, but the raw
    text differs. Every comparison of a note goes through here.
    """
    return " ".join(str(text).split())


def _library_archive(root: Path, record_id: str) -> int:
    """Move a live record into `archive/`. The mirror of :func:`_library_restore`.

    A module takes the component and template it references with it, unless
    another live module still needs them — archiving a component out from under
    a module that still points at it is how a library starts failing reference
    integrity.
    """
    import shutil

    from .io.yamlio import (
        _to_plain,  # noqa: PLC2701 — internal helper reuse
        load_document,
    )
    from .library.build import RECORD_FILES

    kinds = ("components", "templates", "modules", "groups")

    def find_live(rid: str) -> tuple[Path, dict] | None:
        for kind in kinds:
            for file in sorted((root / kind).glob("*/*.yml")):
                if file.name not in RECORD_FILES:
                    continue
                try:
                    data = _to_plain(load_document(file)) or {}
                except Exception:  # noqa: BLE001 — skip unreadable records
                    continue
                if data.get("id") == rid:
                    return file, data
        return None

    def referenced_elsewhere(dep: str, ignoring: set[str]) -> bool:
        """Does any live module still name `dep`, other than the ones going away?"""
        for file in sorted((root / "modules").glob("*/*.yml")):
            try:
                data = _to_plain(load_document(file)) or {}
            except Exception:  # noqa: BLE001
                continue
            if data.get("id") in ignoring:
                continue
            for ref in (data.get("component"), data.get("template")):
                if isinstance(ref, str) and ref.split("@", 1)[0] == dep:
                    return True
        return False

    hit = find_live(record_id)
    if hit is None:
        print(f"{record_id} is not in the live library", file=sys.stderr)
        return 1

    archived: list[str] = []
    going = {record_id}

    def archive_one(rid: str) -> None:
        found = find_live(rid)
        if found is None:
            return
        file, data = found
        src_dir = file.parent
        target = root / "archive" / src_dir.relative_to(root)
        if target.exists():
            print(f"skip {rid}: already archived at "
                  f"{target.relative_to(root)}", file=sys.stderr)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src_dir), str(target))
            archived.append(rid)
            print(f"archived {rid} -> {target.relative_to(root)}")
        for ref in (data.get("component"), data.get("template")):
            if isinstance(ref, str) and "@" in ref:
                dep = ref.split("@", 1)[0]
                if dep not in archived and not referenced_elsewhere(dep, going):
                    archive_one(dep)

    archive_one(record_id)
    print(f"{len(archived)} record(s) archived — run `optikit-core library build` "
          "to refresh the index")
    return 0


def _part_slug(node_name: str) -> str:
    """A readable component id from an Inventor node name.

    ``SUB - 0032 - MASINSLEND12.7F40 - virt ass:1`` → ``masinslend12-7f40``:
    drop the leading type code (SUB/PRT/ASS/BUY/TP), the drawing number, the
    revision and the ``virt ass`` marker, and keep the PART code — which is
    what a human calls that piece. Ugly but true; `decompose` flags the
    record for review so the author can rename it to what the bench says.
    """
    segments = [seg.strip() for seg in node_name.split(" - ") if seg.strip()]
    skip = re.compile(r"^(SUB|PRT|ASS|BUY|TP|TMP)$|^\d+$|^v\d+$|^virt ass", re.I)
    for seg in segments:
        if skip.match(seg):
            continue
        slug = re.sub(r"[^A-Za-z0-9]+", "-", seg.split(":")[0]).strip("-").lower()
        if slug:
            return slug
    return ""


def _library_compose(root: Path, args: argparse.Namespace, apply: bool) -> int:
    """WP-204b: `library compose` — the CLI half of the composer.

    Marries a published optic onto a carrier cube module's axis. Same
    authoring as ``POST /v1/library/compose``; this road exists so a library
    maintainer can compose a whole shelf from a shell script instead of
    clicking the wizard once per part.
    """
    from typing import Any

    from .library import load_library
    from .library.compose import ComposeError, compose_axis_bound, write_composed

    component_id = args.module_id
    carrier_id = getattr(args, "onto", None)
    if not component_id or not carrier_id:
        print("compose needs <component-id> --onto <carrier-module-id>", file=sys.stderr)
        return 2

    library = load_library(root)

    def _find(kind: str, record_id: str):
        hit = next((r for r in library.by_kind(kind) if r.record.id == record_id), None)
        if hit is None:
            print(f"no {kind} {record_id!r} in {root}", file=sys.stderr)
        return hit

    component = _find("optical_component", component_id)
    carrier = _find("cube_module", carrier_id)
    if component is None or carrier is None:
        return 2

    def _floats(raw: str | None, count: int, what: str) -> list[float] | None:
        if not raw:
            return None
        parts = [p.strip() for p in raw.split(",")]
        if len(parts) != count:
            print(f"--{what} wants {count} comma-separated numbers, got {raw!r}",
                  file=sys.stderr)
            return None
        try:
            return [float(p) for p in parts]
        except ValueError:
            print(f"--{what}: {raw!r} is not numeric", file=sys.stderr)
            return None

    at = _floats(getattr(args, "at", None), 3, "at")
    if getattr(args, "at", None) and at is None:
        return 2
    rng = _floats(getattr(args, "range", None), 2, "range")
    if getattr(args, "range", None) and rng is None:
        return 2
    tilt = _floats(getattr(args, "tilt", None), 3, "tilt")
    if getattr(args, "tilt", None) and tilt is None:
        return 2

    spec: dict[str, Any] = {"units": getattr(args, "units", "mm") or "mm"}
    if rng and rng[0] < rng[1]:
        spec["min"], spec["max"] = rng[0], rng[1]

    slug = getattr(args, "slug", None) or (
        f"{component_id.rsplit('.', 1)[-1]}_on_{carrier_id.rsplit('.', 1)[-1]}".lower()
    )
    # WP-240: a design-backed carrier's subdesign rides along.
    carrier_design = None
    carrier_dir = None
    if getattr(carrier.record, "design", ""):
        from .io.yamlio import load_design
        from .library.subdesigns import SubdesignError, subdesign_dir
        try:
            _, design_file = subdesign_dir(library, carrier.record.design)
            carrier_design = load_design(design_file.parent).model_dump(
                by_alias=True, exclude_defaults=True, exclude_none=True)
            carrier_dir = design_file.parent
        except (SubdesignError, ValueError, OSError) as exc:
            print(f"E_COMPOSE_TAKEN: carrier design side does not resolve ({exc})",
                  file=sys.stderr)
            return 2
    try:
        result = compose_axis_bound(
            component.record, carrier.record,
            slug=slug,
            input_name=getattr(args, "input", None) or "z",
            input_spec=spec,
            axis=getattr(args, "axis", None) or "+z",
            beam=getattr(args, "beam", None) or "+x",
            ratio=float(getattr(args, "ratio", 1.0) or 1.0),
            offset_mm=dict(zip("xyz", at, strict=True)) if at else {},
            tilt_deg=dict(zip("xyz", tilt, strict=True)) if tilt else None,
            carrier_design=carrier_design,
            carrier_dir=carrier_dir,
        )
    except ComposeError as exc:
        print(f"{exc.code}: {exc.message}", file=sys.stderr)
        return 2

    child = next(iter(result.design["components"]))
    pose = result.design["components"][child]["pose"]
    print(f"{component_id} on {carrier_id} → {result.module_id}")
    print(f"  subdesign:  {result.design_id}")
    print(f"  input:      {result.input} "
          f"{result.design['inputs'][result.input]}")
    print(f"  child:      {child} {pose.get('translation', {}).get('offset-mm', {})}")
    if "rotation" in pose:
        print(f"  seat:       {pose['rotation']['grid']}")
    print(f"  template:   {result.module['template']} (the carrier's — shared, not copied)")
    for note in result.notes:
        print(f"  NOTE {note}")
    if not apply:
        print("\ndry run — re-run with --apply to write the subdesign + module.")
        return 0

    for rel in write_composed(root, result):
        print(f"wrote {rel}")
    print("  next: `optikit-core library build` to refresh the index.")
    return 0


def _library_seats(root: Path, module_id: str, seats: str | None, apply: bool) -> int:
    """WP-246: re-author a component-backed cube module with its seats as variants.

    The insert-in-cube joint used to ride on the PLACEMENT as `mounting:`, a
    key Go does not know — so every design carrying one rendered its optic
    un-rotated in Ethan's binary. This writes the same joint as design
    `variants:` (Go-native, selected by `instantiation.variant`) and repoints
    the module's optical side at the new subdesign.

    `--seat` lists the LEGAL seats as `z/x` pairs (`--seat -x/+z --seat +y/+x`);
    the home seat is always included. Default: the seats the library's own
    designs already ask this module for.
    """
    from .io.yamlio import dump_document, load_document
    from .library import load_library
    from .library.decompose import seat_variants, write_subdesign

    library = load_library(root)
    hit = next((r for r in library.by_kind("cube_module") if r.record.id == module_id), None)
    if hit is None:
        print(f"no cube_module {module_id!r} in {root}", file=sys.stderr)
        return 2
    module = hit.record
    if getattr(module, "design", ""):
        print(f"{module_id}: already subdesign-backed ({module.design}) — its seats "
              "are the design's variants", file=sys.stderr)
        return 2
    if not module.component:
        print(f"{module_id}: has no component: side to seat", file=sys.stderr)
        return 2
    comp = next((r.record for r in library.by_kind("optical_component")
                 if r.record.id == module.component.split("@")[0]), None)
    tpl = next((r.record for r in library.by_kind("mechanical_template")
                if r.record.id == module.template.split("@")[0]), None)
    if comp is None or tpl is None:
        print(f"{module_id}: cannot resolve its component/template", file=sys.stderr)
        return 2

    if seats:
        wanted = [tuple(part.split("/", 1)) for part in seats.split(",") if part]
        bad = [w for w in wanted if len(w) != 2]
        if bad:
            print(f"--seat takes z/x pairs, e.g. -x/+z (got {bad})", file=sys.stderr)
            return 2
    else:
        wanted = sorted(mountings_for(root, module_id))
        print(f"{module_id}: {len(wanted)} seat(s) in use across the library's designs")

    try:
        result = seat_variants(comp, tpl, [tuple(w) for w in wanted])
    except ValueError as exc:
        print(f"{module_id}: {exc}", file=sys.stderr)
        return 1

    print(f"{module_id} -> {result.design_id}")
    for vid in result.variants:
        print(f"  variant {vid}")
    if not apply:
        print("(dry run — pass --apply to write)")
        return 0

    written = write_subdesign(root, result)
    # D2: ONE optical side. The component moves to the subdesign as provenance
    # (written there), so the module points at the design instead. Edited in
    # place through the comment-preserving loader — everything else in that
    # file is someone's authoring.
    doc = load_document(hit.path)
    doc.pop("component", None)
    doc["design"] = f"{result.design_id}@^0.1"
    major, minor, *_ = (str(module.version).split(".") + ["0", "0"])[:3]
    doc["version"] = f"{major}.{int(minor) + 1}.0"  # the record changed; CI checks
    tags = list(doc.get("tags") or [])
    if "subdesign" not in tags:
        tags.append("subdesign")
    doc["tags"] = tags
    hit.path.write_text(dump_document(doc))
    written.append(str(hit.path.relative_to(root)))
    for line in written:
        print(f"  wrote {line}")
    return 0


def mountings_for(root: Path, module_id: str) -> set[tuple[str, str]]:
    """Every `mounting:` grid the library's designs ask of ``module_id`` (WP-246)."""
    from .io.yamlio import load_document_text_fast

    seats: set[tuple[str, str]] = set()
    for path in sorted(root.glob("**/optikit-design.yml")):
        doc = load_document_text_fast(path.read_text(encoding="utf-8")) or {}
        for comp in (doc.get("components") or {}).values():
            if not isinstance(comp, dict):
                continue
            models = ((comp.get("primitive") or {}).get("static-models") or {})
            if str(models.get("gltf", "")).split("@")[0] != module_id:
                continue
            grid = (((comp.get("mounting") or {}).get("rotation") or {}).get("grid") or {})
            if grid:
                seats.add((str(grid.get("z") or "+z"), str(grid.get("x") or "+x")))
    return seats


def _library_decompose(root: Path, template_id: str, apply: bool) -> int:
    """WP-229: split a monolithic template into a subdesign of components.

    The record already says what moves: ``kinematics`` names the mesh
    subtrees and ``dof`` names the axis and travel. This writes that as
    Go-native structure instead — one component per moving part, its motion a
    POSE EXPRESSION over a design input — and splits the GLB so each
    component owns its geometry (:func:`glb_extract_subtrees`, which keeps
    world transforms exact and does not duplicate buffer data).

    Rotations are only emitted when the composed pose is an affine euler
    triple (GO-SYNC §6a); the 16-of-72 seat/axis pairs that are not are
    reported and left alone rather than silently mis-posed.
    """
    from typing import Any

    from .io.yamlio import dump_design, dump_document
    from .library import load_library
    from .library.mesh import glb_extract_subtrees
    from .schema.design import DesignDecl
    from .schema.library import TemplateRecord

    library = load_library(root)
    hit = next(
        (r for r in library.by_kind("mechanical_template") if r.record.id == template_id),
        None,
    )
    if hit is None:
        print(f"no mechanical_template {template_id!r} in {root}", file=sys.stderr)
        return 2
    template = hit.record
    assert isinstance(template, TemplateRecord)

    # WP-230 deleted DofSpec/KinematicsEntry from the schema, so a LEGACY
    # record's retired keys load as plain dicts via `extra="allow"` — which is
    # decompose's entire input. This adapter restores attribute access over
    # them (dashed YAML spelling first, the old field name second); a CURRENT
    # record simply has neither key and reports nothing to decompose.
    class _Legacy:
        def __init__(self, raw: dict) -> None:
            self._raw = raw

        def __getattr__(self, name: str):
            dashed = name.replace("_", "-")
            return self._raw.get(dashed, self._raw.get(name))

    dofs = [_Legacy(d) for d in (getattr(template, "dof", None) or [])
            if isinstance(d, dict)]
    kin_entries = [_Legacy(k) for k in (getattr(template, "kinematics", None) or [])
                   if isinstance(k, dict)]
    if not dofs:
        print(f"{template_id}: carries no retired dof: keys — nothing to decompose "
              "(WP-230: a current record's motion is already inputs + pose expressions)")
        return 0
    if not template.glb:
        print(f"{template_id}: declares no glb — decompose needs a mesh to split",
              file=sys.stderr)
        return 2

    mesh_path = hit.path.parent / template.glb
    if not mesh_path.is_file():
        print(f"{template_id}: {template.glb} is not on disk", file=sys.stderr)
        return 2
    data = mesh_path.read_bytes()

    # One component per DOF, from the kinematics table. A DOF with no entry
    # moves nothing in the mesh — it still becomes an input (the value is
    # real; only the geometry is missing), which is what the record said.
    by_dof: dict[str, list] = {}
    for entry in kin_entries:
        by_dof.setdefault(entry.dof, []).append(entry)

    slug = template_id.rsplit(".", 1)[-1]
    design_id = f"{template_id.split('.', 1)[0]}.subdesign.{slug}"
    out_dir = root / "subdesigns" / design_id

    inputs: dict[str, Any] = {}
    components: dict[str, Any] = {}
    files: dict[str, bytes] = {}
    notes: list[str] = []

    moving_names: set[str] = set()
    for dof in dofs:
        spec: dict[str, Any] = {"kind": "float64" if dof.kind != "parameter" else "int"}
        if dof.unit:
            spec["units"] = dof.unit
        if dof.range and len(dof.range) == 2:
            spec["min"], spec["max"] = float(dof.range[0]), float(dof.range[1])
        if dof.resolution:
            spec["resolution"] = dof.resolution
        if dof.actuation and dof.actuation != "manual":
            spec["actuation"] = dof.actuation
        inputs[dof.name] = spec

        for entry in by_dof.get(dof.name, []):
            moving_names.update(entry.nodes)
            axis = (entry.axis or "").lstrip("+-")
            sign = -1.0 if (entry.axis or "").startswith("-") else 1.0
            comp_id = _part_slug(entry.nodes[0]) or dof.name
            scale = (entry.deg_per_unit if entry.motion == "rotation"
                     else entry.mm_per_unit) or 1.0
            expr = f"~ inputs['{dof.name}'].value"
            if scale != 1.0 or sign < 0:
                expr = f"~ {sign * scale} * inputs['{dof.name}'].value"
            if entry.motion == "translation":
                pose = {"translation": {"offset-mm": {axis: expr}}}
            elif axis in ("x", "y", "z") and not dof.pivot_frame:
                # A rotation about the node's own origin, seat identity: the
                # euler triple is affine by construction (GO-SYNC §6a).
                pose = {"rotation": {"kind": "euler", "euler": {axis: expr}}}
            elif dof.pivot_frame:
                # R about a point p is T(p)·R·T(-p): the translation leaf
                # would need trig of the input, which the grammar has not
                # got. The Go-native spelling is a PARENT component at the
                # pivot whose child rotates about its own origin — that
                # needs to know where the pivot sits in the mesh, which is
                # CAD knowledge this tool does not have.
                notes.append(
                    f"{dof.name}: rotates about frame {dof.pivot_frame!r}, not the "
                    "node origin — author a parent component at the pivot and "
                    "rotate its child (an expression cannot move the pivot)"
                )
                continue
            else:
                notes.append(
                    f"{dof.name}: rotation about {entry.axis!r} is not an F3 axis — "
                    "left for hand-authoring (the pivot needs its own parent component)"
                )
                continue
            # Two DOFs may drive the SAME node (a gimbal: tilt_x and tilt_y
            # on one mirror). Merge the pose leaves rather than letting the
            # second entry clobber the first — an extrinsic-ZXY triple holds
            # all three axes, which is exactly what a gimbal needs.
            existing = components.get(comp_id)
            if existing is not None:
                merged = existing["pose"]
                for block, leaves in pose.items():
                    target = merged.setdefault(block, {})
                    for sub, values in leaves.items():
                        if isinstance(values, dict):
                            target.setdefault(sub, {}).update(values)
                        else:
                            target[sub] = values  # `kind: euler`, a scalar
                continue
            components[comp_id] = {
                "kind": "primitive",
                "category": "mechanics",
                "primitive": {"static-models": {"gltf": f"{comp_id}.glb"}},
                "pose": pose,
            }
            try:
                files[f"{comp_id}.glb"] = glb_extract_subtrees(data, set(entry.nodes))
            except ValueError as exc:
                print(f"{template_id}: {exc}", file=sys.stderr)
                return 2

    if not components:
        print(f"{template_id}: no kinematics entry resolves to a moving component")
        for note in notes:
            print(f"  {note}")
        return 1

    # Everything that does not move is the body, in one piece.
    files["body.glb"] = glb_extract_subtrees(data, moving_names, invert=True)
    components = {
        "body": {
            "kind": "primitive",
            "category": "mechanics",
            "primitive": {"static-models": {"gltf": "body.glb"}},
        },
        **components,
    }

    decl = DesignDecl.model_validate({
        "optikit-version": "v0.0.0-alpha.1",
        "design": {
            "name": slug.replace("_", "-"),
            "version": "0.1.0",
            "description": template.description or f"{template_id}, decomposed",
        },
        "inputs": inputs,
        "components": components,
    })
    record = {
        "kind": "cube_subdesign",
        "id": design_id,
        "version": "0.1.0",
        "description": f"{template.description or template_id} (decomposed, WP-229)",
        "tags": list(template.tags),
        "review": [
            f"decomposed from {template_id} by `library decompose` — the optics "
            "still live on the module's component record; move them onto the "
            "moving child if the optic is what travels",
        ],
    }

    print(f"{template_id} → {design_id}")
    print(f"  inputs:     {', '.join(inputs) or 'none'}")
    print(f"  components: {', '.join(components)}")
    for name, blob in sorted(files.items()):
        print(f"  {name}: {len(blob):,} B")
    for note in notes:
        print(f"  NOTE {note}")
    if not apply:
        print("\ndry run — re-run with --apply to write the subdesign folder.")
        return 0

    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "subdesign.yml").write_text(dump_document(record))
    (out_dir / "optikit-design.yml").write_text(dump_design(decl))
    for name, blob in files.items():
        (out_dir / name).write_bytes(blob)
    print(f"\nwrote {out_dir}")
    print("  next: point the module at it (`design:` instead of `component:`),")
    print("        drop `dof:`/`kinematics:` from the template, `library build`.")
    return 0


def _drop_mesh_frame(record_dir: Path) -> bool:
    """Remove `mesh-frame:` from the record beside a re-framed mesh (WP-234).

    Comment-preserving: everything else in the file is someone's authoring.
    Returns whether a key was actually removed.
    """
    from .io.yamlio import dump_document, load_document

    changed = False
    for name in ("template.yml", "component.yml", "module.yml", "subdesign.yml"):
        path = record_dir / name
        if not path.is_file():
            continue
        data = load_document(path)
        if not isinstance(data, dict) or "mesh-frame" not in data:
            continue
        del data["mesh-frame"]
        path.write_text(dump_document(data))
        changed = True
    return changed


def _library_retessellate(
    root: Path,
    apply: bool,
    linear: float | None,
    angular: float | None,
    reframe: bool = False,
) -> int:
    """WP-231: re-mesh every GLB from its STEP at the current tolerance.

    Decimating an existing triangle mesh throws away what the CAD knew; when
    the STEP sits next to the GLB (it does for every template in the shipped
    libraries) re-tessellating from the source is both simpler and better —
    the surfaces are re-sampled, not approximated twice.

    A GLB with no STEP beside it is REPORTED, not touched: decimating it is a
    different job (WP-224's converter work) and silently leaving it out of
    the report would hide the part of the library this cannot help.

    **Frame guard.** Re-meshing is only safe when the result lands in the
    same frame as the file it replaces, and it often does NOT: the library
    holds two glTF conventions, and a GLB that PyInventor exported directly
    does not agree with what OCCT writes from the same STEP. Measured the
    hard way — a blind run turned 0 `E_MESH_AXES_PERMUTED` into 5. So every
    candidate is meshed to a temporary file first and its bounding box
    compared with the original's; a part whose extents permute or move is
    REFUSED, with the axes named. Those need their `mesh-frame` re-declared
    (or a re-export), which is a record decision, not a mesh one.
    """
    from .importers.step_glb import ANG_DEFLECTION, LIN_DEFLECTION, step_file_to_glb
    from .library.mesh import glb_bounding_box

    lin = LIN_DEFLECTION if linear is None else linear
    ang = ANG_DEFLECTION if angular is None else angular
    print(f"{root}: re-tessellating at linear={lin} mm, angular={ang} rad")

    pairs: list[tuple[Path, Path]] = []
    orphans: list[Path] = []
    for glb in sorted(root.rglob("*.glb")):
        stems = [
            p for p in glb.parent.iterdir()
            if p.suffix.lower() in (".stp", ".step") and p.stem == glb.stem
        ] or [
            p for p in glb.parent.iterdir() if p.suffix.lower() in (".stp", ".step")
        ]
        (pairs.append((glb, stems[0])) if stems else orphans.append(glb))

    if not pairs and not orphans:
        print("  no GLB assets here")
        return 0

    import shutil
    import tempfile

    before = after = 0
    failed: list[str] = []
    refused: list[str] = []
    reframed: list[str] = []
    #: A coarser mesh moves the surface by up to the chord error, so the box
    #: may breathe by that much — anything beyond is a frame change.
    tol = max(lin * 4, 0.5)
    for glb, step in pairs:
        was = glb.stat().st_size
        before += was
        try:
            with tempfile.TemporaryDirectory() as tmp:
                probe = Path(tmp) / glb.name
                step_file_to_glb(step, probe, linear=lin, angular=ang)
                now = probe.stat().st_size
                old_box, new_box = glb_bounding_box(glb), glb_bounding_box(probe)
                drift = [abs(a - b) for a, b in zip(old_box.size, new_box.size, strict=True)]
                # WP-234 `--reframe`: the migration to a single glTF
                # convention WANTS the frame to change — the whole point is
                # that the re-meshed file is cube-frame, so `mesh-frame` can
                # be retired. Only a PERMUTATION is allowed through: the same
                # three extents in a different order is a rotation, while a
                # changed extent means a different part or a broken
                # conversion, which stays refused either way.
                # Compare SORTED extents within the same tolerance the drift
                # check uses: a coarser mesh legitimately shrinks the box by
                # up to the chord error, so an exact match would reject real
                # permutations (25.4 -> 25.2 is the mesh, not a different
                # part).
                permuted = all(
                    abs(a - b) <= tol
                    for a, b in zip(sorted(old_box.size), sorted(new_box.size), strict=True)
                )
                if reframe and max(drift) > tol and permuted:
                    reframed.append((glb, f"{glb.parent.name}/{glb.name}"))
                elif max(drift) > tol:
                    refused.append(
                        f"{glb.parent.name}/{glb.name}: extents "
                        f"{tuple(round(v, 1) for v in old_box.size)} -> "
                        f"{tuple(round(v, 1) for v in new_box.size)} — the STEP "
                        "and this GLB are in different frames; re-declare "
                        "`mesh-frame` or re-export, do not re-mesh"
                    )
                    after += was
                    continue
                if apply:
                    shutil.copyfile(probe, glb)
        except Exception as exc:  # a broken STEP is its own finding
            failed.append(f"{glb.parent.name}/{glb.name}: {exc}")
            after += was
            continue
        after += now
        pct = (1 - now / was) * 100 if was else 0.0
        print(f"  {glb.parent.name}/{glb.name}: "
              f"{was / 1e6:.1f} -> {now / 1e6:.1f} MB ({pct:+.0f}%)")

    for glb in orphans:
        print(f"  SKIP {glb.parent.name}/{glb.name}: no STEP beside it "
              f"({glb.stat().st_size / 1e6:.1f} MB) — needs mesh decimation, not re-meshing")
    for glb, label in reframed:
        # The mesh IS cube-frame now, so a record still declaring
        # `mesh-frame: record` would misdescribe it — drop the key in the
        # same pass that changed the file, never as a separate step someone
        # can forget.
        dropped = _drop_mesh_frame(glb.parent) if apply else True
        print(f"  REFRAMED {label}: now cube-frame"
              + ("  — `mesh-frame` dropped" if dropped else ""))
    for line in refused:
        print(f"  REFUSED {line}")
    for line in failed:
        print(f"  FAIL {line}")

    saved = before - after
    print(f"\n  {len(pairs)} re-meshed: {before / 1e6:.1f} -> {after / 1e6:.1f} MB "
          f"({saved / 1e6:+.1f} MB, {saved / before * 100 if before else 0:.0f}% smaller)")
    if refused:
        print(f"  {len(refused)} refused on a frame change — see above.")
    if not apply:
        print("  dry run — re-run with --apply to write the meshes.")
    return 1 if failed else 0


def _library_mergemesh(root: Path, apply: bool) -> int:
    """WP-224: collapse each GLB's primitives by material.

    OCCT writes one glTF primitive per B-rep face, and every primitive is a
    draw call — measured across the shipped libraries, 62,624 of them, with
    one galvo board accounting for 11,275. That is the 2-3 fps in the
    assembly view, and it is fixed in the FILE, not the renderer.

    Merging is exact (primitives in a mesh share its node transform, so
    concatenating those with the same material and mode changes nothing you
    can see) and is verified per file: the bounding box before and after must
    agree, or the file is left alone and reported.
    """
    from .library.glb_merge import merge_glb_file

    files = sorted(p for p in root.rglob("*.glb") if "archive" not in p.parts)
    if not files:
        print("  no GLB assets here")
        return 0

    before = after = 0
    failed: list[str] = []
    for glb in files:
        try:
            if apply:
                # merge_glb_file verifies BEFORE it writes and raises rather
                # than damaging the asset, so there is nothing to undo here.
                result = merge_glb_file(glb)
            else:
                from .library.glb_merge import merge_by_material
                from .library.mesh import _chunks

                gltf, binary = _chunks(glb.read_bytes())
                _merged, _bin, result = merge_by_material(gltf, binary or b"")
        except Exception as exc:
            failed.append(f"{glb.parent.name}/{glb.name}: {exc}")
            continue
        before += result.before
        after += result.after
        if result.saved:
            print(f"  {glb.parent.name}/{glb.name}: "
                  f"{result.before:,} -> {result.after} primitives "
                  f"({result.before // max(result.after, 1)}x)")

    for line in failed:
        print(f"  FAIL {line}")
    print(f"\n  {len(files)} file(s): {before:,} -> {after:,} draw calls "
          f"({before // max(after, 1)}x fewer)")
    if not apply:
        print("  dry run — re-run with --apply to write the meshes.")
    return 1 if failed else 0


def _library_sidecar(root: Path, apply: bool) -> int:
    """WP-232: move each component's prescription into a standalone file.

    The record keeps its identity, frames and ports — what positions the
    glass in the cube. The prescription moves to a file Optiland loads
    directly, which is what makes it portable: someone with Optiland and no
    knowledge of the DSN can open it.

    Every sidecar is VERIFIED against optiland before it is written (when the
    `sim` extra is installed): a file that does not load is worse than an
    inline fragment, because it looks like an interchange format.
    """
    from .export.optiland_sidecar import SIDECAR_NAME, component_to_optiland, sidecar_text
    from .io.yamlio import dump_document, load_document
    from .schema.library import ComponentRecord, load_record

    try:
        from optiland.optic import Optic
    except ImportError:
        Optic = None  # type: ignore[assignment]
        print("optiland not installed (uv sync --extra sim) — writing WITHOUT "
              "the load check, which is the whole point of the format")

    written = skipped = failed = 0
    for file in sorted(root.rglob("component.yml")):
        if {"dist", "archive"} & set(file.relative_to(root).parts):
            continue
        try:
            data = dict(load_document(file) or {})
            record = load_record(data)
        except Exception as exc:
            print(f"  SKIP {file.parent.name}: does not load ({exc})")
            failed += 1
            continue
        if not isinstance(record, ComponentRecord):
            continue
        optics = data.get("optics") or {}
        if "fragment" not in optics:
            skipped += 1
            continue

        if Optic is not None:
            try:
                Optic.from_dict(component_to_optiland(record))
            except Exception as exc:
                print(f"  FAIL {record.id}: optiland refuses the sidecar "
                      f"({type(exc).__name__}: {exc})")
                failed += 1
                continue

        surfaces = len((optics.get("fragment") or {}).get("surfaces", []))
        print(f"  {record.id}: {surfaces} surface(s) -> {SIDECAR_NAME}")
        if not apply:
            continue
        (file.parent / SIDECAR_NAME).write_text(sidecar_text(record))
        # Rewrite the record: the prescription is a reference now, and the
        # frames/ports stay exactly where they were.
        optics.pop("fragment")
        optics["fragment-file"] = SIDECAR_NAME
        data["optics"] = optics
        file.write_text(dump_document(data))
        written += 1

    print(f"\n  {written} written, {skipped} already referenced or fragment-less, "
          f"{failed} failed")
    if not apply:
        print("  dry run — re-run with --apply to write the sidecars.")
    return 1 if failed else 0


def _library_migrate(root: Path, apply: bool) -> int:
    """WP-230: bring a library or design tree onto the current DSN spelling.

    Dry run by default — it prints what each migration WOULD rewrite, because
    this edits records in place and a shared library is somebody's working
    tree. Idempotent: a migrated tree reports nothing on the next run.
    """
    from .library.migrate import MIGRATIONS, migrate_tree, yaml_files

    files = list(yaml_files(root))
    print(f"{root}: {len(files)} YAML file(s)")
    if not apply:
        # Dry run: copy the tree, migrate the copy, report, discard.
        import shutil
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            mirror = Path(tmp) / root.name
            shutil.copytree(root, mirror)
            report = migrate_tree(mirror)
    else:
        report = migrate_tree(root)

    total = 0
    for name, _run, desc in MIGRATIONS:
        touched = report.get(name, {})
        count = sum(touched.values())
        total += count
        print(f"\n  {name}: {desc}")
        if not touched:
            print("    nothing to do")
            continue
        for rel, n in sorted(touched.items()):
            print(f"    {rel}: {n} key(s)")
    if not apply:
        print(f"\ndry run — {total} key(s) would change. Re-run with --apply to write.")
    else:
        print(f"\nrewrote {total} key(s) in {root}")
    return 0


def _library_reset(root: Path, apply: bool) -> int:
    """R0 curated carry-over: archive what an importer guessed, flag what stays.

    The rule is one line — **a record carrying a `review:` block was drafted by
    an importer and nobody confirmed it, so it does not survive the reset** —
    and the interesting part is what happens to the survivors: they are stamped
    with :data:`CARRY_OVER_NOTE`, which makes them badge as unreviewed
    everywhere the palette shows them until a human opens the record and
    deletes the note.

    Archiving is trio-aware (a module drags its component and template unless
    another module still needs them), so reference integrity holds afterwards
    — which `library validate` will confirm.

    Dry run by default. This moves directories and rewrites records; it should
    be read before it is run.
    """
    from .io.yamlio import (
        _to_plain,  # noqa: PLC2701 — internal helper reuse
        dump_document,
        load_document,
    )
    from .library.build import RECORD_FILES

    doomed: list[tuple[str, str, int]] = []          # (kind, id, note count)
    survivors: list[tuple[Path, str, bool]] = []      # (file, id, is_starter)
    module_refs: dict[str, tuple[str, str]] = {}      # module id → (comp id, tpl id)
    for kind in ("components", "templates", "modules", "groups"):
        for file in sorted((root / kind).glob("*/*.yml")):
            if file.name not in RECORD_FILES:
                continue
            try:
                data = _to_plain(load_document(file)) or {}
            except Exception:  # noqa: BLE001
                continue
            rid = data.get("id") or file.parent.name
            if kind == "modules":
                refs = tuple(
                    str(data.get(k) or "").split("@", 1)[0]
                    for k in ("component", "template")
                )
                module_refs[rid] = refs  # type: ignore[assignment]
            # A record's OWN carry-over stamp is not an importer's guess. Left
            # uncounted, the second run of a reset archives everything the
            # first one carried over — the stamp would be a slow delete.
            notes = [n for n in (data.get("review") or [])
                     if _norm_note(n) != _norm_note(CARRY_OVER_NOTE)]
            if notes:
                doomed.append((kind, rid, len(notes)))
            else:
                survivors.append((file, rid, STARTER_TAG in (data.get("tags") or [])))

    # A trio is archived whole. A module whose component or template is doomed
    # would otherwise survive pointing at a record that is no longer there —
    # `library validate` then fails with "does not resolve", and `library
    # build` refuses to write an index at all, which is how a reset produces a
    # catalogue that cannot be served. The reverse direction (a doomed module
    # dragging its private component out) is `_library_archive`'s job and is
    # already guarded by `referenced_elsewhere`.
    doomed_ids = {rid for _kind, rid, _n in doomed}
    orphaned: list[tuple[str, str, int]] = []
    for mod_id, (comp_id, tpl_id) in sorted(module_refs.items()):
        if mod_id in doomed_ids:
            continue
        if comp_id in doomed_ids or tpl_id in doomed_ids:
            orphaned.append(("modules", mod_id, 0))
            doomed_ids.add(mod_id)
    if orphaned:
        doomed.extend(orphaned)
        survivors = [(f, rid, st) for f, rid, st in survivors if rid not in doomed_ids]

    print(f"{len(doomed)} record(s) carry a review: block and will be ARCHIVED")
    if orphaned:
        print(f"  ({len(orphaned)} of them are modules whose component or template "
              f"is going — a trio is archived whole)")
    for kind, rid, n in doomed:
        print(f"  archive  {kind:11} {rid}  ({n} note(s))")
    print()
    starters = [rid for _f, rid, is_starter in survivors if is_starter]
    print(f"{len(survivors)} record(s) are clean and will be CARRIED OVER "
          f"({len(survivors) - len(starters)} stamped unreviewed, "
          f"{len(starters)} starter record(s) left untouched)")
    for _file, rid, is_starter in survivors:
        print(f"  {'starter ' if is_starter else 'carry   '} {rid}")

    if not apply:
        print()
        print("dry run — nothing moved. Re-run with --apply to perform the reset.")
        return 0

    for _kind, rid, _n in doomed:
        _library_archive(root, rid)

    stamped = 0
    for file, rid, is_starter in survivors:
        if is_starter:
            continue  # the quality bar keeps its meaning (see STARTER_TAG)
        if not file.is_file():
            continue  # archived as a trio dependency in the loop above
        doc = load_document(file)
        existing = list(_to_plain(doc).get("review") or [])
        # Compared on normalized whitespace: the YAML writer line-wraps a note
        # this long, and a re-read gives back the folded form. Comparing raw
        # would stack a duplicate stamp on every run.
        if any(_norm_note(n) == _norm_note(CARRY_OVER_NOTE) for n in existing):
            continue
        doc["review"] = [*existing, CARRY_OVER_NOTE]
        file.write_text(dump_document(doc), encoding="utf-8", newline="\n")
        stamped += 1
        print(f"flagged  {rid}")

    print()
    print(f"reset applied: {len(doomed)} archived, {stamped} carried over and "
          f"flagged, {len(starters)} starter record(s) untouched.")
    print("Every carried-over part now badges as unreviewed in the palette until "
          "someone confirms it in the component editor and removes the note.")
    print("Run `optikit-core library validate` then `library build`.")
    return 0


def cmd_library(args: argparse.Namespace) -> int:
    from .library import (
        LibraryError,
        build_index,
        check_references,
        load_library,
        write_index,
    )

    root = Path(args.root) if args.root else default_library_root()
    if not root.is_dir():
        print(f"no library directory at {root}", file=sys.stderr)
        return 2

    if args.subcommand == "archive":
        if not args.module_id:
            print("archive needs a <record-id>", file=sys.stderr)
            return 2
        return _library_archive(root, args.module_id)

    if args.subcommand == "migrate":
        return _library_migrate(root, apply=bool(getattr(args, "apply", False)))

    if args.subcommand == "compose":
        return _library_compose(root, args, apply=bool(getattr(args, "apply", False)))

    if args.subcommand == "seats":
        if not args.module_id:
            print("seats needs a <cube-module-id>", file=sys.stderr)
            return 2
        return _library_seats(root, args.module_id, getattr(args, "seat", None),
                              apply=bool(getattr(args, "apply", False)))

    if args.subcommand == "decompose":
        if not args.module_id:
            print("decompose needs a <template-id>", file=sys.stderr)
            return 2
        return _library_decompose(root, args.module_id,
                                  apply=bool(getattr(args, "apply", False)))

    if args.subcommand == "retessellate":
        return _library_retessellate(
            root,
            apply=bool(getattr(args, "apply", False)),
            linear=getattr(args, "linear", None),
            angular=getattr(args, "angular", None),
            reframe=bool(getattr(args, "reframe", False)),
        )

    if args.subcommand == "mergemesh":
        return _library_mergemesh(root, apply=bool(getattr(args, "apply", False)))

    if args.subcommand == "sidecar":
        return _library_sidecar(root, apply=bool(getattr(args, "apply", False)))

    if args.subcommand == "reset":
        return _library_reset(root, apply=bool(getattr(args, "apply", False)))

    if args.subcommand == "restore":
        # WP-68: move an archived record trio back into the live library.
        if not args.module_id:
            print("restore needs a <record-id>", file=sys.stderr)
            return 2
        return _library_restore(root, args.module_id)

    if args.subcommand in ("lock", "unlock"):
        if not args.module_id:
            print(f"{args.subcommand} needs a <record-id> or <namespace>.*", file=sys.stderr)
            return 2
        return _library_lock(root, args.module_id, lock=args.subcommand == "lock")

    library = load_library(root)

    if args.subcommand == "vendor-assets":
        # WP-58: pull remotely-referenced meshes next to their record so the
        # ONE library has ONE asset home (the WP-43 migration left 64 records
        # naming a local file they never shipped).
        from .library.vendor import plan, vendor_all

        pending = plan(library)
        if not pending:
            print("nothing to vendor — every referenced asset is already local")
            return 0
        if args.dry_run:
            for item in pending:
                print(f"WOULD FETCH  {item.record_id}\n             {item.url}\n"
                      f"          -> {item.target}")
            print(f"\n{len(pending)} asset(s) would be downloaded")
            return 0
        fetched, failed = vendor_all(library)
        for item, size in fetched:
            print(f"OK   {item.record_id}: {size / 1024:.0f} KiB -> {item.target.name}")
        for item, error in failed:
            print(f"FAIL {item.record_id}: {error}", file=sys.stderr)
        print(f"\nvendored {len(fetched)}, failed {len(failed)}")
        return 1 if failed else 0

    if args.subcommand == "migrate-materials":
        # WP-63: one-shot repair of the WP-43 migration's invented material
        # tag — {type: "ideal"} → optiland's registry vocabulary. A purely
        # mechanical edit through the ruamel round-trip (comments and review
        # flags untouched).
        from .io.yamlio import dump_document, load_document

        changed = 0
        for path in sorted(root.glob("**/component.yml")):
            if "dist" in path.parts:
                continue
            doc = load_document(path)
            surfaces = ((((doc or {}).get("optics") or {}).get("fragment") or {})
                        .get("surfaces") or [])
            touched = False
            for surface in surfaces:
                for key in ("material_post", "material_pre"):
                    material = surface.get(key)
                    if not (isinstance(material, dict) and material.get("type") == "ideal"):
                        continue
                    if material.get("name"):
                        material["type"] = "Material"
                    elif "index" in material:
                        material["type"] = "IdealMaterial"
                    else:
                        print(f"SKIP {path}: bare {{type: ideal}} with neither "
                              "name nor index", file=sys.stderr)
                        continue
                    touched = True
            if touched:
                path.write_text(dump_document(doc), encoding="utf-8")
                changed += 1
                print(f"migrated {path.relative_to(root)}")
        print(f"\n{changed} record(s) rewritten onto optiland's registry vocabulary")
        return 0

    if args.subcommand == "verify-t1":
        from .library.verify import verify_t1, verify_t1_ok

        if not args.module_id:
            print("verify-t1 needs a <module-id>", file=sys.stderr)
            return 2
        findings = verify_t1(library, args.module_id)
        for finding in findings:
            print(finding, file=sys.stderr if finding.level == "error" else sys.stdout)
        if not verify_t1_ok(findings):
            return 1
        print(f"OK  {args.module_id}: optics and mechanics agree (T1)")
        return 0

    errors = list(library.errors)
    errors += check_references(library)

    # WP-40: surfaces are the truth — warn where a component's authored port
    # directions disagree with what its fragment + frame rotations imply.
    from .library.actuation import check_actuation
    from .library.derive import check_port_directions
    from .schema.library import ComponentRecord as _CompRec

    direction_warnings: list[str] = []
    for record in library.records:
        if isinstance(record.record, _CompRec):
            direction_warnings += [
                f"{record.record.id}: {w}" for w in check_port_directions(record.record)
            ]

    # WP-42: the actuation contract — template DOFs ↔ module firmware axis-map.
    actuation_warnings: list[str] = []
    for level, code, message in check_actuation(library):
        if level == "error":
            errors.append(LibraryError("", f"{code}: {message}"))
        else:
            actuation_warnings.append(f"{code}: {message}")

    kinematics_warnings: list[str] = []  # WP-230: the contract retired with `dof:`

    # KIT-00: read every fragment through the canvas dialect and surface its
    # findings informationally. Dialect errors do not fail `library validate`
    # yet — they become blocking when the materializer (KIT-02+) consumes them.
    from .canvas import parse_fragment

    dialect_findings: list[str] = []
    for record in library.records:
        rec = record.record
        if not isinstance(rec, _CompRec) or rec.optics.fragment is None:
            continue
        where = f"{rec.id}.optics.fragment.surfaces"
        for finding in parse_fragment(rec.optics.fragment.surfaces, where).findings:
            dialect_findings.append(str(finding))

    # WP-48: authored schematic symbols — present, scalable, themable.
    # WP-47: slm/display records carry their pixel facts.
    from .library.symbols import check_programmable_records, check_symbols

    symbol_warnings: list[str] = []
    for level, code, message in check_symbols(library) + check_programmable_records(library):
        if level == "error":
            errors.append(LibraryError("", f"{code}: {message}"))
        else:
            symbol_warnings.append(f"{code}: {message}")

    # WP-109: a cube template's MESH must measure the cell it claims. The
    # library carries two undeclared glTF frame conventions (one ships an
    # Rx(-90°) wrapper node, one does not), and the way that fails is a cube
    # rendering on its side. Checking the bounding box catches a lost wrapper,
    # wrong units and the wrong file at once — no new schema field needed.
    from .library.mesh import check_template_mesh
    from .schema.library import TemplateRecord as _TplRec

    mesh_warnings: list[str] = []
    for record in library.records:
        tpl = record.record
        if not isinstance(tpl, _TplRec) or not tpl.glb:
            continue
        glb_path = record.path.parent / tpl.glb
        if not glb_path.is_file():
            continue
        env = tpl.envelope
        envelope = (
            (float(env.x_mm), float(env.y_mm), float(env.z_mm)) if env else None
        )
        pose = getattr(tpl, "mesh_pose", None)
        pose_grid = (
            (pose.rotation.grid.z or "+z", pose.rotation.grid.x or "+x")
            if pose is not None
            else None
        )
        # WP-156: a residual tilt (housings only — the schema rejects it on
        # cube-mounted templates) switches the mesh checks to their
        # orientation-tolerant readings.
        pose_off = pose.rotation.offset_deg if pose is not None else None
        pose_tilted = pose_off is not None and any(
            abs(float(v or 0.0)) > 1e-9 for v in (pose_off.x, pose_off.y, pose_off.z)
        )
        for level, code, message in check_template_mesh(
            tpl.id, envelope, tpl.footprint_grid, tpl.provenance, glb_path,
            mesh_frame=getattr(tpl, "mesh_frame", ""),
            # WP-137: the file->cube correction, when declared.
            mesh_pose_grid=pose_grid,
            mesh_pose_tilted=pose_tilted,
            # WP-134: the AS-MOUNTED ports (cube frame) are what the glass has
            # to agree with — the record's own F2 ports describe an unmounted
            # optic and say nothing about which way the mirror ended up facing.
            optical_ports={
                name: str(port.direction)
                for name, port in (tpl.optical_ports or {}).items()
                if isinstance(port.direction, str)
            },
        ):
            if level == "error":
                errors.append(LibraryError("", f"{code}: {message}"))
            else:
                mesh_warnings.append(f"{code}: {message}")

    # WP-53: group structure — envelope, overlaps, sandwich plates, joints.
    from .library.groups import check_groups

    group_warnings: list[str] = []
    for finding in check_groups(library):
        if finding.level == "error":
            errors.append(LibraryError("", f"{finding.code}: {finding.message}"))
        else:
            group_warnings.append(f"{finding.code}: {finding.message}")

    for record in sorted(library.records, key=lambda r: (r.record.kind, r.record.id)):
        flag = " [review]" if record.record.review else ""
        print(f"OK  {record.record.kind:<20} {record.record.id}@{record.record.version}{flag}")
    for warning in (
        direction_warnings + actuation_warnings + kinematics_warnings
        + symbol_warnings + group_warnings + mesh_warnings
    ):
        print(f"WARN {warning}")
    for finding in dialect_findings:
        print(f"DIALECT {finding}")
    for error in errors:
        print(f"ERR {error}", file=sys.stderr)

    if errors:
        return 1
    if args.subcommand == "build":
        out = write_index(library, root)
        index = build_index(library, root)
        print(f"wrote {out} ({index['count']} module(s))")
    return 0


def cmd_import_layout_json(args: argparse.Namespace) -> int:
    from .importers.layout_json import import_layout_json
    from .library import load_library

    root = Path(args.library) if args.library else default_library_root()
    library = load_library(root)
    source = Path(args.layout)
    result = import_layout_json(source, library, name=args.name)

    out_dir = Path(args.out) if args.out else source.with_suffix(".dsn")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / "optikit-design.yml"
    out_file.write_text(result.design_yaml, encoding="utf-8")

    print(f"wrote {out_file} ({result.components} component(s))")
    for warning in result.warnings:
        print(f"WARN {warning}")
    if result.unresolved:
        print(f"⚠ {len(result.unresolved)} unresolved module reference(s) — "
              f"review before publishing")
    return 0


def cmd_group(args: argparse.Namespace) -> int:
    import json

    from .library import load_library
    from .library.groups import suggest_structure
    from .schema.library import GroupRecord

    root = Path(args.root) if args.root else default_library_root()
    library = load_library(root)
    hit = next(
        (
            e for e in library.by_kind("cube_group")
            if isinstance(e.record, GroupRecord) and e.record.id == args.group_id
        ),
        None,
    )
    if hit is None:
        print(f"no group {args.group_id!r} in {root}", file=sys.stderr)
        return 2
    assert isinstance(hit.record, GroupRecord)
    suggestion = suggest_structure(hit.record, library)
    print(json.dumps(suggestion, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="optikit-core",
        description="Normative datamodel tools for the openUC2 Optikit toolchain",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    validate = sub.add_parser(
        "validate",
        help="validate design files (a .dsn dir, an optikit-design.yml, or a tree of them)",
    )
    validate.add_argument("paths", nargs="+", help="design dirs/files or trees to scan")
    validate.add_argument(
        "-W", "--warnings", action="store_true", help="also print warning-level findings"
    )
    validate.set_defaults(func=cmd_validate)

    flatten_p = sub.add_parser(
        "flatten",
        help="anchor-resolve a design and report primitive world poses (Go: report primitives)",
    )
    flatten_p.add_argument("path", help="design dir or optikit-design.yml")
    flatten_p.add_argument("--format", choices=["yaml", "json"], default="yaml")
    flatten_p.set_defaults(func=cmd_flatten)

    cubify_p = sub.add_parser(
        "cubify",
        help="decompose world poses into grid poses (p = S·g + δ, R = R24·ΔR) and run DRC",
    )
    cubify_p.add_argument("path", help="design dir or optikit-design.yml")
    cubify_p.set_defaults(func=cmd_cubify)

    go_dsn_p = sub.add_parser(
        "go-dsn",
        help="export the design as a Go-composable nested .dsn folder "
        "(library modules become materialized subdesigns, WP-172)",
    )
    go_dsn_p.add_argument("path", help="design dir or optikit-design.yml")
    go_dsn_p.add_argument("out", help="output directory (the .dsn folder)")
    go_dsn_p.add_argument("--library", default=None, help="library dir (default: repo library/)")
    go_dsn_p.set_defaults(func=cmd_go_dsn)

    chain_p = sub.add_parser(
        "chain",
        help="infer paths: blocks by chief-ray propagation over world poses",
    )
    chain_p.add_argument("design", help="design dir or optikit-design.yml")
    chain_p.add_argument("--infer", action="store_true", required=True,
                         help="run inference (explicit by design)")
    chain_p.add_argument("--write", action="store_true",
                         help="merge proposed paths into the design file")
    chain_p.set_defaults(func=cmd_chain)

    compile_p = sub.add_parser(
        "compile",
        help="compile a design path to a native Optiland optic.json + trace manifest",
    )
    compile_p.add_argument("design", help="design dir or optikit-design.yml")
    compile_p.add_argument(
        "--path", dest="path_name", default=None,
        help="path name to compile (default: every declared path)",
    )
    compile_p.add_argument("--out", default=".", help="output directory (default: cwd)")
    compile_p.add_argument(
        "--summary", action="store_true",
        help="also write summary.json with paraxial properties (requires optiland)",
    )
    compile_p.set_defaults(func=cmd_compile)

    annotate_p = sub.add_parser(
        "back-annotate",
        help="classify an optimized optic.json against the design (dry run by default)",
    )
    annotate_p.add_argument("design", help="design dir or optikit-design.yml")
    annotate_p.add_argument("optimized", help="optimized optic.json from Optiland")
    annotate_p.add_argument("--path", dest="path_name", required=True, help="path name")
    annotate_p.add_argument(
        "--apply", action="store_true",
        help="write accepted deltas into the components' instantiation.inputs + provenance",
    )
    annotate_p.add_argument("--optimized-by", default="optiland", help="provenance tool tag")
    annotate_p.set_defaults(func=cmd_back_annotate)

    # WP-86: the OTHER return leg — a running instrument's measured axes.
    calib_p = sub.add_parser(
        "calibrate",
        help="classify measured instrument axis positions against the design "
             "(dry run by default) — the hardware return leg",
    )
    calib_p.add_argument("design", help="design dir or optikit-design.yml")
    calib_p.add_argument(
        "measurements",
        help="JSON: {'<component>.<dof>': <measured value in the dof's unit>, …}",
    )
    calib_p.add_argument(
        "--apply", action="store_true",
        help="write measured values into the components' instantiation.inputs + "
             "provenance {source: instrument}",
    )
    calib_p.add_argument("--instrument", default="", help="instrument id / device URL")
    calib_p.add_argument("--note", default="", help="free-text provenance note")
    calib_p.set_defaults(func=cmd_calibrate)

    serve_p = sub.add_parser("serve", help="run the HTTP service (FastAPI/uvicorn)")
    serve_p.add_argument(
        "--host", default="127.0.0.1",
        help="bind address (default: loopback only — see WP-188; pass 0.0.0.0 "
             "to expose it, only behind a proxy that authenticates)")
    serve_p.add_argument("--port", type=int, default=8000)
    serve_p.add_argument(
        "--library-root", metavar="DIR", default="",
        help="record library to serve and write (sets OPTIKIT_LIBRARY_ROOT; "
             "default: the library/ beside this checkout). Point it at your "
             "clone of the dedicated library repo, e.g. ~/optikit-library/library",
    )
    serve_p.set_defaults(func=cmd_serve)

    library_p = sub.add_parser("library", help="validate and index the record library")
    library_p.add_argument(
        "subcommand",
        choices=["validate", "build", "verify-t1", "vendor-assets", "migrate-materials",
                 "migrate", "decompose", "compose", "seats", "retessellate", "mergemesh",
                 "sidecar",
                 "archive", "reset", "restore", "lock", "unlock"],
        help="validate: check records only; build: also write library/dist/index.json; "
             "verify-t1: cross-check a fixed module's optics against its mechanics (WP-35); "
             "vendor-assets: download remotely-referenced meshes next to their record (WP-58); "
             "migrate-materials: rewrite legacy {type: ideal} materials onto "
             "optiland's registry vocabulary (WP-63, one-shot); "
             "migrate: bring a library or design tree onto the current DSN "
             "spelling (WP-230) — run this on any tree the schema now refuses; "
             "decompose: split a monolithic template's mesh into a subdesign "
             "whose moving parts are components (WP-229); "
             "compose: the mirror of decompose — marry a published optic onto a "
             "carrier cube module's axis, e.g. a lens onto a z-stage (WP-204); "
             "seats: re-author a component-backed cube module so its insert's "
             "90 deg seats are design variants instead of a placement's "
             "`mounting:` (WP-246); "
             "retessellate: re-convert every GLB from its STEP at the current "
             "(coarser) meshing tolerance, shrinking the served assets (WP-231); "
             "sidecar: move each component's prescription out to a standalone "
             "Optiland file beside it (WP-232); "
             "mergemesh: collapse each GLB's primitives by material — the "
             "draw-call fix, ~400x on the worst records (WP-224); "
             "archive: move a live record trio OUT to archive/ (the mirror of restore); "
             "reset: R0 curated carry-over — archive every record carrying a review: "
             "block and flag the survivors as unconfirmed (dry run unless --apply); "
             "restore: move an archived record trio back into the library (WP-68)",
    )
    library_p.add_argument(
        "--apply", action="store_true",
        help="reset/migrate/decompose/compose/seats: actually write "
             "(default is a dry run)",
    )
    # WP-204b: `library compose <component-id> --onto <carrier-module-id>`.
    library_p.add_argument("--seat", default=None,
                           help="seats: comma-separated z/x pairs, e.g. "
                                "--seat=-x/+z,+y/+x (default: the seats the "
                                "library's designs already ask for)")
    library_p.add_argument("--onto", default=None,
                           help="compose: the CARRIER cube module (a stage) — untouched")
    library_p.add_argument("--slug", default=None,
                           help="compose: names the new pair (default <optic>_on_<carrier>)")
    library_p.add_argument("--input", default="z", help="compose: the axis variable")
    library_p.add_argument("--units", default="mm", help="compose: the input's units")
    library_p.add_argument("--axis", default="+z",
                           help="compose: cube direction the optic travels")
    library_p.add_argument("--beam", default="+x",
                           help="compose: where the record's +z (optical axis) points")
    library_p.add_argument("--ratio", type=float, default=1.0,
                           help="compose: mm of travel per unit of the input")
    # NOTE the `=` form for negatives: argparse reads a bare `-10,10` as a flag.
    library_p.add_argument("--at", default=None,
                           help="compose: x,y,z mm from the cell centre at input=0 "
                                "(use --at=-5,0,0 for negatives)")
    library_p.add_argument("--range", default=None,
                           help="compose: min,max for the input's slider "
                                "(use --range=-10,10)")
    library_p.add_argument("--tilt", default=None,
                           help="compose: x,y,z offset-deg residual on the "
                                "child — align by rotation (use --tilt=0,45,0)")
    library_p.add_argument(
        "--dry-run", action="store_true",
        help="vendor-assets: list what WOULD be downloaded, fetch nothing",
    )
    library_p.add_argument(
        "module_id", nargs="?", default=None,
        help="record id for verify-t1 / restore (e.g. openuc2.cube.mirror_45)",
    )
    library_p.add_argument(
        "--linear", type=float, default=None,
        help="retessellate: chord error in mm (default: the module's 0.3)",
    )
    library_p.add_argument(
        "--angular", type=float, default=None,
        help="retessellate: normal deviation in radians (default: 0.5)",
    )
    library_p.add_argument(
        "--reframe", action="store_true",
        help="retessellate: accept a frame CHANGE (a permutation of the "
             "extents, never a size change) and drop the record's "
             "`mesh-frame` — the WP-234 migration to one glTF convention",
    )
    library_p.add_argument("--root", default=None, help="library dir (default: repo library/)")
    library_p.set_defaults(func=cmd_library)

    group_p = sub.add_parser("group", help="cube-group tools (WP-53): the OPM arrangement")
    group_p.add_argument(
        "subcommand", choices=["suggest"],
        help="suggest: derive the minimal plates + puzzle joints for a group",
    )
    group_p.add_argument("group_id", help="group id, e.g. openuc2.group.opm_brightfield")
    group_p.add_argument("--root", default=None, help="library dir (default: repo library/)")
    group_p.set_defaults(func=cmd_group)

    export_p = sub.add_parser("export", help="export a design to a downstream format")
    export_sub = export_p.add_subparsers(dest="format", required=True)
    step_p = export_sub.add_parser(
        "step", help="one grouped STEP assembly: modules, lathed optics, the beam (WP-57)"
    )
    step_p.add_argument("design", help="path to the .dsn design directory")
    step_p.add_argument("-o", "--out", default=None, help="output .step (default: <design>.step)")
    step_p.add_argument(
        "--beam", choices=["solid", "wires", "off"], default="solid",
        help="how the traced beam is emitted (default: solid swept cylinders)",
    )
    step_p.add_argument(
        "--beam-radius", type=float, default=None,
        help="radius of a beam solid in mm (default: 0.5)",
    )
    step_p.add_argument(
        "--component", default=None, metavar="KEY",
        help="WP-84: export ONE design component, posed w.r.t. its cube frame "
             "(for designing the cube module around it in Inventor)",
    )
    step_p.add_argument("--library", default=None, help="library dir (default: repo library/)")
    step_p.set_defaults(func=cmd_export_step)

    scene3_p = export_sub.add_parser(
        "scene3",
        help="materialize a design into a Scene3 (.ocanvas v2) + manifest for the Canvas kernel",
    )
    scene3_p.add_argument("design", help="design dir or optikit-design.yml")
    scene3_p.add_argument(
        "--path", dest="path_name", default=None,
        help="single path to materialize (default: all paths in one scene)",
    )
    scene3_p.add_argument("--out", default=".", help="output directory (default: cwd)")
    scene3_p.add_argument("--pretty", action="store_true", help="indent the emitted JSON")
    scene3_p.set_defaults(func=cmd_export_scene3)

    import_p = sub.add_parser("import", help="import external CAD/vendor formats into the library")
    import_sub = import_p.add_subparsers(dest="format", required=True)
    glb_p = import_sub.add_parser("glb", help="an openUC2 Inventor GLB export → library records")
    glb_p.add_argument("glb", help="path to the .glb file")
    glb_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    glb_p.add_argument("--namespace", default="openuc2", help="id namespace (default: openuc2)")
    glb_p.add_argument("--catalog", default=None,
                       help="catalog snapshot dir (default: <library root>/../vendor/catalog)")
    glb_p.add_argument("--catalog-road", default="auto", choices=["auto", "zmx", "derive"],
                       help="how a matched part number becomes optics (default: auto)")
    glb_p.add_argument("--no-catalog", action="store_true",
                       help="ignore part numbers; optics from the name tokens only")
    glb_p.set_defaults(func=cmd_import_glb)

    asm_p = import_sub.add_parser(
        "assembly",
        help="a named CAD assembly (one STEP + assembly.yml) → carrier and mounted-part records",
    )
    asm_p.add_argument("spec", help="path to the assembly.yml spec")
    asm_p.add_argument("--step", default=None,
                       help="the STEP (default: spec `source` beside the spec)")
    asm_p.add_argument("--glb", default=None,
                       help="an already converted GLB of the STEP (skips conversion)")
    asm_p.add_argument("--linear", type=float, default=1.0,
                       help="tessellation chord error, mm (default 1.0)")
    asm_p.add_argument("--angular", type=float, default=0.8,
                       help="tessellation angle, rad (default 0.8)")
    asm_p.add_argument("--prune", action="store_true",
                       help="drop fasteners, cables and boards before meshing; the "
                            "spec's own node names are protected")
    asm_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    asm_p.set_defaults(func=cmd_import_assembly)

    zmx_p = import_sub.add_parser(
        "zmx", help="a vendor Zemax prescription → optical component record"
    )
    zmx_p.add_argument("zmx", help="path to the .zmx file")
    zmx_p.add_argument("--mpn", default="", help="manufacturer part number (default: filename)")
    zmx_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    zmx_p.add_argument("--namespace", default="thorlabs", help="id namespace (default: thorlabs)")
    zmx_p.add_argument("--vendor", default="Thorlabs", help="vendor name (default: Thorlabs)")
    zmx_p.set_defaults(func=cmd_import_zmx)

    obj_p = import_sub.add_parser(
        "objective",
        help="vendor-table objective → component record (facts + thin-lens stand-in; "
             "optional .zmx prescription and STEP barrel)",
    )
    obj_p.add_argument("slug", help="record name, e.g. soptop_hr_20x")
    obj_p.add_argument("--name", default="", help="display name (default: the slug)")
    obj_p.add_argument("--manufacturer", required=True)
    obj_p.add_argument("--mag", type=float, required=True, help="magnification")
    obj_p.add_argument("--na", type=float, required=True, help="numerical aperture")
    obj_p.add_argument("--efl", type=float, default=None,
                       help="EFL mm (default: tube-lens-f / mag)")
    obj_p.add_argument("--wd", type=float, default=None, help="working distance mm")
    obj_p.add_argument("--tube-lens-f", type=float, default=180.0,
                       help="design tube lens f, mm (default 180)")
    obj_p.add_argument("--immersion", default="air")
    obj_p.add_argument("--thread", default="", help="RMS | M25x0.75 | …")
    obj_p.add_argument("--parfocal", type=float, default=None, help="parfocal distance mm")
    obj_p.add_argument("--field-number", type=float, default=None)
    obj_p.add_argument("--correction", default="", help="achromatic | plan-achromat | …")
    obj_p.add_argument("--price", type=float, default=None, help="EUR")
    obj_p.add_argument("--mpn", default="")
    obj_p.add_argument("--docs", default="", help="product/docs URL")
    obj_p.add_argument("--zmx", default=None, help="vendor .zmx (the real prescription)")
    obj_p.add_argument("--step", default=None, help="barrel STEP → a housing template")
    obj_p.add_argument("--step-axis", default="-z",
                       choices=["+x", "-x", "+y", "-y", "+z", "-z"],
                       help="which mesh axis points at the SAMPLE (default -z; the "
                            "openUC2 barrel parts are drawn +y)")
    obj_p.add_argument("--namespace", default="openuc2")
    obj_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    obj_p.set_defaults(func=cmd_import_objective)

    thorlabs_p = import_sub.add_parser(
        "thorlabs",
        help="batch: Thorlabs MPNs → component records, from local .zmx files",
        description="Downloads are out of scope: fetch each part's Zemax file from "
        "its thorlabs.com product page and drop it into --zmx-dir.",
    )
    thorlabs_p.add_argument("mpns", nargs="+", help="manufacturer part numbers, e.g. AC254-050-A")
    thorlabs_p.add_argument("--zmx-dir", required=True, help="directory with the .zmx files")
    thorlabs_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    thorlabs_p.add_argument("--namespace", default="thorlabs", help="id namespace")
    thorlabs_p.set_defaults(func=cmd_import_thorlabs)

    catalog_p = sub.add_parser(
        "catalog",
        help="the vendor catalog snapshot (WP-225): convert, crawl, fpbase, search, fetch, import",
        description="A pinned snapshot of vendor rows under the library's vendor/catalog/ "
        "(or OPTIKIT_CATALOG_DIR). A record is minted only on import.",
    )
    catalog_sub = catalog_p.add_subparsers(dest="catalog_command", required=True)

    def _catalog_common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--catalog", default=None,
                       help="snapshot dir (default: <library root>/../vendor/catalog)")

    cb_p = catalog_sub.add_parser("convert-bomb",
                                  help="BOMB's generated Thorlabs catalogs → one snapshot")
    cb_p.add_argument("repo", help="path to the microscope_builder checkout")
    _catalog_common(cb_p)
    cb_p.set_defaults(func=cmd_catalog_convert_bomb)

    fl_p = catalog_sub.add_parser(
        "from-library",
        help="library components → catalog rows, merged over the latest snapshot",
        description="The openUC2 primitives as a self-contained snapshot: rows derived "
        "from the curated records (re-run after a record change). Merges over the "
        "latest snapshot by default — the service reads only the latest file, so a "
        "standalone one would shadow the vendor rows.",
    )
    fl_p.add_argument("--namespace", default="openuc2", help="record namespace (default: openuc2)")
    fl_p.add_argument("--library", default=None, help="record root (default: repo library/)")
    fl_p.add_argument("--version", default=None,
                      help="snapshot version (default: optics-catalog-<today>)")
    fl_p.add_argument("--standalone", action="store_true",
                      help="write ONLY the library rows (shadows the vendor snapshot!)")
    _catalog_common(fl_p)
    fl_p.set_defaults(func=cmd_catalog_from_library)

    cr_p = catalog_sub.add_parser("crawl",
                                  help="crawl Thorlabs family pages into a snapshot")
    cr_p.add_argument("--scope", action="append", choices=["lenses", "fold", "filters"],
                      help="which families (default: all three)")
    cr_p.add_argument("--slug", action="append", help="crawl these family slugs only")
    cr_p.add_argument("--delay", type=float, default=30.0,
                      help="seconds between requests (robots: 30)")
    cr_p.add_argument("--max-depth", type=int, default=None, help="link depth (default: per scope)")
    cr_p.add_argument("--version", default=None, help="snapshot version (default: thorlabs-<date>)")
    _catalog_common(cr_p)
    cr_p.set_defaults(func=cmd_catalog_crawl)

    fp_p = catalog_sub.add_parser(
        "fpbase",
        help="FPbase fluorophore spectra → one snapshot under vendor/spectra/ (CC BY-SA 4.0)",
    )
    fp_p.add_argument("--spectra-dir", default=None,
                      help="snapshot dir (default: <library root>/../vendor/spectra)")
    fp_p.set_defaults(func=cmd_catalog_fpbase)

    cs_p = catalog_sub.add_parser("search", help="rows matching a query")
    cs_p.add_argument("query", nargs="*", help="search terms (all must match)")
    cs_p.add_argument("--kind", default=None,
                      help="sphericalLens, achromatDoublet, filter, dichroic, …")
    cs_p.add_argument("--cased", choices=["any", "yes", "no"], default="any",
                      help="mounted (yes) or bare (no)")
    cs_p.add_argument("--limit", type=int, default=25)
    _catalog_common(cs_p)
    cs_p.set_defaults(func=cmd_catalog_search)

    csh_p = catalog_sub.add_parser("show", help="one row, as JSON")
    csh_p.add_argument("part_id", help="e.g. thorlabs:LA1131")
    _catalog_common(csh_p)
    csh_p.set_defaults(func=cmd_catalog_show)

    cf_p = catalog_sub.add_parser("fetch",
                                  help="fetch a row's product-level Zemax file (vendor cache)")
    cf_p.add_argument("part_id")
    _catalog_common(cf_p)
    cf_p.set_defaults(func=cmd_catalog_fetch)

    ci_p = catalog_sub.add_parser("import",
                                  help="mint a component record from a row (zmx or table)")
    ci_p.add_argument("part_id")
    ci_p.add_argument("--road", choices=["auto", "zmx", "derive"], default="auto")
    ci_p.add_argument("--namespace", default="thorlabs")
    ci_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    _catalog_common(ci_p)
    ci_p.set_defaults(func=cmd_catalog_import)

    actuate_p = sub.add_parser(
        "actuate",
        help="resolve an actuatable DOF value → a firmware command (WP-26)",
        description="Prints the CAN/UC2-REST command that drives a module's DOF "
        "to a value, via its axis-map binding. Does not talk to hardware.",
    )
    actuate_p.add_argument("module_id", help="cube module id, e.g. openuc2.cube.galvo")
    actuate_p.add_argument("assignment", help="<dof>=<value>, e.g. tilt_x=7.5")
    actuate_p.add_argument("--root", default=None, help="library dir (default: repo library/)")
    actuate_p.set_defaults(func=cmd_actuate)

    layout_p = import_sub.add_parser(
        "layout-json", help="a legacy grid-builder layout JSON → .dsn design (WP-54)"
    )
    layout_p.add_argument("layout", help="path to the legacy layout .json")
    layout_p.add_argument(
        "--out", default=None,
        help="output .dsn directory (default: <layout-name>.dsn/ next to the input)",
    )
    layout_p.add_argument("--name", default="", help="design name (default: from filename)")
    layout_p.add_argument("--library", default=None, help="library dir (default: repo library/)")
    layout_p.set_defaults(func=cmd_import_layout_json)

    csv_p = import_sub.add_parser(
        "csv", help="the legacy CSV palette → library record trios (WP-43)"
    )
    csv_p.add_argument("csv", help="path to modules_updated.csv (';'-delimited)")
    csv_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    csv_p.add_argument("--namespace", default="openuc2", help="id namespace (default: openuc2)")
    csv_p.set_defaults(func=cmd_import_csv)

    generate_p = sub.add_parser(
        "generate",
        help="run a T3 (generative) template's CadQuery generator headlessly",
        description="Artifacts land in out/<template-id>/<sha256[:12] of canonical "
        "params>/ as model.step + model.stl + model.glb + meta.json.",
    )
    generate_p.add_argument("template_id", nargs="?", default=None, help="library template id")
    generate_p.add_argument(
        "--all", action="store_true", help="regenerate every T3 template in the library"
    )
    generate_p.add_argument(
        "--param", action="append", default=[], metavar="KEY=VALUE",
        help="override one generator parameter (repeatable)",
    )
    generate_p.add_argument("--params-json", default=None, help="JSON file with overrides")
    generate_p.add_argument(
        "--design", default=None,
        help="design dir: with --component, regenerate around the placed pose (WP-35 T3)",
    )
    generate_p.add_argument(
        "--component", default=None, help="design component key whose pose drives the cavity",
    )
    generate_p.add_argument("--out", default="out", help="artifact root (default: out/)")
    generate_p.add_argument("--library", default=None, help="library dir (default: repo library/)")
    generate_p.add_argument(
        "--force", action="store_true", help="regenerate even if the key already exists"
    )
    generate_p.add_argument(
        "--install", action="store_true",
        help="copy the STEP/GLB into the template's record dir and declare them",
    )
    generate_p.set_defaults(func=cmd_generate)

    rebuild_p = sub.add_parser(
        "rebuild",
        help="verify a release bundle: check lockfile pins + recompile all paths",
        description="The reproducibility check for bundles exported by the editor "
        "(File → Export Release Bundle): every pinned file must hash to its pin, "
        "and every locked path must recompile to a bit-identical optic.",
    )
    rebuild_p.add_argument("bundle", help="path to the release .zip")
    rebuild_p.set_defaults(func=cmd_rebuild)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    # Debug entry: a bare `python cli.py` starts the API with defaults (the
    # serve command); any explicit arguments dispatch through the full CLI.
    if len(sys.argv) > 1:
        sys.exit(main())
    cmd_serve(argparse.Namespace(host="127.0.0.1", port=8000, library_root=""))


# Re-exported for tests / callers that want the resolution rule without the CLI.
__all__ = ["main", "resolve_design_file"]
