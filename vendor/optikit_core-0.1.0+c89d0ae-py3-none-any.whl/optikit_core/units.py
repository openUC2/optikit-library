"""How long a glTF unit is (WP-237).

The glTF spec says **metres**. Our corpus says **millimetres** — deliberately,
since the PyInventor era: `importers/step_glb.py` used to suppress OCCT's
mm→metres rescale so 1 unit = 1 mm, and every consumer grew to assume it.
Ethan's Go implementation follows the spec and therefore had to shrink our
meshes 1000× by hand (GO-SYNC / GO-PROPOSAL-OPTICS §2.2).

WP-237 moves us to the spec **without a flag day**, because a flag day would
silently break every GLB not regenerated in the same instant — including
files we do not own (a user's own STEP converted last week, a community
repo, a hand-made mesh). Instead:

- what we WRITE is spec metres, and says so: :data:`UNIT_EXTRA` is stamped
  into ``asset.extras`` so the file is self-describing rather than
  conventional;
- what we READ is normalized to mm by :func:`mm_per_unit`, which believes the
  stamp when there is one and otherwise measures. An optikit part is between
  a millimetre and a metre across; the same part in metres is a thousand
  times smaller than in millimetres, so the two populations do not overlap
  and the guess is safe in exactly this domain.

Everything above the readers keeps speaking millimetres, which is the DSN's
own unit — this module is the only place the question exists.
"""

from __future__ import annotations

from typing import Any

#: Millimetres per metre. Named, because `1000` in a scale expression reads
#: like a magic number and this one has a direction that is easy to invert.
MM_PER_M = 1000.0

#: `asset.extras` key naming the file's length unit ("mm" | "m").
UNIT_EXTRA = "optikit_length_unit"

#: What we write now (the glTF spec's own unit).
SPEC_UNIT = "m"

#: Extents (in mm, once converted) an optikit part can plausibly have. A cube
#: is 50 mm; a baseplate a few hundred. Nothing in the toolchain is a metre
#: across or a millimetre small, which is what makes the fallback decidable.
MIN_PART_MM = 1.0

_SCALE = {"mm": 1.0, "millimeter": 1.0, "millimetre": 1.0,
          "m": MM_PER_M, "meter": MM_PER_M, "metre": MM_PER_M}


def declared_unit(gltf: dict[str, Any]) -> str:
    """The unit a glTF file declares, or "" when it says nothing."""
    extras = (gltf.get("asset") or {}).get("extras") or {}
    return str(extras.get(UNIT_EXTRA) or "").strip().lower()


def mm_per_unit(gltf: dict[str, Any], largest_extent: float) -> float:
    """Millimetres per glTF unit for this file.

    ``largest_extent`` is the biggest dimension measured in the file's OWN
    units — only consulted when the file declares nothing.
    """
    declared = declared_unit(gltf)
    if declared in _SCALE:
        return _SCALE[declared]
    if largest_extent <= 0:
        return 1.0  # nothing to measure; the legacy assumption is mm
    # Undeclared. Below a millimetre-scale reading the file cannot be mm (no
    # optikit part is under 1 mm), so it is metres — which is also what a
    # spec-following converter elsewhere produces.
    return MM_PER_M if largest_extent < MIN_PART_MM else 1.0


def stamp_unit(gltf: dict[str, Any], unit: str = SPEC_UNIT) -> None:
    """Record the file's unit in ``asset.extras`` (in place)."""
    asset = gltf.setdefault("asset", {})
    asset.setdefault("extras", {})[UNIT_EXTRA] = unit
