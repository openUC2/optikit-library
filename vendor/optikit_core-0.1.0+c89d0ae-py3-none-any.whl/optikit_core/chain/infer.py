"""Chain inference: propose ``paths:`` blocks by chief-ray propagation.

Generalizes the 2D grid-hopping beam router of the legacy ``optikit_exporter``
(``beam_router.py``) to full 3D over flattened world poses:

- a walk starts at every port of a ``category: source`` (or ``sample`` —
  secondary emitters) component, traveling the direction the port faces;
- the ray snaps to the nearest port that faces it within angular tolerance and
  whose clear aperture (fragment semi-apertures, fallback template envelope)
  contains the hit point;
- multi-exit components (beamsplitters, dichroics) branch the walk — one
  proposed path per root-to-leaf; branches that reach no terminal are pruned
  with a warning (a partially-reflective surface legitimately feeds dead arms);
- a walk terminates on arriving at a ``detector`` or ``sample`` port.

Hard, named errors — inference never guesses:

- ``E_AMBIGUOUS_CHAIN``: two candidate ports at (nearly) the same distance;
  both are named. Author the path manually.
- ``E_NO_TARGET``: a source's ray escapes with no surviving branch.
- ``E_LOOP``: the walk re-enters a component through the same port.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..compile.compiler import PortFrame, _angle_between, _port_frame
from ..geometry.flatten import FlatPose, flatten
from ..geometry.rotations import direction_vector
from ..schema.common import is_expr
from ..schema.design import CompSpec, DesignDecl
from ..schema.merge import instantiate
from ..schema.response import exit_survives, response_of_surface

ANGLE_TOL_DEG = 20.0
#: Two candidates closer together than this along the ray are ambiguous.
AMBIGUITY_TOL_MM = 1.0
DEFAULT_APERTURE_MM = 25.0
MAX_DEPTH = 64

START_CATEGORIES = ("source", "sample")
TERMINAL_CATEGORIES = ("detector", "sample")


@dataclass
class Escape:
    """A ray that left the system with nothing to catch it (WP-52).

    Structured so the editor can DRAW the escaping ray and name where it left:
    ``origin_mm`` + ``direction`` are the world-frame exit point and travel
    unit vector; ``from_comp``/``from_port`` is the element (and its exit port)
    the ray last left; ``reason`` is a short human hint.
    """

    source: str  #: the source port that started this walk ("laser.out")
    from_comp: str  #: element the ray last left ("mirror_1x1")
    from_port: str  #: that element's exit port ("reflected"; "" from the source)
    origin_mm: list[float]
    direction: list[float]
    reason: str


class ChainError(Exception):
    """Typed inference failure; ``code`` is stable API."""

    def __init__(
        self, code: str, where: str, message: str, escapes: list[Escape] | None = None
    ) -> None:
        super().__init__(f"{code} at {where}: {message}")
        self.code = code
        self.where = where
        #: Escape points for this failure (populated for E_NO_TARGET).
        self.escapes = escapes or []


@dataclass
class InferResult:
    #: Proposed ``paths:`` block — {name: {"chain": [...]}}.
    paths: dict[str, dict[str, Any]]
    warnings: list[str] = field(default_factory=list)
    #: Rays that left the system with no target (pruned branches + dead arms).
    escapes: list[Escape] = field(default_factory=list)


def _clear_aperture_mm(comp: CompSpec) -> float:
    """Semi-aperture: datum-disc aperture, else fragment apertures, else the envelope.

    A ``PLN`` datum marker measures the real clear aperture on the mechanics, so
    it outranks the prescription's ``semi_aperture`` (which is nominal glass).
    """
    if comp.optics:
        stated = [
            float(f.clear_aperture_mm) / 2.0
            for f in comp.optics.frames.values()
            if f.clear_aperture_mm is not None
            and isinstance(f.clear_aperture_mm, int | float)
            and not is_expr(f.clear_aperture_mm)
        ]
        if stated:
            return min(stated)
    radii: list[float] = []
    if comp.optics and comp.optics.fragment:
        for surf in comp.optics.fragment.surfaces:
            semi = surf.get("semi_aperture")
            if isinstance(semi, int | float):
                radii.append(float(semi))
            diameter = surf.get("aperture_diameter")
            if isinstance(diameter, int | float):
                radii.append(float(diameter) / 2.0)
    if radii:
        return max(radii)
    if comp.template is not None:
        extents = [
            float(v)
            for v in (
                comp.template.envelope.x_mm,
                comp.template.envelope.y_mm,
                comp.template.envelope.z_mm,
            )
            if isinstance(v, int | float) and not is_expr(v) and v
        ]
        if extents:
            return min(extents) / 2.0
    return DEFAULT_APERTURE_MM


def _source_wavelength(comp: CompSpec) -> float | None:
    """The active line a source emits (WP-74): the placement's picked line, else
    the record's first declared line, else None — which leaves inference
    wavelength-blind, exactly as before WP-74.

    ``CompSpec.source`` is a typed ``SourceSpec`` since WP-145, but a design
    parsed from an older corpus may still carry it as a plain dict — both
    shapes are read here.
    """
    if isinstance(comp.wavelength_um, int | float) and comp.wavelength_um > 0:
        return float(comp.wavelength_um)
    source = getattr(comp, "source", None)
    lines = (
        source.get("wavelengths_um") if isinstance(source, dict)
        else getattr(source, "wavelengths_um", None)
    )
    if lines:
        return float(lines[0])
    return None


def _exit_response(comp: CompSpec, port_name: str):  # noqa: ANN202
    """The spectral response of the surface an exit port sits after (WP-74)."""
    if not comp.optics or not comp.optics.fragment:
        return None
    port = comp.optics.ports.get(port_name)
    if port is None or port.after_surface is None:
        return None
    surfaces = comp.optics.fragment.surfaces
    if 0 <= port.after_surface < len(surfaces):
        return response_of_surface(surfaces[port.after_surface])
    return None


def _fmt_dir(direction: list[float]) -> str:
    """A ±axis label when the ray runs along one, else a rounded vector."""
    axes = ("x", "y", "z")
    big = [i for i, v in enumerate(direction) if abs(v) > 0.99]
    if len(big) == 1:
        i = big[0]
        return f"{'+' if direction[i] > 0 else '-'}{axes[i]}"
    return "(" + ", ".join(f"{v:+.2f}" for v in direction) + ")"


def _escape_summary(escapes: list[Escape]) -> str:
    """One-line, human-first summary of where a source's rays leaked out."""
    if not escapes:
        return "The ray does not reach any element (check the source direction)."
    parts = []
    for e in escapes:
        where = f"{e.from_comp}.{e.from_port}" if e.from_port else e.from_comp
        parts.append(f"{where} → {_fmt_dir(e.direction)} ({e.reason})")
    return "Ray leaves at: " + "; ".join(parts) + "."


@dataclass
class _Port:
    comp_id: str
    name: str
    frame: PortFrame
    aperture_mm: float


def _all_ports(
    components: dict[str, CompSpec], poses: dict[str, FlatPose]
) -> list[_Port]:
    ports: list[_Port] = []
    for comp_id, comp in components.items():
        if not comp.optics or not comp.optics.ports:
            continue
        aperture = _clear_aperture_mm(comp)
        for name, port in comp.optics.ports.items():
            if direction_vector(port.direction) is None:
                continue
            ports.append(
                _Port(comp_id, name, _port_frame(comp_id, comp, name, poses[comp_id]), aperture)
            )
    return ports


def _fiber_arrival(
    hop: tuple[str, str],
    components: dict[str, CompSpec],
    poses: dict[str, FlatPose],
) -> _Port | None:
    """The far connector of a fiber hop as an arrival port (WP-46)."""
    far_ref, _name = hop
    comp_id, _, port_name = far_ref.partition(".")
    comp = components.get(comp_id)
    if comp is None or not comp.optics or port_name not in comp.optics.ports:
        return None
    return _Port(
        comp_id,
        port_name,
        _port_frame(comp_id, comp, port_name, poses[comp_id]),
        _clear_aperture_mm(comp),
    )


def _fiber_hops(decl: DesignDecl) -> dict[str, tuple[str, str]]:
    """``"comp.port" -> (far "comp.port", fiber name)`` for every fiber (WP-46).

    Fibers are traversable in both directions: a walk that reaches either
    connector continues out of the other one.
    """
    hops: dict[str, tuple[str, str]] = {}
    for name, fiber in decl.fibers.items():
        if not fiber.from_port or not fiber.to_port:
            continue
        hops[fiber.from_port] = (fiber.to_port, name)
        hops[fiber.to_port] = (fiber.from_port, name)
    return hops


def infer_paths(decl: DesignDecl) -> InferResult:
    """Propose paths for every source in the design (see module docstring)."""
    components = instantiate(decl)
    poses = flatten(components)
    ports = _all_ports(components, poses)
    angle_tol = np.radians(ANGLE_TOL_DEG)
    fiber_hops = _fiber_hops(decl)

    warnings: list[str] = []
    escapes: list[Escape] = []

    def _last_hop(chain: list[str]) -> tuple[str, str]:
        """(comp, exit-port) the ray left from, parsing the last chain entry.

        Entries are ``comp.port`` (a source start) or ``comp.entry>exit`` (a
        traversal step); the escaping ray leaves from the exit side.
        """
        last = chain[-1]
        comp = last.split(".", 1)[0]
        port = last.split(">")[-1] if ">" in last else last.split(".", 1)[-1]
        return comp, port

    def find_next(origin: np.ndarray, direction: np.ndarray, skip_comp: str) -> _Port | None:
        candidates: list[tuple[float, _Port]] = []
        for port in ports:
            if port.comp_id == skip_comp:
                continue
            to_port = port.frame.position - origin
            t = float(to_port @ direction)
            if t < 1e-6:
                continue # port is behind the ray origin
            lateral = float(np.linalg.norm(to_port - t * direction))
            if lateral > port.aperture_mm:
                continue # port is outside the clear aperture of the ray
            if _angle_between(port.frame.direction, -direction) > angle_tol:
                continue # port is facing away from the ray
            candidates.append((t, port)) # add candidate with distance along the ray
        if not candidates:
            return None
        candidates.sort(key=lambda c: c[0])
        if len(candidates) > 1 and candidates[1][0] - candidates[0][0] < AMBIGUITY_TOL_MM:
            a, b = candidates[0][1], candidates[1][1]
            raise ChainError(
                "E_AMBIGUOUS_CHAIN",
                f"{skip_comp} → ?",
                f"two candidate ports at the same distance "
                f"({candidates[0][0]:.2f} vs {candidates[1][0]:.2f} mm): "
                f"{a.comp_id}.{a.name} and {b.comp_id}.{b.name} — author this path manually",
            )
        return candidates[0][1]

    def walk(
        origin: np.ndarray,
        direction: np.ndarray,  # direction as a unit vector in world coordinates
        skip_comp: str,
        chain: list[str],
        visited: frozenset[tuple[str, str]],
        depth: int,
        wl_um: float | None,  # WP-74: the propagating line, for spectral gating
    ) -> list[list[str]]:
        """Extend the chain from a free-flying ray; returns completed chains."""
        if depth > MAX_DEPTH:
            raise ChainError("E_LOOP", chain[-1], f"walk exceeded {MAX_DEPTH} elements")
        # WP-46: a fiber on the port we just left carries the light to its far
        # connector — no geometry, so it wins over the free-space search.
        from_comp, from_port = _last_hop(chain)
        hop = fiber_hops.get(f"{from_comp}.{from_port}")
        hit = _fiber_arrival(hop, components, poses) if hop else None
        if hit is None and hop is not None:
            warnings.append(
                f"pruned: fiber {hop[1]!r} from {from_comp}.{from_port} does not "
                f"resolve to a component port ({hop[0]})"
            )
            return []
        if hit is None:
            hit = find_next(origin, direction, skip_comp)
        if hit is None:
            comp, port = _last_hop(chain)
            escapes.append(
                Escape(
                    source=chain[0],
                    from_comp=comp,
                    from_port=port,
                    origin_mm=[float(v) for v in origin],
                    direction=[float(v) for v in direction],
                    reason="no port faces this ray",
                )
            )
            warnings.append(
                f"pruned: ray from {chain[-1]} escaped at "
                f"({', '.join(f'{v:.0f}' for v in origin)}) mm heading "
                f"({', '.join(f'{v:+.0f}' for v in direction)})"
            )
            return []
        comp = components[hit.comp_id]
        state = (hit.comp_id, hit.name)
        if state in visited:
            raise ChainError(
                "E_LOOP",
                f"{hit.comp_id}.{hit.name}",
                f"beam re-enters through the same port: {' -> '.join(chain)} -> "
                f"{hit.comp_id}.{hit.name}",
            )
        if comp.category in TERMINAL_CATEGORIES:
            return [[*chain, f"{hit.comp_id}.{hit.name}"]]

        exits = [
            _Port(hit.comp_id, name, _port_frame(hit.comp_id, comp, name, poses[hit.comp_id]),
                  hit.aperture_mm)
            for name in (comp.optics.ports if comp.optics else {})
            if name != hit.name
        ]
        if not exits:
            escapes.append(
                Escape(
                    source=chain[0],
                    from_comp=hit.comp_id,
                    from_port=hit.name,
                    origin_mm=[float(v) for v in hit.frame.position],
                    direction=[float(v) for v in direction],
                    reason=f"dead-end: {comp.category or 'part'} has no exit port",
                )
            )
            warnings.append(
                f"pruned: {hit.comp_id}.{hit.name} has no exit port (category "
                f"{comp.category or 'unset'} is not terminal)"
            )
            return []

        # WP-74: prune exits the propagating wavelength cannot take — a 505 nm
        # dichroic's reflected arm is not proposed at 488 nm, its transmitted
        # arm is not proposed at 525 nm. A band-pruned arm is an INFO finding,
        # NOT a dead-end escape: the light legitimately does not go that way, so
        # a component whose every arm is band-blocked simply ends the walk.
        surviving_exits: list[_Port] = []
        for exit_port in exits:
            if exit_survives(_exit_response(comp, exit_port.name), exit_port.name, wl_um):
                surviving_exits.append(exit_port)
            elif wl_um is not None:
                warnings.append(
                    f"pruned by band: {hit.comp_id}.{hit.name}>{exit_port.name} "
                    f"({wl_um * 1000:.0f} nm outside the surface's response)"
                )
        exits = surviving_exits

        completed: list[list[str]] = []
        for exit_port in exits:
            completed.extend(
                walk( # recursively walk from the exit port of the current component
                    exit_port.frame.position,
                    exit_port.frame.direction,
                    hit.comp_id,
                    [*chain, f"{hit.comp_id}.{hit.name}>{exit_port.name}"],
                    visited | {state},
                    depth + 1,
                    wl_um,
                )
            )
        return completed

    proposals: dict[str, dict[str, Any]] = {}
    used_names: set[str] = set()
    for comp_id, comp in components.items():
        if comp.category not in START_CATEGORIES:
            continue
        # WP-47: a source that is switched off emits nothing — the inferred
        # netlist matches what the bench is actually doing.
        if not comp.enabled:
            warnings.append(f"{comp_id}: source is off — skipped")
            continue
        wl_um = _source_wavelength(comp)
        for port_name in comp.optics.ports if comp.optics else {}:
            start = _port_frame(comp_id, comp, port_name, poses[comp_id])
            before = len(escapes)
            chains = walk(
                start.position,
                start.direction,
                comp_id,
                [f"{comp_id}.{port_name}"],
                frozenset(),
                0,
                wl_um,
            )
            if not chains:
                if comp.category == "source":
                    mine = escapes[before:]
                    where = f"{comp_id}.{port_name}"
                    raise ChainError(
                        "E_NO_TARGET",
                        where,
                        "no branch of this source's ray reaches a detector/sample "
                        f"port. {_escape_summary(mine)}",
                        escapes=mine,
                    )
                warnings.append(f"{comp_id}.{port_name}: no chain found (secondary emitter)")
                continue
            for i, chain in enumerate(chains):
                name = f"from-{comp_id}" if len(chains) == 1 else f"from-{comp_id}-{i + 1}"
                while name in used_names:
                    name += "x"
                used_names.add(name)
                proposals[name] = {"chain": chain}

    return InferResult(paths=proposals, warnings=warnings, escapes=escapes)
