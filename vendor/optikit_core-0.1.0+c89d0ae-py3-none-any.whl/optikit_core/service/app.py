"""HTTP service: the optikit-core engine for the React editor (WP-6).

Stateless: every request carries the .dsn directory as a JSON file tree
``{"files": {"optikit-design.yml": "<yaml>"}}``; nothing is stored server-side.
Typed engine errors surface as HTTP 422 ``{code, message, context}``.

Simulation/optimization endpoints run Optiland in-process and answer 501 when
the ``sim`` extra (``pip install optikit-core[sim]``) is not installed. Ray
polylines are returned in WORLD coordinates, re-folded through the compile
manifest's per-surface fold maps, so the frontend can overlay them in 3D.
"""

from __future__ import annotations

import json
import math
import os
import re
import secrets
from dataclasses import asdict
from pathlib import Path
from typing import Any, Literal

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field, ValidationError

from .. import __version__
from ..annotate import AnnotateError, apply_to_document, back_annotate
from ..catalog.types import CatalogFile
from ..chain import ChainError, infer_paths
from ..compile import CompileError, CompileResult, compile_path
from ..geometry import FlattenError, cubify, flat_report
from ..io.yamlio import dump_document, load_document_text, load_document_text_fast
from ..library.root import LIBRARY_ROOT_ENV, library_root
from ..schema import DESIGN_DECL_FILE, DesignDecl, check
from ..schema.design import collect_input_values, set_input_value
from ..schema.merge import instantiate

SCHEMA_DIST = __import__("pathlib").Path(__file__).resolve().parents[3] / "schema" / "dist"

#: The record library this service serves and writes: `library_root()`
#: (ARCHITECTURE.md §10.4), read per call so a test or an operator can
#: repoint `OPTIKIT_LIBRARY_ROOT` without reimporting the module.
#: Announced once per value, not once per request.
_announced_roots: set[Path] = set()


def library_root_path() -> Path:
    """The record library root, honouring :data:`LIBRARY_ROOT_ENV`."""
    root = library_root()
    if root not in _announced_roots:
        _announced_roots.add(root)
        print(f"Using {LIBRARY_ROOT_ENV}={root}")
    return root


def _catalog_dir() -> Path:
    from ..catalog.snapshot import default_catalog_dir

    return default_catalog_dir(library_root_path())


_catalog_cache: dict[str, Any] = {"path": None, "mtime": None, "snapshot": None}


def _catalog_snapshot():  # noqa: ANN202
    """The newest snapshot in the catalog dir, re-read when its file changes."""
    from ..catalog.snapshot import latest_snapshot_path, load_snapshot

    directory = _catalog_dir()
    path = latest_snapshot_path(directory)
    if path is None:
        raise HTTPException(404, {"code": "E_CATALOG_EMPTY",
                                  "message": "no catalog snapshot — run `optikit-core catalog "
                                             "convert-bomb` or `catalog crawl`",
                                  "context": str(directory)})
    mtime = path.stat().st_mtime
    if _catalog_cache["path"] != path or _catalog_cache["mtime"] != mtime:
        _catalog_cache.update(path=path, mtime=mtime, snapshot=load_snapshot(path))
    return _catalog_cache["snapshot"]


_spectra_cache: dict[str, Any] = {"path": None, "mtime": None, "snapshot": None}


def _spectra_snapshot():  # noqa: ANN202
    """The newest fluorophore snapshot beside the catalog, re-read when its file changes."""
    from ..catalog.fpbase import default_spectra_dir, load_spectra
    from ..catalog.snapshot import latest_snapshot_path

    directory = default_spectra_dir(library_root_path())
    path = latest_snapshot_path(directory)
    if path is None:
        raise HTTPException(404, {"code": "E_NO_SPECTRA",
                                  "message": "no fluorophore spectra snapshot — run "
                                             "`optikit-core catalog fpbase`",
                                  "context": str(directory)})
    mtime = path.stat().st_mtime
    if _spectra_cache["path"] != path or _spectra_cache["mtime"] != mtime:
        _spectra_cache.update(path=path, mtime=mtime, snapshot=load_spectra(path))
    return _spectra_cache["snapshot"]


def _library_state_key(root: Path) -> tuple[float, int]:
    """(max mtime, entry count) over the tree — changes on any write.

    ~3 ms where a full ``load_library`` re-parse costs ~300 ms; the freshness
    contract (WP-22: dev writes appear on the next request) is identical.
    """
    latest = 0.0
    count = 0
    stack = [str(root)]
    while stack:
        with os.scandir(stack.pop()) as entries:
            for entry in entries:
                count += 1
                stat = entry.stat(follow_symlinks=False)
                if stat.st_mtime > latest:
                    latest = stat.st_mtime
                if entry.is_dir(follow_symlinks=False):
                    stack.append(entry.path)
    return latest, count


#: One parsed library per tree state. Safe to share across requests: every
#: consumer only ``resolve()``s against it, and ``instantiate()`` returns
#: evaluated copies. Endpoints that WRITE records bump the tree's mtime, so
#: the next request misses and reloads.
_library_cache: dict[str, Any] = {"root": None, "key": None, "library": None}


def cached_library(root: Path):
    """`load_library(root)`, cached against :func:`_library_state_key`."""
    from ..library import load_library

    key = _library_state_key(root)
    if _library_cache["root"] != root or _library_cache["key"] != key:
        _library_cache["library"] = load_library(root)
        _library_cache["root"] = root
        _library_cache["key"] = key
    return _library_cache["library"]


class FiniteJSONResponse(JSONResponse):
    """JSON with non-finite floats made strict-JSON safe: ±inf → ±1e999 (which
    JSON.parse overflows back to ±Infinity), NaN → null.

    The substitution runs on the STRUCTURE, never on the serialized text. A
    blind `text.replace("NaN", "null")` also rewrote every STRING that
    happened to contain those letters — and base64 hits them constantly: a
    4.7 MB STL came back exactly one character too long, so the browser's
    `atob` refused the whole artifact. Floats are swapped for a per-response
    random sentinel first, and only the QUOTED sentinel is replaced; a quote
    cannot occur inside a JSON string body, so nothing else can match.
    """

    def render(self, content: Any) -> bytes:
        token = secrets.token_hex(8)
        pos, neg, nan = f"@inf-{token}", f"@-inf-{token}", f"@nan-{token}"

        def swap(value: Any) -> Any:
            if isinstance(value, float):
                if math.isnan(value):
                    return nan
                if value == math.inf:
                    return pos
                if value == -math.inf:
                    return neg
                return value
            if isinstance(value, dict):
                return {k: swap(v) for k, v in value.items()}
            if isinstance(value, list | tuple):
                return [swap(v) for v in value]
            return value

        text = json.dumps(swap(content), allow_nan=False, separators=(",", ":"))
        text = (
            text.replace(f'"{pos}"', "1e999")
            .replace(f'"{neg}"', "-1e999")
            .replace(f'"{nan}"', "null")
        )
        return text.encode("utf-8")


def _normalize_optic(optic: dict[str, Any]) -> dict[str, Any]:
    """Undo JavaScript's lossy Infinity handling on incoming optic dicts.

    ``JSON.stringify(Infinity)`` is ``null``, so a browser sending back an
    optimized optic delivers flat radii as null (and huge overflow floats for
    1e999-encoded values). Restore them to ±inf so diffs against the compiled
    baseline stay meaningful.
    """
    for surface in (optic.get("surface_group") or {}).get("surfaces") or []:
        geometry = surface.get("geometry")
        if not isinstance(geometry, dict):
            continue
        radius = geometry.get("radius")
        if radius is None:
            geometry["radius"] = math.inf
        elif isinstance(radius, int | float) and abs(radius) >= 1e308:
            geometry["radius"] = math.copysign(math.inf, radius)
    return optic


# --- request models ---------------------------------------------------------------------


class DesignBody(BaseModel):
    files: dict[str, str]


class PathBody(DesignBody):
    path: str | None = None


class TraceQualityBody(BaseModel):
    """Numerical sampling override for /v1/scene3 (§9.5) — rendering policy,
    never part of the physical emission model."""

    spatial_samples: int = 64
    angular_samples: int = 1
    seed: int = 0
    #: Kernel sampling sequence (§6.10): Grid = centered strata, Stratified =
    #: jittered strata (seeded), Sobol = low-discrepancy van der Corput.
    sequence: Literal["Grid", "Stratified", "Sobol"] = "Grid"


class Scene3Body(PathBody):
    trace_quality: TraceQualityBody | None = None


class SimulateBody(DesignBody):
    path: str
    actions: list[str] = Field(default_factory=lambda: ["trace", "paraxial"])
    # Hexapolar counts RINGS: 6 rings ≈ 127 rays — sane overlay payloads.
    num_rays: int = 6
    distribution: str = "hexapolar"


class SequenceBody(DesignBody):
    """WP-165 producer: trace-derived sequences.

    ``path`` names one declared path and answers for it alone. **Omit it** and
    the endpoint *discovers* instead: every (source, detector) pair the scene
    holds is traced, the pairs that carry light come back as paths, and the
    result is diffed against the authored ``paths:`` block. Discovery needs no
    declared chain — that is the point of it (part2r Phase A / §0.6).
    """

    path: str = ""
    #: "optic" adds the folded Optiland projection (emit_folded).
    actions: list[str] = Field(default_factory=list)
    trace_quality: TraceQualityBody | None = None
    #: A previously blessed pin (A1c). Discovery mode always returns the pin
    #: for what it just traced; supply the stored one and the response also
    #: carries ``pin_diff`` — held / drifted / appeared / vanished, keyed
    #: ``(variant, path, band)``. Absent = a first trace, which auto-accepts.
    pin: dict[str, Any] | None = None


class LibraryPublishBody(BaseModel):
    """M2: which already-written records to put up for review."""

    #: Repo-relative paths inside the library root, as `/v1/library/save`
    #: returns them in `written`. An explicit list, never a wildcard: a publish
    #: must not sweep up unrelated edits an operator has open.
    files: list[str]
    #: Branch-name seed, normally the record id. Sanitized before use.
    slug: str = ""
    message: str = ""


class ExportStepBody(DesignBody):
    """WP-57: how the beam should appear in the exported CAD assembly."""

    beam: str = "solid"  # solid | wires | off
    beam_radius_mm: float = Field(default=0.5, alias="beam-radius-mm")


class ExportStepPartBody(DesignBody):
    """WP-84: which design component to export, posed w.r.t. its cube frame."""

    component: str


class OptimizeBody(DesignBody):
    path: str
    dofs: list[str] | None = None  # default: every ranged DOF
    num_rays: int = 12
    max_iter: int = 40


class AnnotateBody(DesignBody):
    path: str
    optimized: dict[str, Any]
    apply: bool = False
    optimized_by: str = "optiland"


class CalibrateBody(DesignBody):
    """WP-86: measured axis positions from a RUNNING instrument.

    ``measurements`` maps ``"<component>.<dof>"`` → the absolute measured
    position in the DOF's unit (mm / degrees) — what a motor controller
    reports over the WP-26 UC2-REST link.
    """

    measurements: dict[str, float]
    apply: bool = False
    instrument: str = ""
    note: str = ""


class StepBody(BaseModel):
    """A STEP file for conversion, base64-encoded (no multipart dependency)."""

    filename: str = "part.step"
    data_b64: str


class MeshNodesBody(BaseModel):
    """A GLB whose named node tree the moving-parts picker wants (WP-192)."""

    data_b64: str


class LibraryDeleteBody(BaseModel):
    """Record ids to retire from the library (moved to archive/, not erased)."""

    ids: list[str]
    password: str


class ImportZmxBody(BaseModel):
    """WP-82: a vendor .zmx prescription for review — nothing is written."""

    filename: str = "lens.zmx"
    data_b64: str
    mpn: str = ""
    namespace: str = "thorlabs"
    vendor_name: str = "Thorlabs"


class CatalogImportBody(BaseModel):
    """WP-225/255: a catalog row → the proposed component record — nothing is written."""

    id: str
    road: Literal["auto", "zmx", "derive"] = "auto"
    namespace: str = "thorlabs"


class ImportGlbBody(BaseModel):
    """WP-82: a marker-stamped Inventor GLB for review — nothing is written."""

    filename: str = "cube.glb"
    data_b64: str
    namespace: str = "openuc2"


class ImportOptilandBody(BaseModel):
    """WP-87: a serialized Optiland system (``optic.to_dict()`` JSON) for review."""

    filename: str = "setup.json"
    data_b64: str
    namespace: str = "user"


class DrawBody(DesignBody):
    """WP-82: the compiled optic's 2D layout drawing (optiland's own viewer)."""

    path: str
    num_rays: int = 8


class GenerateBody(BaseModel):
    """A T3 generator run (WP-61): an existing generative template by id, or
    an ad-hoc boolean holder around a bare optical component. With ``files``
    + ``component`` the design component's placed pose folds into the params
    (the cavity lands where the optic actually sits)."""

    template_id: str | None = None
    component_id: str | None = None
    params: dict[str, Any] = Field(default_factory=dict)
    files: dict[str, str] | None = None
    component: str | None = None
    #: WP-245: which generator holds an ad-hoc component. Default: the
    #: boolean holder. `generators/lens_cartridge_v4.py` is the manufactured
    #: V4 road (molded master inserts + the cube's notch grid).
    generator: str | None = None
    #: WP-250: which artifact formats to inline. A cartridge run is ~38 MB of
    #: base64 across step+stl+glb; a viewer wants the GLBs alone. The files
    #: stay on disk either way — publishing reads them from `out_dir`.
    artifact_formats: list[str] | None = None


class LibraryCubifyBody(BaseModel):
    """WP-243: publish a finished T3 run as a cube module.

    `out_dir` and `generator`/`params` are what `/v1/generate` returned, so
    the template's provenance is exactly what produced the mesh beside it.
    """

    component_id: str  #: the EXISTING optic — its record is referenced, not rewritten
    slug: str  #: names the pair: <ns>.subdesign.<slug> / <ns>.cube.<slug>
    out_dir: str  #: repo-relative artifact directory from /v1/generate
    generator: str  #: the generator script path
    params: dict[str, Any] = Field(default_factory=dict)
    footprint_grid: list[int] = Field(default_factory=lambda: [1, 1, 1])
    #: WP-249: the cube whose template the module shares and whose shell mesh
    #: the design folder carries.
    shell_module: str = "user.cube.cube_base"


class QuoteNotifyBody(BaseModel):
    """A quote request to mail; header fields refuse line breaks (no header injection)."""

    subject: str = Field(min_length=1, max_length=200, pattern=r"^[^\r\n]+$")
    text: str = Field(min_length=1, max_length=20000)
    reply_to: str = Field(default="", max_length=200, pattern=r"^[^\r\n]*$")


class ObjectiveImportBody(BaseModel):
    """`import objective` over the wire: the facts, an optional barrel STEP, an optional zmx."""

    slug: str = Field(min_length=1, max_length=60, pattern=r"^[a-z0-9][a-z0-9_]*$")
    display: str = ""
    manufacturer: str = ""
    magnification: float = Field(gt=0)
    numerical_aperture: float = Field(gt=0, le=2)
    working_distance_mm: float | None = None
    tube_lens_f_mm: float = Field(default=180.0, gt=0)
    efl_mm: float | None = None
    immersion: str = "air"
    thread: str = ""
    parfocal_distance_mm: float | None = None
    field_number_mm: float | None = None
    correction: str = ""
    price_eur: float | None = None
    mpn: str = ""
    docs: list[str] = Field(default_factory=list)
    namespace: str = Field(default="openuc2", pattern=r"^[a-z0-9]+$")
    step_b64: str = ""
    step_name: str = "barrel.step"
    #: which mesh axis points at the sample (the openUC2 barrels are drawn +y)
    step_axis: Literal["+x", "-x", "+y", "-y", "+z", "-z"] = "-z"
    zmx_text: str = ""


class OpmStructureBody(BaseModel):
    """An arrangement whose sandwich is wanted: the group record's own shape."""

    members: dict[str, Any]
    envelope_grid: list[int] = Field(alias="envelope-grid")

    model_config = {"populate_by_name": True}


class LibrarySaveBody(BaseModel):
    """Records to write into the repo library (developer mode, env-gated).

    ``records`` maps YAML text by record; optional binary assets (GLB/STEP)
    ride along base64-encoded, stored next to their record.
    """

    records: list[str]
    assets: dict[str, str] = Field(default_factory=dict)  # "<id>/<file>" → b64


class LibraryDecomposeBody(BaseModel):
    """WP-229 tail: the wizard's moving-parts rows, sent at publish.

    WP-230 removed the record spelling these rows used to land in, so the
    frontend hands them to the service instead: each surface-bound rotation
    becomes an optics-only child in a subdesign, and the module's optical side
    moves onto it (``component:`` → ``design:``, decision D2).
    """

    template_id: str
    component_id: str
    module_id: str
    #: The wizard rows verbatim: dof/motion/axis/surface/rangeMin/rangeMax/
    #: resolution/unit/actuation. Opaque here; `decompose_moving_parts`
    #: validates the shape.
    moving_parts: list[dict[str, Any]]


class LibraryComposeBody(BaseModel):
    """WP-204: marry a published optic onto a moving cube (the fifth road).

    ``component_id`` rides ``module_id``'s ``axis``: the service writes a
    cube_subdesign (optic verbatim, translation an expression over a new
    ``input``) plus a NEW module sharing the carrier's template. The carrier
    is never modified.
    """

    component_id: str
    module_id: str  #: the CARRIER (a stage) — stays untouched
    slug: str  #: names the new pair: <ns>.subdesign.<slug> / <ns>.cube.<slug>
    input: str = "z"
    units: str = "mm"
    min: float | None = None
    max: float | None = None
    axis: str = "+z"  #: cube direction the optic travels
    beam: str = "+x"  #: where the record's +z (optical axis) points
    ratio: float = 1.0  #: mm per input unit
    offset_mm: dict[str, float] = Field(default_factory=dict)  #: cell pos at input=0
    #: WP-240: offset-deg residual on the child — rotation alignment.
    tilt_deg: dict[str, float] | None = None


#: WP-185: cap on a decoded setup screenshot. The writer downscales to ~960 px
#: before encoding, so a real one lands well under a megabyte; this only stops
#: something absurd from being written into the library tree.
SETUP_PREVIEW_MAX_BYTES = 6 * 1024 * 1024

#: Leading bytes each accepted format must actually start with. The media type
#: in a data URL is a claim by the sender; this is the check.
_IMAGE_MAGIC = {"image/png": b"\x89PNG\r\n\x1a\n", "image/jpeg": b"\xff\xd8\xff"}


def _write_setup_preview(setup_dir: Path, data_url: str) -> str:
    """Decode a `data:image/…;base64,…` screenshot into ``setup_dir``.

    Returns the filename written. Raises ``ValueError`` with a human-readable
    reason for anything malformed — the caller keeps the design and reports
    the reason rather than failing the whole save over a picture.
    """
    import base64
    import binascii

    from ..library.build import SETUP_PREVIEWS

    match = re.match(r"^data:(image/(?:png|jpeg));base64,(.+)$", data_url, re.DOTALL)
    if not match:
        raise ValueError("expected a data:image/png or data:image/jpeg base64 URL")
    media, payload = match.group(1), match.group(2)
    try:
        raw = base64.b64decode(payload, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError(f"the image is not valid base64: {exc}") from exc
    if len(raw) > SETUP_PREVIEW_MAX_BYTES:
        raise ValueError(
            f"the image is {len(raw) // 1024} kB, over the "
            f"{SETUP_PREVIEW_MAX_BYTES // 1024} kB limit"
        )
    if not raw.startswith(_IMAGE_MAGIC[media]):
        raise ValueError(f"the payload is not a {media} image")

    name = "preview.png" if media == "image/png" else "preview.jpg"
    # Re-saving in the other format must not leave the old one behind — the
    # reader takes the first extension it finds, which would be the stale one.
    for other in SETUP_PREVIEWS:
        if other != name:
            (setup_dir / other).unlink(missing_ok=True)
    (setup_dir / name).write_bytes(raw)
    return name


def _artifact_dir(repo: Path, rel: str) -> Path:
    """A generate run's `out_dir`, refused unless it lies under the repo's `out/`.

    The path comes from OUR own generate response; the guard keeps a crafted
    request from reading arbitrary files through the artifact roads.
    """
    out_dir = (repo / rel).resolve()
    if not out_dir.is_dir() or (repo / "out").resolve() not in out_dir.parents:
        raise HTTPException(422, {
            "code": "E_BAD_REQUEST",
            "message": f"{rel!r} is not a generate artifact directory",
            "context": rel})
    return out_dir


def download_name(raw: str | None, fallback: str = "design") -> str:
    """A caller-supplied name reduced to something safe in a filename header.

    Copilot review (PR #15, app.py:466): these names came from the request and
    reached both a ZIP entry path and a quoted `Content-Disposition`, with only
    `/` replaced. A quote closes the header's filename early and a CR/LF splits
    the response — so the allowed set is stated positively here instead of
    blacklisting the separators someone thought of.
    """
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", (raw or "").strip())
    # A leading dot hides the file (and `..` walks); trailing dots break Windows.
    cleaned = cleaned.strip("._")[:80]
    return cleaned or fallback


def _refuse_locked(library_root: Path, record_ids: list[str]) -> None:
    """403 E_RECORD_LOCKED when any id names a live record with `locked: true`.

    `OPTIKIT_ALLOW_LOCKED_WRITE=1` lifts it for a maintainer's session.
    """
    if os.environ.get("OPTIKIT_ALLOW_LOCKED_WRITE") == "1":
        return
    from ..library.build import RECORD_FILES

    locked = [
        rid for rid in record_ids
        for folder in ("components", "templates", "modules", "groups")
        for file in RECORD_FILES
        if (library_root / folder / rid / file).is_file()
        and (load_document_text_fast((library_root / folder / rid / file).read_text("utf-8"))
             or {}).get("locked") is True
    ]
    if locked:
        raise HTTPException(403, {
            "code": "E_RECORD_LOCKED",
            "message": "locked curated record(s) — change them through a pull request or the "
                       "CLI (`optikit-core library unlock <id>`), or run the service with "
                       "OPTIKIT_ALLOW_LOCKED_WRITE=1",
            "context": ", ".join(sorted(set(locked))),
        })


def _require_library_write() -> None:
    """WP-182: the library-write gate, shared by `/v1/library/save` and the
    setup save.

    WP-31/102: on by default only when the service runs from a git checkout
    (the "we are the developers" case); OPTIKIT_ALLOW_LIBRARY_WRITE=0 forces
    it off, =1 forces it on. Container images carry no .git, so deployments
    stay read-only even without the env var — the service authenticates
    nothing itself (WP-188: loopback bind + a local-dev CORS allowlist; the
    deployment's proxy owns auth).
    """
    env = os.environ.get("OPTIKIT_ALLOW_LIBRARY_WRITE")
    dev_checkout = (SCHEMA_DIST.parents[1] / ".git").exists()
    enabled = env != "0" if env is not None else dev_checkout
    if not enabled:
        raise HTTPException(403, {
            "code": "E_WRITE_DISABLED",
            "message": "library writes are disabled — they are on by default only "
                       "when the service runs from a git checkout; set "
                       "OPTIKIT_ALLOW_LIBRARY_WRITE=1 to force-enable "
                       "(the PR flow is the normal contribution road)",
            "context": "",
        })


class SetupSaveBody(BaseModel):
    """WP-182: a whole design to store in the library as `setups/<id>.dsn`."""

    id: str
    design: str  # optikit-design.yml text
    #: WP-185: a `data:image/(png|jpeg);base64,…` screenshot of the viewport as
    #: the user had it when they saved. Optional — a setup saved without one
    #: is still a setup, it just shows a placeholder card.
    thumbnail: str | None = None


class VerifyT1Body(BaseModel):
    """A PROPOSED record trio to verify (WP-113) — YAML texts, not published
    ids: the wizard has not written anything yet. The on-disk library is
    still loaded underneath so refs to already-published records resolve;
    proposed records shadow published ones of the same id."""

    records: list[str]
    #: The cube_module to verify; empty = the single module among ``records``.
    module_id: str = ""


# --- app ----------------------------------------------------------------------------------
#: A LAN- or Tailscale-served frontend names its origin explicitly:
#: OPTIKIT_CORS_ORIGINS=http://100.100.43.118:5173. A public read-only
#: deployment may still set "*" — deliberately, in one place, with writes off.
DEFAULT_CORS_ORIGINS = (
    "http://localhost:5173,http://127.0.0.1:5173,"
    "http://localhost:8000,http://127.0.0.1:8000"
)


def _cors_origins() -> list[str]:

    raw = os.environ.get("OPTIKIT_CORS_ORIGINS", DEFAULT_CORS_ORIGINS)
    return [origin.strip() for origin in raw.split(",") if origin.strip()]


def _generator_holds(repo_root: Path, script: str) -> dict[str, Any]:
    """A generator's `holds` block (WP-258), or {} when it declares none."""
    path = repo_root / f"{script.removesuffix('.py')}.params.json"
    try:
        spec = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    holds = spec.get("holds")
    return holds if isinstance(holds, dict) else {}


def create_app() -> FastAPI:
    app = FastAPI(
        title="optikit-core",
        version=__version__,
        default_response_class=FiniteJSONResponse,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins(),
        allow_methods=["*"],
        allow_headers=["*"],
    )

    def entry_base(files: dict[str, str]) -> str:
        """Directory prefix of the design entry inside the uploaded bundle."""
        if DESIGN_DECL_FILE in files:
            return ""
        key = next((k for k in files if k.endswith("/" + DESIGN_DECL_FILE)), "")
        return key[: -len("/" + DESIGN_DECL_FILE)] if key else ""

    def files_subdesign_loader(files: dict[str, str], base: str = ""):
        """WP-175: SubdesignLoader over the request's files dict.

        A ``design:`` ref resolves to ``<dir>/optikit-design.yml`` within the
        same uploaded bundle (the .dsn zip already carries nested design
        directories); nothing touches the filesystem. Scoped per directory so
        nesting resolves relative to each subdesign, like
        ``io.yamlio.design_dir_loader`` does on disk.
        """
        import posixpath

        from ..schema.design import InstSpec

        def load(design_path: str, instantiation: InstSpec):
            sub = posixpath.normpath(posixpath.join(base, design_path)) if base \
                else posixpath.normpath(design_path)
            key = f"{sub}/{DESIGN_DECL_FILE}"
            text = files.get(key)
            if text is None:
                raise LookupError(f"no {key} in files")
            decl = DesignDecl.model_validate(load_document_text_fast(text) or {})
            return instantiate(decl, instantiation), files_subdesign_loader(files, sub)

        return load

    def subdesign_loader_for(files: dict[str, str]):
        """The loader a design gets: library subdesigns first, then the bundle.

        WP-198: a placed subdesign-backed module carries a LIBRARY ref in
        `design:` (`openuc2.subdesign.x@^0.1`); Go's own relative `*.dsn`
        paths fall through to the uploaded-files loader, so a bundle may mix
        both. With no library configured the bundle loader stands alone —
        exactly the pre-WP-198 behaviour.
        """
        from ..library.subdesigns import library_subdesign_loader

        files_loader = files_subdesign_loader(files, entry_base(files))
        root = library_root_path()
        if not root.is_dir():
            return files_loader
        # cached_library, not load_library: this sits on the live /v1/scene3
        # loop, and a full library re-parse per drag settle is the ~1 s lag.
        return library_subdesign_loader(cached_library(root), fallback=files_loader)

    def parse_design(body: DesignBody) -> DesignDecl:
        entry = body.files.get(DESIGN_DECL_FILE) or next(
            (v for k, v in body.files.items() if k.endswith("/" + DESIGN_DECL_FILE)), None
        )
        if entry is None:
            raise HTTPException(422, {"code": "E_STRUCTURE",
                                      "message": f"no {DESIGN_DECL_FILE} in files",
                                      "context": sorted(body.files)})
        try:
            # Fast plain-data load: the tree goes straight into Pydantic and is
            # discarded, so comment preservation buys nothing here — and this
            # parse is the largest single cost of the live /v1/scene3 loop.
            return DesignDecl.model_validate(load_document_text_fast(entry) or {})
        except ValidationError as exc:
            raise HTTPException(422, {
                "code": "E_STRUCTURE",
                "message": "design failed structural validation",
                "context": [
                    {"loc": ".".join(map(str, e["loc"])), "msg": e["msg"]}
                    for e in exc.errors()
                ],
            }) from exc

    def engine_422(exc: Exception) -> HTTPException:
        code = getattr(exc, "code", "E_INTERNAL")
        where = getattr(exc, "where", getattr(exc, "comp_id", ""))
        detail: dict[str, Any] = {"code": code, "message": str(exc), "context": where}
        escapes = getattr(exc, "escapes", None)
        if escapes:
            # WP-52: structured escape points so the editor can draw the
            # escaping ray and name where it left the system.
            detail["escapes"] = [
                {
                    "source": e.source,
                    "from_comp": e.from_comp,
                    "from_port": e.from_port,
                    "origin_mm": e.origin_mm,
                    "direction": e.direction,
                    "reason": e.reason,
                }
                for e in escapes
            ]
        return HTTPException(422, detail)

    # --- structural / geometric endpoints --------------------------------------------

    @app.post("/v1/validate")
    def validate(body: DesignBody) -> dict[str, Any]:
        decl = parse_design(body)
        findings = check(decl)
        return {
            "ok": not any(f.severity == "error" for f in findings),
            "findings": [
                {"code": f.code, "severity": f.severity, "where": f.where, "message": f.message}
                for f in findings
            ],
        }

    @app.post("/v1/flatten")
    def flatten_endpoint(body: DesignBody) -> dict[str, Any]:
        decl = parse_design(body)
        try:
            report = flat_report(instantiate(decl))
        except (FlattenError, KeyError) as exc:
            raise engine_422(exc) from exc
        return {"report": [e.dump() for e in report]}

    @app.post("/v1/cubify")
    def cubify_endpoint(body: DesignBody) -> dict[str, Any]:
        decl = parse_design(body)
        try:
            result = cubify(
                instantiate(decl),
                dof_values={
                    k: v
                    for k, v in collect_input_values(
                        decl.components, decl.instantiation
                    ).items()
                    if isinstance(v, int | float)
                },
            )
        except FlattenError as exc:
            raise engine_422(exc) from exc
        return {
            "poses": {cid: pose.pose_dict() for cid, pose in result.poses.items()},
            "findings": [f.__dict__ for f in result.findings],
        }

    @app.post("/v1/drc")
    def drc_endpoint(body: DesignBody) -> dict[str, Any]:
        return {"findings": cubify_endpoint(body)["findings"]}

    @app.post("/v1/chain/infer")
    def chain_infer(body: DesignBody) -> dict[str, Any]:
        decl = parse_design(body)
        try:
            result = infer_paths(decl)
        except (ChainError, FlattenError, CompileError) as exc:
            print("chain_infer failed", exc)
            raise engine_422(exc) from exc
        return {
            "paths": result.paths,
            "warnings": result.warnings,
            "escapes": [
                {
                    "source": e.source,
                    "from_comp": e.from_comp,
                    "from_port": e.from_port,
                    "origin_mm": e.origin_mm,
                    "direction": e.direction,
                    "reason": e.reason,
                }
                for e in result.escapes
            ],
        }

    @app.post("/v1/export/go-dsn")
    def export_go_dsn_endpoint(body: DesignBody) -> Response:
        """WP-172/173: the design as a Go-composable nested .dsn folder,
        zipped — library modules become materialized ``modules/<id>.dsn``
        subdesigns with their meshes copied in (see export/go_dsn.py)."""
        import io
        import zipfile

        from ..export.go_dsn import design_to_go_dsn

        decl = parse_design(body)
        library_root = library_root_path()
        library = cached_library(library_root) if library_root.is_dir() else None
        if library is None:
            raise HTTPException(422, {"code": "E_NO_LIBRARY",
                                      "message": f"no library at {library_root}",
                                      "context": str(library_root)})
        # WP-187: a POSTed design has no folder on disk, so a relative
        # subassembly cannot be carried — the warning says so rather than
        # shipping a dangling ref silently.
        result = design_to_go_dsn(decl, library)
        name = download_name(decl.design.name)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for rel, content in sorted(result.files.items()):
                zf.writestr(f"{name}.dsn/{rel}", content)
        headers = {
            "Content-Disposition": f'attachment; filename="{name}.dsn.zip"',
        }
        if result.warnings:
            headers["X-Optikit-Warnings"] = str(len(result.warnings))
        return Response(buf.getvalue(), media_type="application/zip", headers=headers)

    @app.post("/v1/export/step")
    def export_step_endpoint(body: ExportStepBody) -> Response:
        """WP-57: the design as one grouped STEP assembly, streamed back.

        The file is built in a temp dir and returned as bytes — the service
        keeps no state, so nothing is left behind for the caller to clean up.
        """
        import tempfile

        from ..export import ExportError as _ExportError
        from ..export import export_step

        decl = parse_design(body)
        library_root = library_root_path()
        with tempfile.TemporaryDirectory() as tmp:
            safe = download_name(decl.design.name)
            out = Path(tmp) / f"{safe}.step"
            try:
                export_step(
                    decl,
                    out,
                    library_root=library_root if library_root.is_dir() else None,
                    beam=body.beam,
                    beam_radius_mm=body.beam_radius_mm,
                )
            except (_ExportError, FlattenError) as exc:
                raise engine_422(exc) from exc
            payload = out.read_bytes()
        return Response(
            payload,
            media_type="model/step",
            headers={
                "Content-Disposition": f'attachment; filename="{safe}.step"'
            },
        )

    @app.post("/v1/export/step/part")
    def export_step_part_endpoint(body: ExportStepPartBody) -> Response:
        """WP-84: ONE component as a STEP posed w.r.t. its CUBE frame — the
        Inventor round-trip's outbound leg ("design the module around it").

        The return leg needs no endpoint of its own: attaching the resulting
        Inventor STP/GLB back onto the SAME record is a plain
        ``/v1/library/save`` write into the existing template directory.
        """
        import tempfile

        from ..export import ExportError as _ExportError
        from ..export import export_step_part

        decl = parse_design(body)
        library_root = library_root_path()
        safe = download_name(body.component, "component")
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / f"{safe}-in-cube.step"
            try:
                export_step_part(
                    decl,
                    body.component,
                    out,
                    library_root=library_root if library_root.is_dir() else None,
                )
            except (_ExportError, FlattenError) as exc:
                raise engine_422(exc) from exc
            payload = out.read_bytes()
        return Response(
            payload,
            media_type="model/step",
            headers={
                "Content-Disposition": f'attachment; filename="{safe}-in-cube.step"'
            },
        )

    @app.post("/v1/compile")
    def compile_endpoint(body: PathBody) -> dict[str, Any]:
        decl = parse_design(body)
        names = [body.path] if body.path else sorted(decl.paths)
        if not names:
            raise HTTPException(422, {"code": "E_BAD_PATH",
                                      "message": "design declares no paths", "context": ""})
        out: dict[str, Any] = {}
        for name in names:
            try:
                result = compile_path(decl, name)
            except (CompileError, FlattenError) as exc:
                raise engine_422(exc) from exc
            out[name] = {
                "optic": result.optic,
                "manifest": [m.dump() for m in result.manifest],
                "warnings": result.warnings,
            }
        # Return the Response directly: FastAPI's jsonable_encoder would null
        # the ±Infinity radii before FiniteJSONResponse could encode them.
        return FiniteJSONResponse({"paths": out})

    @app.post("/v1/projection")
    def projection_endpoint(body: PathBody) -> dict[str, Any]:
        """WP-153 (B1): the sequential projection, read-only.

        One table per declared path (or the named one): surface rows the way
        a designer reads them — component, type, radius, unfolded z, the gap
        to the next surface, material, semi-aperture — plus `driven_by`, the
        design inputs whose pose expressions move that row (empty = a T1
        row). The editable phase writes those through the D1 channel; this
        endpoint only projects.
        """
        decl = parse_design(body)
        names = [body.path] if body.path else sorted(decl.paths)
        if not names:
            raise HTTPException(422, {"code": "E_BAD_PATH",
                                      "message": "design declares no paths", "context": ""})
        from ..compile.sequence import sequence_rows

        out: dict[str, Any] = {}
        for name in names:
            try:
                result = compile_path(decl, name)
            except (CompileError, FlattenError) as exc:
                raise engine_422(exc) from exc
            out[name] = {
                "rows": sequence_rows(decl, result),
                "warnings": result.warnings,
            }
        return FiniteJSONResponse({"paths": out})

    @app.post("/v1/scene3")
    def scene3_endpoint(body: Scene3Body) -> Response:
        decl = parse_design(body)   # parse the incoming model to the dsn specificiation
        if body.path:
            if body.path not in decl.paths:
                raise HTTPException(422, {"code": "E_BAD_PATH",
                                          "message": f"design declares no path {body.path!r}",
                                          "context": ""})
            decl.paths = {body.path: decl.paths[body.path]}
        from ..canvas import materialize
        findings: list[dict[str, Any]] = []
        tq = body.trace_quality.model_dump() if body.trace_quality else None
        result = materialize(
            decl, trace_quality=tq,
            subdesign_loader=subdesign_loader_for(body.files))
        # Decision 6.14: only *physical* materialization errors reject.
        errors = [f for f in result.findings if f.severity == "error"]
        if errors:
            f = errors[0]
            raise HTTPException(422, {"code": f.code, "message": f.message, "context": f.where})
        # The scene is finite by construction (agent rule 9), so the ±1e999
        # non-finite encoding never triggers; FiniteJSONResponse keeps the
        # response consistent with the other endpoints.
        return FiniteJSONResponse({
            "scene": result.scene,
            "manifest": result.manifest,
            "warnings": [str(w) for w in result.findings if w.severity == "warning"],
            "findings": findings,
        })

    @app.post("/v1/sequence")
    def sequence_endpoint(body: SequenceBody) -> Response:
        """WP-165, producer half: materialize, let the kernel trace, resolve the
        hits to document identity.

        Two modes, one extractor. **Named** ``path`` → that path's declared
        intent alone, plus the folded Optiland projection under
        ``actions=["optic"]`` (``emit_folded``, merged with PR #7). **No path**
        → discovery: every (source, detector) pair is traced and the ones
        carrying light come back as paths, diffed against the authored
        ``paths:`` block. Discovery reads no chain, which is what lets the
        editor stop asking a human to wire ports (part2r Phase A / §0.6).
        """
        decl = parse_design(body)
        if body.path and body.path not in decl.paths:
            raise HTTPException(422, {"code": "E_BAD_PATH",
                                      "message": f"design declares no path {body.path!r}",
                                      "context": ""})
        from ..canvas import materialize
        from ..canvas.sequence import SequenceUnavailable, sequence_for_path

        tq = body.trace_quality.model_dump() if body.trace_quality else None
        result = materialize(
            decl, trace_quality=tq,
            subdesign_loader=subdesign_loader_for(body.files))
        errors = [f for f in result.findings if f.severity == "error"]
        if errors:
            f = errors[0]
            raise HTTPException(422, {"code": f.code, "message": f.message, "context": f.where})

        if not body.path:
            from ..canvas.discover import diff_authored, discover

            try:
                found = discover(result, decl)
            except SequenceUnavailable as exc:
                status = 501 if exc.code == "E_KERNEL_UNAVAILABLE" else 422
                raise HTTPException(status, {"code": exc.code, "message": str(exc),
                                             "context": ""}) from exc
            from ..canvas.pin import SequencePin, diff_pin, pin_from

            out: dict[str, Any] = {
                "paths": {p.name: asdict(p.sequence) for p in found.found},
                "terminals": {p.name: {"source": list(p.source),
                                       "detector": list(p.detector),
                                       "authored_as": p.authored_as}
                              for p in found.found},
                "rejected": [asdict(r) for r in found.rejected],
                "diff": asdict(diff_authored(found, decl)),
                "pairs_traced": found.pairs_traced,
                # A1c: always returned, so a FIRST trace auto-accepts the whole
                # set simply by the client storing what came back (§0.2).
                "pin": pin_from(found, decl).to_dict(),
            }
            if body.pin is not None:
                try:
                    stored = SequencePin.from_dict(body.pin)
                except (ValueError, KeyError, TypeError) as exc:
                    raise HTTPException(422, {
                        "code": "E_PIN_MALFORMED", "message": str(exc),
                        "context": "pin"}) from exc
                drift = diff_pin(stored, found, decl)
                out["pin_diff"] = {
                    "held": [str(k) for k in drift.held],
                    "drifted": [{"key": str(d.key), "summary": d.summary(),
                                 "pinned": asdict(d.pinned),
                                 "traced": asdict(d.traced)}
                                for d in drift.drifted],
                    "appeared": [str(k) for k in drift.appeared],
                    "vanished": [str(k) for k in drift.vanished],
                    "held_fast": drift.held_fast,
                }
            return FiniteJSONResponse(out)

        try:
            seq = sequence_for_path(result, body.path)
        except SequenceUnavailable as exc:
            status = 501 if exc.code == "E_KERNEL_UNAVAILABLE" else 422
            raise HTTPException(status, {"code": exc.code, "message": str(exc),
                                         "context": body.path}) from exc
        out: dict[str, Any] = {"path": body.path, "sequence": asdict(seq)}
        if "optic" in body.actions:
            from ..compile.folded import emit_folded

            try:
                folded = emit_folded(decl, seq)
            except (CompileError, FlattenError) as exc:
                raise engine_422(exc) from exc
            out["optic"] = folded.optic
            out["manifest"] = [m.dump() for m in folded.manifest]
            out["notes"] = [
                *folded.notes,
                "optic is emitted untraced: tracing it rides the upstream optiland "
                "paraxial entry fix. This response carries geometry, not ray results.",
            ]
        return FiniteJSONResponse(out)

    @app.post("/v1/back-annotate")
    def back_annotate_endpoint(body: AnnotateBody) -> dict[str, Any]:
        decl = parse_design(body)
        try:
            result = back_annotate(decl, body.path, _normalize_optic(body.optimized))
        except (AnnotateError, CompileError, FlattenError) as exc:
            raise engine_422(exc) from exc
        response: dict[str, Any] = {
            "deltas": [d.__dict__ for d in result.deltas],
            "findings": [f.__dict__ for f in result.findings],
            "dof_updates": result.dof_updates,
            "updated_design": None,
        }
        if body.apply and result.dof_updates:
            import datetime

            entry_name = DESIGN_DECL_FILE if DESIGN_DECL_FILE in body.files else next(
                k for k in body.files if k.endswith("/" + DESIGN_DECL_FILE)
            )
            doc = load_document_text(body.files[entry_name])
            apply_to_document(
                doc, result,
                optimized_by=body.optimized_by,
                run=datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds"),
                merit={},
            )
            response["updated_design"] = dump_document(doc)
        return FiniteJSONResponse(response)

    @app.post("/v1/calibrate")
    def calibrate_endpoint(body: CalibrateBody) -> dict[str, Any]:
        """WP-86: measured instrument axes → classified dof_value updates.

        The hardware leg of the round trip, through the SAME reviewed table
        the optimizer leg uses. Applying stamps ``provenance.source:
        instrument`` so a calibrated design is distinguishable from an
        optimized one; needs no optiland (nothing is traced — the
        instrument already measured it).
        """
        from ..annotate import apply_calibration_to_document, calibrate_from_instrument

        decl = parse_design(body)
        try:
            result = calibrate_from_instrument(
                decl, body.measurements, instrument=body.instrument
            )
        except (AnnotateError, FlattenError) as exc:
            raise engine_422(exc) from exc
        response: dict[str, Any] = {
            "deltas": [d.__dict__ for d in result.deltas],
            "findings": [f.__dict__ for f in result.findings],
            "dof_updates": result.dof_updates,
            "updated_design": None,
        }
        if body.apply and result.dof_updates:
            import datetime

            entry_name = DESIGN_DECL_FILE if DESIGN_DECL_FILE in body.files else next(
                k for k in body.files if k.endswith("/" + DESIGN_DECL_FILE)
            )
            doc = load_document_text(body.files[entry_name])
            apply_calibration_to_document(
                doc, result,
                instrument=body.instrument,
                run=datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds"),
                note=body.note,
            )
            response["updated_design"] = dump_document(doc)
        return FiniteJSONResponse(response)

    # --- optiland-backed endpoints -----------------------------------------------------

    @app.post("/v1/simulate")
    def simulate(body: SimulateBody) -> dict[str, Any]:
        decl = parse_design(body)
        from optiland import optic as optic_mod
        try:
            compiled = compile_path(decl, body.path)
        except (CompileError, FlattenError) as exc:
            raise engine_422(exc) from exc
        # A path may compile to NOTHING but the object/image planes (every
        # chain component passthrough or terminal). Optiland's ray aimer then
        # dies on a zero-size array — answer with the diagnosis instead.
        if not any(e.fragment_surface_index is not None for e in compiled.manifest):
            raise HTTPException(422, {
                "code": "E_EMPTY_SYSTEM",
                "message": (
                    f"path '{body.path}' contains no optical surfaces — every chain "
                    "component compiled without a fragment (passthrough or terminal). "
                    "Give the components real `optics.fragment` surfaces, or place "
                    "library parts whose records carry a prescription."
                ),
                "context": body.path,
            }) # optic_mod is the imported library
        optic = _optic_from_dict_422(optic_mod, compiled.optic)
        out: dict[str, Any] = {"path": body.path, "warnings": compiled.warnings}
        wavelength = compiled.optic["wavelengths"]["wavelengths"][0]["value"]
        if "trace" in body.actions or "spot" in body.actions:
            optic.trace(
                Hx=0.0, Hy=0.0, wavelength=wavelength,
                num_rays=body.num_rays, distribution=body.distribution,
            )
        if "trace" in body.actions:
            out["rays_world"] = _world_polylines(optic, compiled)
        if "spot" in body.actions:
            sg = optic.surface_group
            out["spot"] = {
                "x": np.asarray(sg.x[-1]).ravel().tolist(),
                "y": np.asarray(sg.y[-1]).ravel().tolist(),
            }
        if "paraxial" in body.actions:
            out["paraxial"] = _paraxial(optic)
        # WP-74: how much light reaches the sensor — the BOM analogue. Best
        # effort: a path with no spectral data reports a fraction of 1.0.
        if "budget" in body.actions or "paraxial" in body.actions:
            import contextlib

            from ..budget import photon_budget

            with contextlib.suppress(KeyError, ValueError):
                out["photon_budget"] = photon_budget(decl, body.path)
        return FiniteJSONResponse(out)

    def _optic_from_dict_422(optic_mod, optic_dict: dict[str, Any]):  # noqa: ANN202
        """WP-63 hardening: an optic optiland's registry rejects is a typed
        422 naming the surface, never an ASGI traceback."""
        try:
            return optic_mod.Optic.from_dict(optic_dict)
        except (ValueError, KeyError, TypeError) as exc:
            surfaces = (optic_dict.get("surface_group") or {}).get("surfaces") or []
            offending = [
                f"surface {i} ({s.get('comment', '?')}): "
                f"material_post type {(s.get('material_post') or {}).get('type')!r}"
                for i, s in enumerate(surfaces)
                if isinstance(s.get("material_post"), dict)
                and (s["material_post"].get("type") or "")
                not in ("Material", "IdealMaterial", "AbbeMaterial", "MaterialFile")
            ]
            raise HTTPException(422, {
                "code": "E_OPTIC_INVALID",
                "message": f"optiland rejected the compiled optic: {exc}",
                "context": offending or [str(exc)],
            }) from exc

    @app.post("/v1/optimize")
    def optimize(body: OptimizeBody) -> dict[str, Any]:
        decl = parse_design(body)
        from optiland import optic as optic_mod
        keys, bounds = _free_dofs(decl, body.dofs)
        if not keys:
            raise HTTPException(422, {"code": "E_NO_DOF",
                                      "message": "no ranged DOFs to optimize",
                                      "context": body.dofs or []})

        def merit(values: np.ndarray) -> float:
            trial = decl.model_copy(deep=True)
            for key, value in zip(keys, values, strict=True):
                set_input_value(trial, key, float(value))
            try:
                compiled = compile_path(trial, body.path)
                optic = optic_mod.Optic.from_dict(compiled.optic)
                wl = compiled.optic["wavelengths"]["wavelengths"][0]["value"]
                optic.trace(Hx=0.0, Hy=0.0, wavelength=wl, num_rays=body.num_rays)
                sg = optic.surface_group
                x = np.asarray(sg.x[-1]).ravel()
                y = np.asarray(sg.y[-1]).ravel()
                return float(np.sqrt(np.nanmean((x - np.nanmean(x)) ** 2 +
                                                (y - np.nanmean(y)) ** 2)))
            except Exception:  # noqa: BLE001 — infeasible trial point
                return 1e9

        from scipy import optimize as sopt

        current = collect_input_values(decl.components, decl.instantiation)
        x0 = np.array([float(current.get(k, 0.0) or 0.0) for k in keys])
        # WP-63: validate the BASELINE optic once, loudly — merit() swallows
        # per-trial failures (infeasible points), which would otherwise turn a
        # broken material into a silent all-1e9 "optimization".
        try:
            baseline = compile_path(decl, body.path)
        except (CompileError, FlattenError) as exc:
            raise engine_422(exc) from exc
        _optic_from_dict_422(optic_mod, baseline.optic)
        rms_before = merit(x0)
        res = sopt.minimize(
            merit, x0, method="Nelder-Mead", bounds=bounds,
            options={"maxiter": body.max_iter, "xatol": 1e-3, "fatol": 1e-9},
        )
        best = {k: float(v) for k, v in zip(keys, res.x, strict=True)}

        optimized_decl = decl.model_copy(deep=True)
        for key, value in best.items():
            set_input_value(optimized_decl, key, value)
        compiled = compile_path(optimized_decl, body.path)
        annotate_result = back_annotate(decl, body.path, compiled.optic)

        # The response used to carry an `fx` block — the Inventor-side
        # changeset for the optimized dof values. That contract is retired
        # with the bridge; the dof values below are the whole answer, and
        # whatever drives CAD next reads them directly.
        return FiniteJSONResponse({
            "dof_values": best,
            "merit": {"rms_spot_before_mm": rms_before, "rms_spot_after_mm": float(res.fun),
                      "iterations": int(res.nit)},
            "optic": compiled.optic,
            "deltas": [d.__dict__ for d in annotate_result.deltas],
            "findings": [f.__dict__ for f in annotate_result.findings],
        })

    # --- mechanical conversion (WP-19 part-binding workbench) --------------------------

    @app.post("/v1/convert/step-to-glb")
    def step_to_glb(body: StepBody) -> Response:
        """STEP → GLB via the OCP XCAF pipeline, mm units preserved.

        WP-175: assembly structure, product names, and colors survive the
        conversion (the old cadquery path fused everything into one grey
        shape, which broke the CUBHLF cube-half mask, the insert re-mount
        split, and colors for every STP import). GLB is a render-only
        exchange format; the STEP stays the mechanical source of truth
        referenced by the record (ARCHITECTURE.md).
        """
        import base64
        import binascii
        import tempfile
        from pathlib import Path as _Path

        try:
            import OCP  # noqa: F401
        except ImportError as exc:
            raise HTTPException(
                501,
                {"code": "E_NO_CADQUERY",
                 "message": "install the generate extra: pip install optikit-core[generate]",
                 "context": str(exc)},
            ) from exc
        from ..importers.step_glb import StepGlbError, step_file_to_glb

        try:
            step_bytes = base64.b64decode(body.data_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"data_b64 is not valid base64: {exc}",
                                      "context": body.filename}) from exc
        with tempfile.TemporaryDirectory() as tmp:
            step_path = _Path(tmp) / "part.step"
            step_path.write_bytes(step_bytes)
            glb_path = _Path(tmp) / "part.glb"
            try:
                step_file_to_glb(step_path, glb_path)
            except StepGlbError as exc:
                raise HTTPException(422, {"code": exc.code,
                                          "message": str(exc),
                                          "context": body.filename}) from exc
            except Exception as exc:  # noqa: BLE001 — OCC raises plain Exceptions
                raise HTTPException(422, {"code": "E_BAD_STEP",
                                          "message": f"OCCT could not convert the STEP: {exc}",
                                          "context": body.filename}) from exc
            return Response(glb_path.read_bytes(), media_type="model/gltf-binary")

    # --- importers for review (WP-82: CLI ↔ frontend parity) ---------------------------
    # The CLI importers auto-write into library/; these endpoints run the SAME
    # importers but return the PROPOSED records for review — the frontend's
    # drop-zone previews them and the user accepts through the ordinary
    # dev-write / zip exits. Nothing here touches the library tree.

    @app.post("/v1/import/zmx")
    def import_zmx(body: ImportZmxBody) -> dict[str, Any]:
        """A vendor .zmx prescription → the proposed component record."""
        import base64
        import binascii
        import tempfile
        from pathlib import Path as _Path

        try:
            import optiland  # noqa: F401

            from ..importers.thorlabs import ZmxImportError, zmx_to_component
        except ImportError as exc:
            raise HTTPException(
                501,
                {"code": "E_NO_OPTILAND",
                 "message": "install the sim extra: pip install optikit-core[sim]",
                 "context": str(exc)},
            ) from exc
        from ..io.yamlio import dump_document

        try:
            zmx_bytes = base64.b64decode(body.data_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"data_b64 is not valid base64: {exc}",
                                      "context": body.filename}) from exc
        with tempfile.TemporaryDirectory() as tmp:
            zmx_path = _Path(tmp) / (_Path(body.filename).name or "lens.zmx")
            zmx_path.write_bytes(zmx_bytes)
            try:
                result = zmx_to_component(
                    zmx_path, mpn=body.mpn,
                    namespace=body.namespace, vendor_name=body.vendor_name,
                )
            except ZmxImportError as exc:
                raise HTTPException(422, {"code": "E_BAD_ZMX",
                                          "message": str(exc),
                                          "context": body.filename}) from exc
        component_id = str(result.component["id"])
        return {
            "component": result.component,
            "review": result.review,
            "efl_mm": result.efl_mm,
            "mpn": result.mpn,
            # Ready for the two accept exits, in the library-PR layout.
            "records": {
                f"components/{component_id}/component.yml": dump_document(result.component),
            },
        }

    # --- the vendor catalog (WP-225/255): a snapshot of candidates, a record only on import ----

    @app.get("/v1/catalog/index")
    def catalog_index(
        kind: str | None = None, q: str = "", cased: bool | None = None,
        page: int = 1, size: int = 100, compact: bool = False,
    ) -> dict[str, Any]:
        """Rows of the newest snapshot, filtered and paged; ``compact`` is the picker's list."""
        from ..catalog.snapshot import paginate, query

        snapshot = _catalog_snapshot()
        hits = query(snapshot.parts, kind=kind, q=q, cased=cased)
        out = paginate(hits, page, size)
        out["items"] = [p.to_compact() if compact else p.to_json() for p in out["items"]]
        out["snapshot"] = snapshot.summary()
        return out

    @app.get("/v1/catalog/part/{part_id:path}")
    def catalog_part(part_id: str) -> dict[str, Any]:
        snapshot = _catalog_snapshot()
        part = snapshot.by_id(part_id)
        if part is None:
            raise HTTPException(404, {"code": "E_CATALOG_UNKNOWN_PART",
                                      "message": f"no row {part_id!r}",
                                      "context": snapshot.version})
        return {"snapshot": snapshot.summary(), "part": part.to_json(), "cased": part.is_cased(),
                "prescriptionFile": (part.prescription_file() or CatalogFile(kind="", url=""))
                .to_json() or None}

    @app.post("/v1/catalog/import")
    def catalog_import(body: CatalogImportBody) -> dict[str, Any]:
        """A catalog row → the proposed component record, same shape as /v1/import/zmx."""
        from ..catalog.importer import CatalogImportError, import_part
        from ..io.yamlio import dump_document

        snapshot = _catalog_snapshot()
        # A row derived FROM a library record (`catalog from-library`) is that
        # record: hand it back as it is, nothing to derive or write.
        row = snapshot.by_id(body.id)
        if row is not None and row.provenance and row.provenance[0].source == "libraryRecord":
            from ..library import load_library, resolve

            record_id = row.provenance[0].note.split("@", 1)[0]
            hit = resolve(load_library(library_root_path()), f"{record_id}@*")
            if hit is None:
                raise HTTPException(404, {"code": "E_CATALOG_UNKNOWN_PART",
                                          "message": f"{record_id} is no longer in the library",
                                          "context": body.id})
            component = hit.record.model_dump(by_alias=True, exclude_none=True)
            return {"component": component, "review": [], "efl_mm": None,
                    "road": "library", "part_id": body.id, "records": {}}
        try:
            outcome = import_part(snapshot, body.id, road=body.road, namespace=body.namespace,
                                  cache_dir=_catalog_dir() / "files")
        except CatalogImportError as exc:
            status = (404 if exc.code == "E_CATALOG_UNKNOWN_PART"
                      else 501 if exc.code == "E_NO_OPTILAND" else 422)
            raise HTTPException(status, {"code": exc.code, "message": str(exc),
                                         "context": body.id}) from exc
        component_id = str(outcome.component["id"])
        return {
            "component": outcome.component,
            "review": outcome.review,
            "efl_mm": outcome.efl_mm,
            "road": outcome.road,
            "part_id": outcome.part_id,
            "records": {f"components/{component_id}/component.yml":
                        dump_document(outcome.component)},
        }

    # --- fluorophore spectra (FPbase, CC BY-SA 4.0): the filter-set dialog's dye curves ------

    @app.get("/v1/spectra/index")
    def spectra_index() -> dict[str, Any]:
        """Every fluorophore's identity and peaks — no curves."""
        snapshot = _spectra_snapshot()
        return {"snapshot": snapshot.summary(), "provenance": snapshot.provenance,
                "items": [e.head() for e in snapshot.entries]}

    @app.get("/v1/spectra/{entry_id:path}")
    def spectra_entry(entry_id: str) -> dict[str, Any]:
        """One fluorophore with its normalized ex/em curves (1 nm grid, peak = 1)."""
        snapshot = _spectra_snapshot()
        entry = snapshot.by_id(entry_id)
        if entry is None:
            raise HTTPException(404, {"code": "E_SPECTRA_UNKNOWN",
                                      "message": f"no fluorophore {entry_id!r}",
                                      "context": snapshot.version})
        return {"snapshot": snapshot.summary(), "entry": asdict(entry)}

    @app.post("/v1/import/optiland")
    def import_optiland(body: ImportOptilandBody) -> dict[str, Any]:
        """A whole Optiland setup → unbound components + a placement plan (WP-87)."""
        import base64
        import binascii
        from pathlib import Path as _Path

        from ..importers.optiland_setup import (
            OptilandSetupError,
            name_prefix_from_filename,
            setup_to_components,
        )

        try:
            setup_bytes = base64.b64decode(body.data_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"data_b64 is not valid base64: {exc}",
                                      "context": body.filename}) from exc
        try:
            optic_json = json.loads(setup_bytes.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_OPTILAND",
                                      "message": f"not a JSON document: {exc}",
                                      "context": body.filename}) from exc
        if isinstance(optic_json, dict):
            # A browser round-trip flattens ±Infinity radii — restore them.
            optic_json = _normalize_optic(optic_json)
        try:
            result = setup_to_components(
                optic_json,
                namespace=body.namespace,
                name_prefix=name_prefix_from_filename(_Path(body.filename).name),
            )
        except OptilandSetupError as exc:
            raise HTTPException(422, {"code": "E_BAD_OPTILAND",
                                      "message": str(exc),
                                      "context": body.filename}) from exc
        return {
            "components": result.components,
            "placements": result.placements,
            "review": result.review,
            # Ready for the two accept exits, in the library-PR layout.
            "records": result.records,
            "wavelengths_um": result.wavelengths_um,
        }

    @app.post("/v1/import/glb")
    def import_glb(body: ImportGlbBody) -> dict[str, Any]:
        """A marker-stamped Inventor GLB → the proposed record trio."""
        import base64
        import binascii
        import tempfile
        from pathlib import Path as _Path

        try:
            import pygltflib  # noqa: F401

            from ..importers import import_glb_file
        except ImportError as exc:
            raise HTTPException(
                501,
                {"code": "E_NO_PYGLTFLIB",
                 "message": "install the importers extra: pip install optikit-core[importers]",
                 "context": str(exc)},
            ) from exc
        from ..importers.glb2template import bbox_thumbnail_svg
        from ..io.yamlio import dump_document

        try:
            glb_bytes = base64.b64decode(body.data_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"data_b64 is not valid base64: {exc}",
                                      "context": body.filename}) from exc
        glb_name = _Path(body.filename).name or "cube.glb"
        with tempfile.TemporaryDirectory() as tmp:
            glb_path = _Path(tmp) / glb_name
            glb_path.write_bytes(glb_bytes)
            try:
                result = import_glb_file(glb_path, namespace=body.namespace)
            except Exception as exc:  # noqa: BLE001 — pygltflib raises plain errors
                raise HTTPException(422, {"code": "E_BAD_GLB",
                                          "message": f"could not parse the GLB: {exc}",
                                          "context": body.filename}) from exc

        # The mesh the user just dropped IS the template asset — reference it
        # so the accepting client (which holds the bytes) ships it alongside,
        # and the honesty rule (assets only advertised when present) holds.
        template = dict(result.template)
        template["glb"] = glb_name
        module = dict(result.module)
        module["thumbnail"] = "thumbnail.svg"
        component_id = str(result.component["id"])
        template_id = str(template["id"])
        module_id = str(module["id"])
        return {
            "component": result.component,
            "template": template,
            "module": module,
            "review": result.review,
            "envelope_mm": list(result.envelope_mm),
            "glb_asset_path": f"templates/{template_id}/{glb_name}",
            "records": {
                f"components/{component_id}/component.yml": dump_document(result.component),
                f"templates/{template_id}/template.yml": dump_document(template),
                f"modules/{module_id}/module.yml": dump_document(module),
                f"modules/{module_id}/thumbnail.svg": bbox_thumbnail_svg(
                    result.envelope_mm, module_id.rsplit(".", 1)[-1]
                ),
            },
        }

    @app.post("/v1/draw")
    def draw_layout(body: DrawBody) -> Response:
        """WP-82: the compiled path as optiland's 2D layout drawing (PNG).

        The engine has always been able to draw this (`main.py --only draw`);
        now the editor can at least view it. Headless: matplotlib Agg, no
        window, the bytes stream back.
        """
        import io

        try:
            import matplotlib
            from optiland.optic import Optic
        except ImportError as exc:
            raise HTTPException(
                501,
                {"code": "E_NO_OPTILAND",
                 "message": "install the sim extra: pip install optikit-core[sim]",
                 "context": str(exc)},
            ) from exc
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        decl = parse_design(body)
        try:
            result = compile_path(decl, body.path)
        except (CompileError, FlattenError) as exc:
            raise engine_422(exc) from exc
        optic = Optic.from_dict(result.optic)
        try:
            optic.draw(num_rays=max(1, min(64, body.num_rays)), figsize=(10, 4))
            buffer = io.BytesIO()
            plt.savefig(buffer, format="png", dpi=110, bbox_inches="tight")
        finally:
            plt.close("all")
        return Response(buffer.getvalue(), media_type="image/png")

    # --- T3 generation (WP-61: the harness becomes service-reachable) ------------------

    @app.get("/v1/generators")
    def list_generators() -> dict[str, Any]:
        """WP-258: what each T3 generator can HOLD, so an editor offers only the
        ones a record satisfies — the wizard rule, served rather than hardcoded.

        A generator declares `holds` in its `params.json`; one that declares
        none is not a holder (`optic_solid` builds the optic itself, `plate_nxm`
        a baseplate) and is left out.
        """
        repo_root = SCHEMA_DIST.parents[1]
        out: list[dict[str, Any]] = []
        for path in sorted((repo_root / "generators").glob("*.params.json")):
            try:
                spec = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            holds = spec.get("holds")
            if not isinstance(holds, dict):
                continue
            out.append({
                "script": f"generators/{path.name[: -len('.params.json')]}.py",
                "title": spec.get("title", ""),
                "description": spec.get("description", ""),
                "holds": holds,
                # The schemas are `additionalProperties: false`, so a caller has
                # to know which of the pose keys THIS road takes: the boolean
                # holder has no `beam_axis`, the thread no plate outline.
                "accepts": sorted(spec.get("properties", {})),
            })
        return {"generators": out}

    @app.post("/v1/generate")
    def generate_t3(body: GenerateBody) -> dict[str, Any]:
        """Run a T3 generator: an existing generative template by id, OR an
        ad-hoc boolean holder around a bare optical component (WP-60's
        unbound primitives — the "put it in a cube" verb).

        Honours the sha256 params key: an identical request is a cache hit
        (``regenerated: false``), not a rebuild. With ``files`` + ``component``
        the design component's placed intra-cube δ/ΔR folds into the params
        (``pose_params_from_component``) so the cavity is carved where the
        optic ACTUALLY sits. Artifacts return base64-inline — they live under
        the repo's ``out/``, which is not a served asset tree.
        """
        import base64

        from ..generate import GenerateError, generate, pose_params_from_component
        from ..schema.library import TemplateRecord

        if bool(body.template_id) == bool(body.component_id):
            raise HTTPException(422, {
                "code": "E_BAD_REQUEST",
                "message": "give exactly one of template_id | component_id",
                "context": {"template_id": body.template_id,
                            "component_id": body.component_id},
            })

        # `repo_root` is a DIFFERENT thing from the library root and stays
        # tied to this source tree: it is where generated CAD lands (`out/`),
        # which belongs to the service, not to the record library.
        repo_root = SCHEMA_DIST.parents[1]
        library_root = library_root_path()
        if not library_root.is_dir():
            raise HTTPException(404, {"code": "E_NOT_FOUND",
                                      "message": f"no record library at {library_root}",
                                      "context": str(library_root)})
        library = cached_library(library_root)

        if body.template_id:
            record = next(
                (e.record for e in library.records
                 if isinstance(e.record, TemplateRecord) and e.record.id == body.template_id),
                None,
            )
            if record is None:
                raise HTTPException(404, {"code": "E_NOT_FOUND",
                                          "message": f"no template {body.template_id!r}",
                                          "context": str(library_root)})
            # An ADAPTIVE template is the T2 road. It used to be driven by
            # the Inventor bridge (WP-85), which is retired — the road is
            # being rebuilt on CadQuery, so say that plainly instead of
            # running the T3 generator on a template it was never meant for.
            if record.class_ == "adaptive":
                raise HTTPException(501, {
                    "code": "E_T2_UNAVAILABLE",
                    "message": "the T2 (adaptive) road is being ported to CadQuery — "
                               "the Inventor bridge that drove it is retired",
                    "context": body.template_id,
                })
        else:
            # Ad-hoc holder around a bare component. Prefer the vendor STEP
            # when the record ships one; otherwise the cut body is derived
            # from the prescription (WP-62). The synthesized id matches what
            # the editor materializes on accept, so the accepted template's
            # first regenerate is a cache hit on this very run.
            slug = (body.component_id or "").split(".")[-1].replace("-", "_")
            comp_step = library_root / "components" / str(body.component_id) / "model.step"
            if "part_step" in body.params or "part_prescription" in body.params:
                # The request names its own cut body — exactly-one is enforced
                # by the params schema, so the record must not add a default.
                cut_body: dict[str, Any] = {}
            elif comp_step.is_file():
                cut_body = {"part_step": f"library/components/{body.component_id}/model.step"}
            else:
                cut_body = {"part_prescription": {"component": body.component_id}}
            # WP-245/WP-258: which generator holds it. The boolean holder is
            # the general one (any shape, any STEP); every other road cuts from
            # the PRESCRIPTION and says what it can hold in its `holds` block.
            # Naming the script beats inferring it: a mirror in a cartridge is
            # a refusal we want the caller to see, not a silent fallback.
            script = body.generator or "generators/boolean_holder_1x1.py"
            holds = _generator_holds(repo_root, script)
            if holds.get("outline", "any") == "any":
                generator_params: dict[str, Any] = {
                    **cut_body, "clearance_mm": 0.15,
                    "split_plane": "xz", "body_height_mm": 30}
                description = f"boolean holder around {body.component_id}"
                envelope = {"x-mm": 50, "y-mm": 50, "z-mm": 50}
            else:
                # These cut from the PRESCRIPTION only — a vendor STEP is the
                # boolean holder's road. A road that does not cut from it (the
                # SM1 thread) is not handed one: a record with no fragment
                # would fail expansion for a check it only uses as a guard.
                base: dict[str, Any] = {}
                if holds.get("needs_prescription") and "part_prescription" not in body.params:
                    base = {"part_prescription": {"component": body.component_id}}
                generator_params = {**base, "fit_clearance_mm": 0.15}
                label = holds.get("label") or "printed holder"
                description = f"printed {label} around {body.component_id}"
                envelope = {"x-mm": 50, "y-mm": 50, "z-mm": 55}
            record = TemplateRecord.model_validate({
                "kind": "mechanical_template",
                "id": f"user.tpl.holder_{slug}",
                "version": "0.1.0",
                "class": "generative",
                "description": description,
                "envelope": envelope,
                "generator": {"script": script, "params": generator_params},
            })

        # The T3 road runs CadQuery in-process; gate here so a T2 run above
        # never needed the generate extra at all.
        try:
            import cadquery  # noqa: F401
        except ImportError as exc:
            # The harness could shell out via uv, but a service that quietly
            # spawns subprocess builds per request is a foot-gun — mirror
            # /v1/convert/step-to-glb and ask for the extra instead.
            raise HTTPException(
                501,
                {"code": "E_NO_CADQUERY",
                 "message": "install the generate extra: pip install optikit-core[generate]",
                 "context": str(exc)},
            ) from exc

        overrides: dict[str, Any] = {}
        if body.files and body.component:
            decl = parse_design(DesignBody(files=body.files))
            comp = decl.components.get(body.component)
            if comp is None:
                raise HTTPException(422, {
                    "code": "E_BAD_REQUEST",
                    "message": f"no component {body.component!r} in the design",
                    "context": sorted(decl.components),
                })
            overrides.update(pose_params_from_component(
                comp, record.generator.params if record.generator else {}
            ))
        overrides.update(body.params)

        try:
            result = generate(
                record,
                params_override=overrides,
                out_root=repo_root / "out",
                repo_root=repo_root,
                # The RECORD library, which is its own repo since R1 — not
                # `repo_root/library`. Without it a `part_prescription`
                # naming the user's own component fails "not in the library".
                library_root=library_root,
            )
        except GenerateError as exc:
            raise engine_422(exc) from exc

        wanted = {
            f".{fmt.lstrip('.').lower()}" for fmt in
            (body.artifact_formats or ["step", "stl", "glb"])
        }
        artifacts = {
            p.name: base64.b64encode(p.read_bytes()).decode("ascii")
            for p in sorted(result.out_dir.glob("model*"))
            if p.suffix in {".step", ".stl", ".glb"} and p.suffix in wanted
        }
        return {
            "template_id": result.template_id,
            "generator": record.generator.script if record.generator else "",
            "key": result.key,
            "out_dir": str(result.out_dir.relative_to(repo_root)),
            "regenerated": result.regenerated,
            "meta": result.meta,
            "artifacts": artifacts,
        }

    @app.post("/v1/library/cubify")
    def library_cubify(body: LibraryCubifyBody) -> dict[str, Any]:
        """WP-243: publish a generated holder as a cube module.

        The T3 run already happened (`/v1/generate` — its `out_dir` and the
        params that keyed it come back in the request); this turns those
        artifacts into the record trio: a T3 template carrying the generator
        + params as provenance and the STEP/GLB as its mesh, plus a module
        binding it to the EXISTING optical component. The prescription is
        never re-authored — D2's `component:` side names the published record.
        """
        from ..library.cubify import CubifyError, cubify_generated, write_cubified

        _require_library_write()
        library_root = library_root_path()
        library = cached_library(library_root)

        component = next(
            (r.record for r in library.by_kind("optical_component")
             if r.record.id == body.component_id), None)
        if component is None:
            raise HTTPException(404, {
                "code": "E_NOT_FOUND",
                "message": f"no optical_component {body.component_id!r}",
                "context": body.component_id})

        out_dir = _artifact_dir(SCHEMA_DIST.parents[1], body.out_dir)
        artifacts = {
            p.name: p.read_bytes() for p in sorted(out_dir.iterdir())
            if p.suffix in {".step", ".stp", ".glb"}
        }

        # The cube shell: the module shares the cube's own template, and its
        # mesh is copied into the design folder as a `cube-shell` child so the
        # subdesign stands alone the way Go's examples do.
        shell = next((r for r in library.by_kind("cube_module")
                      if r.record.id == body.shell_module), None)
        if shell is None:
            raise HTTPException(404, {
                "code": "E_NOT_FOUND",
                "message": f"no cube_module {body.shell_module!r} to take the shell from",
                "context": body.shell_module})
        shell_template = str(shell.record.template)
        shell_mesh: tuple[str, bytes] | None = None
        tpl_id = shell_template.split("@")[0]
        tpl = next((r for r in library.by_kind("mechanical_template")
                    if r.record.id == tpl_id), None)
        if tpl is not None and getattr(tpl.record, "glb", None):
            mesh_path = tpl.path.parent / str(tpl.record.glb)
            if mesh_path.is_file():
                shell_mesh = ("cube-shell.glb", mesh_path.read_bytes())

        try:
            result = cubify_generated(
                component,
                slug=body.slug,
                generator_script=body.generator,
                params=body.params,
                artifacts=artifacts,
                shell_template=shell_template,
                shell_mesh=shell_mesh,
                footprint_grid=tuple(body.footprint_grid),
            )
        except CubifyError as exc:
            raise HTTPException(422, {"code": exc.code, "message": exc.message,
                                      "context": body.slug}) from exc
        written = write_cubified(library_root, result)
        return {
            "design_id": result.design_id,
            "module_id": result.module_id,
            "written": written,
            "notes": result.notes,
        }

    @app.get("/v1/generate/bundle")
    def generate_bundle(out_dir: str, name: str = "parts") -> Response:
        """WP-251: one run's artifacts as a single zip — STEP, STL, GLB and
        the run's meta.json. `out_dir` is what `/v1/generate` returned; the
        files never left the disk, so this is a read, not a rebuild.
        """
        import io
        import zipfile

        target = _artifact_dir(SCHEMA_DIST.parents[1], out_dir)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as bundle:
            for path in sorted(target.iterdir()):
                if path.suffix in {".step", ".stl", ".glb", ".json"}:
                    bundle.write(path, path.name)
        stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("_.") or "parts"
        return Response(
            buf.getvalue(), media_type="application/zip",
            headers={"Content-Disposition": f'attachment; filename="{stem}.zip"'},
        )

    @app.post("/v1/mesh/nodes")
    def mesh_nodes(body: MeshNodesBody) -> dict[str, Any]:
        """WP-192: the named node hierarchy of a GLB, hardware-classified.

        The moving-parts picker consumes this so the tree, the hardware
        filter and the names E_KIN_NODE_MISSING later validates against all
        come from ONE implementation (library.mesh.glb_node_tree /
        HARDWARE_NODE_RE). The frontend keeps a mirror only as its offline
        fallback.
        """
        import base64
        import binascii

        from ..library.mesh import glb_node_tree

        try:
            data = base64.b64decode(body.data_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"data_b64 is not base64: {exc}",
                                      "context": ""}) from exc
        try:
            return {"nodes": glb_node_tree(data)}
        except ValueError as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": str(exc), "context": ""}) from exc

    @app.post("/v1/library/delete")
    def library_delete(body: LibraryDeleteBody) -> dict[str, Any]:
        """Retire records: move their directories to ``archive/`` (WP-68).

        Never an erase — the archive keeps the files and ``archived_ids``
        keeps the ids out of ref resolution. Guarded by the library-write
        gate plus a password. TODO: the password is a hardcoded placeholder
        until the service grows real auth; rotate it by editing this string.
        """
        import shutil

        _require_library_write()
        if body.password != "youseetoo123":
            raise HTTPException(403, {"code": "E_BAD_PASSWORD",
                                      "message": "wrong password", "context": ""})
        library_root = library_root_path()
        _refuse_locked(library_root, list(body.ids))
        archived: list[str] = []
        missing: list[str] = []
        for record_id in body.ids:
            found = False
            for folder in ("components", "templates", "modules", "groups"):
                source = library_root / folder / record_id
                if not source.is_dir():
                    continue
                target = library_root / "archive" / folder / record_id
                if target.exists():
                    n = 2
                    while (library_root / "archive" / folder / f"{record_id}-{n}").exists():
                        n += 1
                    target = library_root / "archive" / folder / f"{record_id}-{n}"
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(source), str(target))
                archived.append(f"{folder}/{record_id}")
                found = True
            if not found:
                missing.append(record_id)
        return {"archived": archived, "missing": missing}

    @app.post("/v1/library/save")
    def library_save(body: LibrarySaveBody) -> dict[str, Any]:
        """Developer fast path: write records straight into the repo library.

        WP-31: enabled BY DEFAULT when the service runs from a git checkout
        (the "we are the developers" case); OPTIKIT_ALLOW_LIBRARY_WRITE=0
        forces it off (the prod compose pins that), =1 forces it on. Container
        images carry no .git, so deployments stay read-only even without the
        env var. The normal road for contributions is the PR flow (WP-22).
        """
        import base64

        from ..io.yamlio import load_document_text
        from ..schema.library import (
            COMPONENT_FILE,
            GROUP_FILE,
            MODULE_FILE,
            TEMPLATE_FILE,
            load_record,
        )

        # WP-102: this used to `setdefault(..., "1")` FIRST, which made `env`
        # never None and the checkout probe below dead code — so writes were
        # enabled unconditionally, in containers too, contradicting the
        # docstring. With no auth of its own (pre-WP-188 the CORS default was
        # even "*"), that let any page a user visits POST arbitrary YAML into
        # their library while the service ran. Let the probe do its job.
        _require_library_write()

        library_root = library_root_path()
        kind_files = {
            "optical_component": ("components", COMPONENT_FILE),
            "mechanical_template": ("templates", TEMPLATE_FILE),
            "cube_module": ("modules", MODULE_FILE),
            "cube_group": ("groups", GROUP_FILE),
        }
        written: list[str] = []
        records = []
        for text in body.records:
            try:
                record = load_record(load_document_text(text) or {})
            except Exception as exc:  # noqa: BLE001 — reported as a typed 422
                raise HTTPException(422, {"code": "E_BAD_RECORD",
                                          "message": str(exc), "context": ""}) from exc
            if record.kind not in kind_files:
                raise HTTPException(422, {
                    "code": "E_BAD_RECORD",
                    "message": f"{record.kind} records are not written through this endpoint",
                    "context": record.id,
                })
            records.append((text, record))
        # Nothing is written before every record passed: a locked id in the
        # batch refuses the whole batch.
        _refuse_locked(library_root, [r.id for _, r in records])
        for text, record in records:
            folder, filename = kind_files[record.kind]
            rec_dir = library_root / folder / record.id
            rec_dir.mkdir(parents=True, exist_ok=True)
            (rec_dir / filename).write_text(text, encoding="utf-8")
            written.append(f"{folder}/{record.id}/{filename}")
        for rel, data_b64 in body.assets.items():
            target = (library_root / rel).resolve()
            if library_root.resolve() not in target.parents:
                raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                          "message": f"asset path escapes the library: {rel}",
                                          "context": rel})
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(base64.b64decode(data_b64))
            written.append(rel)
        return {"written": written}

    @app.post("/v1/library/decompose")
    def library_decompose(body: LibraryDecomposeBody) -> dict[str, Any]:
        """Turn a published record's moving parts into a subdesign.

        Runs AFTER `/v1/library/save` wrote the trio: reads the records back
        off the library, authors the children with their input expressions
        (surface-bound tilts and/or whole-optic travel, WP-229 + WP-235),
        writes the subdesign folder, and points the module's optical side at
        it. The served index then carries `design.inputs`, so the editors'
        sliders exist the moment the palette refreshes.
        """
        from ..library.decompose import (
            DecomposeError,
            decompose_moving_parts,
            point_module_at_design,
            write_subdesign,
        )

        _require_library_write()
        library_root = library_root_path()
        library = cached_library(library_root)

        def _record(kind: str, record_id: str):
            hit = next(
                (r for r in library.by_kind(kind) if r.record.id == record_id), None)
            if hit is None:
                raise HTTPException(404, {"code": "E_NOT_FOUND",
                                          "message": f"no {kind} {record_id!r}",
                                          "context": record_id})
            return hit

        component = _record("optical_component", body.component_id)
        template = _record("mechanical_template", body.template_id)
        module = _record("cube_module", body.module_id)
        # WP-238: hand the template's mesh over so the moving subtrees the
        # wizard picked can be split out — without it the optic rides the
        # slider and the metal stays put.
        mesh: bytes | None = None
        glb = getattr(template.record, "glb", None)
        if glb:
            mesh_path = template.path.parent / str(glb)
            if mesh_path.is_file():
                mesh = mesh_path.read_bytes()
        try:
            result = decompose_moving_parts(
                component.record, template.record, body.moving_parts, mesh=mesh)
        except DecomposeError as exc:
            raise HTTPException(422, {"code": exc.code, "message": exc.message,
                                      "context": body.template_id}) from exc
        written = write_subdesign(library_root, result)
        point_module_at_design(module.path, result.design_id)
        written.append(str(module.path.relative_to(library_root)))
        return {
            "design_id": result.design_id,
            "inputs": result.inputs,
            "written": written,
            "notes": result.notes,
        }

    @app.post("/v1/library/compose")
    def library_compose(body: LibraryComposeBody) -> dict[str, Any]:
        """WP-204: publish an optic-on-a-moving-cube pair (the fifth road).

        Reads both existing records off the library, authors the subdesign +
        the new module, and writes them. The index then serves the new module
        with `design.inputs`, so its slider exists on the next palette refresh.
        """
        from ..library.compose import (
            ComposeError,
            compose_axis_bound,
            write_composed,
        )

        _require_library_write()
        library_root = library_root_path()
        library = cached_library(library_root)

        def _record(kind: str, record_id: str):
            hit = next(
                (r for r in library.by_kind(kind) if r.record.id == record_id), None)
            if hit is None:
                raise HTTPException(404, {"code": "E_NOT_FOUND",
                                          "message": f"no {kind} {record_id!r}",
                                          "context": record_id})
            return hit

        component = _record("optical_component", body.component_id)
        carrier = _record("cube_module", body.module_id)
        spec: dict[str, Any] = {"units": body.units}
        if body.min is not None and body.max is not None and body.min < body.max:
            spec["min"], spec["max"] = body.min, body.max
        # WP-240: a design-backed carrier's subdesign rides along — resolve
        # it here, where the library is in hand.
        carrier_design = None
        carrier_dir = None
        if getattr(carrier.record, "design", ""):
            from ..io.yamlio import load_design
            from ..library.subdesigns import SubdesignError, subdesign_dir
            try:
                _, design_file = subdesign_dir(library, carrier.record.design)
                carrier_design = load_design(design_file.parent).model_dump(
                    by_alias=True, exclude_defaults=True, exclude_none=True)
                carrier_dir = design_file.parent
            except (SubdesignError, ValueError, OSError) as exc:
                raise HTTPException(422, {
                    "code": "E_COMPOSE_TAKEN",
                    "message": f"carrier {carrier.record.id} has a design: "
                               f"side that does not resolve ({exc})",
                    "context": body.module_id}) from exc
        try:
            result = compose_axis_bound(
                component.record, carrier.record,
                slug=body.slug, input_name=body.input, input_spec=spec,
                axis=body.axis, beam=body.beam, ratio=body.ratio,
                offset_mm=body.offset_mm, tilt_deg=body.tilt_deg,
                carrier_design=carrier_design, carrier_dir=carrier_dir,
            )
        except ComposeError as exc:
            raise HTTPException(422, {"code": exc.code, "message": exc.message,
                                      "context": body.module_id}) from exc
        written = write_composed(library_root, result)
        return {
            "design_id": result.design_id,
            "module_id": result.module_id,
            "input": result.input,
            "written": written,
            "notes": result.notes,
        }

    @app.post("/v1/library/opm-structure")
    def library_opm_structure(body: OpmStructureBody) -> dict[str, Any]:
        """The plates and puzzle joints an arrangement needs (the OPM wizard).

        Derived from the members, never typed: the covering rectangle per
        outer layer and a joint wherever cubes stack. A plate size with no
        record yet is MINTED here (trio + `plate_nxm` geometry), which is why
        this writes and needs the library-write gate.
        """
        from ..library.opm import opm_structure

        _require_library_write()
        try:
            return opm_structure(library_root_path(), body.members, list(body.envelope_grid))
        except ValidationError as exc:
            raise HTTPException(422, {"code": "E_BAD_RECORD", "message": str(exc),
                                      "context": "members"}) from exc

    @app.post("/v1/quote/notify")
    def quote_notify(body: QuoteNotifyBody) -> dict[str, Any]:
        """Mail a quote request to openUC2 over SMTP.

        Config: `OPTIKIT_SMTP_HOST` (+ `_PORT` 587, `_USER`, `_PASSWORD`),
        `OPTIKIT_QUOTE_TO`, `OPTIKIT_QUOTE_FROM` (defaults to the recipient).
        Unconfigured → 503 E_QUOTE_MAIL_UNCONFIGURED; the client then falls
        back to its `mailto:` road. A send failure is 502 E_QUOTE_MAIL_FAILED.
        """
        import smtplib
        from email.message import EmailMessage

        host = os.environ.get("OPTIKIT_SMTP_HOST")
        to = os.environ.get("OPTIKIT_QUOTE_TO")
        if not host or not to:
            raise HTTPException(503, {
                "code": "E_QUOTE_MAIL_UNCONFIGURED",
                "message": "set OPTIKIT_SMTP_HOST and OPTIKIT_QUOTE_TO (and OPTIKIT_SMTP_USER/"
                           "OPTIKIT_SMTP_PASSWORD, OPTIKIT_QUOTE_FROM) to mail quote requests",
                "context": "",
            })
        msg = EmailMessage()
        msg["Subject"] = body.subject
        msg["From"] = os.environ.get("OPTIKIT_QUOTE_FROM") or to
        msg["To"] = to
        if body.reply_to:
            msg["Reply-To"] = body.reply_to
        msg.set_content(body.text)
        try:
            port = int(os.environ.get("OPTIKIT_SMTP_PORT", "587"))
            with smtplib.SMTP(host, port, timeout=20) as smtp:
                smtp.starttls()
                user = os.environ.get("OPTIKIT_SMTP_USER")
                if user:
                    smtp.login(user, os.environ.get("OPTIKIT_SMTP_PASSWORD", ""))
                smtp.send_message(msg)
        except (OSError, smtplib.SMTPException) as exc:
            raise HTTPException(502, {"code": "E_QUOTE_MAIL_FAILED", "message": str(exc),
                                      "context": host}) from exc
        return {"sent": True, "to": to}

    @app.post("/v1/import/objective")
    def import_objective(body: ObjectiveImportBody) -> dict[str, Any]:
        """Mint an objective's records into a scratch root and return them for review.

        Same road as `optikit-core import objective`; nothing reaches the
        library until the client saves through `/v1/library/save` (the write
        gate lives there). Records come back as YAML text by relative path,
        assets (the converted barrel GLB) base64 by relative path.
        """
        import base64
        import tempfile

        from ..importers.objective import ObjectiveFacts, mint_objective

        facts = ObjectiveFacts(
            slug=body.slug,
            display=body.display or body.slug.replace("_", " "),
            manufacturer=body.manufacturer,
            magnification=body.magnification,
            numerical_aperture=body.numerical_aperture,
            efl_mm=body.efl_mm if body.efl_mm is not None
            else body.tube_lens_f_mm / body.magnification,
            working_distance_mm=body.working_distance_mm,
            tube_lens_f_mm=body.tube_lens_f_mm,
            immersion=body.immersion,
            thread=body.thread,
            parfocal_distance_mm=body.parfocal_distance_mm,
            field_number_mm=body.field_number_mm,
            correction=body.correction,
            price_eur=body.price_eur,
            mpn=body.mpn,
            docs=list(body.docs),
        )
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            step = zmx = None
            if body.step_b64:
                step = root / (Path(body.step_name).name or "barrel.step")
                step.write_bytes(base64.b64decode(body.step_b64))
            if body.zmx_text:
                zmx = root / "vendor.zmx"
                zmx.write_text(body.zmx_text, encoding="utf-8")
            try:
                written = mint_objective(root, facts, namespace=body.namespace,
                                         zmx=zmx, step=step, front_axis=body.step_axis)
            except Exception as exc:  # noqa: BLE001 — a bad STEP/zmx is the user's input
                raise HTTPException(422, {"code": "E_OBJECTIVE_IMPORT", "message": str(exc),
                                          "context": body.slug}) from exc
            records: dict[str, str] = {}
            assets: dict[str, str] = {}
            for file in written:
                rel = file.relative_to(root).as_posix()
                if file.suffix in (".yml", ".yaml"):
                    records[rel] = file.read_text(encoding="utf-8")
                else:
                    assets[rel] = base64.b64encode(file.read_bytes()).decode()
        return {"records": records, "assets": assets}

    @app.post("/v1/library/publish")
    def library_publish(body: LibraryPublishBody) -> dict[str, Any]:
        """M2: put already-written records into review as a pushed branch.

        Two gates, deliberately separate. `OPTIKIT_ALLOW_LIBRARY_WRITE`
        governs whether the service may write a file at all;
        `OPTIKIT_LIBRARY_PUSH_REMOTE` governs whether it may push to the
        shared catalogue. "Can save locally" and "can publish to everyone" are
        different permissions and collapsing them into one flag is how a dev
        convenience becomes a supply-chain hole.

        The service does not open the PR. It pushes a branch and hands back
        GitHub's compare URL; a human clicks it, reads the diff, and raises the
        PR under their own account — so there is no bot identity to create, no
        PR token to scope, and the reviewer is talking to the author.
        """
        from ..library.publish import PublishError, publish

        env = os.environ.get("OPTIKIT_ALLOW_LIBRARY_WRITE")
        dev_checkout = (SCHEMA_DIST.parents[1] / ".git").exists()
        if not (env != "0" if env is not None else dev_checkout):
            raise HTTPException(403, {
                "code": "E_WRITE_DISABLED",
                "message": "library writes are disabled; publishing needs them on",
                "context": "",
            })
        try:
            result = publish(
                library_root_path(), body.files, body.slug or "record",
                body.message or f"library: {body.slug or 'record'}")
        except PublishError as exc:
            status = 403 if exc.code == "E_PUBLISH_DISABLED" else 422
            raise HTTPException(status, {"code": exc.code, "message": exc.message,
                                         "context": ""}) from exc
        return {
            "branch": result.branch,
            "commit": result.commit,
            "remote": result.remote,
            "files": result.files,
            # Empty for a non-GitHub remote: the branch is pushed either way,
            # and saying so beats inventing a URL that 404s.
            "compare_url": result.compare_url,
        }

    @app.post("/v1/library/verify-t1")
    def library_verify_t1(body: VerifyT1Body) -> dict[str, Any]:
        """verify-t1 over a PROPOSED trio (WP-113): do the optical model and
        the mechanics agree, before anything is published?

        The check existed only as a CLI command; the wizard's last step runs
        it here. Findings come back verbatim ({code, level, message}) —
        including ``W_NO_INSERT_FRAME``, which the caller must surface: a
        template with no ``frames:`` makes the OK VACUOUS (it passes without
        ever comparing a pose, which is precisely how a wrong record ships).
        """
        from ..io.yamlio import load_document_text
        from ..library.build import Library, LoadedRecord
        from ..library.verify import verify_t1, verify_t1_ok
        from ..schema.library import load_record

        proposed: list[LoadedRecord] = []
        for i, text in enumerate(body.records):
            try:
                record = load_record(load_document_text(text) or {})
            except Exception as exc:  # noqa: BLE001 — reported as a typed 422
                raise HTTPException(422, {"code": "E_BAD_RECORD",
                                          "message": str(exc), "context": ""}) from exc
            proposed.append(LoadedRecord(record=record, path=Path(f"proposed-{i}")))

        module_id = body.module_id or next(
            (r.record.id for r in proposed if r.record.kind == "cube_module"), "")
        if not module_id:
            raise HTTPException(422, {
                "code": "E_BAD_REQUEST",
                "message": "no cube_module among the proposed records and no module_id "
                           "given — verify-t1 checks a module's bound pair",
                "context": "",
            })

        # Proposed records FIRST so a same-id@higher-version proposal wins
        # resolution; the published library underneath resolves refs to
        # records the proposal does not carry.
        library_root = library_root_path()
        published = cached_library(library_root) if library_root.is_dir() else Library()
        library = Library(records=[*proposed, *published.records], root=published.root)

        findings = verify_t1(library, module_id)
        return {
            "ok": verify_t1_ok(findings),
            "module_id": module_id,
            "findings": [
                {"code": f.code, "level": f.level, "message": f.message} for f in findings
            ],
        }

    # --- library registry (WP-22) --------------------------------------------------------
    # The service IS the registry: the frontend's default index URL points
    # here; the static /configurator/optikit-library/index.json bundled with
    # the frontend is the offline fallback only.

    # WP-51: the index is cached against the library tree's state key
    # (max mtime + file count from a cheap os.scandir walk), so dev writes
    # still appear instantly — they touch the tree, the key changes, the
    # cache misses. `?fresh=1` bypasses the cache outright.
    index_cache: dict[str, Any] = {"key": None, "index": None}

    @app.get("/v1/library/index")
    def library_index(fresh: bool = False) -> Response:
        from ..library.build import (
            build_index,
            dump_index_json,
            serving_provenance,
        )

        library_root = library_root_path()
        if not library_root.is_dir():
            raise HTTPException(404, {"code": "E_NOT_FOUND",
                                      "message": f"no record library at {library_root} "
                                                 "(set OPTIKIT_LIBRARY_ROOT)",
                                      "context": ""})

        key = _library_state_key(library_root)
        if fresh or index_cache["key"] != key or index_cache["index"] is None:
            # Build from the tree (the WP-22 freshness contract), then cache
            # the DICT against the tree state it was built from.
            index_cache["key"] = key
            index_cache["index"] = build_index(
                cached_library(library_root), library_root)
        # Provenance is response-only and computed per request, never cached:
        # it answers "WHICH library is this process serving, at which commit",
        # and a hash cached from before the operator's last commit would
        # mislead in exactly the situation the field exists for. The committed
        # index artifact stays free of it — see `serving_provenance`'s
        # docstring for why an environment field in the artifact breaks the
        # rebuild-equality CI. dump_index_json keeps .inf fragment radii
        # strict-JSON safe (WP-60).
        body = dump_index_json(
            {**index_cache["index"], **serving_provenance(library_root)})
        return Response(body, media_type="application/json")

    @app.get("/v1/library/setups/{setup_id}")
    def library_setup(setup_id: str) -> Response:
        """WP-182: one library setup's design YAML.

        A setup IS a design (`setups/<id>.dsn/optikit-design.yml`); the
        browser opens it through the same `.dsn` import road every other
        design takes, so nothing here needs to understand optics.
        """
        from ..io.yamlio import DESIGN_DECL_FILE
        from ..library.build import SETUPS_DIR

        library_root = library_root_path()
        target = (library_root / SETUPS_DIR / f"{setup_id}.dsn" / DESIGN_DECL_FILE).resolve()
        # No traversal: the resolved file must stay under library/setups.
        setups_root = (library_root / SETUPS_DIR).resolve()
        if setups_root not in target.parents or not target.is_file():
            raise HTTPException(404, {"code": "E_NOT_FOUND",
                                      "message": f"no setup {setup_id!r}",
                                      "context": ""})
        return Response(target.read_text(encoding="utf-8"), media_type="text/yaml")

    @app.post("/v1/library/setups")
    def library_setup_save(body: SetupSaveBody) -> dict[str, Any]:
        """WP-182: save the current design into the library as a setup.

        Same write gate as `/v1/library/save` (dev checkout, or
        OPTIKIT_ALLOW_LIBRARY_WRITE=1) — this writes into the user's library
        tree, so it must not be reachable from a random page in prod.
        """
        from ..io.yamlio import DESIGN_DECL_FILE
        from ..library.build import SETUPS_DIR

        _require_library_write()
        slug = re.sub(r"[^a-z0-9._-]+", "-", body.id.strip().lower()).strip("-._")
        if not slug:
            raise HTTPException(422, {"code": "E_BAD_ID",
                                      "message": "a setup needs a name",
                                      "context": body.id})
        # Structural gate: what lands in the library must be a valid design.
        # Unparseable YAML is the same kind of refusal as a schema violation —
        # both mean "this is not a design", and neither may reach the disk.
        try:
            DesignDecl.model_validate(load_document_text_fast(body.design) or {})
        except ValidationError as exc:
            raise HTTPException(422, {"code": "E_STRUCTURE",
                                      "message": "the design does not validate",
                                      "context": str(exc.errors()[:3])}) from exc
        except Exception as exc:  # noqa: BLE001 — YAML parsers raise their own
            raise HTTPException(422, {"code": "E_STRUCTURE",
                                      "message": f"the design is not readable YAML: {exc}",
                                      "context": ""}) from exc
        target = library_root_path() / SETUPS_DIR / f"{slug}.dsn"
        target.mkdir(parents=True, exist_ok=True)
        (target / DESIGN_DECL_FILE).write_text(body.design, encoding="utf-8")
        written = [f"{SETUPS_DIR}/{slug}.dsn/{DESIGN_DECL_FILE}"]

        # WP-185: the viewport screenshot. A bad image must not cost the user
        # the design they just saved, so the YAML is already on disk and a
        # preview that will not decode is dropped with a note in the reply.
        preview_note: str | None = None
        if body.thumbnail:
            try:
                name = _write_setup_preview(target, body.thumbnail)
            except ValueError as exc:
                preview_note = str(exc)
            else:
                written.append(f"{SETUPS_DIR}/{slug}.dsn/{name}")
        return {
            "id": slug,
            "written": written[0],
            "files": written,
            "preview": preview_note is None and len(written) > 1,
            "preview_error": preview_note,
        }

    @app.get("/v1/library/setups/{setup_id}/preview")
    def library_setup_preview(setup_id: str) -> Response:
        """WP-185: the screenshot saved with a setup (see `setup_preview_path`)."""
        from ..library.build import SETUPS_DIR, setup_preview_path

        library_root = library_root_path()
        setup_dir = (library_root / SETUPS_DIR / f"{setup_id}.dsn").resolve()
        setups_root = (library_root / SETUPS_DIR).resolve()
        # No traversal: the resolved directory must stay under library/setups.
        if setups_root != setup_dir.parent:
            raise HTTPException(404, {"code": "E_NOT_FOUND",
                                      "message": f"no setup {setup_id!r}",
                                      "context": ""})
        preview = setup_preview_path(setup_dir)
        if preview is None:
            raise HTTPException(404, {"code": "E_NOT_FOUND",
                                      "message": f"setup {setup_id!r} has no preview",
                                      "context": ""})
        media = "image/png" if preview.suffix == ".png" else "image/jpeg"
        return Response(preview.read_bytes(), media_type=media)

    # `:path`: a WP-228 record nests .dsn folders, so an asset path may
    # carry subdirectories. The traversal guard below still applies.
    @app.get("/v1/library/assets/{kind}/{record_id}/{filename:path}")
    def library_asset(kind: str, record_id: str, filename: str) -> Response:
        import mimetypes

        if kind not in ("components", "templates", "modules", "subdesigns"):
            raise HTTPException(404, {"code": "E_NOT_FOUND", "message": kind, "context": ""})
        library_root = library_root_path()
        target = (library_root / kind / record_id / filename).resolve()
        # No traversal: the resolved file must stay under library/.
        if library_root not in target.parents or not target.is_file():
            raise HTTPException(404, {"code": "E_NOT_FOUND",
                                      "message": f"{kind}/{record_id}/{filename}",
                                      "context": ""})
        media = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if target.suffix == ".glb":
            media = "model/gltf-binary"
        return Response(target.read_bytes(), media_type=media)

    # --- schema ------------------------------------------------------------------------

    @app.get("/v1/schema")
    def schema_index() -> dict[str, Any]:
        return {"schemas": sorted(p.name for p in SCHEMA_DIST.glob("*.schema.json"))}

    @app.get("/v1/schema/{name}")
    def schema_file(name: str) -> Response:
        file = SCHEMA_DIST / name
        if not file.is_file() or file.suffix != ".json":
            raise HTTPException(404, {"code": "E_NOT_FOUND", "message": name, "context": ""})
        return Response(file.read_text(encoding="utf-8"), media_type="application/json")

    return app


# --- optiland helpers -----------------------------------------------------------------------



def _paraxial(optic: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for name in ("f1", "f2", "F1", "F2", "P1", "P2", "EPD", "EPL", "FNO", "magnification"):
        try:
            out[name] = float(getattr(optic.paraxial, name)())
        except Exception:  # noqa: BLE001 — metric not defined for this system
            continue
    return out


def _world_polylines(optic: Any, compiled: CompileResult) -> list[list[list[float]]]:
    """Re-fold traced per-surface intersections into world-coordinate polylines."""
    sg = optic.surface_group
    xs, ys, zs = np.asarray(sg.x), np.asarray(sg.y), np.asarray(sg.z)
    n_rays = xs.shape[1] if xs.ndim == 2 else 1
    polylines: list[list[list[float]]] = []
    for ray in range(n_rays):
        points: list[list[float]] = []
        for entry in compiled.manifest:
            world = entry.world
            if world is None:
                continue
            i = entry.surface_index
            x = float(xs[i][ray]) if xs.ndim == 2 else float(xs[i])
            y = float(ys[i][ray]) if ys.ndim == 2 else float(ys[i])
            z = float(zs[i][ray]) if zs.ndim == 2 else float(zs[i])
            if not all(map(math.isfinite, (x, y, z))):
                continue
            p = (
                np.array(world["axis_point"])
                + x * np.array(world["u"])
                + y * np.array(world["v"])
                + (z - world["cs_z"]) * np.array(world["direction"])
            )
            points.append([round(float(v), 6) for v in p])
        if len(points) >= 2:
            polylines.append(points)
    return polylines


def _free_dofs(
    decl: DesignDecl, requested: list[str] | None
) -> tuple[list[str], list[tuple[float, float]]]:
    """The optimizer's variable set and bounds — from the design's `inputs:`.

    WP-230: this used to walk every component's `dof:` for a declared range.
    With that retired, the Go-native source is the design's own input
    declarations, whose `min`/`max` ARE Go's fields — so a parametric design
    optimizes over exactly the variables it declares, which is also what the
    editor's sliders offer. Values ride `instantiation.inputs` as before.

    A variable is a design INPUT with both bounds declared; the key is the
    input's own name, because that is what the design calls it (the old
    ``<component>.<dof>`` key named a declaration that no longer exists).
    """
    keys: list[str] = []
    bounds: list[tuple[float, float]] = []
    for name, spec in decl.inputs.items():
        if spec.min is None or spec.max is None:
            continue
        if requested is not None and name not in requested:
            continue
        keys.append(name)
        bounds.append((float(spec.min), float(spec.max)))
    return keys, bounds


app = create_app()
