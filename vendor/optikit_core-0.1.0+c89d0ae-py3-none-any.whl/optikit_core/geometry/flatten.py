"""Resolve the translation anchor digraph to absolute world poses.

Mirrors the semantics of the Go reference (exp/designs/designs-.go, as of
``origin/subassemblies``, synced 2026-07-17 — WP-36):

- **anchor chains** (``CompsSpec.TranslFlattened()``): translations accumulate
  along the chain with grid and mm offsets kept separate; **rotations do not
  compose along the chain** — a component's rotation is always relative to its
  own design's frame. Ethan's rename ``Flattened → TranslFlattened`` codifies
  exactly this contract.
- **subassembly boundaries** (``FSDesign.Flattened()``, new on the branch):
  the FULL 4×4 transform composes — a subassembly's rotation rotates its
  children: ``M_world = M_parent · M_child``. Component ids join with ``/``
  and primitive model paths are prefixed with the subdesign path
  (:func:`flat_design_report`).

Deviation from Go, deliberate: a component with rotation type ``""`` (no
spatial geometry) reports the identity rotation rather than Go's degenerate
zero matrix. The grid-pitch constant (E1) is fixed on Ethan's branch — both
implementations now use (50, 50, 55) mm.
"""

from __future__ import annotations

import posixpath
from dataclasses import dataclass, field
from typing import Any, Protocol

import numpy as np

from ..constants import UC2_GRID_MM
from ..schema.common import is_expr
from ..schema.design import (
    KNOWN_ROT_TYPES,
    CompSpec,
    InstSpec,
    PoseSpec,
)
from .rotations import compose, matrix_to_euler_zxy


class FlattenError(Exception):
    """Typed flattening failure; ``code`` is stable API."""

    def __init__(self, code: str, comp_id: str, message: str) -> None:
        super().__init__(f"{code} at component {comp_id!r}: {message}")
        self.code = code
        self.comp_id = comp_id


@dataclass
class FlatPose:
    """Absolute pose of one component in the design frame."""

    #: Accumulated integer grid offset (kept separate, as in Go).
    offset_grid: tuple[int, int, int]
    #: Accumulated continuous offset, mm.
    offset_mm: tuple[float, float, float]
    #: 3×3 rotation matrix (R24 · ΔR from offset-deg).
    rotation: np.ndarray

    @property
    def position_mm(self) -> tuple[float, float, float]:
        g, mm, s = self.offset_grid, self.offset_mm, UC2_GRID_MM
        return (g[0] * s[0] + mm[0], g[1] * s[1] + mm[1], g[2] * s[2] + mm[2])


def _numeric(value: Any, comp_id: str, what: str) -> float:
    if isinstance(value, bool) or not isinstance(value, int | float):
        if is_expr(value):
            raise FlattenError(
                "E_TEMPLATED",
                comp_id,
                f"{what} holds unresolved template {value!r}; instantiate first",
            )
        raise FlattenError("E_BAD_VALUE", comp_id, f"{what} is not a number: {value!r}")
    return float(value)


def _rotation_matrix(comp_id: str, comp: CompSpec) -> np.ndarray:
    # WP-140: a `quaternion` rotation (Go @21dc193) is normalized to the
    # equivalent grid + offset-deg on the way in — one resolver, and the
    # discrete state the editors read is recovered rather than lost.
    rot = comp.pose.rotation.normalized()
    if rot.kind not in KNOWN_ROT_TYPES or rot.kind == "z-spherical":
        if rot.kind == "z-spherical":
            raise FlattenError(
                "E_ROT_UNSUPPORTED", comp_id, "z-spherical rotations are not resolved yet"
            )
        raise FlattenError("E_ROT_UNSUPPORTED", comp_id, f"rotation type {rot.kind!r}")
    if rot.kind == "euler":
        # WP-194: normalized() converts every numeric euler to grid+offset-deg;
        # the type survives only when a leaf holds an unresolved template.
        # Name the leaf rather than silently posing the part at identity.
        for axis in ("x", "y", "z"):
            _numeric(getattr(rot.euler, axis), comp_id, f"euler.{axis}")
        raise FlattenError("E_TEMPLATED", comp_id, "euler rotation left unresolved")
    offset_deg = {
        "x": _numeric(rot.offset_deg.x, comp_id, "offset-deg.x"),
        "y": _numeric(rot.offset_deg.y, comp_id, "offset-deg.y"),
        "z": _numeric(rot.offset_deg.z, comp_id, "offset-deg.z"),
    }
    # type "" = no spatial geometry: identity keeps the report well-defined.
    try:
        return compose(rot.grid.z, rot.grid.x, offset_deg)
    except ValueError as exc:
        # GO-SYNC §7.5: a bad axis name is DATA, so it must fail typed. It
        # reaches here only on a path that skipped check() (which reports
        # E_ROT_AXIS); without this the service answered 500 instead of 422.
        raise FlattenError("E_ROT_AXIS", comp_id, str(exc)) from None


def flatten(components: dict[str, CompSpec]) -> dict[str, FlatPose]:
    """Anchor-resolve every component to an absolute pose.

    Raises :class:`FlattenError` with code ``E_ANCHOR_MISSING`` or
    ``E_ANCHOR_CYCLE`` (or ``E_TEMPLATED`` for unresolved parametric values).
    """
    poses: dict[str, FlatPose] = {}

    Vec3i = tuple[int, int, int]
    Vec3f = tuple[float, float, float]

    def resolve(comp_id: str, trail: tuple[str, ...]) -> tuple[Vec3i, Vec3f]:
        if comp_id in trail:
            cycle = " -> ".join([*trail[trail.index(comp_id):], comp_id])
            raise FlattenError(
                "E_ANCHOR_CYCLE", comp_id, f"translation anchors form a cycle: {cycle}"
            )
        comp = components.get(comp_id)
        if comp is None:
            raise FlattenError("E_ANCHOR_MISSING", trail[-1] if trail else comp_id,
                               f"nonexistent translation anchor {comp_id!r}")
        t = comp.pose.translation
        gx = int(_numeric(t.offset_grid.x, comp_id, "offset-grid.x"))
        gy = int(_numeric(t.offset_grid.y, comp_id, "offset-grid.y"))
        gz = int(_numeric(t.offset_grid.z, comp_id, "offset-grid.z"))
        mx = _numeric(t.offset_mm.x, comp_id, "offset-mm.x")
        my = _numeric(t.offset_mm.y, comp_id, "offset-mm.y")
        mz = _numeric(t.offset_mm.z, comp_id, "offset-mm.z")
        if t.anchor:
            (ax, ay, az), (amx, amy, amz) = resolve(t.anchor, (*trail, comp_id))
            return (gx + ax, gy + ay, gz + az), (mx + amx, my + amy, mz + amz)
        return (gx, gy, gz), (mx, my, mz)

    for comp_id, comp in components.items():
        grid, mm = resolve(comp_id, ())
        poses[comp_id] = FlatPose(
            offset_grid=grid, offset_mm=mm, rotation=_rotation_matrix(comp_id, comp)
        )
    return poses


# --- DOF application (shared by compile and canvas materialize) --------------------











# --- FlatReport (the Go PrimReport analogue) ---------------------------------------


@dataclass
class FlatEntry:
    """One primitive in the report. Field names match the Go ``PrimReport``
    (type/static-models/position/rotation{type,order,angles}); ``id`` is
    additive, and ``model`` is the schema-v0 singular spelling (WP-170:
    resolved via ``PrimSpec.model_path()``, so it is populated whichever
    spelling authored the primitive)."""

    id: str
    kind: str
    position: tuple[float, float, float]
    rotation: dict[str, Any] = field(default_factory=dict)
    static_models: dict[str, str] = field(default_factory=dict)

    def dump(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "id": self.id,
            "kind": self.kind,
            "position": list(self.position),
            "rotation": self.rotation,
        }
        if self.static_models:
            out["static-models"] = self.static_models
        return out


def flat_report(components: dict[str, CompSpec]) -> list[FlatEntry]:
    """World pose per primitive component, sorted by id (Go: ReportPrimitives)."""
    poses = flatten(components)
    entries: list[FlatEntry] = []
    for comp_id in sorted(components):
        comp = components[comp_id]
        if comp.kind != "primitive":
            continue
        if _poseless(comp):
            continue
        pose = poses[comp_id]
        ex, ey, ez = matrix_to_euler_zxy(pose.rotation)
        angles: dict[str, float] = {}
        if abs(ex) > 1e-12:
            angles["x"] = ex
        if abs(ey) > 1e-12:
            angles["y"] = ey
        if abs(ez) > 1e-12:
            angles["z"] = ez
        entries.append(
            FlatEntry(
                id=comp_id,
                kind=comp.primitive.kind or "static",
                position=pose.position_mm,
                rotation={"kind": "extrinsic", "order": "zxy", "angles": angles},
                static_models=_static_models_dict(comp, ""),
            )
        )
    return entries


def _poseless(comp: CompSpec) -> bool:
    """Go's ``ReportPrimitives`` skips primitives whose pose is entirely the
    zero value — e.g. a BOM-only purchasable (a magnet) with no geometry."""
    return comp.pose == PoseSpec()


def _static_models_dict(comp: CompSpec, model_prefix: str) -> dict[str, str]:
    """The primitive's ``static-models`` as a plain dict, paths prefixed like
    Go's ``FSDesign.Flattened`` prefixes subdesign model paths."""
    sm = comp.primitive.static_models
    out: dict[str, str] = {}
    for fmt, path in (("gltf", sm.gltf), ("step", sm.step)):
        if path:
            out[fmt] = posixpath.join(model_prefix, path) if model_prefix else path
    return out


# --- recursive subassembly flattening (WP-36, Go: FSDesign.Flattened) ---------------


class SubdesignLoader(Protocol):
    """Loads a subassembly's components; scoped to one design directory.

    Called with the ``design:`` path (relative to the current design's
    directory) and the instantiation for the child — the requested variant
    plus input VALUES, both already CONCRETE (the parent's environment
    evaluated them, WP-195). Returns the instantiated components plus a
    loader scoped to the SUBDESIGN's own directory, so nesting resolves like
    the Go reference's ``FSDesign.LoadFSDesign`` (each design sees paths
    relative to itself).
    """

    def __call__(
        self, design_path: str, instantiation: InstSpec
    ) -> tuple[dict[str, CompSpec], SubdesignLoader]: ...


def _child_instantiation(comp_id: str, comp: CompSpec) -> InstSpec:
    """The InstSpec a ``type: design`` component hands its loader.

    By this point the parent's :func:`~optikit_core.schema.merge.instantiate`
    must have evaluated ``instantiation.variant`` — a surviving ``~ `` prefix
    means the design skipped instantiation, and silently treating the
    expression as a literal variant id would select nothing.
    """
    variant = comp.instantiation.variant
    if variant.startswith("~ "):
        raise FlattenError(
            "E_TEMPLATED",
            comp_id,
            f"instantiation.variant holds unevaluated expression {variant!r}; "
            "instantiate first",
        )
    return InstSpec(variant=variant, inputs=dict(comp.instantiation.inputs))


def _euler_angles(rotation: np.ndarray) -> dict[str, float]:
    ex, ey, ez = matrix_to_euler_zxy(rotation)
    return {k: v for k, v in (("x", ex), ("y", ey), ("z", ez)) if abs(v) > 1e-12}


def flat_design_report(
    components: dict[str, CompSpec],
    load_subdesign: SubdesignLoader | None = None,
) -> list[FlatEntry]:
    """World pose per primitive, recursing into ``type: design`` components.

    Anchor chains still compose translations only (:func:`flatten`), but at a
    subassembly boundary the parent's FULL transform applies to the children —
    ``R_world = R_parent · R_sub``, ``t_world = R_parent · t_sub + t_parent``
    (Go: ``FSDesign.Flattened``, ``flattenedSubmat = mat · submat``). Ids join
    with ``/``; model paths are prefixed with the subdesign path. Without a
    loader, ``design`` components are skipped (the WP-2 behavior).
    """
    entries: list[FlatEntry] = []

    def collect(
        comps: dict[str, CompSpec],
        loader: SubdesignLoader | None,
        id_prefix: str,
        model_prefix: str,
        parent_r: np.ndarray,
        parent_t: np.ndarray,
    ) -> None:
        poses = flatten(comps)
        for comp_id in sorted(comps):
            comp = comps[comp_id]
            pose = poses[comp_id]
            world_r = parent_r @ pose.rotation
            world_t = parent_r @ np.asarray(pose.position_mm) + parent_t
            joined = posixpath.join(id_prefix, comp_id) if id_prefix else comp_id
            if comp.kind == "primitive":
                if _poseless(comp):
                    continue
                entries.append(
                    FlatEntry(
                        id=joined,
                        kind=comp.primitive.kind or "static",
                        position=(float(world_t[0]), float(world_t[1]), float(world_t[2])),
                        rotation={
                            "kind": "extrinsic",
                            "order": "zxy",
                            "angles": _euler_angles(world_r),
                        },
                        static_models=_static_models_dict(comp, model_prefix),
                    )
                )
            elif comp.kind == "design" and loader is not None:
                sub_comps, sub_loader = loader(comp.design, _child_instantiation(joined, comp))
                collect(
                    sub_comps,
                    sub_loader,
                    joined,
                    posixpath.join(model_prefix, comp.design) if model_prefix else comp.design,
                    world_r,
                    world_t,
                )

    collect(components, load_subdesign, "", "", np.eye(3), np.zeros(3))
    return sorted(entries, key=lambda e: e.id)


def inline_subassemblies(
    components: dict[str, CompSpec],
    load_subdesign: SubdesignLoader | None = None,
    _depth: int = 0,
) -> tuple[dict[str, CompSpec], list[tuple[str, str, str]]]:
    """WP-175: expand ``type: design`` components into ``/``-namespaced siblings.

    The optical lanes iterate a flat components dict, so without this a
    subassembly's contents are invisible to them: the assembly RENDERS (the
    mechanical lane recurses — :func:`flat_design_report`) while every lens
    inside is optically missing, and a trace happily "confirms" a beam that
    only reaches the detector because the glass is not there.

    Children arrive with their world pose BAKED — anchors resolved within the
    subassembly, then the parent's full transform applied (``R_w = R_parent ·
    R_child``) and written back as grid + ``offset-deg`` residual + ``offset-mm``
    — so plain :func:`flatten` and its consumers see an ordinary flat design.

    Returns the expanded dict plus ``(code, where, message)`` notes for
    subassemblies that could not be expanded (no loader, unresolvable
    ``design:``). The design component stays as an inert placed box either way,
    so manifests keep naming it.
    """
    if _depth > 32:
        raise FlattenError(
            "E_SUBDESIGN_DEPTH", "",
            "subassembly nesting deeper than 32 levels — a design that includes itself?")
    notes: list[tuple[str, str, str]] = []
    out: dict[str, CompSpec] = dict(components)
    design_ids = [cid for cid, c in components.items() if c.kind == "design"]
    if not design_ids:
        return out, notes
    poses = flatten(components)
    for cid in sorted(design_ids):
        comp = components[cid]
        where = f"components.{cid}"
        if load_subdesign is None:
            notes.append((
                "W_SUBDESIGN_SKIPPED", where,
                f"subassembly {comp.design!r} not expanded (no subdesign loader "
                "here); its contents are invisible to the trace"))
            continue
        # An unevaluated `~ ` variant is a caller bug (instantiate first), not
        # a loading problem — it raises rather than degrading to a note.
        child_inst = _child_instantiation(cid, comp)
        try:
            sub_comps, sub_loader = load_subdesign(comp.design, child_inst)
        except Exception as exc:
            notes.append((
                "W_SUBDESIGN_SKIPPED", where,
                f"subassembly {comp.design!r} failed to load ({exc}); "
                "its contents are invisible to the trace"))
            continue
        sub_comps, sub_notes = inline_subassemblies(sub_comps, sub_loader, _depth + 1)
        notes += [
            (code, f"components.{posixpath.join(cid, w.removeprefix('components.'))}", msg)
            for code, w, msg in sub_notes
        ]
        sub_poses = flatten(sub_comps)
        parent_r = poses[cid].rotation
        parent_t = np.asarray(poses[cid].position_mm)
        for sub_id in sorted(sub_comps):
            child = sub_comps[sub_id]
            world_r = parent_r @ sub_poses[sub_id].rotation
            world_t = parent_r @ np.asarray(sub_poses[sub_id].position_mm) + parent_t
            ex, ey, ez = matrix_to_euler_zxy(world_r)
            out[posixpath.join(cid, sub_id)] = child.model_copy(update={
                "pose": PoseSpec.model_validate({
                    "rotation": {"kind": "grid",
                                 "offset-deg": {"x": ex, "y": ey, "z": ez}},
                    "translation": {"offset-mm": {"x": float(world_t[0]),
                                                  "y": float(world_t[1]),
                                                  "z": float(world_t[2])}},
                }),
            })
    return out, notes
