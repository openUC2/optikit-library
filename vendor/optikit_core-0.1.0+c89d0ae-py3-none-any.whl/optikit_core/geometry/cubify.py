"""Cubify — forward annotation from world poses to grid poses, plus DRC.

The KiCad "update board from schematic" step: for each component,

    p = S·g + δ      g = round(p / S) → ``translation.offset-grid``
                     δ = p − S·g     → ``translation.offset-mm``
    R = R24 · ΔR     nearest of the 24 → ``rotation.grid``
                     ΔR (extrinsic-ZXY degrees) → ``rotation.offset-deg``

followed by design-rule checks. Each finding carries a stable code, the
component id, and the axis it concerns (`` "" `` when not axis-specific).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..constants import UC2_GRID_MM
from ..schema.common import is_expr
from ..schema.design import CompSpec
from .flatten import FlatPose, flatten
from .rotations import Rot24Decomposition, decompose

#: Below this, a residual is considered numerical noise, not a real offset.
TOLERANCE_MM = 1e-6
TOLERANCE_DEG = 1e-6

AXES = ("x", "y", "z")


def _round_half_up(v: float) -> int:
    """JS Math.round semantics (ties toward +∞), matching the TS frontend."""
    return int(math.floor(v + 0.5))


@dataclass(frozen=True)
class DrcFinding:
    """One design-rule violation. ``code`` ∈ DRC_RANGE | DRC_T1_MOVED |
    DRC_COLLISION | DRC_APERTURE."""

    code: str
    comp: str
    axis: str  # x|y|z, or "" when not axis-specific
    message: str

    def __str__(self) -> str:
        where = f"{self.comp}.{self.axis}" if self.axis else self.comp
        return f"{self.code} at {where}: {self.message}"


@dataclass
class CubifiedPose:
    """The grid pose a world pose decomposes into (ready for a ``.dsn`` pose)."""

    offset_grid: tuple[int, int, int]
    offset_mm: tuple[float, float, float]
    rot24: tuple[str, str]  # (z, x)
    offset_deg: dict[str, float]
    residual_angle_deg: float

    def pose_dict(self) -> dict:
        """As a schema-v0 ``pose:`` mapping (zero members omitted)."""
        grid = {a: v for a, v in zip(AXES, self.offset_grid, strict=True) if v}
        mm = {a: v for a, v in zip(AXES, self.offset_mm, strict=True) if abs(v) > TOLERANCE_MM}
        deg = {a: v for a, v in self.offset_deg.items() if abs(v) > TOLERANCE_DEG}
        rotation: dict = {"kind": "grid"}
        rot_grid = {}
        if self.rot24[0] != "+z":
            rot_grid["z"] = self.rot24[0]
        if self.rot24[1] != "+x":
            rot_grid["x"] = self.rot24[1]
        if rot_grid:
            rotation["grid"] = rot_grid
        if deg:
            rotation["offset-deg"] = deg
        translation: dict = {}
        if grid:
            translation["offset-grid"] = grid
        if mm:
            translation["offset-mm"] = mm
        return {"rotation": rotation, "translation": translation}


def cubify_pose(position_mm: tuple[float, float, float], rotation: np.ndarray) -> CubifiedPose:
    """Decompose one world pose (mm + rotation matrix) into a grid pose."""
    g = tuple(_round_half_up(p / s) for p, s in zip(position_mm, UC2_GRID_MM, strict=True))
    delta = tuple(p - gi * s for p, gi, s in zip(position_mm, g, UC2_GRID_MM, strict=True))
    dec: Rot24Decomposition = decompose(rotation)
    return CubifiedPose(
        offset_grid=g,  # type: ignore[arg-type]
        offset_mm=delta,  # type: ignore[arg-type]
        rot24=(dec.z, dec.x),
        offset_deg=dec.offset_deg,
        residual_angle_deg=dec.residual_angle_deg,
    )


@dataclass
class CubifyResult:
    poses: dict[str, CubifiedPose]
    findings: list[DrcFinding] = field(default_factory=list)

    @property
    def errors(self) -> list[DrcFinding]:
        return self.findings


def cubify(
    components: dict[str, CompSpec],
    world: dict[str, tuple[tuple[float, float, float], np.ndarray]] | None = None,
    dof_values: dict[str, float] | None = None,
) -> CubifyResult:
    """Cubify every component and run DRC.

    ``world`` maps component id → (position_mm, rotation matrix). When omitted,
    the components' own (anchor-resolved) poses are used — that is the
    round-trip / re-check mode; an editor passes its schematic layout instead.
    ``dof_values`` is the instance's collected DOF values (D1) mapping
    (``"<component>.<dof>"`` → value), range-checked as part of DRC.
    """
    if world is None:
        # Resolve world poses from the components themselves (grid positions
        # and rotations) when the caller does not provide them.
        flat: dict[str, FlatPose] = flatten(components)
        world = {cid: (p.position_mm, p.rotation) for cid, p in flat.items()}

    # The final cubified pose per component, in mm/°.
    poses: dict[str, CubifiedPose] = {}
    for comp_id in components:
        if comp_id not in world:
            continue
        position, rotation = world[comp_id]
        poses[comp_id] = cubify_pose(position, rotation)

    result = CubifyResult(poses=poses)
    result.findings.extend(drc(components, poses, dof_values))
    return result


# --- DRC ----------------------------------------------------------------------------


def drc(
    components: dict[str, CompSpec],
    poses: dict[str, CubifiedPose],
    dof_values: dict[str, float] | None = None,
) -> list[DrcFinding]:
    findings: list[DrcFinding] = []
    occupied: dict[tuple[int, int, int], str] = {}

    for comp_id, pose in poses.items():
        comp = components.get(comp_id)
        if comp is None:
            continue
        tpl = comp.template
        if tpl is None:
            # Free primitive without a mechanical binding: nothing to check yet.
            continue

        if tpl.class_ == "fixed":
            findings.extend(_check_t1(comp_id, pose))
        elif tpl.class_ == "adaptive":
            findings.extend(_check_t2_offsets(comp_id, comp, pose))
        # generative: δ maps to generator params — resolved in WP-10, no DRC here.

        cell = pose.offset_grid
        if cell in occupied:
            findings.append(
                DrcFinding(
                    "DRC_COLLISION",
                    comp_id,
                    "",
                    f"grid cell {list(cell)} already occupied by {occupied[cell]!r}",
                )
            )
        else:
            occupied[cell] = comp_id

        findings.extend(_check_aperture(comp_id, comp, pose))

    return findings


def _check_t1(comp_id: str, pose: CubifiedPose) -> list[DrcFinding]:
    """T1 fixed: any real δ or ΔR is a violation, not a geometry change."""
    findings = []
    for axis, delta in zip(AXES, pose.offset_mm, strict=True):
        if abs(delta) > TOLERANCE_MM:
            findings.append(
                DrcFinding(
                    "DRC_T1_MOVED",
                    comp_id,
                    axis,
                    f"fixed (T1) component has a {delta:+.3f} mm off-grid offset",
                )
            )
    if pose.residual_angle_deg > TOLERANCE_DEG:
        findings.append(
            DrcFinding(
                "DRC_T1_MOVED",
                comp_id,
                "",
                f"fixed (T1) component has a {pose.residual_angle_deg:.3f}° residual rotation",
            )
        )
    return findings




def _check_t2_offsets(comp_id: str, comp: CompSpec, pose: CubifiedPose) -> list[DrcFinding]:
    """WP-230/233: the travel check MOVED — it did not disappear.

    This used to compare a placement's residual offset against the
    component's declared `dof:` travel, which worked only because the offset
    WAS the DOF value. It is not any more: a pose leaf like
    ``offset-mm.z: ~ -5.0 + inputs['dz'].value`` is a standoff PLUS the
    travel, so checking the residual against the input's range would compare
    two different quantities and fail on legal poses.

    What the check was for — "the part cannot travel further than its
    mechanics allow" — is enforced where the travel actually is: the input's
    own ``min``/``max``, refused by :func:`~optikit_core.schema.inputs
    .make_env` with ``E_INPUT_RANGE`` when the design is instantiated, which
    is before any pose exists to cubify. That is also where Go enforces it.
    """
    return []




def _check_aperture(comp_id: str, comp: CompSpec, pose: CubifiedPose) -> list[DrcFinding]:
    """DRC_APERTURE (WP-79): the optic's clear aperture must still admit the
    on-axis beam after its intra-cube placement.

    The clear aperture is authored (a datum-marker disc, or the bind
    workbench's diameter field) and now travels through the index (WP-79); this
    is its first consumer. The check is per-part and beam-free: the residual
    decenter δ, projected TRANSVERSE to each port's axis, must stay inside the
    aperture radius — a part dragged so far its glass no longer covers the cube
    axis clips the beam. Full beam-width-vs-aperture (the EPD against each
    traversed surface) is the compile/simulate half; this catches the gross
    placement error at the board stage, where δ lives.
    """
    from .rotations import direction_vector

    if not comp.optics or not comp.optics.ports:
        return []
    delta = np.array([float(v) for v in pose.offset_mm])
    findings: list[DrcFinding] = []
    for pname, port in comp.optics.ports.items():
        frame = comp.optics.frames.get(port.frame)
        if frame is None:
            continue
        ap = frame.clear_aperture_mm
        if not isinstance(ap, int | float) or is_expr(ap) or float(ap) <= 0:
            continue
        radius = float(ap) / 2.0
        axis = direction_vector(port.direction)
        if axis is None:
            transverse = float(np.linalg.norm(delta))  # unknown axis: full decenter
        else:
            n = np.array(axis, dtype=float)
            transverse = float(np.linalg.norm(delta - (delta @ n) * n))
        if transverse >= radius:
            findings.append(
                DrcFinding(
                    "DRC_APERTURE",
                    comp_id,
                    "",
                    f"intra-cube decenter {transverse:.2f} mm transverse to port "
                    f"{pname!r} meets/exceeds the clear-aperture radius "
                    f"{radius:.2f} mm — the beam walks off the optic",
                )
            )
    return findings
