"""Chain inference: chief-ray propagation over world poses → `paths:` proposals."""

from .infer import (
    AMBIGUITY_TOL_MM,
    ANGLE_TOL_DEG,
    ChainError,
    Escape,
    InferResult,
    infer_paths,
)

__all__ = [
    "AMBIGUITY_TOL_MM",
    "ANGLE_TOL_DEG",
    "ChainError",
    "Escape",
    "InferResult",
    "infer_paths",
]
