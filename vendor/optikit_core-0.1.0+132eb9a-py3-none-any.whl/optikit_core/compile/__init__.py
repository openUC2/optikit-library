"""Compiler: design record → per-path Optiland optic dict + trace manifest."""

from .compiler import (
    ANGLE_TOL_DEG,
    TRANSVERSE_TOL_MM,
    CompileError,
    CompileResult,
    ManifestEntry,
    compile_path,
)

__all__ = [
    "ANGLE_TOL_DEG",
    "TRANSVERSE_TOL_MM",
    "CompileError",
    "CompileResult",
    "ManifestEntry",
    "compile_path",
]
