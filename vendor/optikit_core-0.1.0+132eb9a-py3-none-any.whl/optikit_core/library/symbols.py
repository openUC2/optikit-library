"""Authored schematic symbols (WP-48).

A derived glyph — category shape + surface profile + ports — can never drift
from the record, so it stays the default. But parts with no optical shape
(controller boards, carriers, exotic mechanics) deserve a drawn symbol, and
that symbol ships WITH the record so it versions alongside it.

The contract, enforced here and documented in DOCS/LIBRARY.md:

- the file sits next to ``component.yml`` and is named by ``symbol:``;
- it declares a ``viewBox`` centered on the part origin, 1 unit = 1 mm, with
  the beam axis along +x — the same convention the derived glyphs use, so a
  rotated part looks right;
- strokes/fills use ``currentColor`` so the symbol themes with light AND dark
  canvases; a hardcoded colour warns.

A symbol is LOOKS ONLY. Pins always come from ``optics.ports`` — an SVG never
defines connectivity.

Findings:

- **E_SYMBOL_MISSING** — ``symbol:`` names a file that is not there;
- **E_SYMBOL_NOT_SVG** — the file is not an SVG;
- **W_SYMBOL_NO_VIEWBOX** — no ``viewBox`` (the editor cannot scale it to mm);
- **W_SYMBOL_FIXED_COLOR** — hardcoded colours instead of ``currentColor``.
"""

from __future__ import annotations

import re

from ..schema.library import ComponentRecord
from .build import Library

#: Colour literals that defeat theming (hex, rgb(), and the common names).
_FIXED_COLOR_RE = re.compile(
    r'(?:fill|stroke)\s*[:=]\s*"?\s*(#[0-9a-fA-F]{3,8}|rgba?\([^)]*\)|'
    r"black|white|red|green|blue|gray|grey)",
    re.IGNORECASE,
)
_VIEWBOX_RE = re.compile(r"\bviewBox\s*=", re.IGNORECASE)


def check_programmable_records(library: Library) -> list[tuple[str, str, str]]:
    """An ``slm``/``display`` RECORD must carry its pixel facts (WP-47).

    This lives at the library level, not in design checks: pitch and
    resolution belong to the part, and every design that places it inherits
    them. Requiring the block per placement would duplicate the truth.
    """
    findings: list[tuple[str, str, str]] = []
    for loaded in library.by_kind("optical_component"):
        record = loaded.record
        assert isinstance(record, ComponentRecord)
        if record.category not in ("slm", "display"):
            continue
        # A record that ALREADY admits it is unfinished (a non-empty review
        # block) warns; one that presents itself as complete errors. This is
        # what keeps an honest migration gap from breaking the gate while
        # still nagging until someone reads the datasheet.
        level = "warning" if record.review else "error"
        prog = record.programmable
        if prog is None:
            findings.append(
                (level, "E_RECORD_PROGRAMMABLE_MISSING",
                 f"{record.id}: a {record.category!r} record needs a `programmable` block "
                 "(mode, pixel-pitch-um, resolution)")
            )
            continue
        if prog.pixel_pitch_um is None or prog.resolution is None:
            findings.append(
                (level, "E_RECORD_PROGRAMMABLE_FACTS",
                 f"{record.id}: `programmable` needs both pixel-pitch-um and resolution")
            )
    return findings


def check_symbols(library: Library) -> list[tuple[str, str, str]]:
    """Return ``(level, code, message)`` for every authored-symbol issue."""
    findings: list[tuple[str, str, str]] = []
    for loaded in library.by_kind("optical_component"):
        record = loaded.record
        assert isinstance(record, ComponentRecord)
        if not record.symbol:
            continue
        where = record.id
        path = loaded.path.parent / record.symbol
        if not path.is_file():
            findings.append(
                ("error", "E_SYMBOL_MISSING",
                 f"{where}: symbol {record.symbol!r} is not next to the record")
            )
            continue
        if path.suffix.lower() != ".svg":
            findings.append(
                ("error", "E_SYMBOL_NOT_SVG",
                 f"{where}: symbol {record.symbol!r} must be an .svg")
            )
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if not _VIEWBOX_RE.search(text):
            findings.append(
                ("warning", "W_SYMBOL_NO_VIEWBOX",
                 f"{where}: symbol has no viewBox — the editor cannot scale it to mm "
                 "(1 unit = 1 mm, centered on the part origin, beam axis +x)")
            )
        hit = _FIXED_COLOR_RE.search(text)
        if hit:
            findings.append(
                ("warning", "W_SYMBOL_FIXED_COLOR",
                 f"{where}: symbol hardcodes {hit.group(1)!r} — use currentColor so it "
                 "themes with the light and dark canvases")
            )
    return findings
