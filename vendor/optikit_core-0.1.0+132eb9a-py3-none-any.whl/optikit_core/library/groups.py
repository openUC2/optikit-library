"""Cube-group structure checks + the arrangement assistant (WP-53).

The miniFRAME pattern this encodes: two (or more) layers of cubes, PUZZLE
pieces between the layers (one per cell, holding the cube below and above by
their pins), and solid aluminium plates sandwiching the stack top and bottom.
``suggest_structure`` derives the minimal structure from the member
arrangement; ``check_groups`` warns when a group's declared structure would
not hold it together.

Cells are relative integer grid coordinates ``(x, y, z)`` with z the layer.
A member's occupied cells expand its module's ``footprint_grid`` from its
cell (rot90 swaps x/y for odd quarter-turns). ``overhang: true`` members
(the miniFRAME's camera arm) may leave the envelope and the plate footprint
without complaint — hanging off the side is their documented purpose.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..schema.library import GroupRecord, ModuleRecord
from .build import Library, resolve

Cell = tuple[int, int, int]


@dataclass
class GroupFinding:
    """One validation finding; ``level`` is ``"error"`` or ``"warning"``."""

    level: str
    code: str
    message: str


def _member_cells(group: GroupRecord, library: Library) -> dict[str, list[Cell]]:
    """Occupied cells per member (footprint expanded, rot90-aware)."""
    out: dict[str, list[Cell]] = {}
    for key, member in group.members.items():
        hit = resolve(library, member.module)
        footprint = (1, 1, 1)
        if hit is not None and isinstance(hit.record, ModuleRecord):
            footprint = hit.record.footprint_grid
        fx, fy, fz = footprint
        if member.rot90 % 2 == 1:
            fx, fy = fy, fx
        x0, y0, z0 = member.cell
        out[key] = [
            (x0 + dx, y0 + dy, z0 + dz)
            for dx in range(fx)
            for dy in range(fy)
            for dz in range(fz)
        ]
    return out


def _layer_cells(
    cells_by_member: dict[str, list[Cell]],
    group: GroupRecord,
    *,
    include_overhang: bool = False,
) -> dict[int, set[tuple[int, int]]]:
    """Occupied (x, y) per layer, skipping overhang members by default."""
    layers: dict[int, set[tuple[int, int]]] = {}
    for key, cells in cells_by_member.items():
        if not include_overhang and group.members[key].overhang:
            continue
        for x, y, z in cells:
            layers.setdefault(z, set()).add((x, y))
    return layers


def _covering_rect(cells: set[tuple[int, int]]) -> tuple[tuple[int, int], tuple[int, int]]:
    """(origin, size) of the minimal axis-aligned rectangle covering ``cells``."""
    xs = [c[0] for c in cells]
    ys = [c[1] for c in cells]
    origin = (min(xs), min(ys))
    size = (max(xs) - origin[0] + 1, max(ys) - origin[1] + 1)
    return origin, size


def suggest_structure(group: GroupRecord, library: Library) -> dict[str, Any]:
    """The minimal structure holding this arrangement together.

    Returns plates (bottom under the lowest layer, top over the highest, each
    the minimal covering rectangle of that layer's non-overhang cubes, with a
    stock-record hint ``openuc2.cube.plate_<nx>x<ny>``) and the puzzle joint
    cells (one per cell where a cube sits on BOTH sides of a layer interface).
    """
    cells_by_member = _member_cells(group, library)
    layers = _layer_cells(cells_by_member, group)
    if not layers:
        return {"plates": {}, "joint_cells": []}

    lo, hi = min(layers), max(layers)
    plates: dict[str, Any] = {}
    for face, layer in (("bottom", lo), ("top", hi)):
        origin, size = _covering_rect(layers[layer])
        plates[face] = {
            "origin": list(origin),
            "size": list(size),
            "module_hint": f"openuc2.cube.plate_{size[0]}x{size[1]}",
        }

    joint_cells: list[list[int]] = []
    for z in range(lo, hi):
        below = layers.get(z, set())
        above = layers.get(z + 1, set())
        joint_cells += [[x, y, z] for (x, y) in sorted(below & above)]

    return {"plates": plates, "joint_cells": joint_cells}


def check_groups(library: Library) -> list[GroupFinding]:
    """Structural validation of every group record (refs are checked upstream)."""
    findings: list[GroupFinding] = []
    for loaded in library.by_kind("cube_group"):
        group = loaded.record
        assert isinstance(group, GroupRecord)
        gid = group.id
        cells_by_member = _member_cells(group, library)

        # Envelope containment (non-overhang members only).
        ex, ey, ez = group.envelope_grid
        for key, cells in cells_by_member.items():
            if group.members[key].overhang:
                continue
            for x, y, z in cells:
                if not (0 <= x < ex and 0 <= y < ey and 0 <= z < ez):
                    findings.append(GroupFinding(
                        "error", "E_GROUP_MEMBER_OUTSIDE_ENVELOPE",
                        f"{gid}: member {key!r} occupies cell ({x}, {y}, {z}) outside "
                        f"the {ex}x{ey}x{ez} envelope (mark overhang: true if intended)",
                    ))
                    break

        # Overlaps — two members claiming the same cell.
        owner: dict[Cell, str] = {}
        for key, cells in cells_by_member.items():
            for cell in cells:
                if cell in owner:
                    findings.append(GroupFinding(
                        "error", "E_GROUP_OVERLAP",
                        f"{gid}: members {owner[cell]!r} and {key!r} both occupy "
                        f"cell {cell}",
                    ))
                else:
                    owner[cell] = key

        layers = _layer_cells(cells_by_member, group)
        multi_layer = len(layers) > 1
        structure = group.structure

        # A multi-layer stack needs its sandwich: plates + joints (WP-53).
        if multi_layer:
            plates = structure.plates if structure else {}
            for face in ("bottom", "top"):
                if face not in plates:
                    findings.append(GroupFinding(
                        "warning", f"W_GROUP_NO_{face.upper()}_PLATE",
                        f"{gid}: {len(layers)}-layer group declares no {face} plate — "
                        f"the stack is not sandwiched",
                    ))
            if not structure or structure.joints != "puzzle":
                findings.append(GroupFinding(
                    "warning", "W_GROUP_NO_JOINTS",
                    f"{gid}: multi-layer group declares no inter-layer joints "
                    f"(structure.joints: puzzle)",
                ))

        if structure is None:
            continue

        # Plate coverage: every non-overhang cube of the face layer inside the rect.
        if layers:
            lo, hi = min(layers), max(layers)
            for face, layer in (("bottom", lo), ("top", hi)):
                plate = structure.plates.get(face)
                if plate is None:
                    continue
                ox, oy = plate.origin
                sx, sy = plate.size
                for x, y in sorted(layers.get(layer, set())):
                    if not (ox <= x < ox + sx and oy <= y < oy + sy):
                        findings.append(GroupFinding(
                            "warning", "W_GROUP_PLATE_UNDERSIZED",
                            f"{gid}: {face} plate ({sx}x{sy} at {plate.origin}) does not "
                            f"cover the cube at ({x}, {y}, layer {layer})",
                        ))

        # Joints: every upper-layer cube wants a puzzle piece underneath.
        if structure.joints == "puzzle" and layers:
            declared = {tuple(c) for c in structure.joint_cells}
            lo, hi = min(layers), max(layers)
            for z in range(lo, hi):
                below = layers.get(z, set())
                above = layers.get(z + 1, set())
                for x, y in sorted(above):
                    if (x, y) in below and (x, y, z) not in declared:
                        findings.append(GroupFinding(
                            "warning", "W_GROUP_JOINT_MISSING",
                            f"{gid}: no puzzle joint under the layer-{z + 1} cube at "
                            f"({x}, {y}) — declare joint-cells or run group suggest",
                        ))
            for x, y, z in sorted(declared):
                if (x, y) not in layers.get(z, set()) or (x, y) not in layers.get(z + 1, set()):
                    findings.append(GroupFinding(
                        "warning", "W_GROUP_JOINT_UNSUPPORTED",
                        f"{gid}: joint at ({x}, {y}, {z}) has no cube on both sides",
                    ))

        # Interface ports point at real members (port names live on the
        # component record; membership is what we can check cheaply here).
        for name, port in group.interface.items():
            if port.member not in group.members:
                findings.append(GroupFinding(
                    "error", "E_GROUP_INTERFACE_UNKNOWN_MEMBER",
                    f"{gid}: interface port {name!r} maps to unknown member "
                    f"{port.member!r}",
                ))
    return findings
