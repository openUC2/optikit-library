"""The actuation contract: template DOFs ↔ module firmware axis-map (WP-42).

A moving surface and the firmware that moves it are ONE named fact spread
across two records: the mechanical template declares the DOF (``kind:
rotation`` for a galvo mirror, ``translation`` for a motorized stage — with a
``pivot-frame`` and the fragment ``surface`` it drives), and the cube module's
``electronics.axis-map`` binds each actuatable DOF to its firmware object. The
name is the same everywhere — the DOF name IS the fx parameter name (WP-35) IS
the axis-map ``dof`` — so this check keeps the three in agreement:

- **E_AXIS_MAP_UNKNOWN_DOF** — an axis-map entry names a DOF the template does
  not declare (a dangling firmware binding);
- **W_ACTUATABLE_UNBOUND** — an ``actuatable`` DOF has no axis-map entry (the
  mechanism moves but nothing drives it — a motor/firmware gap, WP-26);
- **E_DOF_SURFACE_RANGE** — a DOF's ``surface`` index is out of the bound
  component's fragment;
- **W_DOF_PIVOT_UNKNOWN** — a DOF's ``pivot-frame`` names no component frame.
"""

from __future__ import annotations

from ..schema.library import ComponentRecord, ModuleRecord, TemplateRecord
from .build import Library, resolve


def check_actuation(library: Library) -> list[tuple[str, str, str]]:
    """Return ``(level, code, message)`` for every actuation-contract issue.

    ``level`` is ``"error"`` or ``"warning"``. Modules without electronics or
    template DOFs are silently fine.
    """
    findings: list[tuple[str, str, str]] = []
    for loaded in library.by_kind("cube_module"):
        module = loaded.record
        assert isinstance(module, ModuleRecord)
        tpl_hit = resolve(library, module.template)
        template = tpl_hit.record if tpl_hit else None
        if not isinstance(template, TemplateRecord):
            continue
        comp_hit = resolve(library, module.component)
        component = comp_hit.record if comp_hit else None
        n_surfaces = 0
        frame_names: set[str] = set()
        if isinstance(component, ComponentRecord):
            frag = component.optics.fragment
            n_surfaces = len(frag.surfaces) if frag else 0
            frame_names = set(component.optics.frames)

        dof_names = {d.name for d in template.dof}
        axis_map = module.electronics.axis_map if module.electronics else []
        mapped = {entry.dof for entry in axis_map}

        for entry in axis_map:
            if entry.dof not in dof_names:
                findings.append((
                    "error", "E_AXIS_MAP_UNKNOWN_DOF",
                    f"{module.id}: axis-map binds dof {entry.dof!r} but template "
                    f"{template.id} declares no such DOF",
                ))
        for dof in template.dof:
            if dof.actuatable and dof.name not in mapped:
                findings.append((
                    "warning", "W_ACTUATABLE_UNBOUND",
                    f"{module.id}: DOF {dof.name!r} is actuatable but no axis-map "
                    "entry drives it (add the firmware binding — WP-26)",
                ))
            if dof.surface is not None and not 0 <= dof.surface < max(n_surfaces, 1):
                findings.append((
                    "error", "E_DOF_SURFACE_RANGE",
                    f"{template.id}: DOF {dof.name!r} moves surface {dof.surface} but "
                    f"the bound component has {n_surfaces} fragment surface(s)",
                ))
            if dof.pivot_frame and frame_names and dof.pivot_frame not in frame_names:
                findings.append((
                    "warning", "W_DOF_PIVOT_UNKNOWN",
                    f"{template.id}: DOF {dof.name!r} pivots about frame "
                    f"{dof.pivot_frame!r}, which the bound component does not declare",
                ))
    return findings
