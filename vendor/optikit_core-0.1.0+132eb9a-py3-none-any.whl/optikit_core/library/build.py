"""Load, validate, and index the library of git-versioned records.

The library lives under ``library/`` as one directory per record, each holding
a ``component.yml`` / ``template.yml`` / ``module.yml``. ``build_index`` resolves
every module's semver references to concrete latest-matching versions and emits
``library/dist/index.json`` — the flat catalog the frontend sidebar consumes.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from ..io.yamlio import (
    _to_plain,  # noqa: PLC2701 — internal helper reuse
    load_document,
)
from ..schema.library import (
    COMPONENT_FILE,
    GROUP_FILE,
    MODULE_FILE,
    TEMPLATE_FILE,
    ComponentRecord,
    GroupRecord,
    ModuleRecord,
    RecordBase,
    TemplateRecord,
    load_record,
    parse_ref,
)
from .semver import Version, satisfies

RECORD_FILES = (COMPONENT_FILE, TEMPLATE_FILE, MODULE_FILE, GROUP_FILE)


@dataclass
class LoadedRecord:
    record: RecordBase
    path: Path


@dataclass
class LibraryError:
    path: str
    message: str

    def __str__(self) -> str:
        return f"{self.path}: {self.message}"


@dataclass
class Library:
    records: list[LoadedRecord] = field(default_factory=list)
    errors: list[LibraryError] = field(default_factory=list)
    #: The directory the records were loaded from (None for hand-built
    #: libraries). check_references peeks at ``root/archive`` through this.
    root: Path | None = None

    def by_kind(self, kind: str) -> list[LoadedRecord]:
        return [r for r in self.records if r.record.kind == kind]

    def versions_of(self, record_id: str) -> list[LoadedRecord]:
        return [r for r in self.records if r.record.id == record_id]


def load_library(root: Path) -> Library:
    """Load and validate every record file under ``root`` (recursively).

    ``dist/`` (the built index) and ``archive/`` (retired records, WP-68) are
    skipped — an archived record is invisible until ``library restore`` moves
    it back. Both names are matched RELATIVE to ``root``, so pointing the
    loader AT an archive directory still works.
    """
    library = Library(root=root)
    seen: dict[tuple[str, str], Path] = {}
    for file in sorted(root.rglob("*.yml")):
        rel_parts = file.relative_to(root).parts
        if file.name not in RECORD_FILES or {"dist", "archive"} & set(rel_parts):
            continue
        # POSIX separators: the index is a wire artifact (asset URLs, the
        # tracked dist/ file CI diffs) and must not vary by build platform.
        rel = file.relative_to(root).as_posix()
        try:
            data = _to_plain(load_document(file)) or {}
            record = load_record(data)
        except ValidationError as exc:
            for err in exc.errors():
                loc = ".".join(str(p) for p in err["loc"])
                library.errors.append(LibraryError(rel, f"{loc}: {err['msg']}"))
            continue
        except (ValueError, KeyError) as exc:
            library.errors.append(LibraryError(rel, str(exc)))
            continue
        key = (record.id, record.version)
        if key in seen:
            library.errors.append(
                LibraryError(rel, f"duplicate {record.id}@{record.version} "
                                  f"(also {seen[key]})")
            )
            continue
        seen[key] = file
        library.records.append(LoadedRecord(record=record, path=file))
    return library


def resolve(library: Library, ref: str) -> LoadedRecord | None:
    """Highest version of ``<id>`` satisfying the range in ``<id>@<range>``."""
    record_id, spec = parse_ref(ref)
    candidates = [
        r for r in library.versions_of(record_id)
        if satisfies(r.record.version, spec)
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda r: Version.parse(r.record.version))


def archived_ids(root: Path | None) -> set[str]:
    """Record ids parked under ``root/archive`` (WP-68) — cheap id-only scan."""
    ids: set[str] = set()
    if root is None:
        return ids
    archive = root / "archive"
    if not archive.is_dir():
        return ids
    for file in archive.rglob("*.yml"):
        if file.name not in RECORD_FILES:
            continue
        try:
            data = _to_plain(load_document(file)) or {}
        except Exception:  # noqa: BLE001 — an unreadable archived file is just not restorable
            continue
        record_id = data.get("id")
        if isinstance(record_id, str):
            ids.add(record_id)
    return ids


def check_references(library: Library) -> list[LibraryError]:
    """Every module's component/template references must resolve.

    A reference that misses the live library but names a record parked under
    ``archive/`` gets the actionable ``E_ARCHIVED`` message (WP-68) instead of
    the plain dangling-ref one.
    """
    errors: list[LibraryError] = []
    archived: set[str] | None = None  # lazily scanned on the first miss

    def missing(rel: str, what: str, ref: str) -> None:
        nonlocal archived
        if archived is None:
            archived = archived_ids(library.root)
        record_id = ref.split("@", 1)[0]
        if record_id in archived:
            errors.append(LibraryError(
                rel,
                f"E_ARCHIVED: {ref} is archived — restore with: "
                f"optikit-core library restore {record_id}",
            ))
        else:
            errors.append(LibraryError(rel, f"{what} ref {ref!r} does not resolve"))

    for loaded in library.by_kind("cube_module"):
        module = loaded.record
        assert isinstance(module, ModuleRecord)
        rel = str(loaded.path)
        for label, ref in (("component", module.component), ("template", module.template)):
            if resolve(library, ref) is None:
                missing(rel, label, ref)
        # WP-67: a housing (footprint_grid: null) is NOT cube-mounted — a
        # module referencing one contradicts the template's own declaration.
        tpl = resolve(library, module.template)
        if tpl is not None and isinstance(tpl.record, TemplateRecord) \
                and tpl.record.footprint_grid is None:
            errors.append(LibraryError(
                rel,
                f"template ref {module.template!r} resolves to a HOUSING "
                "(footprint_grid: null) — a housing is not cube-mounted; "
                "package it as a cube (T3) instead of referencing it from a module",
            ))
    # WP-67: a housing's own component ref must resolve (no module carries it).
    for loaded in library.by_kind("mechanical_template"):
        template = loaded.record
        assert isinstance(template, TemplateRecord)
        if template.component and resolve(library, template.component) is None:
            missing(str(loaded.path), "component", template.component)
    # WP-53: group members and structure plates reference cube modules.
    for loaded in library.by_kind("cube_group"):
        group = loaded.record
        assert isinstance(group, GroupRecord)
        rel = str(loaded.path)
        for key, member in group.members.items():
            if resolve(library, member.module) is None:
                missing(rel, f"member {key!r}", member.module)
        for face, plate in (group.structure.plates if group.structure else {}).items():
            if resolve(library, plate.module) is None:
                missing(rel, f"plate {face!r}", plate.module)
    return errors


def _thumbnail_rel(loaded: LoadedRecord, root: Path) -> str | None:
    thumb = loaded.record.thumbnail
    if not thumb:
        return None
    candidate = (loaded.path.parent / thumb).resolve()
    try:
        return candidate.relative_to(root.resolve()).as_posix()
    except ValueError:
        return thumb


def _asset_url(rel: str | None) -> str | None:
    """Service asset URL for a library-root-relative file path (WP-34).

    The palette resolves these against the index origin, so entries work both
    from the live service (``/v1/library/assets/...``) and stay harmless in
    the bundled offline snapshot.
    """
    if not rel:
        return None
    return f"/v1/library/assets/{rel}"


def _mesh_pose_grid(template: object) -> list[str] | None:
    """[z, x] of a declared mesh-pose grid rotation, or None."""
    pose = getattr(template, "mesh_pose", None)
    if pose is None:
        return None
    grid = pose.rotation.grid
    return [grid.z or "+z", grid.x or "+x"]


def _mesh_pose_offset(template: object) -> list[float] | None:
    """WP-156: the mesh-pose translation (mm) — a housing's recorded position
    in the cell, measured from the cell centre. None when absent/zero."""
    pose = getattr(template, "mesh_pose", None)
    if pose is None:
        return None
    t = pose.translation.offset_mm
    off = [float(t.x or 0.0), float(t.y or 0.0), float(t.z or 0.0)]
    return off if any(abs(v) > 1e-9 for v in off) else None


def _mesh_pose_offset_deg(template: object) -> list[float] | None:
    """WP-156: the mesh-pose residual rotation (extrinsic Z-X-Y degrees,
    right-multiplied onto the grid) — a housing's orientation in the cell.
    None when absent/zero (cube-mounted templates never carry one)."""
    pose = getattr(template, "mesh_pose", None)
    if pose is None:
        return None
    d = pose.rotation.offset_deg
    off = [float(d.x or 0.0), float(d.y or 0.0), float(d.z or 0.0)]
    return off if any(abs(v) > 1e-9 for v in off) else None


def _module_assets(
    tpl: LoadedRecord | None,
    module_thumb: str | None,
    comp: LoadedRecord | None = None,
) -> dict[str, str | None]:
    """Thumbnail + mesh asset URLs a palette tile and the assembly view need."""
    template = tpl.record if tpl else None
    glb = step = None
    if tpl and isinstance(template, TemplateRecord):
        tpl_dir = tpl.path.parent.name
        # The GLB is advertised only when it is actually THERE. 64 migrated
        # records name a mesh they do not ship (their real source is a remote
        # `glb-url`), and an unguarded URL here made the index promise an
        # asset that 404s. `library vendor-assets` pulls those in; until it
        # has run, the honest answer is null. Same rule as step/symbol below.
        if template.glb and (tpl.path.parent / template.glb).is_file():
            glb = _asset_url(f"templates/{tpl_dir}/{template.glb}")
        step_file = template.step or (
            template.glb.rsplit(".", 1)[0] + ".step" if template.glb else ""
        )
        if step_file and (tpl.path.parent / step_file).is_file():
            step = _asset_url(f"templates/{tpl_dir}/{step_file}")
    thumb = _asset_url(module_thumb)
    if thumb is None and tpl:
        thumb = _asset_url(_thumbnail_rel(tpl, tpl.path.parents[2]))
    # WP-48: an authored schematic symbol, when the component ships one.
    symbol = None
    component = comp.record if comp else None
    if (
        comp
        and isinstance(component, ComponentRecord)
        and component.symbol
        and (comp.path.parent / component.symbol).is_file()
    ):
        symbol = _asset_url(f"components/{comp.path.parent.name}/{component.symbol}")
    return {"thumbnail": thumb, "glb": glb, "step": step, "symbol": symbol,
            "mesh_frame": (
                template.mesh_frame
                if isinstance(template, TemplateRecord)
                else ""
            ),
            # WP-137: the FILE->cube correction grid, when declared. The
            # renderer composes it under the basis so a wrongly exported
            # file draws corrected everywhere it appears.
            "mesh_pose_grid": _mesh_pose_grid(template),
            # WP-156: the translation half — where the mesh sits in the cell —
            # and the residual rotation (a housing's orientation in it).
            "mesh_pose_offset_mm": _mesh_pose_offset(template),
            "mesh_pose_offset_deg": _mesh_pose_offset_deg(template)}


def _component_ports(component: ComponentRecord | None) -> list[dict[str, Any]]:
    """Record ports with frame offsets resolved to local mm (WP-34).

    The same resolution the frontend applies to a retained source design —
    shipping it in the index means the palette needs no per-record requests.
    """
    if component is None:
        return []
    optics = component.optics
    out: list[dict[str, Any]] = []
    for name, port in optics.ports.items():
        frame = optics.frames.get(port.frame)
        position = [
            float(v) if isinstance(v, (int, float)) else 0.0
            for v in (
                (frame.x_mm, frame.y_mm, frame.z_mm) if frame else (0.0, 0.0, 0.0)
            )
        ]
        entry: dict[str, Any] = {
            "name": name,
            "direction": port.direction or "+z",
            "position_mm": position,
            "after_surface": port.after_surface,
            # WP-46: "fiber" ports take a patch cord, "" is free space.
            "coupling": port.coupling,
        }
        # WP-79: a tilted datum frame tilts the beam — ship the quaternion so a
        # gizmo-placed 45° mirror simulates folded, not axis-aligned. And the
        # frame's measured clear aperture, so DRC can check beam vs aperture.
        if frame is not None and frame.rotation is not None:
            entry["rotation"] = [float(v) for v in frame.rotation]
        if (
            frame is not None
            and frame.clear_aperture_mm is not None
            and isinstance(frame.clear_aperture_mm, int | float)
        ):
            entry["clear_aperture_mm"] = float(frame.clear_aperture_mm)
        out.append(entry)
    return out


def _as_mounted_ports(
    template: TemplateRecord | None, component: ComponentRecord | None
) -> list[dict[str, Any]]:
    """WP-122: the PLACED part's pins — as mounted, not as authored.

    A placed cube module's local frame is the CUBE (F3); the component's
    ports are record-frame (F2). Since WP-116 the template precomposes the
    insert-pose into ``optical_ports`` (directions) and ``frames`` (posed
    positions) — serving THOSE here is what makes the canvas fold, the
    assembly glyph and the inspector agree with the binding the parts
    editor showed. Round 17's field report: the editor said
    "front faces -y" while the placed part's pins said "front faces -z".

    Only a template WITH an ``insert-pose`` gets this treatment: its
    optical_ports were authored by the binding machinery and are complete by
    construction. Legacy templates (no pose) may carry a hand-written,
    PARTIAL optical_ports block — openuc2.tpl.mirror_mount_1x1 declares only
    ``front`` while the component folds through ``reflected`` — so they fall
    back to the component's record ports, which under the identity pose ARE
    the as-mounted ports.
    """
    if (
        template is None
        or getattr(template, "insert_pose", None) is None
        or not template.optical_ports
    ):
        return _component_ports(component)
    comp_frames = component.optics.frames if component is not None else {}
    out: list[dict[str, Any]] = []
    for name, port in template.optical_ports.items():
        tpl_frame = template.frames.get(port.frame)
        position = [
            float(v) if isinstance(v, (int, float)) else 0.0
            for v in (
                (tpl_frame.x_mm, tpl_frame.y_mm, tpl_frame.z_mm)
                if tpl_frame
                else (0.0, 0.0, 0.0)
            )
        ]
        entry: dict[str, Any] = {
            "name": name,
            "direction": port.direction or "+z",
            "position_mm": position,
            "after_surface": port.after_surface,
            "coupling": port.coupling,
        }
        # Clear aperture is an OPTICAL fact — it travels from the component's
        # frame of the same name (the pose does not change a diameter).
        comp_frame = comp_frames.get(port.frame) if comp_frames else None
        if (
            comp_frame is not None
            and comp_frame.clear_aperture_mm is not None
            and isinstance(comp_frame.clear_aperture_mm, int | float)
        ):
            entry["clear_aperture_mm"] = float(comp_frame.clear_aperture_mm)
        out.append(entry)
    return out


def _source_view(component: ComponentRecord | None) -> dict[str, Any]:
    """Normalized source facts for the palette: the WP-47 ``source:`` block
    when the record has one, else derived from the §9.5 ``optics.emission``
    block (spectrum → line list; cone half-angle ×2 → full divergence; disc
    radius ×2 → 1/e² beam diameter). The library holds both source dialects;
    without this the emission-dialect records (laser_488) index with an empty
    line list and the picker — and the exported emission — go blind."""
    empty = {"wavelengths_um": [], "divergence_deg": 0.0, "beam_diameter_mm": None}
    if component is None:
        return empty
    if component.source is not None:
        return {
            "wavelengths_um": list(component.source.wavelengths_um),
            "divergence_deg": float(component.source.divergence_deg),
            "beam_diameter_mm": component.source.beam_diameter_mm,
        }
    emission = component.optics.emission if component.optics else None
    if emission is None:
        return empty
    divergence = 0.0
    if emission.angular.type == "cone" and isinstance(
        emission.angular.half_angle_deg, int | float
    ):
        divergence = 2.0 * float(emission.angular.half_angle_deg)
    beam = None
    if emission.spatial.type == "disc" and isinstance(
        emission.spatial.radius_mm, int | float
    ):
        beam = 2.0 * float(emission.spatial.radius_mm)
    return {
        "wavelengths_um": [float(line.wavelength_um) for line in emission.spectrum],
        "divergence_deg": divergence,
        "beam_diameter_mm": beam,
    }


def _mirror_rect_mm(component: ComponentRecord | None) -> list[float] | None:
    """WP-125: the reflective surface's rectangular clear aperture, [w, h] mm.

    The parts editor draws a rectangular mirror as the plate the record
    declares; the assembly glyph renders off the module INDEX entry, which
    (unlike bare-component entries) does not ship fragment surfaces — so the
    one fact the glyph needs travels as a field. None = round (semi-aperture
    disc), the default."""
    if component is None or component.optics.fragment is None:
        return None
    surfaces = [dict(s) for s in component.optics.fragment.surfaces]
    reflective = [
        s for s in surfaces
        if isinstance(s.get("interaction_model"), dict)
        and s["interaction_model"].get("is_reflective")
    ] or surfaces
    for surf in reflective:
        ap = surf.get("aperture")
        if isinstance(ap, dict) and ap.get("type") == "RectangularAperture":
            try:
                w = float(ap["x_max"]) - float(ap["x_min"])
                h = float(ap["y_max"]) - float(ap["y_min"])
            except (KeyError, TypeError, ValueError):
                continue
            if w > 0 and h > 0:
                return [w, h]
    return None


def _component_entries(library: Library) -> list[dict[str, Any]]:
    """Latest version of every optical component — the WP-14 editor browses
    these, and since WP-60 the palette places the UNBOUND ones directly, so
    each entry ships its ports (resolved to local mm) and source facts."""
    latest: dict[str, LoadedRecord] = {}
    for loaded in library.by_kind("optical_component"):
        record = loaded.record
        assert isinstance(record, ComponentRecord)
        held = latest.get(record.id)
        if held is None or Version.parse(record.version) > Version.parse(
            held.record.version
        ):
            latest[record.id] = loaded
    out: list[dict[str, Any]] = []
    for loaded in sorted(latest.values(), key=lambda x: x.record.id):
        record = loaded.record
        assert isinstance(record, ComponentRecord)
        # WP-48/WP-60: an authored symbol, when the record ships one on disk.
        symbol = None
        if record.symbol and (loaded.path.parent / record.symbol).is_file():
            symbol = _asset_url(f"components/{loaded.path.parent.name}/{record.symbol}")
        out.append(
            {
                "id": record.id,
                "version": record.version,
                "kind": "optical_component",
                "category": record.category,
                "description": record.description,
                "tags": record.tags,
                "vendor": record.vendor.model_dump(),
                "efl_mm": record.effective_focal_length_mm,
                "n_surfaces": len(record.optics.fragment.surfaces)
                if record.optics.fragment
                else 0,
                "review": bool(record.review),
                # WP-60: enough to PLACE a bare symbol — its ports and, for
                # sources, the emission lines the wavelength picker offers.
                "ports": _component_ports(record),
                # WP-145: the beam width the trace must use (from either source
                # dialect). Without it the compiler fell back to a hardcoded
                # 10 mm entrance pupil, so a 2 mm laser drew 2 mm on the canvas
                # and traced 10 mm.
                **_source_view(record),
                "symbol": symbol,
                # WP-60: the record's own surface stack, verbatim — a placed
                # unbound part exports (and simulates) the REAL prescription,
                # not a thin-lens approximation. May carry .inf radii; every
                # index dump goes through dump_index_json for that reason.
                "fragment_surfaces": (
                    [dict(s) for s in record.optics.fragment.surfaces]
                    if record.optics.fragment
                    else []
                ),
            }
        )
    return out


def _provenance(root: Path) -> dict[str, Any]:
    """`{source, source_commit}` for the tree an index was built from.

    Best effort by design: a library served from a plain directory has no
    commit, and saying so by omission is better than inventing one.
    """
    import subprocess

    out: dict[str, Any] = {"source": root.name}
    try:
        rev = subprocess.run(  # noqa: S603 — fixed argv, no shell
            ["git", "-C", str(root), "rev-parse", "--short", "HEAD"],  # noqa: S607
            capture_output=True, text=True, timeout=5, check=False,
        )
        if rev.returncode == 0 and rev.stdout.strip():
            out["source_commit"] = rev.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass  # no git, no commit — the field simply does not appear
    return out


def build_index(library: Library, root: Path) -> dict[str, Any]:
    """Flat catalog with modules resolved to concrete component/template versions."""
    entries: list[dict[str, Any]] = []
    for loaded in library.by_kind("cube_module"):
        module = loaded.record
        assert isinstance(module, ModuleRecord)
        comp = resolve(library, module.component)
        tpl = resolve(library, module.template)
        component = comp.record if comp else None
        template = tpl.record if tpl else None
        assert component is None or isinstance(component, ComponentRecord)
        assert template is None or isinstance(template, TemplateRecord)
        entries.append(
            {
                "id": module.id,
                "version": module.version,
                "kind": "cube_module",
                "description": module.description,
                "tags": module.tags,
                "category": component.category if component else "other",
                "thumbnail": _thumbnail_rel(loaded, root),
                "footprint_grid": list(module.footprint_grid),
                "price": module.price,
                "review": bool(module.review or (component and component.review)
                               or (template and template.review)),
                # WP-108: the review NOTES, not just the boolean. A flag alone
                # cannot distinguish "placeholder CAD, do not print" from
                # "confirm the glass name", so the editor badged a curated,
                # priced, shipping part as a "draft" and users learned to
                # ignore it. Carrying the text makes the badge actionable —
                # and names which of the three records it came from.
                "review_notes": [
                    *(f"module: {n}" for n in (module.review or [])),
                    *(f"component: {n}" for n in ((component.review if component else None) or [])),
                    *(f"template: {n}" for n in ((template.review if template else None) or [])),
                ],
                "component": {
                    "ref": module.component,
                    "resolved": component.version if component else None,
                    "vendor": component.vendor.model_dump() if component else None,
                    "efl_mm": component.effective_focal_length_mm if component else None,
                    # WP-47: the source's emission lines drive the panel's
                    # wavelength picker and the ray tint; divergence + beam
                    # diameter feed the exported §9.5 emission block.
                    **_source_view(component),
                    # WP-125: rectangular reflective aperture, for the
                    # assembly/schematic mirror glyph ([w, h] mm; None=round).
                    "mirror_rect_mm": _mirror_rect_mm(component),
                    # WP-47: pixel facts for slm/display parts.
                    "programmable": (
                        component.programmable.model_dump(by_alias=True)
                        if component and component.programmable
                        else None
                    ),
                },
                "template": {
                    "ref": module.template,
                    "id": template.id if template else None,
                    "resolved": template.version if template else None,
                    "class": template.class_ if template else None,
                    "actuatable": bool(
                        template and any(d.actuatable for d in template.dof)
                    ),
                    # WP-45: carriers host cubes; bays are their docking regions.
                    "carrier": bool(template.carrier) if template else False,
                    "bays": {
                        name: {
                            "origin_cell": list(bay.origin_cell),
                            "size": list(bay.size),
                            "axis": bay.axis,
                        }
                        for name, bay in (template.bays if template else {}).items()
                    },
                    # WP-34: what the schematic needs to enforce the class —
                    # T2 DOF axes/ranges and T1 discrete states.
                    "dof": [
                        {
                            "name": d.name,
                            "kind": d.kind,
                            "axis": d.axis,
                            "unit": d.unit,
                            "range": list(d.range) if d.range else None,
                            "actuatable": d.actuatable,
                            # WP-42: the actuation binding the editors consume.
                            "pivot_frame": d.pivot_frame,
                            "surface": d.surface,
                            "can_object": next(
                                (
                                    e.can_object
                                    for e in (
                                        module.electronics.axis_map
                                        if module.electronics
                                        else []
                                    )
                                    if e.dof == d.name
                                ),
                                None,
                            ),
                        }
                        for d in (template.dof if template else [])
                    ],
                    "states": list(template.states) if template else [],
                },
                # WP-34: palette tiles + assembly renders straight off the index.
                "assets": _module_assets(tpl, _thumbnail_rel(loaded, root), comp),
                # WP-122: pins as MOUNTED (template optical_ports, posed
                # frames) — the record ports fold in the record frame, which
                # is not where the cube points them.
                "ports": _as_mounted_ports(template, component),
                # WP-124: WHICH frame those ports speak. 'mounted' = cube
                # frame F3, already in-plane — placement may only YAW the
                # cube (pins stay +z, the T-rule). 'record' = component F2
                # fallback — placement still tips the optics into the plane.
                "ports_frame": (
                    "mounted"
                    if template is not None
                    and getattr(template, "insert_pose", None) is not None
                    and template.optical_ports
                    else "record"
                ),
                "electronics": module.electronics.model_dump(by_alias=True)
                if module.electronics
                else None,
            }
        )
    entries.sort(key=lambda e: e["id"])
    components = _component_entries(library)
    return {
        "schema": "optikit-library-index/v0",
        "count": len(entries),
        # M4 (DOCS/LIBRARY-REGISTRY.md): where this index came from.
        #
        # A static host cannot rebuild the index — CI commits the artifact —
        # so a stale one is indistinguishable from a fresh one at the client,
        # and "the part I just pushed is not in the palette" has no diagnosis.
        # `source` names the tree it was built from and `source_commit` the
        # revision, when the tree is a git checkout. Both are OMITTED rather
        # than faked when unknown, and neither carries a timestamp: a
        # wall-clock field would change on every rebuild and break the
        # byte-determinism the index relies on for caching.
        **_provenance(root),
        "modules": entries,
        "components": components,
        # WP-44: groups — placeable arrangements (the OPM). The palette
        # places their members as one rigid unit.
        "groups": _group_entries(library),
        # WP-67: bare housings (footprint_grid: null) — mechanics with no
        # cube. The frontend joins these onto the unbound component entries
        # by component id, so a housed part's mesh travels with it and the
        # three states (bare symbol / symbol+housing / cube module) are
        # distinguishable.
        "housings": _housing_entries(library),
    }


def _housing_entries(library: Library) -> list[dict[str, Any]]:
    """Housing templates (WP-67): footprint_grid null, component ref carried
    on the template itself because no module exists to carry the pair."""
    out: list[dict[str, Any]] = []
    for loaded in library.by_kind("mechanical_template"):
        template = loaded.record
        assert isinstance(template, TemplateRecord)
        if template.footprint_grid is not None:
            continue
        comp = resolve(library, template.component) if template.component else None
        component = comp.record if comp else None
        assert component is None or isinstance(component, ComponentRecord)
        tpl_dir = loaded.path.parent.name
        glb = step = None
        if template.glb and (loaded.path.parent / template.glb).is_file():
            glb = _asset_url(f"templates/{tpl_dir}/{template.glb}")
        step_file = template.step or (
            template.glb.rsplit(".", 1)[0] + ".step" if template.glb else ""
        )
        if step_file and (loaded.path.parent / step_file).is_file():
            step = _asset_url(f"templates/{tpl_dir}/{step_file}")
        out.append(
            {
                "id": template.id,
                "version": template.version,
                "kind": "mechanical_template",
                "class": template.class_,
                "description": template.description,
                "review": bool(template.review or (component and component.review)),
                "component": {
                    "ref": template.component or None,
                    "resolved": component.version if component else None,
                    "id": component.id if component else None,
                },
                "dof": [
                    {
                        "name": d.name, "kind": d.kind, "axis": d.axis,
                        "unit": d.unit,
                        "range": list(d.range) if d.range else None,
                        "actuatable": d.actuatable,
                        "pivot_frame": d.pivot_frame,
                        "surface": d.surface,
                    }
                    for d in template.dof
                ],
                "assets": {
                    "thumbnail": _asset_url(
                        _thumbnail_rel(loaded, loaded.path.parents[2])
                    ),
                    # WP-137: housings render through the same content-basis
                    # rule as modules — this block used to drop the frame
                    # fields entirely, leaving the assembly to sniff.
                    "mesh_frame": template.mesh_frame,
                    "mesh_pose_grid": _mesh_pose_grid(template),
                    "mesh_pose_offset_mm": _mesh_pose_offset(template),
                    "mesh_pose_offset_deg": _mesh_pose_offset_deg(template),
                    "glb": glb,
                    "step": step,
                },
                # WP-156: pins as MOUNTED, exactly like modules (WP-122) — a
                # housed laser aligned to look +x used to serve its record
                # ports (+z) because this block never shipped the template's
                # as-mounted spelling, so the alignment was silently identity.
                "ports": _as_mounted_ports(template, component),
                "ports_frame": (
                    "mounted"
                    if getattr(template, "insert_pose", None) is not None
                    and template.optical_ports
                    else "record"
                ),
            }
        )
    out.sort(key=lambda e: e["id"])
    return out


def _group_entries(library: Library) -> list[dict[str, Any]]:
    """Cube groups for the palette (WP-44): members + structure, verbatim."""
    out: list[dict[str, Any]] = []
    for loaded in library.by_kind("cube_group"):
        group = loaded.record
        assert isinstance(group, GroupRecord)
        structure = group.structure
        out.append(
            {
                "id": group.id,
                "version": group.version,
                "kind": "cube_group",
                "description": group.description,
                "tags": group.tags,
                "review": bool(group.review),
                "envelope_grid": list(group.envelope_grid),
                "members": [
                    {
                        "key": key,
                        "module": member.module_id,
                        "cell": list(member.cell),
                        "rot90": member.rot90,
                        "overhang": member.overhang,
                    }
                    for key, member in group.members.items()
                ],
                "structure": {
                    "plates": {
                        face: {
                            "module": plate.module_id,
                            "origin": list(plate.origin),
                            "size": list(plate.size),
                        }
                        for face, plate in (structure.plates if structure else {}).items()
                    },
                    "joints": structure.joints if structure else "",
                    "joint_cells": [list(c) for c in structure.joint_cells]
                    if structure
                    else [],
                    "joint_module": "openuc2.cube.puzzle_1x1",
                },
                "interface": {
                    name: {"member": port.member, "port": port.port}
                    for name, port in group.interface.items()
                },
            }
        )
    out.sort(key=lambda e: e["id"])
    return out


def dump_index_json(index: dict[str, Any], **kwargs: Any) -> str:
    """Strict-JSON dump of a built index: ±inf → ±1e999 (JSON.parse overflows
    back to ±Infinity), NaN → null — the FiniteJSONResponse convention. Needed
    since WP-60: component fragment surfaces carry real radii, and a flat is
    ``.inf``."""
    text = json.dumps(index, allow_nan=True, **kwargs)
    return text.replace("Infinity", "1e999").replace("NaN", "null")


def write_index(library: Library, root: Path) -> Path:
    dist = root / "dist"
    dist.mkdir(parents=True, exist_ok=True)
    index = build_index(library, root)
    out = dist / "index.json"
    # newline pinned: a Windows build must produce the same bytes CI diffs.
    out.write_text(dump_index_json(index, indent=2) + "\n", encoding="utf-8", newline="\n")
    return out
