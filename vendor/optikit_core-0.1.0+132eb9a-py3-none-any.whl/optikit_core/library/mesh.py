"""WP-109: does a template's mesh actually agree with the record? (glTF only)

The library holds **two undeclared mesh conventions** and nothing in the schema
distinguishes them:

* the older exports ship a literal ``Rx(-90°)`` wrapper node (quaternion
  ``[-0.7071, 0, 0, 0.7071]``) that performs the document→three basis change
  *inside* the glTF, so their post-transform bounding box is y-up;
* the newer Open CASCADE exports (``__mm_scale__`` root, no rotation) leave the
  vertices in the document frame, z-up.

A renderer feeds mesh axes straight into its own frame, so the two families
only look the same because a placed part's default rotation happens to
compensate. That is folklore, not a contract — and the way it fails is a cube
lying on its side, which nobody notices until they look.

Rather than add a ``mesh-frame:`` field and institutionalise the ambiguity,
this checks the thing we actually care about: a template that declares a
``footprint_grid`` is a CUBE, so its mesh must measure roughly one grid cell —
50 × 50 × 55 mm — with the 55 mm extent on the stacking axis. Anything else is
either the wrong file, the wrong units, or a lost wrapper node, and all three
are worth failing loudly at ingest instead of discovering in the viewport.

Pure stdlib: a glTF binary is a 12-byte header plus length-prefixed JSON and
BIN chunks, and accessor ``min``/``max`` give the bounding box without touching
vertex data. No mesh library, no import cost when the check does not run.
"""

from __future__ import annotations

import json
import math
import re
import struct
from dataclasses import dataclass
from pathlib import Path

#: UC2 grid pitch (mm). A 1×1×1 cube mesh should measure about this.
UC2_CELL_MM = (50.0, 50.0, 55.0)
#: How far a real export may sit from the nominal cell before we complain.
#: The shipped TH1 cube measures 49.8 × 49.8 × 54.4 — joint clearance, not error.
CELL_TOL_MM = 3.0


@dataclass(frozen=True)
class MeshBox:
    """A glTF's world bounding box, after node transforms."""

    min: tuple[float, float, float]
    max: tuple[float, float, float]

    @property
    def size(self) -> tuple[float, float, float]:
        return tuple(hi - lo for lo, hi in zip(self.min, self.max, strict=True))  # type: ignore[return-value]

    @property
    def center(self) -> tuple[float, float, float]:
        return tuple((hi + lo) / 2 for lo, hi in zip(self.min, self.max, strict=True))  # type: ignore[return-value]


def _chunks(data: bytes) -> tuple[dict, bytes | None]:
    """Split a .glb into its JSON chunk and its BIN chunk."""
    if len(data) < 12 or data[:4] != b"glTF":
        raise ValueError("not a glTF binary (missing magic)")
    version, total = struct.unpack_from("<II", data, 4)
    if version != 2:
        raise ValueError(f"unsupported glTF version {version}")
    if total != len(data):
        raise ValueError(f"declared length {total} != file size {len(data)}")
    offset, gltf, binary = 12, None, None
    while offset + 8 <= len(data):
        length, kind = struct.unpack_from("<I4s", data, offset)
        payload = data[offset + 8 : offset + 8 + length]
        if kind == b"JSON":
            gltf = json.loads(payload)
        elif kind == b"BIN\x00":
            binary = payload
        offset += 8 + length + (-length % 4)
    if gltf is None:
        raise ValueError("glTF has no JSON chunk")
    return gltf, binary


def _matrix(node: dict) -> list[float]:
    """A node's local transform as a column-major 4×4, per the glTF spec."""
    if "matrix" in node:
        return list(node["matrix"])
    tx, ty, tz = node.get("translation", (0.0, 0.0, 0.0))
    qx, qy, qz, qw = node.get("rotation", (0.0, 0.0, 0.0, 1.0))
    sx, sy, sz = node.get("scale", (1.0, 1.0, 1.0))
    # rotation matrix from the quaternion
    r = [
        1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy + qz * qw), 2 * (qx * qz - qy * qw),
        2 * (qx * qy - qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz + qx * qw),
        2 * (qx * qz + qy * qw), 2 * (qy * qz - qx * qw), 1 - 2 * (qx * qx + qy * qy),
    ]
    return [
        r[0] * sx, r[1] * sx, r[2] * sx, 0.0,
        r[3] * sy, r[4] * sy, r[5] * sy, 0.0,
        r[6] * sz, r[7] * sz, r[8] * sz, 0.0,
        tx, ty, tz, 1.0,
    ]


def _mul(a: list[float], b: list[float]) -> list[float]:
    """Column-major 4×4 product a·b (apply b, then a)."""
    out = [0.0] * 16
    for col in range(4):
        for row in range(4):
            out[col * 4 + row] = sum(a[k * 4 + row] * b[col * 4 + k] for k in range(4))
    return out


def _apply(m: list[float], p: tuple[float, float, float]) -> tuple[float, float, float]:
    x, y, z = p
    return (
        m[0] * x + m[4] * y + m[8] * z + m[12],
        m[1] * x + m[5] * y + m[9] * z + m[13],
        m[2] * x + m[6] * y + m[10] * z + m[14],
    )


IDENTITY = [1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0]


#: glTF component types → (struct format, byte size). POSITION is VEC3 of
#: one of these; the quantized forms arrive with `normalized: true`.
_COMPONENT_FORMATS = {
    5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2), 5123: ("H", 2), 5126: ("f", 4),
}

#: glTF component types → the divisor that turns a NORMALIZED integer back
#: into its real value (KHR_mesh_quantization). Float accessors need none.
_NORMALIZED_DIVISOR = {5120: 127.0, 5121: 255.0, 5122: 32767.0, 5123: 65535.0}


def _dequantize(accessor: dict, values: list[float]) -> list[float]:
    """Undo a normalized-integer accessor's scaling.

    WP-147: `KHR_mesh_quantization` stores positions as normalized int16 and
    puts the real millimetres in the node's scale. Reading `min`/`max`
    verbatim therefore measured the FRAME body as 10 157 770 mm — a check
    that cannot be satisfied and a mesh that cannot be placed. three.js
    handles the extension natively, so only our own readers were blind.
    """
    if not accessor.get("normalized"):
        return values
    divisor = _NORMALIZED_DIVISOR.get(accessor.get("componentType", 5126))
    if divisor is None:
        return values
    return [max(-1.0, v / divisor) for v in values]


def glb_bounding_box(path: Path) -> MeshBox:
    """World bounding box of a .glb, honouring node transforms.

    Accessor min/max are per-primitive and pre-transform, so each mesh's box
    corners are pushed through its node chain — which is precisely what makes
    the wrapper-node family measurable at all.
    """
    gltf, _ = _chunks(path.read_bytes())
    nodes = gltf.get("nodes", [])
    meshes = gltf.get("meshes", [])
    accessors = gltf.get("accessors", [])
    scene = gltf.get("scenes", [{}])[gltf.get("scene", 0)]

    lo = [float("inf")] * 3
    hi = [float("-inf")] * 3

    def walk(index: int, parent: list[float]) -> None:
        node = nodes[index]
        world = _mul(parent, _matrix(node))
        mesh_index = node.get("mesh")
        if mesh_index is not None:
            for prim in meshes[mesh_index].get("primitives", []):
                acc = accessors[prim["attributes"]["POSITION"]]
                a_min, a_max = acc.get("min"), acc.get("max")
                if not a_min or not a_max:
                    continue
                a_min, a_max = _dequantize(acc, a_min), _dequantize(acc, a_max)
                # Every corner, because a rotation turns a box into a box only
                # if you transform all eight of them.
                for i in range(8):
                    corner = (
                        a_max[0] if i & 1 else a_min[0],
                        a_max[1] if i & 2 else a_min[1],
                        a_max[2] if i & 4 else a_min[2],
                    )
                    wx, wy, wz = _apply(world, corner)
                    for axis, value in enumerate((wx, wy, wz)):
                        lo[axis] = min(lo[axis], value)
                        hi[axis] = max(hi[axis], value)
        for child in node.get("children", []):
            walk(child, world)

    for root in scene.get("nodes", []):
        walk(root, IDENTITY)
    if lo[0] == float("inf"):
        raise ValueError("glTF declares no positioned geometry")
    return MeshBox(tuple(lo), tuple(hi))  # type: ignore[arg-type]


@dataclass(frozen=True)
class MeshPlate:
    """A flat, plate-like mesh measured in the file's own axes (F3).

    ``normal`` is a LINE, not an arrow: PCA cannot know which face is coated,
    so ±normal are the same plate and every comparison must use ``abs(dot)``.
    """

    node_name: str
    normal: tuple[float, float, float]
    thickness_mm: float
    size_mm: tuple[float, float]


def _positions(
    gltf: dict, blob: bytes | None, accessor_index: int
) -> list[tuple[float, float, float]]:
    """Decode a POSITION accessor to a list of vertices.

    Only the float32 VEC3 form glTF mandates for POSITION is handled; anything
    else returns nothing rather than guessing, because a wrong decode would
    silently produce a wrong plate normal — the exact class of error this
    module exists to catch.
    """
    if blob is None:
        return []
    acc = gltf.get("accessors", [])[accessor_index]
    if acc.get("type") != "VEC3":
        return []
    fmt, size = _COMPONENT_FORMATS.get(acc.get("componentType", 5126), (None, 0))
    if fmt is None:
        return []
    views = gltf.get("bufferViews", [])
    view_index = acc.get("bufferView")
    if view_index is None:
        return []
    view = views[view_index]
    start = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
    element = size * 3
    stride = view.get("byteStride") or element
    out: list[tuple[float, float, float]] = []
    for i in range(acc.get("count", 0)):
        offset = start + i * stride
        chunk = blob[offset : offset + element]
        if len(chunk) < element:
            break
        raw = struct.unpack(f"<{fmt * 3}", chunk)
        x, y, z = _dequantize(acc, list(raw))
        out.append((x, y, z))
    return out


Vec3 = tuple[float, float, float]


def _plate_of(points: list[Vec3]) -> tuple[Vec3, Vec3] | None:
    """Principal axes of a vertex cloud: (normal, extents along the 3 axes).

    Jacobi eigen-decomposition of the 3x3 covariance — small, exact enough,
    and it keeps this module dependency-free like the rest of the file.
    """
    n = len(points)
    if n < 4:
        return None
    cx = sum(p[0] for p in points) / n
    cy = sum(p[1] for p in points) / n
    cz = sum(p[2] for p in points) / n
    cov = [[0.0] * 3 for _ in range(3)]
    for px, py, pz in points:
        d = (px - cx, py - cy, pz - cz)
        for i in range(3):
            for j in range(3):
                cov[i][j] += d[i] * d[j]
    vectors = [[1.0 if i == j else 0.0 for j in range(3)] for i in range(3)]
    for _ in range(64):
        p_, q_ = max(
            ((i, j) for i in range(3) for j in range(3) if i < j),
            key=lambda ij: abs(cov[ij[0]][ij[1]]),
        )
        if abs(cov[p_][q_]) < 1e-14:
            break
        theta = 0.5 * math.atan2(2 * cov[p_][q_], cov[q_][q_] - cov[p_][p_])
        c, s = math.cos(theta), math.sin(theta)
        for k in range(3):
            akp, akq = cov[k][p_], cov[k][q_]
            cov[k][p_], cov[k][q_] = c * akp - s * akq, s * akp + c * akq
        for k in range(3):
            apk, aqk = cov[p_][k], cov[q_][k]
            cov[p_][k], cov[q_][k] = c * apk - s * aqk, s * apk + c * aqk
        for k in range(3):
            vkp, vkq = vectors[k][p_], vectors[k][q_]
            vectors[k][p_], vectors[k][q_] = c * vkp - s * vkq, s * vkp + c * vkq
    axes = sorted(
        ((cov[i][i], (vectors[0][i], vectors[1][i], vectors[2][i])) for i in range(3)),
        key=lambda item: item[0],
    )
    # Extent along each principal axis, in mm — variance alone cannot tell a
    # thin plate from a small one.
    extents: list[float] = []
    for _, axis in axes:
        projected = [
            (p[0] - cx) * axis[0] + (p[1] - cy) * axis[1] + (p[2] - cz) * axis[2]
            for p in points
        ]
        extents.append(max(projected) - min(projected))
    return axes[0][1], (extents[0], extents[1], extents[2])


#: A mesh counts as a plate when it is this much thinner than it is wide. A
#: 25.4 mm achromat measures 0.284 and must NOT be mistaken for a mirror.
PLATE_ASPECT_MAX = 0.15

#: How far the measured plate may sit from the declared one. Matches
#: derive.py's DIRECTION_TOL_DEG — one tolerance for one question.
FOLD_TOL_DEG = 2.0

#: Node names that suggest a reflective surface. The geometric test decides;
#: this only ranks candidates, because ``BUY - Mirror`` is one vendor's habit
#: and only 4 of 13 shipped template GLBs follow it.
_PLATE_HINT = re.compile(r"mirror|mir\d|reflect|beamsplit|dichro", re.I)


def glb_reflective_plate(path: Path) -> MeshPlate | None:
    """The reflective plate in a cube mesh, measured in file axes (F3).

    This is the only fact about a mount that the RECORD cannot state and the
    mesh can: which way the glass actually faces. Round 20 shipped a template
    declaring a fold its own mirror could not perform (plate normal
    (-0.707, +0.707, 0) folds x<->y; the record said the beam left along -z,
    the pin axis) and every check in both repos passed, because every check
    was record-level and the record was internally consistent.

    Returns the largest plate-like mesh, preferring name-hinted candidates.
    ``None`` when nothing qualifies — never a guess.
    """
    gltf, blob = _chunks(path.read_bytes())
    nodes = gltf.get("nodes", [])
    meshes = gltf.get("meshes", [])
    scene = gltf.get("scenes", [{}])[gltf.get("scene", 0)]
    best: tuple[float, int, MeshPlate] | None = None

    def walk(index: int, parent: list[float]) -> None:
        nonlocal best
        node = nodes[index]
        world = _mul(parent, _matrix(node))
        mesh_index = node.get("mesh")
        name = str(node.get("name", ""))
        if mesh_index is not None:
            for prim in meshes[mesh_index].get("primitives", []):
                attrs = prim.get("attributes", {})
                if "POSITION" not in attrs:
                    continue
                local = _positions(gltf, blob, attrs["POSITION"])
                if not local:
                    continue
                points = [_apply(world, p) for p in local]
                measured = _plate_of(points)
                if measured is None:
                    continue
                normal, extents = measured
                thin, mid, wide = extents
                if mid <= 0 or thin / mid > PLATE_ASPECT_MAX:
                    continue
                area = mid * wide
                hinted = 1 if _PLATE_HINT.search(name) else 0
                plate = MeshPlate(
                    node_name=name,
                    normal=normal,
                    thickness_mm=thin,
                    size_mm=(mid, wide),
                )
                if best is None or (hinted, area) > (best[1], best[0]):
                    best = (area, hinted, plate)
        for child in node.get("children", []):
            walk(child, world)

    for root in scene.get("nodes", []):
        walk(root, IDENTITY)
    return best[2] if best else None


def fold_normal_deviation_deg(
    plate: MeshPlate, entry: tuple[float, float, float], exit_: tuple[float, float, float]
) -> float | None:
    """Angle between the measured plate and the one the ports imply.

    The plate that turns ``entry`` into ``exit_`` has normal proportional to
    (exit - entry) — the bisector, the same law the editors draw. Compared as
    LINES, because PCA gives ±n. ``None`` when the ports are degenerate.
    """
    bisector = tuple(exit_[i] - entry[i] for i in range(3))
    length = math.sqrt(sum(v * v for v in bisector))
    if length < 1e-9:
        return None
    implied = tuple(v / length for v in bisector)
    measured = plate.normal
    m_len = math.sqrt(sum(v * v for v in measured))
    if m_len < 1e-9:
        return None
    dot = abs(sum(implied[i] * measured[i] / m_len for i in range(3)))
    return math.degrees(math.acos(max(0.0, min(1.0, dot))))


#: Axis literals, as F3 unit vectors.
_AXIS: dict[str, Vec3] = {
    "+x": (1.0, 0.0, 0.0), "-x": (-1.0, 0.0, 0.0),
    "+y": (0.0, 1.0, 0.0), "-y": (0.0, -1.0, 0.0),
    "+z": (0.0, 0.0, 1.0), "-z": (0.0, 0.0, -1.0),
}

#: An entry port states the face it PRESENTS, so the beam travels the other
#: way. The same six names the editors use — see DSN-CONTRACT §4.
_ENTRY_NAMES = frozenset({"front", "sensor", "in", "plane"})


def _fold_findings(
    template_id: str,
    glb_path: Path,
    optical_ports: dict[str, str] | None,
    mesh_frame: str = "",
    mesh_pose_grid: tuple[str, str] | None = None,
) -> list[tuple[str, str, str]]:
    """Compare the mesh's plate with the fold the template's ports declare."""
    if not optical_ports or len(optical_ports) < 2:
        return []
    entry_name = next(
        (n for n in optical_ports if n in _ENTRY_NAMES), None
    )
    exit_name = next(
        (n for n in optical_ports if n != entry_name and n not in _ENTRY_NAMES), None
    )
    if entry_name is None or exit_name is None:
        return []
    entry_face = _AXIS.get(str(optical_ports[entry_name]))
    exit_dir = _AXIS.get(str(optical_ports[exit_name]))
    if entry_face is None or exit_dir is None:
        return []
    entry_travel = tuple(-v for v in entry_face)
    # A straight-through pair is not a fold; nothing to check against a plate.
    if sum(entry_travel[i] * exit_dir[i] for i in range(3)) > 0.99:
        return []
    try:
        plate = glb_reflective_plate(glb_path)
    except (ValueError, KeyError, IndexError, struct.error):
        return []
    if plate is not None:
        # Measured in file axes; the ports speak cube axes — same map as the
        # envelope checks (identity unless a correction is declared).
        to_cube = _mesh_to_cube(mesh_frame, mesh_pose_grid)
        plate = MeshPlate(
            node_name=plate.node_name,
            normal=to_cube(plate.normal),
            thickness_mm=plate.thickness_mm,
            size_mm=plate.size_mm,
        )
    if plate is None:
        return [(
            "warning",
            "W_MESH_NO_PLATE",
            f"{template_id}: the ports declare a fold but no plate-like mesh was found "
            f"in {glb_path.name}, so the optics could not be checked against the glass",
        )]
    deviation = fold_normal_deviation_deg(plate, entry_travel, exit_dir)
    if deviation is None or deviation <= FOLD_TOL_DEG:
        return []
    return [(
        "error",
        "E_FOLD_MESH_MISMATCH",
        f"{template_id}: the mirror in {glb_path.name} ('{plate.node_name}') cannot perform "
        f"the declared fold. Its plate normal is "
        f"({', '.join(f'{v:+.3f}' for v in plate.normal)}) in the CUBE frame, which is "
        f"{deviation:.1f}° from the plate that would send {entry_name} "
        f"({optical_ports[entry_name]}) to {exit_name} ({optical_ports[exit_name]}). "
        f"The insert-pose is rotated about the entry axis — the ports and the pose agree "
        f"with each other and neither agrees with the glass.",
    )]


#: mesh-frame sugar as FILE->cube grid maps: where the FILE's +z and +x land.
_FRAME_GRIDS: dict[str, tuple[str, str]] = {
    "record": ("-y", "+x"),  # y-up glTF: file y = cube z, file z = cube -y
}


def _grid_matrix(z: str, x: str) -> list[Vec3] | None:
    """Rows of the FILE-to-cube rotation for a grid spelling (None = identity)."""
    zv = _AXIS.get(z)
    xv = _AXIS.get(x)
    if zv is None or xv is None:
        return None
    yv = (
        zv[1] * xv[2] - zv[2] * xv[1],
        zv[2] * xv[0] - zv[0] * xv[2],
        zv[0] * xv[1] - zv[1] * xv[0],
    )
    # Columns are the images of file x/y/z; rows give cube components.
    return [
        (xv[0], yv[0], zv[0]),
        (xv[1], yv[1], zv[1]),
        (xv[2], yv[2], zv[2]),
    ]


def _mesh_to_cube(mesh_frame: str, mesh_pose_grid: tuple[str, str] | None):
    """FILE-to-cube vector map from the declared correction (WP-137).

    ``mesh-pose`` wins over the ``mesh-frame`` sugar; both absent = identity.
    """
    grid = mesh_pose_grid or _FRAME_GRIDS.get(mesh_frame)
    if grid is None:
        return lambda v: (v[0], v[1], v[2])
    rows = _grid_matrix(*grid)
    if rows is None:
        return lambda v: (v[0], v[1], v[2])
    return lambda v: tuple(
        rows[i][0] * v[0] + rows[i][1] * v[1] + rows[i][2] * v[2] for i in range(3)
    )


def _abs3(v: tuple[float, float, float]) -> tuple[float, float, float]:
    return (abs(v[0]), abs(v[1]), abs(v[2]))


def check_template_mesh(
    template_id: str,
    envelope: tuple[float, float, float] | None,
    footprint_grid: list[int] | tuple[int, int, int] | None,
    provenance: str,
    glb_path: Path,
    mesh_frame: str = "",
    optical_ports: dict[str, str] | None = None,
    mesh_pose_grid: tuple[str, str] | None = None,
    mesh_pose_tilted: bool = False,
) -> list[tuple[str, str, str]]:
    """(level, code, message) findings for one template's mesh.

    Three questions, in order of how certain the answer is:

    1. Does the mesh FIT the envelope the record declares, under *any* axis
       assignment? If not, the file is in the wrong units or is the wrong file
       — the one failure mode with no legitimate reading.
    2. If it fits only after permuting axes, the mesh frame and the record
       frame disagree — the wrapper-node split. A warning, not an error,
       because both families ship today and both render correctly once a
       placement rotation is applied. It is the ambiguity made *visible*
       rather than made official.
    3. If the record claims ``provenance: whole-module`` — "this mesh IS the
       cube" — then it must actually measure the cell it occupies.
    4. WP-134: if the template declares a FOLD, can the mirror in the mesh
       physically perform it? This is the only question here whose answer the
       record cannot fake: ports and pose are self-consistent statements, and
       round 20 shipped a trio where both agreed with each other and neither
       agreed with the glass. Pass ``optical_ports`` (as-mounted name →
       direction) to enable it.
    """
    findings: list[tuple[str, str, str]] = []
    try:
        box = glb_bounding_box(glb_path)
    except (OSError, ValueError, KeyError, IndexError, struct.error) as exc:
        return [("error", "E_MESH_UNREADABLE", f"{template_id}: {glb_path.name}: {exc}")]

    # WP-135/137: measurements are compared in CUBE axes. A declared
    # record-frame file (or any mesh-pose grid) is un-rotated first, or a
    # perfectly correct converted STP fails its own cell check (testlens:
    # 49.8 × 53.8 × 49.8 against a 50 × 50 × 55 cell, which IS the cell once
    # y and z swap back). Declaring the frame used to change only the
    # SEVERITY of the axis check while the numbers stayed in file axes.
    to_cube = _mesh_to_cube(mesh_frame, mesh_pose_grid)
    size = _abs3(to_cube(box.size))
    center = to_cube(box.center)
    shown = f"{size[0]:.1f} × {size[1]:.1f} × {size[2]:.1f} mm"

    if envelope:
        fits_sorted = all(
            m <= e + CELL_TOL_MM
            for m, e in zip(sorted(size), sorted(envelope), strict=True)
        )
        # WP-156: a mesh-pose with a residual tilt (a housing sitting at an
        # angle in its cell) has no axis-exact reading — the 24-fold
        # un-rotation only covers the grid part, so the per-axis comparison
        # would flag a perfectly correct record. The intrinsic (sorted) box
        # comparison stays exact regardless of orientation.
        fits_axes = mesh_pose_tilted or all(
            m <= e + CELL_TOL_MM for m, e in zip(size, envelope, strict=True)
        )
        if not fits_sorted:
            findings.append((
                "error",
                "E_MESH_EXCEEDS_ENVELOPE",
                f"{template_id}: {glb_path.name} measures {shown}, which does not fit the "
                f"declared envelope {envelope[0]:g} × {envelope[1]:g} × {envelope[2]:g} mm "
                "in any orientation — wrong units, or the wrong file.",
            ))
        elif not fits_axes:
            # WP-115: with `mesh-frame` DECLARED the axis assignment is no
            # longer ambiguous — a permuted fit stops being "two conventions
            # ship, tolerate both" and becomes a plain error.
            declared = bool(mesh_frame) or mesh_pose_grid is not None
            findings.append((
                "error" if declared else "warning",
                "E_MESH_AXES_PERMUTED" if declared else "W_MESH_AXES_PERMUTED",
                f"{template_id}: {glb_path.name} measures {shown}, which fits the declared "
                f"envelope {envelope[0]:g} × {envelope[1]:g} × {envelope[2]:g} mm only after "
                "permuting axes — the mesh frame and the record frame disagree. The library "
                "holds two glTF conventions: older exports ship an Rx(-90°) wrapper node "
                "that pre-applies the document→viewer basis change, newer OCCT exports do "
                "not. Both render today only because a placement rotation compensates.",
            ))

    if provenance == "whole-module" and footprint_grid:
        cell = tuple(UC2_CELL_MM[i] * max(1, int(footprint_grid[i])) for i in range(3))
        if max(abs(size[i] - cell[i]) for i in range(3)) > CELL_TOL_MM:
            findings.append((
                "error",
                "E_MESH_CELL_MISMATCH",
                f"{template_id}: {glb_path.name} claims `provenance: whole-module` — the mesh "
                f"IS the cube — but measures {shown} where footprint_grid "
                f"{list(footprint_grid)} wants {cell[0]:.0f} × {cell[1]:.0f} × {cell[2]:.0f} mm.",
            ))
        # A whole cube's origin is its CENTRE (the DSN contract's part origin);
        # a corner-origin export renders offset by half a cell and says nothing.
        if max(abs(c) for c in center) > CELL_TOL_MM:
            findings.append((
                "warning",
                "W_MESH_OFF_CENTRE",
                f"{template_id}: {glb_path.name} is centred at "
                f"({center[0]:.1f}, {center[1]:.1f}, {center[2]:.1f}) mm (cube axes), not on "
                "the part origin — a placed part will sit offset by that much.",
            ))
    # ── 4. does the glass agree with the ports? (WP-134) ────────────────
    # WP-156: the plate math runs through the GRID map only, so a tilted
    # housing would false-flag its own mirror — say nothing rather than
    # guess (the same rule as W_MESH_NO_PLATE).
    if not mesh_pose_tilted:
        findings.extend(
            _fold_findings(template_id, glb_path, optical_ports, mesh_frame, mesh_pose_grid)
        )
    return findings
