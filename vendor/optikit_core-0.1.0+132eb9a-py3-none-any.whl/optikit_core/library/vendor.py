"""Vendor remote record assets into the library tree (WP-58).

The WP-43 CSV migration left a split brain: 64 template records name a local
``glb:`` file they do not ship and carry a remote ``glb-url`` pointing at a
branch of the Store repo. Two asset homes, one of them a moving target — and
the index cannot serve a file that is not there.

This module pulls those remote assets down beside their record so the ONE
library has ONE asset home. ``glb-url`` is kept afterwards as provenance (it
records where the bytes came from), but it stops being load-bearing.

Nothing here is implicit: the caller chooses to fetch, sees exactly what would
be downloaded first (``plan``), and every write lands next to the record whose
``glb:`` field names it.
"""

from __future__ import annotations

import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from ..schema.library import TemplateRecord
from .build import Library

#: Be a good citizen against raw.githubusercontent.com.
USER_AGENT = "optikit-core/library-vendor-assets"
TIMEOUT_S = 30


@dataclass
class VendorItem:
    """One asset that a record references remotely but does not ship."""

    record_id: str
    #: Where the bytes should land (``<record dir>/<glb name>``).
    target: Path
    url: str

    @property
    def already_local(self) -> bool:
        return self.target.is_file()


def plan(library: Library) -> list[VendorItem]:
    """Every remote asset the library still depends on, in id order.

    Only records whose local file is MISSING are listed — vendoring is not a
    re-download, and an asset already in the tree is already home.
    """
    items: list[VendorItem] = []
    for loaded in library.by_kind("mechanical_template"):
        record = loaded.record
        if not isinstance(record, TemplateRecord) or not record.glb:
            continue
        # `glb-url` is draft syntax preserved by extra="allow" (WP-43), not a
        # declared field — read it off the model's extras.
        url = (record.model_extra or {}).get("glb-url")
        if not isinstance(url, str):
            continue
        url = url.strip()
        # `glb-url` has been used for two different things in the migrated
        # corpus: a real remote mesh, and (in at least one record) the name of
        # the Inventor source file. Only an http(s) URL is something we can
        # fetch — anything else is provenance and is left alone.
        if not url.startswith(("http://", "https://")):
            continue
        target = loaded.path.parent / record.glb
        if target.is_file():
            continue
        items.append(VendorItem(record.id, target, url.strip()))
    return sorted(items, key=lambda i: i.record_id)


def fetch(item: VendorItem, *, timeout: float = TIMEOUT_S) -> int:
    """Download one asset next to its record; returns the byte count.

    Writes through a temporary file so an interrupted download never leaves a
    truncated mesh that later looks like a valid local asset.
    """
    request = urllib.request.Request(item.url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310
        payload = response.read()
    if not payload:
        raise ValueError(f"{item.url} returned an empty body")
    item.target.parent.mkdir(parents=True, exist_ok=True)
    tmp = item.target.with_suffix(item.target.suffix + ".part")
    tmp.write_bytes(payload)
    tmp.replace(item.target)
    return len(payload)


def vendor_all(
    library: Library, *, dry_run: bool = False, timeout: float = TIMEOUT_S
) -> tuple[list[tuple[VendorItem, int]], list[tuple[VendorItem, str]]]:
    """Fetch every planned asset; returns (fetched, failed).

    A failure is reported and skipped rather than aborting the run — one dead
    URL in a 64-record migration must not block the other 63.
    """
    fetched: list[tuple[VendorItem, int]] = []
    failed: list[tuple[VendorItem, str]] = []
    for item in plan(library):
        if dry_run:
            fetched.append((item, 0))
            continue
        try:
            fetched.append((item, fetch(item, timeout=timeout)))
        except (urllib.error.URLError, OSError, ValueError) as exc:
            failed.append((item, str(exc)))
    return fetched, failed
