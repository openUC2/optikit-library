"""The Inventor SEED for a housed device (WP-156).

The housed-device road ends with a record that states, measured from the
cell centre (the future cube origin): where the housing sits (``mesh-pose``)
and where its optics live (``insert-pose``). The seed turns that statement
into the OUTBOUND leg of the Inventor round trip — one STEP assembly:

- ``PRT - 1/2 - CUBHLF-REF - …`` — two reference cube halves spanning the
  50 × 50 × 55 cell, named with the ``CUBHLF`` token so every viewer's
  "hide the cube halves" toggle catches them on reimport. They are an
  ENVELOPE, not the injection-moulded parts — the designer may swap in the
  real halves; what matters is that the re-exported cube measures the cell.
- ``SUB - 3 - HOUSING - …`` — the device STEP, already POSITIONED at its
  recorded mesh-pose. This is the real part, verbatim.
- ``PLN - OPT - <frame>`` / ``AXIS - OPT`` — the optical datum stamped per
  the Inventor naming contract (importers/glb2template.py), so the
  re-imported cube extracts its origin and beam direction automatically
  ("set the origin from the markers").

The return leg is the existing cube road: export the whole cube from
Inventor, import via "an Inventor cube you already have", and bind to the
EXISTING component id named in the bundled ``seed.yml`` — the optic record
is reused, never re-authored.
"""

from __future__ import annotations

import io
import math
import zipfile
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

import numpy as np
from yaml import safe_dump

from ..geometry.flatten import FlatPose
from ..geometry.rotations import compose
from .step_assembly import ROUND_MM, ExportError, _placement, _require_cadquery

#: The UC2 cell (x, y, z pitch) — the envelope the reference halves span.
CELL_MM = (50.0, 50.0, 55.0)
#: Reference-half wall thickness and side-bore diameter (an envelope, not
#: the moulded part — generous enough to never hide the housing).
WALL_MM = 4.0
BORE_MM = 35.0
#: Marker geometry: a thin disc the importer reads as a PLN plane, and a
#: rod for the AXIS direction.
MARKER_THICKNESS_MM = 0.2
MARKER_DIAMETER_MM = 8.0
AXIS_LENGTH_MM = 20.0
AXIS_DIAMETER_MM = 0.6


@dataclass(frozen=True)
class SeedPose:
    """A stored pose in the contract's spelling: R24 grid · offset-deg
    residual, plus an offset-mm translation."""

    grid: tuple[str, str] = ("+z", "+x")
    offset_deg: tuple[float, float, float] = (0.0, 0.0, 0.0)
    offset_mm: tuple[float, float, float] = (0.0, 0.0, 0.0)

    def rotation(self) -> np.ndarray:
        return compose(
            self.grid[0],
            self.grid[1],
            {"x": self.offset_deg[0], "y": self.offset_deg[1], "z": self.offset_deg[2]},
        )

    def flat(self) -> FlatPose:
        return FlatPose(
            offset_grid=(0, 0, 0),
            offset_mm=tuple(round(v, ROUND_MM) for v in self.offset_mm),
            rotation=self.rotation(),
        )

    def manifest(self) -> dict[str, Any]:
        return {
            "rotation": {
                "type": "grid",
                "grid": {"z": self.grid[0], "x": self.grid[1]},
                "offset-deg": dict(zip("xyz", self.offset_deg, strict=True)),
            },
            "translation": {"offset-mm": dict(zip("xyz", self.offset_mm, strict=True))},
        }


def _cube_half(cq: Any, top: bool) -> Any:
    """One reference half: a square tube spanning half the cell, with the
    side bores of the UC2 face windows. Envelope geometry, deliberately
    plain — the designer models the INSERT, not the cube."""
    height = CELL_MM[2] / 2.0
    z0 = 0.0 if top else -height
    outer = cq.Workplane("XY").workplane(offset=z0).rect(CELL_MM[0], CELL_MM[1]).extrude(height)
    inner = (
        cq.Workplane("XY")
        .workplane(offset=z0)
        .rect(CELL_MM[0] - 2 * WALL_MM, CELL_MM[1] - 2 * WALL_MM)
        .extrude(height)
    )
    half = outer.cut(inner)
    r = BORE_MM / 2.0
    bore_x = cq.Workplane("YZ").circle(r).extrude(CELL_MM[0], both=True)
    bore_y = cq.Workplane("XZ").circle(r).extrude(CELL_MM[1], both=True)
    return half.cut(bore_x).cut(bore_y)


def _along(cq: Any, solid: Any, direction: tuple[float, float, float]) -> Any:
    """Rotate a +z-built solid so its axis points along ``direction``."""
    z = np.array([0.0, 0.0, 1.0])
    d = np.array(direction, dtype=float)
    norm = float(np.linalg.norm(d))
    if norm < 1e-9:
        return solid
    d = d / norm
    axis = np.cross(z, d)
    axis_norm = float(np.linalg.norm(axis))
    if axis_norm > 1e-9:
        angle = math.degrees(math.acos(max(-1.0, min(1.0, float(z @ d)))))
        return solid.rotate((0, 0, 0), tuple(float(v) for v in axis / axis_norm), angle)
    if float(z @ d) < 0:
        return solid.rotate((0, 0, 0), (1, 0, 0), 180)
    return solid


def _readme(name: str, component_id: str, template_id: str, optic_frame: str) -> str:
    return f"""# Inventor seed · {name}

One STEP assembly, in the CELL frame: millimetres, z up, origin = the cube
centre (0, 0, 0) — the same frame every optikit record measures from.

What is in the tree:

- `PRT - 1/2 - CUBHLF-REF - …` — reference cube halves spanning the
  50 × 50 × 55 cell. An envelope: swap in the real openUC2 halves if you
  need the moulded geometry; either way the re-exported cube must measure
  one cell.
- `SUB - 3 - HOUSING - …` — the device, already at its recorded position
  and orientation. Do not move it: the optics records were written against
  exactly this pose.
- `PLN - OPT - {optic_frame}` / `AXIS - OPT` — the optical datum (plane +
  beam direction). KEEP THESE in your assembly: the importer reads them.

The job here: model the INSERT that clamps the housing into the cube.
Everything else is fixed.

Round trip back:

1. Export the whole cube (halves + insert + housing + markers) as ONE STEP.
2. In the configurator: Parts → "an Inventor cube you already have".
3. On the pose step, click "set the origin from the markers" — the PLN/AXIS
   datum fills the pose automatically.
4. Bind to the EXISTING optic record `{component_id}` (the expert tab's
   "bind to a different published component…") instead of re-authoring it;
   the housing record `{template_id}` stays as the no-cube variant.
5. verify-t1 must agree before publish — it checks the Inventor metal
   against the optical record.
"""


def build_inventor_seed(
    *,
    name: str,
    housing_step: bytes,
    housing_filename: str,
    mesh_pose: SeedPose,
    insert_pose: SeedPose,
    optic_position_mm: tuple[float, float, float],
    beam_dir: tuple[float, float, float],
    optic_frame: str = "optical",
    aperture_mm: float | None = None,
    component_id: str = "",
    template_id: str = "",
) -> bytes:
    """The seed zip: ``<name>-seed.step`` + ``README.md`` + ``seed.yml``."""
    cq = _require_cadquery()
    root = cq.Assembly(name=f"ASS - 0 - SEED - {name}")
    root.add(_cube_half(cq, top=False), name="PRT - 1 - CUBHLF-REF - BOTTOM")
    root.add(_cube_half(cq, top=True), name="PRT - 2 - CUBHLF-REF - TOP")

    with TemporaryDirectory() as tmp:
        step_path = Path(tmp) / "housing.step"
        step_path.write_bytes(housing_step)
        try:
            housing = cq.importers.importStep(str(step_path))
        except Exception as exc:  # noqa: BLE001 — OCC raises plain Exceptions
            raise ExportError(
                "E_BAD_STEP", "inventor-seed", f"cadquery could not read the STEP: {exc}"
            ) from exc
        stem = Path(housing_filename).stem or "housing"
        root.add(housing, name=f"SUB - 3 - HOUSING - {stem}", loc=_placement(cq, mesh_pose.flat()))

        # The optical datum, per the naming contract: a thin disc whose
        # normal is the beam, and a rod along it.
        radius = (aperture_mm or MARKER_DIAMETER_MM) / 2.0
        disc = cq.Workplane("XY").circle(radius).extrude(MARKER_THICKNESS_MM)
        rod = cq.Workplane("XY").circle(AXIS_DIAMETER_MM / 2.0).extrude(AXIS_LENGTH_MM)
        p = tuple(round(float(v), ROUND_MM) for v in optic_position_mm)
        root.add(
            _along(cq, disc, beam_dir).translate(p),
            name=f"PLN - OPT - {optic_frame}",
        )
        root.add(_along(cq, rod, beam_dir).translate(p), name="AXIS - OPT")

        out = Path(tmp) / f"{name}-seed.step"
        writer = getattr(root, "export", None) or root.save  # save: cq<=2.8
        writer(str(out))
        step_bytes = out.read_bytes()

    manifest = {
        "kind": "inventor-seed",
        "name": name,
        "component": component_id,
        "template": template_id,
        "housing-step": housing_filename,
        "frame": "cell — mm, z up, origin = the cube centre (0,0,0)",
        "mesh-pose": mesh_pose.manifest(),
        "insert-pose": insert_pose.manifest(),
        "optic-frame": optic_frame,
        "optic-position-mm": [round(float(v), 3) for v in optic_position_mm],
        "beam-dir": [round(float(v), 6) for v in beam_dir],
    }
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(f"{name}-seed.step", step_bytes)
        zf.writestr("README.md", _readme(name, component_id, template_id, optic_frame))
        zf.writestr("seed.yml", safe_dump(manifest, sort_keys=False))
    return buffer.getvalue()
