"""Typed schema for ``scene3-manifest.json`` (KIT-04).

The manifest is the semantic-key layer of the Canvas integration (spec §9.8):
it maps component ids to the Scene3 object ids they produced, records DOF
bindings, and lists the authored path traversals the chain-contract tests
resolve through. Kernel ids never carry meaning; the manifest is where meaning
lives.

These models mirror the dict :func:`optikit_core.canvas.materialize.materialize`
emits. They exist so ``scripts/export_schema.py`` can publish a JSON Schema for
downstream consumers (the configurator, the chain-contract harness) and so a
test can assert the emitted manifest conforms.
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from ..schema.common import SchemaModel


class ManifestDof(SchemaModel):
    """A component DOF binding (§9.9). ``pivot_world`` and ``surface`` are present
    only for DOFs that name a pivot frame or a driven fragment surface."""

    name: str
    axis: str = ""
    kind: str = "translation"
    range: tuple[float, float] | None = None
    pivot_world: dict | None = None
    surface: int | None = None


class ManifestComponent(SchemaModel):
    """The Scene3 objects a component produced, keyed by kind."""

    bodies: list[int] = Field(default_factory=list)
    surfaces: list[int] = Field(default_factory=list)
    apertures: list[int] = Field(default_factory=list)
    sources: list[int] = Field(default_factory=list)
    detectors: list[int] = Field(default_factory=list)
    dof: list[ManifestDof] = Field(default_factory=list)


class ManifestTraversal(SchemaModel):
    """One expected hop of a path: a component, the port, and the objects there."""

    component: str
    port: str
    objects: list[int] = Field(default_factory=list)


class ManifestPath(SchemaModel):
    """A path's intent index, source id, and traversal (§9.8).

    ``inferred`` is **vestigial and always false** since WP-169: it marked a
    chain that came from EMB-A inference rather than the author, and
    ``/v1/scene3`` no longer infers — every path here is the author's. Kept as
    an optional field so a stored manifest written before WP-169 still
    validates; a reader should treat its absence and ``false`` alike.
    """

    intent: int
    source: int
    expected_traversal: list[ManifestTraversal] = Field(default_factory=list)
    inferred: bool = False


class Scene3Manifest(SchemaModel):
    """The full ``scene3-manifest.json`` document."""

    format: Literal["optikit-scene3-manifest"] = "optikit-scene3-manifest"
    version: str
    fragment_dialect: int
    design: str
    components: dict[str, ManifestComponent] = Field(default_factory=dict)
    paths: dict[str, ManifestPath] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
