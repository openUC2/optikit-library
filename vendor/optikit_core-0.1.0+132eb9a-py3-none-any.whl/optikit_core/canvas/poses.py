"""Pose math shared by the materializer (KIT-02).

The kernel's ``Isometry3`` stores a rotation as an ``[x, y, z, w]`` quaternion
and a position. optikit-core carries rotations as 3×3 matrices
(``geometry/rotations.py``: columns = the component's local x/y/z axes in world),
so the materializer converts matrix → quaternion here.

Two frame conventions meet (spec §7, "three frames, one named conversion"): an
optikit record authors its optical axis along local **+z** (Optiland's
sequential convention — ports face ±z, frames offset by ``z-mm``), while a
Scene3 body authors its profile axis along local **+X** (kernel §4.1, matching
``build3::add_singlet``). :data:`REC_TO_SCENE` is the single named basis
conversion between them; no other code may convert between these frames. A
scene object's rotation is ``R @ REC_TO_SCENE.T`` with ``R`` the component
world rotation, so scene-local +X lands on the world direction of record-local
+z (``R @ ẑ``).
"""

from __future__ import annotations

import numpy as np

#: The record-local → Scene3-local basis conversion (spec §7): the proper
#: rotation mapping record (+x, +y, +z) → scene (+Y, +Z, +X). A cyclic
#: permutation, det = +1, so it composes with rotation matrices without
#: introducing a reflection. For dialect v0's surfaces of revolution any fixed
#: transverse choice is equivalent; this one is pinned by test, independent of
#: any component world rotation.
REC_TO_SCENE = np.array(
    [
        [0.0, 0.0, 1.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
    ]
)


def matrix_to_quat_xyzw(r: np.ndarray) -> list[float]:
    """Convert a 3×3 proper rotation matrix to an ``[x, y, z, w]`` quaternion.

    Uses the branch-stable Shepperd method. ``q`` and ``−q`` denote the same
    rotation; the kernel accepts either, so the sign branch is immaterial.
    """
    m = np.asarray(r, dtype=float)
    trace = m[0, 0] + m[1, 1] + m[2, 2]
    if trace > 0.0:
        s = np.sqrt(trace + 1.0) * 2.0
        w = 0.25 * s
        x = (m[2, 1] - m[1, 2]) / s
        y = (m[0, 2] - m[2, 0]) / s
        z = (m[1, 0] - m[0, 1]) / s
    elif m[0, 0] > m[1, 1] and m[0, 0] > m[2, 2]:
        s = np.sqrt(1.0 + m[0, 0] - m[1, 1] - m[2, 2]) * 2.0
        w = (m[2, 1] - m[1, 2]) / s
        x = 0.25 * s
        y = (m[0, 1] + m[1, 0]) / s
        z = (m[0, 2] + m[2, 0]) / s
    elif m[1, 1] > m[2, 2]:
        s = np.sqrt(1.0 + m[1, 1] - m[0, 0] - m[2, 2]) * 2.0
        w = (m[0, 2] - m[2, 0]) / s
        x = (m[0, 1] + m[1, 0]) / s
        y = 0.25 * s
        z = (m[1, 2] + m[2, 1]) / s
    else:
        s = np.sqrt(1.0 + m[2, 2] - m[0, 0] - m[1, 1]) * 2.0
        w = (m[1, 0] - m[0, 1]) / s
        x = (m[0, 2] + m[2, 0]) / s
        y = (m[1, 2] + m[2, 1]) / s
        z = 0.25 * s
    q = np.array([x, y, z, w])
    q = q / np.linalg.norm(q)
    return [float(v) for v in q]


def quat_xyzw_apply(q: list[float], v: np.ndarray) -> np.ndarray:
    """Rotate vector ``v`` by an ``[x, y, z, w]`` quaternion."""
    x, y, z, w = q
    u = np.array([x, y, z])
    return v + 2.0 * np.cross(u, np.cross(u, v) + w * v)


def arc_quat_xyzw(from_axis: np.ndarray, to_dir: np.ndarray) -> list[float]:
    """Shortest-arc quaternion rotating unit ``from_axis`` onto unit ``to_dir``.

    Reproduces ``glam::DQuat::from_rotation_arc`` for the generic case; the
    antiparallel case picks a fixed perpendicular axis. Used to orient sources
    (local +X onto a beam direction) and mirror/detector discs (local +Z onto a
    normal); the disc is symmetric about its axis, so any such quaternion places
    it correctly (tests assert the resulting axis, not a byte-identical facing).
    """
    a = np.asarray(from_axis, dtype=float)
    b = np.asarray(to_dir, dtype=float)
    la, lb = float(np.linalg.norm(a)), float(np.linalg.norm(b))
    if la < 1e-12 or lb < 1e-12:
        return [0.0, 0.0, 0.0, 1.0]
    a, b = a / la, b / lb
    dot = float(np.dot(a, b))
    if dot > 1.0 - 1e-12:
        return [0.0, 0.0, 0.0, 1.0]
    if dot < -1.0 + 1e-12:
        # 180°: any axis perpendicular to `a`.
        perp = np.cross(a, np.array([1.0, 0.0, 0.0]))
        if float(np.linalg.norm(perp)) < 1e-9:
            perp = np.cross(a, np.array([0.0, 1.0, 0.0]))
        perp = perp / np.linalg.norm(perp)
        return [float(perp[0]), float(perp[1]), float(perp[2]), 0.0]
    axis = np.cross(a, b)
    q = np.array([axis[0], axis[1], axis[2], 1.0 + dot])
    q = q / np.linalg.norm(q)
    return [float(v) for v in q]


def facing_quat_xyzw(normal: np.ndarray) -> list[float]:
    """Shortest-arc quaternion rotating local +Z onto a unit ``normal``."""
    return arc_quat_xyzw(np.array([0.0, 0.0, 1.0]), np.asarray(normal, dtype=float))
