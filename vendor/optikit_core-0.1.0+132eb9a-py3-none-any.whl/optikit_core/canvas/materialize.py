"""KIT-02: materialize a design's geometry into a Scene3 (.ocanvas v2) document.

Implements spec sections 7 and 9.1-9.7: refractive glass spans become closed
``Body3`` solids, reflective surfaces become zero-thickness ``SurfaceObject3``,
stops become ``Aperture3``, and passthrough / fragment-less components emit no
optical objects (they appear only in the manifest). Sources and detectors are
physical component instances (decision 6.13): one ``Source3`` per (source
component, emission port), one ``Detector3`` per (detector component, sensor
port), never one per path — path intents reference the shared objects.

The one reader of surface content is :mod:`.dialect`; glass baking is
:mod:`.materials`; pose/quaternion math is :mod:`.poses`. This module composes
them and never reads a raw surface dict itself.

Determinism (agent rule 10): components materialize in sorted-id order, surfaces
in index order, ids are allocated from a single counter, and no wall-clock value
appears. Same design + library → same bytes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from math import inf as math_inf
from math import isfinite as math_isfinite
from math import radians, sqrt
from typing import Any

import numpy as np

from ..geometry.flatten import FlatPose, apply_dof_values, flatten
from ..geometry.rotations import direction_vector
from ..schema.checks import Finding
from ..schema.common import is_template
from ..schema.design import DesignDecl, OpticsSpec, parse_chain_entry
from ..schema.merge import instantiate
from .dialect import FRAGMENT_DIALECT, DialectSurface, SagModel, parse_fragment
from .materials import GlassCatalogBuilder, catalog_material, is_ambient
from .poses import REC_TO_SCENE, arc_quat_xyzw, facing_quat_xyzw, matrix_to_quat_xyzw

#: Applied when a reflective surface or detector has no semi-aperture (§9.2/9.6).
DEFAULT_SEMI_APERTURE_MM = 12.7
#: Minimum axial glass thickness at the rim of an emitted lens profile. Two
#: caps that meet inside the authored semi-aperture (a biconvex whose sags sum
#: past the center thickness) would revolve into a self-intersecting solid —
#: the kernel then traces rays through the annulus inside-out (back cap before
#: front cap), refracting them into a nonsense cone. The profile is clamped to
#: the radius where this much edge remains, with W_SEMI_APERTURE_CLAMPED.
MIN_EDGE_THICKNESS_MM = 0.01
#: The implicit mount (§9.1): one absorbing annular plate per refractive run,
#: standing in for the insert/housing that physically holds the glass. Without
#: it, rays that miss the clear aperture sail straight through the module's
#: cell and read as "unrefracted" in the editor. Outer radius = half the UC2
#: grid pitch (the cube face), so a beam in a neighbouring cell is unaffected;
#: the plate sits a lip's offset in front of the first vertex so it is never
#: coplanar with the glass or an is_stop aperture.
MOUNT_OUTER_RADIUS_MM = 25.0
MOUNT_LIP_OFFSET_MM = 0.05
#: Placeholder environment wavelength until KIT-03 writes the real spectra.
_PLACEHOLDER_LAMBDA_UM = 0.55


@dataclass(frozen=True)
class ObjectProvenance:
    """Which document entity one emitted scene object came from.

    The reverse index a trace-derived sequence needs: a kernel prescription
    names scene object/patch ids, and this maps them back to
    ``(component, fragment surface index)`` so an emitter can reach the
    authored surface dicts. ``patches`` maps a body's cap patch ids to their
    fragment indices (rim/edge patches are deliberately absent — an axial ray
    striking a rim is not a sequence, it is a diagnosis); ``surface_index``
    carries the same for single-surface objects (mirror, thin lens).
    """

    component: str
    kind: str  # "body" | "mirror" | "thin_lens"
    patches: dict[int, int] = field(default_factory=dict)
    surface_index: int | None = None


@dataclass(frozen=True)
class SceneProvenance:
    """Scene-id → document maps for every id a prescription can mention."""

    objects: dict[int, ObjectProvenance] = field(default_factory=dict)
    sources: dict[int, tuple[str, str]] = field(default_factory=dict)
    detectors: dict[int, tuple[str, str]] = field(default_factory=dict)
    #: path name → scene intent id (the handle sequence extraction takes).
    intents: dict[str, int] = field(default_factory=dict)


@dataclass
class MaterializedScene:
    scene: dict[str, Any]
    manifest: dict[str, Any]
    findings: list[Finding] = field(default_factory=list)
    #: Reverse index for trace-derived consumers. ``None`` only on the early
    #: flatten-error return; a materialized scene always carries one.
    provenance: SceneProvenance | None = None

    @property
    def ok(self) -> bool:
        return not any(f.severity == "error" for f in self.findings)


class _IdAlloc:
    """A single monotonic id space, mirroring ``Scene3::alloc_*`` (one counter
    across bodies, patches, surfaces, apertures, detectors)."""

    def __init__(self) -> None:
        self._next = 0

    def take(self) -> int:
        i = self._next
        self._next += 1
        return i

    @property
    def next_id(self) -> int:
        return self._next


@dataclass(frozen=True)
class TraceQuality:
    """Numerical sampling policy (§9.5) — a rendering/performance setting,
    deliberately separate from the physical emission model. Beam radius lives in
    the record; ray count lives here. Seeded, so rule-10 determinism holds for
    any given values."""

    spatial_samples: int = 64
    angular_samples: int = 1
    seed: int = 0
    #: Kernel SamplingSequence variant name; anything unknown clamps to Grid
    #: (the endpoint's Literal already rejects it at the wire).
    sequence: str = "Grid"


_KNOWN_SEQUENCES = frozenset({"Grid", "Stratified", "Sobol"})


def _is_identity_quat(rotation: list[float] | None) -> bool:
    """True when a FrameSpec rotation is absent or the identity [0, 0, 0, ±1]."""
    if rotation is None:
        return True
    q = np.asarray(rotation, dtype=float)
    return q.shape == (4,) and bool(np.allclose(np.abs(q), [0.0, 0.0, 0.0, 1.0]))


def _trace_quality(raw: dict[str, Any] | None) -> TraceQuality:
    if not raw:
        return TraceQuality()
    sequence = str(raw.get("sequence", "Grid"))
    return TraceQuality(
        spatial_samples=max(1, int(raw.get("spatial_samples", 64))),
        angular_samples=max(1, int(raw.get("angular_samples", 1))),
        seed=max(0, int(raw.get("seed", 0))),
        sequence=sequence if sequence in _KNOWN_SEQUENCES else "Grid",
    )


def materialize(
    decl: DesignDecl,
    trace_quality: dict[str, Any] | None = None,
) -> MaterializedScene:
    """Materialize a design into a Scene3 document + manifest.

    WP-169 dropped the ``inferred_paths`` parameter with the chain inference it
    described: ``/v1/scene3`` no longer fabricates paths for a pathless design,
    so no path here is ever "inferred" and nothing needs marking as such. Every
    path in ``decl.paths`` is the author's.
    """
    findings: list[Finding] = []
    # WP-165 A1c: apply the requested variant, like every other consumer.
    # `budget`, `cli`, `back_annotate`, `calibrate`, `chain/infer`,
    # `compile/compiler`, `step_assembly` and `step_part` all call
    # `instantiate(decl)`; this was the one that did not, so a design with a
    # top-level `instantiation.variant` gave the kernel a DIFFERENT system than
    # the sequential lane compiled — and a pin keyed by variant cannot mean
    # anything while the materializer ignores which variant is active. No
    # design in the corpus sets one today, so this changes no current output.
    #
    # Rebinding `decl` rather than threading a `components` argument is
    # deliberate: a dozen helpers below read `decl.components`, and passing the
    # instantiated set to only some of them would apply the variant to the
    # poses but not to the optics — a subtler wrong than not applying it at all.
    decl = decl.model_copy(update={"components": instantiate(decl)})
    try:
        poses = flatten(decl.components)
    except Exception as exc:  # FlattenError carries a stable code
        code = getattr(exc, "code", "E_FLATTEN")
        where = f"components.{getattr(exc, 'comp_id', '')}"
        return MaterializedScene(
            scene={}, manifest={}, findings=[Finding(code, "error", where, str(exc))]
        )
    # A dragged insert (T2 dz, WP-80 tip/tilt) must move the kernel scene the
    # same way compile moves the sequential system — ONE shared implementation
    # (geometry.flatten.apply_dof_values), or the two engines disagree about
    # where the glass sits.
    dof_warnings: list[str] = []
    apply_dof_values(decl.components, poses, decl.instantiation.dof_values, dof_warnings)
    findings += [Finding("W_DOF_IGNORED", "warning", "instantiation.dof_values", w)
                 for w in dof_warnings]

    ids = _IdAlloc()
    catalog = GlassCatalogBuilder()
    bodies: list[dict[str, Any]] = []
    surfaces: list[dict[str, Any]] = []
    apertures: list[dict[str, Any]] = []
    stop_ids: set[int] = set()  # is_stop-provenance apertures; mounts excluded
    manifest_components: dict[str, Any] = {}
    prov_objects: dict[int, ObjectProvenance] = {}

    for comp_id in sorted(decl.components):
        comp = decl.components[comp_id]
        entry = {"bodies": [], "surfaces": [], "apertures": [],
                 "sources": [], "detectors": [], "dof": []}
        manifest_components[comp_id] = entry
        optics = comp.optics
        if optics is None:
            continue
        # WP-79 gap, made loud: FrameSpec.rotation ("a tilted frame tilts the
        # beam") is not applied by this materializer yet — port directions and
        # surface origins are resolved as if every frame were axis-aligned. A
        # record that authors one must never be mis-posed silently.
        for frame_name in sorted(optics.frames):
            if not _is_identity_quat(optics.frames[frame_name].rotation):
                findings.append(Finding(
                    "W_FRAME_ROTATION_IGNORED", "warning",
                    f"components.{comp_id}.optics.frames.{frame_name}",
                    "frame rotation quaternion is not applied by the Scene3 "
                    "materializer yet; the frame is treated as axis-aligned"))
        if optics.fragment is None or optics.passthrough:
            continue  # §9.4: fragment-less / passthrough — manifest only

        pose = poses[comp_id]
        where = f"components.{comp_id}.optics.fragment.surfaces"
        frag = parse_fragment(optics.fragment.surfaces, where)
        if not frag.ok:
            # A fragment outside dialect v0 is a vocabulary gap, not a physical
            # error: the COMPONENT degrades to "not traced" (manifest only,
            # like a fragment-less part) instead of rejecting the whole design
            # (decisions 6.14/E4 — one unsupported record must never blank the
            # trace). The parse detail survives, demoted to warnings.
            findings += [Finding(f.code, "warning", f.where, f.message)
                         for f in frag.findings]
            findings.append(Finding(
                "W_COMPONENT_NOT_TRACED", "warning", f"components.{comp_id}",
                "fragment is outside dialect v0 — the component emits no "
                "optical objects; rays pass through it untouched"))
            continue
        findings += frag.findings

        placer = _Placer(pose, optics, frag.surfaces)
        fold_normals, fold_findings = _fold_normals(placer, optics, frag.surfaces, where)
        findings += fold_findings
        splitter = comp.category in ("dichroic", "beamsplitter")
        glass_spans: list[tuple[int, float]] = []
        for surf in frag.surfaces:
            if surf.is_stop and surf.semi_aperture is not None:
                ap = _aperture(surf, placer, ids)
                apertures.append(ap)
                entry["apertures"].append(ap["common"]["id"])
                stop_ids.add(ap["common"]["id"])
            if surf.thin_lens_f is not None:
                obj, tl_findings = _thin_lens(surf, placer, ids)
                findings += [Finding(f.code, f.severity,
                                     f"components.{comp_id}.optics.fragment.{f.where}", f.message)
                             for f in tl_findings]
                surfaces.append(obj)
                entry["surfaces"].append(obj["common"]["id"])
                prov_objects[obj["common"]["id"]] = ObjectProvenance(
                    comp_id, "thin_lens", surface_index=surf.index)
                # The black box gets the same physical holder as a glass run —
                # unless its is_stop aperture already masks the whole plane.
                if not (surf.is_stop and surf.semi_aperture is not None):
                    hole = surf.semi_aperture if surf.semi_aperture is not None \
                        else DEFAULT_SEMI_APERTURE_MM
                    mount = _annular_mount(surf.index, hole, placer, ids)
                    apertures.append(mount)
                    entry["apertures"].append(mount["common"]["id"])
            elif surf.is_reflective:
                obj, blind = _mirror(surf, placer, ids, fold_normals[surf.index], splitter)
                if blind:
                    findings.append(Finding(
                        "W_DICHROIC_SPLIT", "warning", f"components.{comp_id}",
                        "dichroic/beamsplitter without a usable response block "
                        "mapped to a wavelength-blind 50/50 split"))
                surfaces.append(obj)
                entry["surfaces"].append(obj["common"]["id"])
                prov_objects[obj["common"]["id"]] = ObjectProvenance(
                    comp_id, "mirror", surface_index=surf.index)
            elif (filter_rt := _absorptive_response(surf.response)) is not None:
                # WP-167: a bandpass/longpass filter. Not reflective and not
                # glass, so it used to fall through every branch and emit
                # nothing — the one element in the netlist the kernel could
                # not see.
                obj = _spectral_filter(surf, placer, ids, filter_rt)
                surfaces.append(obj)
                entry["surfaces"].append(obj["common"]["id"])
                prov_objects[obj["common"]["id"]] = ObjectProvenance(
                    comp_id, "filter", surface_index=surf.index)
            elif not is_ambient(surf.material_post):
                body, ha_eff, body_findings = _lens_body(surf, placer, ids, catalog, where)
                findings += body_findings
                if body is not None:
                    bodies.append(body)
                    entry["bodies"].append(body["common"]["id"])
                    glass_spans.append((surf.index, ha_eff))
                    # The profile's cap patches carry the span's bounding
                    # fragment surfaces: edges[0] = front conic (surface i),
                    # edges[2] = back conic (surface i+1); rims stay unmapped.
                    edges = body["geometry"]["Profile"]["profile"]["edges"]
                    prov_objects[body["common"]["id"]] = ObjectProvenance(
                        comp_id, "body",
                        patches={edges[0]["patch"]: surf.index,
                                 edges[2]["patch"]: surf.index + 1})
        for mount in _mounts(glass_spans, placer, ids):
            apertures.append(mount)
            entry["apertures"].append(mount["common"]["id"])

    # §9.5-9.7 (decision 6.13): sources and detectors are physical component
    # instances — one Source3 per (source component, emission port), one
    # Detector3 per (detector component, sensor port), never one per path.
    # Paths only *reference* them; branching happens physically in the tracer.
    tq = _trace_quality(trace_quality)
    refs = _path_refs(decl, findings)

    sources, source_ids, source_lines, src_findings = _sources(decl, poses, refs, tq, ids)
    findings += src_findings
    detectors, detector_ids, det_findings = _detectors(decl, poses, refs, ids)
    findings += det_findings
    for (comp_id, _port), obj_id in sorted(source_ids.items()):
        if comp_id in manifest_components:
            manifest_components[comp_id]["sources"].append(obj_id)
    for (comp_id, _port), obj_id in sorted(detector_ids.items()):
        if comp_id in manifest_components:
            manifest_components[comp_id]["detectors"].append(obj_id)

    intents: list[dict[str, Any]] = []
    manifest_paths: dict[str, Any] = {}
    prov_intents: dict[str, int] = {}
    for ref in refs:
        src_id = source_ids.get((ref.src_comp, ref.src_port or ""))
        if src_id is None:
            # The record's emission port may differ from the chain port; the
            # component still has exactly one physical source to reference.
            src_id = next((sid for (c, _p), sid in sorted(source_ids.items())
                           if c == ref.src_comp), None)
        det_id = detector_ids.get((ref.det_comp, ref.det_port or ""))
        if src_id is None or det_id is None:
            continue
        stop_id, stop_findings = _path_stop(
            decl, decl.paths[ref.name], manifest_components, ref.name, stop_ids)
        findings += stop_findings
        intent_id = ids.take()
        intents.append({
            "id": intent_id, "source": src_id, "detector": det_id,
            "stop": stop_id, "label": ref.name,
        })
        prov_intents[ref.name] = intent_id
        manifest_paths[ref.name] = {
            "intent": len(intents) - 1,
            "source": src_id,
            "expected_traversal": _traversal(decl.paths[ref.name].chain, manifest_components),
        }

    # §9.9: record DOF bindings per component.
    for comp_id in sorted(decl.components):
        manifest_components[comp_id]["dof"] = _dof_bindings(decl, poses, comp_id)

    # §9.7: env spectrum = union of all source spectra and authored path lists.
    all_wavelengths = source_lines + [
        line for ref in refs for line in _authored_lines(ref.simulation)]
    env_wavelengths = _wavelength_union(all_wavelengths)
    scene = _assemble(bodies, surfaces, apertures, sources, detectors,
                      intents, env_wavelengths, catalog, ids)
    manifest = {
        "format": "optikit-scene3-manifest",
        "version": "1.0.0",
        "fragment_dialect": FRAGMENT_DIALECT,
        "design": decl.design.name if decl.design else "",
        "components": manifest_components,
        "paths": manifest_paths,
        "warnings": [str(f) for f in findings if f.severity == "warning"],
    }
    provenance = SceneProvenance(
        objects=prov_objects,
        sources={sid: key for key, sid in source_ids.items()},
        detectors={did: key for key, did in detector_ids.items()},
        intents=prov_intents,
    )
    return MaterializedScene(scene=scene, manifest=manifest, findings=findings,
                             provenance=provenance)


class _Placer:
    """Resolves a surface index to its world axial position and the component's
    world rotation, bridging the local-+z record frame to the body-+X frame."""

    def __init__(self, pose: FlatPose, optics: OpticsSpec, surfaces: list[DialectSurface]) -> None:
        self.R = np.asarray(pose.rotation, dtype=float)
        self.t = np.asarray(pose.position_mm, dtype=float)
        self._optical = optics.frames.get("optical")
        self._frames = optics.frames
        # A port with `after-surface: i` names the frame that owns surface i.
        self._owned: dict[int, str] = {
            p.after_surface: p.frame
            for p in optics.ports.values()
            if p.after_surface is not None and p.frame in optics.frames
        }
        self._surfaces = surfaces
        self._thickness = [s.thickness for s in surfaces]

    def _base_xyz(self) -> np.ndarray:
        f = self._optical
        return np.array([float(f.x_mm), float(f.y_mm), float(f.z_mm)]) if f else np.zeros(3)

    def local_pos(self, index: int) -> np.ndarray:
        """Surface origin in the component-local frame (optical axis = +z)."""
        owner = self._owned.get(index)
        if owner is not None:
            f = self._frames[owner]
            return np.array([float(f.x_mm), float(f.y_mm), float(f.z_mm)])
        base = self._base_xyz()
        axial = float(sum(self._thickness[:index]))
        return base + np.array([0.0, 0.0, axial])

    def world_pos(self, local: np.ndarray) -> list[float]:
        return [float(v) for v in (self.t + self.R @ local)]

    def world_normal(self, local_axis: np.ndarray) -> np.ndarray:
        return self.R @ local_axis

    def body_quat(self) -> list[float]:
        return matrix_to_quat_xyzw(self.R @ REC_TO_SCENE.T)


def _lens_body(
    front: DialectSurface,
    placer: _Placer,
    ids: _IdAlloc,
    catalog: GlassCatalogBuilder,
    where: str,
) -> tuple[dict[str, Any] | None, float, list[Finding]]:
    """§9.1: a glass span from surface i to i+1 → one closed revolved Body3.

    Returns ``(body, effective_semi_aperture, findings)`` — the semi-aperture
    after the self-intersection clamp, which the run's mount reuses as its
    clear opening.
    """
    i = front.index
    if i + 1 >= len(placer._thickness):
        return None, 0.0, [Finding("E_FRAG_UNSUPPORTED", "error", f"{where}[{i}]",
                                   "glass surface has no following surface to close a body")]
    gid, mat_findings = catalog.intern(front.material_post, f"{where}[{i}].material_post")
    if gid is None:
        return None, 0.0, mat_findings
    findings = list(mat_findings)

    p_front = placer.local_pos(i)
    p_back = placer.local_pos(i + 1)
    thickness = float(p_back[2] - p_front[2])
    center_local = 0.5 * (p_front + p_back)
    zf, zr = -thickness / 2.0, thickness / 2.0

    # Both bounding surfaces of the span; the back surface's geometry is the
    # next dialect surface. A cemented doublet shares that surface between two
    # bodies (coincident interface, §9.1).
    back = placer._surfaces[i + 1]
    ha = min(v for v in (front.semi_aperture, back.semi_aperture, DEFAULT_SEMI_APERTURE_MM)
             if v is not None)
    c1, k1 = _sag_ck(front.sag)
    c2, k2 = _sag_ck(back.sag)
    if _edge_gap(c1, k1, c2, k2, zf, zr, 0.0) < MIN_EDGE_THICKNESS_MM:
        return None, 0.0, findings + [Finding(
            "E_FRAG_UNSUPPORTED", "error", f"{where}[{i}]",
            f"glass span has non-positive axial thickness ({thickness:.4f} mm)")]
    ha_eff = _clamp_semi_aperture(c1, k1, c2, k2, zf, zr, ha)
    if ha_eff < ha:
        findings.append(Finding(
            "W_SEMI_APERTURE_CLAMPED", "warning", f"{where}[{i}]",
            f"front/back caps of the glass span meet inside the authored "
            f"semi-aperture ({ha:.3f} mm); profile clamped to r={ha_eff:.3f} mm "
            f"where {MIN_EDGE_THICKNESS_MM} mm edge thickness remains"))
    edges = _singlet_edges(front.sag, back.sag, zf, zr, ha_eff, ids)

    body = {
        "common": _common(ids.take(), placer.body_quat(), placer.world_pos(center_local)),
        "geometry": {
            "Profile": {
                "profile": {"edges": edges},
                "construction": "RevolveLocalX",
            }
        },
        "material": catalog_material(gid),
        "absorption": "None",
        "surface": _default_surface_props(),
        "priority": 0,
    }
    return body, ha_eff, findings


def _edge_gap(c1: float, k1: float, c2: float, k2: float,
              zf: float, zr: float, r: float) -> float:
    """Axial glass thickness at radius ``r``: back cap minus front cap."""
    return (zr + _conic_sag(c2, k2, r)) - (zf + _conic_sag(c1, k1, r))


def _clamp_semi_aperture(c1: float, k1: float, c2: float, k2: float,
                         zf: float, zr: float, ha: float) -> float:
    """Largest radius ≤ ``ha`` keeping ``MIN_EDGE_THICKNESS_MM`` of glass.

    Bisection on the monotone-enough gap function; a fixed iteration count
    keeps the result byte-deterministic (rule 10).
    """
    if _edge_gap(c1, k1, c2, k2, zf, zr, ha) >= MIN_EDGE_THICKNESS_MM:
        return ha
    lo, hi = 0.0, ha
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if _edge_gap(c1, k1, c2, k2, zf, zr, mid) >= MIN_EDGE_THICKNESS_MM:
            lo = mid
        else:
            hi = mid
    return lo


def _singlet_edges(
    front: SagModel, back: SagModel, zf: float, zr: float, ha: float, ids: _IdAlloc
) -> list[dict[str, Any]]:
    """The four meridional edges (front conic, top rim, back conic, bottom rim),
    matching ``build3::singlet_curves`` so the profile serialization is pinned."""
    c1, k1 = _sag_ck(front)
    c2, k2 = _sag_ck(back)
    ftip = zf + _conic_sag(c1, k1, ha)
    rtip = zr + _conic_sag(c2, k2, ha)
    p0, p1, p2, p3 = (ids.take() for _ in range(4))
    return [
        {"patch": p0, "curve": {"Conic": _conic(zf, c1, k1, ha)}},
        {"patch": p1, "curve": {"Line": {"a": [ftip, ha], "b": [rtip, ha]}}},
        {"patch": p2, "curve": {"Conic": _conic(zr, c2, k2, ha)}},
        {"patch": p3, "curve": {"Line": {"a": [rtip, -ha], "b": [ftip, -ha]}}},
    ]


def _fold_normals(
    placer: _Placer,
    optics: OpticsSpec,
    surfaces: list[DialectSurface],
    where: str,
) -> tuple[dict[int, np.ndarray], list[Finding]]:
    """§9.2: record-local front normals of the reflective surfaces.

    A mirror's fold is authored in the record's ports, never hardcoded (WP-29:
    flat_0 and flat_45 differ only in their ``reflected`` direction). The
    physical mirror plane bisects the authored in/out pair:
    ``n = normalize(d_out − d_in)``, which faces the incoming beam
    (``n · d_in < 0``). ``d_in`` starts at the entry port (no ``after-surface``;
    ``front`` by convention) and advances leg by leg; a reflective surface with
    no owning exit port takes the leg to the next reflective surface's origin
    (the galvo's unauthored intermediate hop between its two pivots).
    """
    findings: list[Finding] = []
    normals: dict[int, np.ndarray] = {}
    reflective = [s.index for s in surfaces if s.is_reflective]
    if not reflective:
        return normals, findings

    ports = optics.ports
    entry = ports.get("front")
    if entry is None or entry.after_surface is not None:
        entry = next((ports[name] for name in sorted(ports)
                      if ports[name].after_surface is None), None)
    d_in: np.ndarray | None = None
    if entry is not None:
        vec = direction_vector(entry.direction)
        if vec is not None:
            # The entry port faces the incoming beam; the beam travels opposite.
            d_in = -np.asarray(vec, dtype=float)

    exits: dict[int, list[tuple[str, np.ndarray]]] = {}
    for name in sorted(ports):
        port = ports[name]
        if port.after_surface is None:
            continue
        vec = direction_vector(port.direction)
        if vec is not None:
            exits.setdefault(port.after_surface, []).append((name, np.asarray(vec, dtype=float)))

    for pos, index in enumerate(reflective):
        candidates = exits.get(index, [])
        named = [v for name, v in candidates if name == "reflected"]
        d_out: np.ndarray | None = None
        if named:
            d_out = named[0]
        elif d_in is not None:
            # A splitter authors several exits; the straight-through one is the
            # continuation of d_in, any other is the fold.
            folds = [v for _name, v in candidates if not np.allclose(v, d_in)]
            if len(folds) == 1:
                d_out = folds[0]
        elif len(candidates) == 1:
            d_out = candidates[0][1]
        if d_out is None and pos + 1 < len(reflective):
            leg = placer.local_pos(reflective[pos + 1]) - placer.local_pos(index)
            norm = float(np.linalg.norm(leg))
            if norm > 1e-9:
                d_out = leg / norm

        if d_in is None or d_out is None or np.allclose(d_out, d_in):
            findings.append(Finding(
                "W_MIRROR_AXIS_DEFAULTED", "warning", f"{where}[{index}]",
                "reflective surface's fold is not derivable from the record "
                "ports; record-local -z normal applied"))
            normals[index] = np.array([0.0, 0.0, -1.0])
            if d_out is not None:
                d_in = d_out
            continue
        bisector = d_out - d_in
        normals[index] = bisector / float(np.linalg.norm(bisector))
        d_in = d_out
    return normals, findings


#: Transition width of a band edge in the emitted step curve, µm (2 nm): the
#: kernel's Tabulated response interpolates linearly between samples, so a
#: cut-on becomes a 2 nm linear ramp rather than a numerical discontinuity.
BAND_EDGE_UM = 0.002


def _band_step_curve(bands: list[Any]) -> tuple[list[float], list[float]] | None:
    """WP-74 ``reflect-bands-um`` → a Tabulated reflectance step curve.

    Inside any band the surface reflects (1.0); outside it transmits (0.0);
    each finite band edge ramps linearly over ``BAND_EDGE_UM``. Open-ended
    sides (``null``) rely on the kernel's Clamp policy holding the endpoint.
    Returns None when the bands carry no finite edge (an all-open band is a
    plain mirror, not a spectral curve).
    """
    spans = sorted(
        (float(lo) if lo is not None else -math_inf,
         float(hi) if hi is not None else math_inf)
        for lo, hi in bands
    )
    # Bands must be disjoint with room for both edge ramps, or the step
    # function is ill-defined (a covered wavelength would read 0).
    for (_, prev_hi), (next_lo, _) in zip(spans, spans[1:], strict=False):
        if prev_hi + 2 * BAND_EDGE_UM > next_lo:
            return None
    points: list[tuple[float, float]] = []
    for lo, hi in spans:
        if math_isfinite(lo):
            points += [(lo - BAND_EDGE_UM, 0.0), (lo, 1.0)]
        if math_isfinite(hi):
            points += [(hi, 1.0), (hi + BAND_EDGE_UM, 0.0)]
    points.sort()
    lam = [p[0] for p in points]
    if not lam:
        return None  # no finite edge: an all-open band is a plain mirror
    return lam, [p[1] for p in points]


def _tabulated(lambda_um: list[float], values: list[float]) -> dict[str, Any]:
    return {"Tabulated": {"lambda_um": lambda_um, "values": values,
                          "interpolation": "Linear", "out_of_range": "Clamp"}}


def _split_responses(response: Any) -> tuple[Any, Any] | None:
    """A splitter surface's WP-74 response → per-face kernel responses.

    - ``dichroic`` with reflect bands → wavelength-true Tabulated R/T (the
      kernel samples the curve at each ray's wavelength), both faces.
    - ``sampler`` → constant split; per ``schema.response``'s convention the
      authored ratio is the REFLECT arm's share.
    - anything else (or no usable data) → None, and the caller falls back to
      the wavelength-blind 50/50 with ``W_DICHROIC_SPLIT``.
    """
    if response is None:
        return None
    if response.kind == "sampler":
        r = 0.5 if response.transmit_ratio is None else float(response.transmit_ratio)
        rt = {"ExplicitRt": {"reflectance": {"Constant": r},
                             "transmittance": {"Constant": 1.0 - r}}}
        return rt, rt
    if response.kind == "dichroic" and response.reflect_bands_um:
        curve = _band_step_curve(response.reflect_bands_um)
        if curve is None:
            return None
        lam, refl = curve
        rt = {"ExplicitRt": {"reflectance": _tabulated(lam, refl),
                             "transmittance": _tabulated(lam, [1.0 - v for v in refl])}}
        return rt, rt
    return None


def _absorptive_response(response: Any) -> dict[str, Any] | None:
    """WP-167: an absorptive filter's ``transmit-bands-um`` → a kernel response.

    A bandpass is a straight-through element with no reflect arm: `R = 0`
    everywhere, `T = 1` in band and `0` outside, and the kernel deposits the
    remaining `1 − R − T` as surface absorption — which is what a filter
    physically does to out-of-band light.

    Reusing :func:`_band_step_curve` keeps one definition of what a band edge
    means (the 2 nm ramp), so a dichroic's cut-on and a filter's cut-on cannot
    drift apart. Returns None when there is nothing spectral to say, and the
    caller then emits no object — an unconditionally clear filter is
    indistinguishable from air, and inventing a surface for it would put a
    false hop in every traced sequence.
    """
    if response is None or response.kind != "absorptive":
        return None
    if not response.transmit_bands_um:
        return None
    curve = _band_step_curve(response.transmit_bands_um)
    if curve is None:
        return None
    lam, pass_band = curve
    return {"ExplicitRt": {"reflectance": _tabulated(lam, [0.0] * len(lam)),
                           "transmittance": _tabulated(lam, pass_band)}}


def _spectral_filter(
    surf: DialectSurface, placer: _Placer, ids: _IdAlloc, response: dict[str, Any],
) -> dict[str, Any]:
    """WP-167: a non-reflective surface with an absorptive response → a
    zero-thickness ``SurfaceObject3`` that actually blocks out-of-band light.

    Before this, a filter with `passthrough: true` emitted nothing at all, so
    the kernel had no object where the netlist said a filter was: every
    wavelength sailed through, bleed-through was untraceable, and a discovered
    sequence could not confirm the hop because there was nothing to hit.
    """
    ha = surf.semi_aperture if surf.semi_aperture is not None else DEFAULT_SEMI_APERTURE_MM
    normal = placer.world_normal(np.array([0.0, 0.0, 1.0]))
    pos = placer.world_pos(placer.local_pos(surf.index))
    return {
        "common": _common(ids.take(), facing_quat_xyzw(normal), pos),
        "geometry": {"Plane": {"shape": {"Disc": {"radius_mm": ha}}}},
        # Same response both ways: a bandpass does not know which side the
        # light arrived from.
        "response_front": response,
        "response_back": response,
    }


def _mirror(
    surf: DialectSurface,
    placer: _Placer,
    ids: _IdAlloc,
    normal_local: np.ndarray,
    splitter: bool,
) -> tuple[dict[str, Any], bool]:
    """§9.2: a reflective surface → a zero-thickness SurfaceObject3 disc,
    front normal along the port-derived fold bisector. Dichroic/beamsplitter
    components split on both faces — wavelength-true when the record's WP-74
    ``response`` block provides bands or a ratio, a wavelength-blind 50/50
    otherwise; plain mirrors reflect front, absorb back. Returns the object
    plus whether the blind fallback was used (the caller warns)."""
    ha = surf.semi_aperture if surf.semi_aperture is not None else DEFAULT_SEMI_APERTURE_MM
    normal = placer.world_normal(normal_local)
    pos = placer.world_pos(placer.local_pos(surf.index))
    if surf.sag.kind == "plane":
        # A record's RectangularAperture IS the mirror's extent (the 1" square
        # mirror): rays outside it miss the surface and continue, exactly as
        # they do past the disc boundary.
        shape: dict[str, Any] = (
            {"Rectangle": {"half_width_mm": surf.aperture.half_width_mm,
                           "half_height_mm": surf.aperture.half_height_mm}}
            if surf.aperture is not None
            else {"Disc": {"radius_mm": ha}}
        )
        geometry: dict[str, Any] = {"Plane": {"shape": shape}}
    else:
        # A standalone SurfaceOfRevolution revolves about local +Z (kernel
        # geom3::surface convention), same facing rule as the plane.
        geometry = {
            "SurfaceOfRevolution": {
                "sag": {"Conic": {"curvature_per_mm": surf.sag.curvature_per_mm,
                                  "conic": surf.sag.conic}},
                "radial_aperture": {"inner_radius_mm": 0.0, "outer_radius_mm": ha},
            }
        }
    blind = False
    if splitter:
        pair = _split_responses(surf.response)
        if pair is None:
            blind = True
            split = {"ExplicitRt": {"reflectance": {"Constant": 0.5},
                                    "transmittance": {"Constant": 0.5}}}
            pair = (split, split)
        response_front, response_back = pair
    else:
        response_front = {"Mirror": {"reflectivity": {"Constant": 1.0}}}
        response_back = "Absorber"
    obj = {
        "common": _common(ids.take(), facing_quat_xyzw(normal), pos),
        "geometry": geometry,
        "response_front": response_front,
        "response_back": response_back,
    }
    return obj, blind


def _mounts(glass_spans: list[tuple[int, float]], placer: _Placer,
            ids: _IdAlloc) -> list[dict[str, Any]]:
    """§9.1: one absorbing annular plate per refractive run — the mount.

    A run is a maximal group of consecutive glass spans (a cemented doublet is
    one run). The plate's clear opening is the run's smallest effective
    semi-aperture, its outer extent the cube face, and it sits a lip's offset
    in front of the run's first vertex. Rays outside the glass terminate at
    the mount (``aperture_blocked``) instead of crossing the module untouched.
    """
    mounts: list[dict[str, Any]] = []
    run: list[tuple[int, float]] = []

    def flush() -> None:
        if not run:
            return
        first_index = run[0][0]
        hole = min(h for _, h in run)
        mounts.append(_annular_mount(first_index, hole, placer, ids))
        run.clear()

    prev: int | None = None
    for index, ha_eff in sorted(glass_spans):
        if prev is not None and index != prev + 1:
            flush()
        run.append((index, ha_eff))
        prev = index
    flush()
    return mounts


def _annular_mount(
    surface_index: int, hole: float, placer: _Placer, ids: _IdAlloc
) -> dict[str, Any]:
    """The §9.1 mount plate: an absorbing annulus a lip in front of the given
    surface's vertex, hole = the clear aperture, outer = the cube face."""
    local = placer.local_pos(surface_index) + np.array([0.0, 0.0, -MOUNT_LIP_OFFSET_MM])
    normal = placer.world_normal(np.array([0.0, 0.0, 1.0]))
    return {
        "common": _common(ids.take(), facing_quat_xyzw(normal), placer.world_pos(local)),
        "shape": {
            "plane_local": {"origin": [0.0, 0.0, 0.0], "u": [1.0, 0.0, 0.0],
                            "v": [0.0, 1.0, 0.0], "normal": [0.0, 0.0, 1.0]},
            "clear_opening": {"Disc": {"radius_mm": hole}},
            "outer_extent": {"Disc": {"radius_mm": MOUNT_OUTER_RADIUS_MM}},
        },
        "interaction": "Absorb",
        "primary_stop_for": [],
    }


def _thin_lens(
    surf: DialectSurface, placer: _Placer, ids: _IdAlloc
) -> tuple[dict[str, Any], list[Finding]]:
    """WP-75: a ``thin_lens`` interaction model → one ideal-lens
    SurfaceObject3 (the kernel's ``ThinLens`` response on both faces, so the
    black box works from either direction). The plane faces the record's
    optical axis (local +z), matching the authored front/back ports."""
    findings: list[Finding] = []
    ha = surf.semi_aperture
    if ha is None:
        ha = DEFAULT_SEMI_APERTURE_MM
        findings.append(Finding(
            "W_APERTURE_DEFAULTED", "warning", f"surfaces[{surf.index}]",
            f"thin lens without semi-aperture; default {DEFAULT_SEMI_APERTURE_MM} mm applied"))
    normal = placer.world_normal(np.array([0.0, 0.0, 1.0]))
    pos = placer.world_pos(placer.local_pos(surf.index))
    response = {"ThinLens": {"focal_length_mm": float(surf.thin_lens_f or 0.0)}}
    obj = {
        "common": _common(ids.take(), facing_quat_xyzw(normal), pos),
        "geometry": {"Plane": {"shape": {"Disc": {"radius_mm": ha}}}},
        "response_front": response,
        "response_back": response,
    }
    return obj, findings


def _aperture(surf: DialectSurface, placer: _Placer, ids: _IdAlloc) -> dict[str, Any]:
    """§9.3: a stop → an absorbing Aperture3 at the surface plane."""
    assert surf.semi_aperture is not None
    normal = placer.world_normal(np.array([0.0, 0.0, 1.0]))
    pos = placer.world_pos(placer.local_pos(surf.index))
    return {
        "common": _common(ids.take(), facing_quat_xyzw(normal), pos),
        "shape": {
            "plane_local": {"origin": [0.0, 0.0, 0.0], "u": [1.0, 0.0, 0.0],
                            "v": [0.0, 1.0, 0.0], "normal": [0.0, 0.0, 1.0]},
            "clear_opening": {"Disc": {"radius_mm": surf.semi_aperture}},
            "outer_extent": None,
        },
        "interaction": "Absorb",
        "primary_stop_for": [],
    }


# --- small serde helpers -------------------------------------------------------


def _assemble(
    bodies: list[dict[str, Any]],
    surfaces: list[dict[str, Any]],
    apertures: list[dict[str, Any]],
    sources: list[dict[str, Any]],
    detectors: list[dict[str, Any]],
    intents: list[dict[str, Any]],
    env_wavelengths: list[list[float]],
    catalog: GlassCatalogBuilder,
    ids: _IdAlloc,
) -> dict[str, Any]:
    return {
        "format": "ocanvas",
        "version": 2,
        "dimension": 3,
        "bodies": bodies,
        "surfaces": surfaces,
        "apertures": apertures,
        "detectors": detectors,
        "sources": sources,
        # §9.7 view synthesis (Slice/orthographic) is a UI nicety that never
        # reaches the tracer; it is deferred rather than emitted as a guess.
        "views": [],
        "env": {
            "ambient_index": 1.0,
            "ambient_absorption": "None",
            "wavelengths": env_wavelengths or [[_PLACEHOLDER_LAMBDA_UM, 1.0]],
        },
        "layers": [{"name": "Layer 0", "visible": True, "opacity": 1.0}],
        "catalog": catalog.to_catalog(),
        "intent": {"primary_paths": intents},
        "next_id": ids.next_id,
    }


# --- KIT-03: sources, detectors, environment, intent ---------------------------


def _endpoint(entry: str) -> tuple[str, str | None, str | None]:
    """Parse one chain entry to (component, port_in, port_out)."""
    return parse_chain_entry(entry)


def _port_pose(
    decl: DesignDecl, poses: dict[str, FlatPose], comp_id: str, port_name: str | None
) -> tuple[np.ndarray, np.ndarray] | None:
    """World (position, direction) of a component port, or None if unresolvable."""
    comp = decl.components.get(comp_id)
    if comp is None or comp.optics is None or port_name is None:
        return None
    port = comp.optics.ports.get(port_name)
    if port is None:
        return None
    frame = comp.optics.frames.get(port.frame)
    frame_pos = (np.array([float(frame.x_mm), float(frame.y_mm), float(frame.z_mm)])
                 if frame else np.zeros(3))
    local_dir = direction_vector(port.direction)
    if local_dir is None:
        return None
    pose = poses[comp_id]
    r = np.asarray(pose.rotation, dtype=float)
    t = np.asarray(pose.position_mm, dtype=float)
    world_pos = t + r @ frame_pos
    world_dir = r @ np.asarray(local_dir, dtype=float)
    return world_pos, world_dir


@dataclass(frozen=True)
class _PathRef:
    """One path's terminal references: which source/detector components and
    ports it names, plus its verbatim simulation block."""

    name: str
    src_comp: str
    src_port: str | None
    det_comp: str
    det_port: str | None
    simulation: dict[str, Any]


def _path_refs(decl: DesignDecl, findings: list[Finding]) -> list[_PathRef]:
    refs: list[_PathRef] = []
    for path_name in sorted(decl.paths):
        path = decl.paths[path_name]
        if len(path.chain) < 2:
            findings.append(Finding("E_SIM_UNSUPPORTED", "error", f"paths.{path_name}",
                                    "path needs at least a source and a detector entry"))
            continue
        # The first and last chain entries are terminals (source exit, detector
        # entry): a single "comp.port", so the port lands in port_in.
        src_comp, src_port, _ = _endpoint(path.chain[0])
        det_comp, det_port, _ = _endpoint(path.chain[-1])
        refs.append(_PathRef(path_name, src_comp, src_port, det_comp, det_port,
                             path.simulation or {}))
    return refs


def _first_port(comp: Any, prefer: str) -> str | None:
    """Deterministic port pick: ``prefer`` if declared, else lexically first."""
    if comp.optics is None or not comp.optics.ports:
        return None
    if prefer in comp.optics.ports:
        return prefer
    return sorted(comp.optics.ports)[0]


def _ports_with_role(decl: DesignDecl, role: str) -> list[tuple[str, str]]:
    """Every ``(component, port)`` declaring ``role`` (WP-166), sorted.

    The terminal-discovery key. A record states what its boundaries DO, so the
    scene can be built — and traced — without any declared path.
    """
    out: list[tuple[str, str]] = []
    for comp_id in sorted(decl.components):
        comp = decl.components[comp_id]
        if comp.optics is None:
            continue
        for port_name in sorted(comp.optics.ports):
            if role in (comp.optics.ports[port_name].roles or []):
                out.append((comp_id, port_name))
    return out


def _inferred_terminals(
    decl: DesignDecl, category: str, prefer: str, role: str, declared: set[str],
) -> tuple[list[tuple[str, str]], list[Finding]]:
    """Legacy discovery for records that predate ``roles:`` (WP-166).

    A ``category: source`` / ``category: detector`` record with no role on any
    port still materializes, from its preferred port, with ``W_ROLE_INFERRED``
    naming the record to migrate. This is the compatibility ramp, not the
    contract: the contract is the role, and the warning is how the corpus gets
    walked to it. It cannot see a dual-role `sample`, which is exactly why
    guessing from `category` had to stop being the mechanism.
    """
    keys: list[tuple[str, str]] = []
    findings: list[Finding] = []
    for comp_id in sorted(decl.components):
        comp = decl.components[comp_id]
        if comp.category != category or comp_id in declared:
            continue
        port = _first_port(comp, prefer=prefer)
        if port is None:
            continue
        keys.append((comp_id, port))
        findings.append(Finding(
            "W_ROLE_INFERRED", "warning", f"components.{comp_id}.optics.ports.{port}",
            f"category {category!r} with no declared port role; {role!r} inferred "
            f"on {port!r} — declare roles: [{role}] to make it explicit"))
    return keys, findings


def _sources(
    decl: DesignDecl,
    poses: dict[str, FlatPose],
    refs: list[_PathRef],
    tq: TraceQuality,
    ids: _IdAlloc,
) -> tuple[list[dict[str, Any]], dict[tuple[str, str], int],
           list[tuple[float, float]], list[Finding]]:
    """§9.5: one ``Source3`` per (source component, emission port).

    Identification is **physical and path-free** (WP-166): a port declaring
    ``roles: [emitter]``, a record with an ``optics.emission`` block, or — with
    ``W_ROLE_INFERRED`` — a legacy ``category: source`` record. A declared path
    is no longer a discovery mechanism, because the tracer has to be able to
    find every terminal in a design that declares no paths at all; that is what
    makes the traced set the producer and ``paths:`` the lockfile.

    Zero referencing paths still emit; N referencing paths never duplicate
    (duplication would double flux and fake beamsplitter branching).
    """
    findings: list[Finding] = []
    # Key discovery: (comp id, port) → referencing paths. The refs are carried
    # only to attribute analysis settings (authored wavelength lists, field
    # warnings) to a source that some path names — never to FIND one.
    keys: dict[tuple[str, str], list[_PathRef]] = {}
    for key in _ports_with_role(decl, "emitter"):
        keys[key] = []
    emission_comps: set[str] = set()
    for comp_id in sorted(decl.components):
        comp = decl.components[comp_id]
        if comp.optics is not None and comp.optics.emission is not None:
            emission_comps.add(comp_id)
            if any(c == comp_id for c, _p in keys):
                continue  # a role already placed this record's emitter port
            port = _first_port(comp, prefer=comp.optics.emission.port or "out")
            if port is None:
                findings.append(Finding(
                    "E_SIM_UNSUPPORTED", "error", f"components.{comp_id}.optics.emission",
                    "emission block on a component with no ports"))
                continue
            keys[(comp_id, port)] = []
    declared = {c for c, _p in keys}
    legacy, legacy_findings = _inferred_terminals(
        decl, "source", "out", "emitter", declared)
    findings += legacy_findings
    for key in legacy:
        keys.setdefault(key, [])
    for ref in refs:
        for key in keys:  # attribute the path to the record's emitter port
            if key[0] == ref.src_comp:
                keys[key].append(ref)
                break

    sources: list[dict[str, Any]] = []
    source_ids: dict[tuple[str, str], int] = {}
    all_lines: list[tuple[float, float]] = []
    for key in sorted(keys):
        comp_id, port = key
        ref_list = keys[key]
        comp = decl.components.get(comp_id)
        # WP-47: a source that is off emits nothing. Chain inference already
        # skips it in the sequential lane; without this the kernel kept firing.
        if comp is not None and comp.enabled is False:
            continue
        where = f"components.{comp_id}"
        pose = _port_pose(decl, poses, comp_id, port or None)
        if pose is None:
            paths = ", ".join(r.name for r in ref_list) or "no path"
            findings.append(Finding("E_SIM_UNSUPPORTED", "error", where,
                                    f"source port {comp_id}.{port} does not resolve "
                                    f"(referenced by: {paths})"))
            continue
        world_pos, world_dir = pose
        emission = comp.optics.emission if comp is not None and comp.optics else None

        spatial, flux, spat_findings = _source_spatial_model(emission, ref_list, comp_id, where)
        findings += spat_findings
        if spatial is None:
            continue
        lines, wl_findings = _source_spectrum(emission, comp, ref_list, where)
        findings += wl_findings
        for ref in ref_list:
            if _has_nonzero_field(ref.simulation.get("fields")):
                findings.append(Finding("W_FIELDS_IGNORED", "warning", f"paths.{ref.name}",
                                        "non-zero field angles are dropped in dialect v0"))

        angular, angular_samples, ang_findings = _source_angular_model(
            emission, tq, where)
        findings += ang_findings
        if angular is None:
            continue

        source = {
            "id": ids.take(),
            "transform": {"rot_xyzw": arc_quat_xyzw(np.array([1.0, 0.0, 0.0]), world_dir),
                          "pos": [float(v) for v in world_pos]},
            "spatial": spatial,
            "angular": angular,
            "spectrum": {"Lines": [[lam, wt] for lam, wt in lines]},
            "flux": flux,
            "samples": {
                "spatial_samples": 1 if spatial == "Point" else tq.spatial_samples,
                "angular_samples": angular_samples,
                "seed": tq.seed, "sequence": tq.sequence,
            },
        }
        sources.append(source)
        source_ids[key] = source["id"]
        all_lines += lines
    return sources, source_ids, all_lines, findings


def _source_angular_model(
    emission: Any, tq: TraceQuality, where: str
) -> tuple[dict[str, Any] | None, int, list[Finding]]:
    """Angular model + angular sample count of one source (§9.5).

    ``collimated`` (and every fallback) emits along the port direction —
    source-local +X after the port-alignment rotation. ``cone`` maps to the
    kernel's ``UniformConeSolidAngle`` about the same axis, so the pose math is
    shared. A cone with one angular sample degenerates to its axis (the Grid
    sequence's single sample is the pole), so cone sources get a floor of 8
    angular samples unless the request asks for more.
    """
    direction = {"Direction": {"local_dir": [1.0, 0.0, 0.0]}}
    if emission is None or emission.angular.type != "cone":
        return direction, tq.angular_samples, []
    half = emission.angular.half_angle_deg
    if half is None or is_template(half) or not 0.0 < float(half) <= 90.0:
        return None, 0, [Finding(
            "E_SIM_UNSUPPORTED", "error", f"{where}.optics.emission.angular",
            f"cone emission needs half_angle_deg in (0, 90], got {half!r}")]
    return (
        {"UniformConeSolidAngle": {"half_angle_rad": radians(float(half))}},
        max(tq.angular_samples, 8),
        [],
    )


def _source_spatial_model(
    emission: Any, refs: list[_PathRef], comp_id: str, where: str
) -> tuple[Any, float, list[Finding]]:
    """Spatial model + flux of one source, from the record's emission block.

    WP-166 removed the fallback that borrowed a referencing path's sequential
    EPD. An entrance pupil is *analysis configuration* — it says how finely to
    sample a declared path, not how wide the physical beam is — and letting it
    stand in for emission meant that deleting a path could change the beam a
    laser emits. A record with no ``optics.emission`` now gets the
    point/collimated default and says so (``W_EMISSION_DEFAULTED``).
    """
    if emission is not None:
        findings: list[Finding] = []
        if emission.angular.type not in ("collimated", "cone"):
            return None, 0.0, [Finding(
                "E_SIM_UNSUPPORTED", "error", f"{where}.optics.emission.angular",
                f"unsupported angular type {emission.angular.type!r} "
                "(collimated | cone)")]
        kind = emission.spatial.type
        if kind == "point":
            return "Point", float(emission.flux), findings
        if kind == "disc":
            radius = emission.spatial.radius_mm
            if is_template(radius):
                return None, 0.0, [Finding(
                    "E_TEMPLATED", "error", f"{where}.optics.emission.spatial.radius_mm",
                    f"unresolved templated value {radius!r}")]
            if (not isinstance(radius, (int, float)) or isinstance(radius, bool)
                    or not np.isfinite(radius) or radius <= 0):
                return None, 0.0, [Finding(
                    "E_SIM_UNSUPPORTED", "error", f"{where}.optics.emission.spatial.radius_mm",
                    f"disc emission needs a positive finite radius_mm, got {radius!r}")]
            return {"Disc": {"radius_mm": float(radius)}}, float(emission.flux), findings
        return None, 0.0, [Finding(
            "E_SIM_UNSUPPORTED", "error", f"{where}.optics.emission.spatial",
            f"unsupported spatial type {kind!r} (point/disc in v0)")]

    _ = (refs, comp_id)
    return "Point", 1.0, [Finding(
        "W_EMISSION_DEFAULTED", "warning", where,
        "source has no optics.emission block; point/collimated default applied "
        "— declare optics.emission to state the physical beam")]


def _record_source_lines(comp: Any) -> list[float]:
    """The WP-47 ``source:`` line list of a design component. In a design the
    block is ``extra="allow"`` (the typed ``SourceSpec`` lives on the library
    record), so it may arrive as a dict — same tolerant read as chain
    inference's ``_source_wavelength``."""
    source = getattr(comp, "source", None)
    lines = (
        source.get("wavelengths_um") if isinstance(source, dict)
        else getattr(source, "wavelengths_um", None)
    )
    out: list[float] = []
    for lam in lines or []:
        if isinstance(lam, int | float) and not isinstance(lam, bool) and lam > 0:
            out.append(float(lam))
    return out


def _source_spectrum(
    emission: Any, comp: Any, refs: list[_PathRef], where: str
) -> tuple[list[tuple[float, float]], list[Finding]]:
    """Spectrum of one source: record emission lines, else the placement's
    picked line (``CompSpec.wavelength_um``), else the WP-47 ``source:`` line
    list, else the union of the referencing paths' authored wavelength lists,
    else 0.55 µm with a warning."""
    if emission is not None and emission.spectrum:
        return [(float(line.wavelength_um), float(line.weight))
                for line in emission.spectrum], []
    if comp is not None:
        lam = comp.wavelength_um
        if isinstance(lam, int | float) and not isinstance(lam, bool) and lam > 0:
            return [(float(lam), 1.0)], []
        record_lines = _record_source_lines(comp)
        if record_lines:
            return [(lam, 1.0) for lam in record_lines], []
    seen: dict[float, float] = {}
    for ref in refs:
        for lam, wt in _authored_lines(ref.simulation):
            seen.setdefault(lam, wt)
    if seen:
        return [(lam, seen[lam]) for lam in sorted(seen)], []
    return [(_PLACEHOLDER_LAMBDA_UM, 1.0)], [Finding(
        "W_WAVELENGTH_DEFAULTED", "warning", where,
        "no emission spectrum declared and no referencing path supplies one; "
        "0.55 um used")]


def _detectors(
    decl: DesignDecl,
    poses: dict[str, FlatPose],
    refs: list[_PathRef],
    ids: _IdAlloc,
) -> tuple[list[dict[str, Any]], dict[tuple[str, str], int], list[Finding]]:
    """§9.6: one ``Detector3`` per (detector component, sensor port) — however
    many paths end there, including none (decision 6.13).

    Path-free discovery, the mirror of :func:`_sources` (WP-166): a port
    declaring ``roles: [sensor]``, or — with ``W_ROLE_INFERRED`` — a legacy
    ``category: detector`` record.
    """
    findings: list[Finding] = []
    keys: set[tuple[str, str]] = set(_ports_with_role(decl, "sensor"))
    legacy, legacy_findings = _inferred_terminals(
        decl, "detector", "sensor", "sensor", {c for c, _p in keys})
    findings += legacy_findings
    keys.update(legacy)
    _ = refs  # detectors are found physically; paths only reference them

    detectors: list[dict[str, Any]] = []
    detector_ids: dict[tuple[str, str], int] = {}
    for comp_id, port in sorted(keys):
        where = f"components.{comp_id}"
        pose = _port_pose(decl, poses, comp_id, port or None)
        if pose is None:
            findings.append(Finding("E_SIM_UNSUPPORTED", "error", where,
                                    f"detector port {comp_id}.{port} does not resolve"))
            continue
        world_pos, world_dir = pose
        half_w, half_h, size_findings = _detector_size(decl.components.get(comp_id), where)
        findings += size_findings
        detector = {
            "common": _common(ids.take(), facing_quat_xyzw(world_dir),
                              [float(v) for v in world_pos]),
            "geometry": {"Rectangle": {"half_width_mm": half_w, "half_height_mm": half_h}},
            "bins": [64, 64],
            "response": "Unity",
            "termination": "Terminate",
        }
        detectors.append(detector)
        detector_ids[(comp_id, port)] = detector["common"]["id"]
    return detectors, detector_ids, findings


def _detector_size(comp: Any, where: str) -> tuple[float, float, list[Finding]]:
    """Sensor half-extents: declared size, else template envelope, else default."""
    if comp is not None and comp.template is not None:
        env = comp.template.envelope
        x, y = env.x_mm, env.y_mm
        if isinstance(x, (int, float)) and isinstance(y, (int, float)) and x > 0 and y > 0:
            return float(x) / 2.0, float(y) / 2.0, []
    return 5.0, 5.0, [Finding("W_DETECTOR_UNSIZED", "warning", where,
                              "no sensor size; default 5 mm half-extents applied")]


def _path_stop(
    decl: DesignDecl, path: Any, manifest_components: dict[str, Any], path_name: str,
    stop_ids: set[int],
) -> tuple[int | None, list[Finding]]:
    """The nominal stop aperture of a path: the one on a chain component (§9.3).

    Only ``is_stop``-provenance apertures qualify; the implicit mounts every
    refractive run carries are physical clipping, never stop candidates.

    Catalog records author ``is_stop`` as the component's OWN internal stop
    (every AC254-style doublet carries one), so a relay of stock lenses used
    to trip E_STOP_MULTIPLE here and reject the whole scene. A system has one
    aperture stop: the first stop along the chain wins, the rest stay plain
    clipping apertures, and W_STOP_DEMOTED names what was demoted.
    """
    seen: set[str] = set()
    stops: list[int] = []
    for entry in path.chain:
        comp_id = parse_chain_entry(entry)[0]
        if comp_id in seen:
            continue
        seen.add(comp_id)
        stops += [a for a in manifest_components.get(comp_id, {}).get("apertures", [])
                  if a in stop_ids]
    if len(stops) > 1:
        return stops[0], [Finding(
            "W_STOP_DEMOTED", "warning", f"paths.{path_name}",
            f"path traverses {len(stops)} stop apertures; kept the first "
            f"(object {stops[0]}), demoted {stops[1:]} to plain apertures — "
            "record-level is_stop marks the component's own stop, not the system's")]
    return (stops[0] if stops else None), []


def _traversal(chain: list[str], manifest_components: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for entry in chain:
        comp_id, port_in, port_out = parse_chain_entry(entry)
        objs = manifest_components.get(comp_id, {})
        out.append({
            "component": comp_id,
            "port": port_out or port_in or "",
            "objects": (objs.get("bodies", []) + objs.get("surfaces", [])
                        + objs.get("apertures", [])),
        })
    return out


def _dof_bindings(
    decl: DesignDecl, poses: dict[str, FlatPose], comp_id: str
) -> list[dict[str, Any]]:
    comp = decl.components[comp_id]
    out: list[dict[str, Any]] = []
    for dof in comp.dof:
        entry: dict[str, Any] = {"name": dof.name, "axis": dof.axis, "kind": dof.kind}
        if dof.range is not None and all(isinstance(v, (int, float)) for v in dof.range):
            entry["range"] = [float(dof.range[0]), float(dof.range[1])]
        if dof.pivot_frame and comp.optics and dof.pivot_frame in comp.optics.frames:
            f = comp.optics.frames[dof.pivot_frame]
            pose = poses[comp_id]
            r = np.asarray(pose.rotation, dtype=float)
            t = np.asarray(pose.position_mm, dtype=float)
            pivot_world = t + r @ np.array([float(f.x_mm), float(f.y_mm), float(f.z_mm)])
            entry["pivot_world"] = {"pos": [float(v) for v in pivot_world],
                                    "rot": matrix_to_quat_xyzw(r)}
        if dof.surface is not None:
            entry["surface"] = dof.surface
        out.append(entry)
    return out


def _authored_lines(simulation: dict[str, Any]) -> list[tuple[float, float]]:
    """A path's authored wavelength list (µm) — no placeholder; defaulting is
    the source's concern (`W_WAVELENGTH_DEFAULTED`, §9.5)."""
    block = simulation.get("wavelengths", {})
    entries = block.get("wavelengths", []) if isinstance(block, dict) else []
    return [(float(w["value"]), 1.0) for w in entries
            if isinstance(w, dict) and "value" in w]


def _wavelength_union(lines: list[tuple[float, float]]) -> list[list[float]]:
    seen: dict[float, float] = {}
    for lam, wt in lines:
        seen.setdefault(lam, wt)
    return [[lam, seen[lam]] for lam in sorted(seen)]


def _has_nonzero_field(fields: Any) -> bool:
    return any(n != 0.0 for n in _iter_field_numbers(fields))


def _iter_field_numbers(node: Any):
    if isinstance(node, bool):
        return
    if isinstance(node, (int, float)):
        yield float(node)
    elif isinstance(node, dict):
        for v in node.values():
            yield from _iter_field_numbers(v)
    elif isinstance(node, list):
        for v in node:
            yield from _iter_field_numbers(v)


def _common(obj_id: int, rot_xyzw: list[float], pos: list[float]) -> dict[str, Any]:
    return {
        "id": obj_id,
        "transform": {"rot_xyzw": rot_xyzw, "pos": pos},
        "layer": 0,
        "locked": False,
        "label": "",
        "visible": True,
    }


def _default_surface_props() -> dict[str, Any]:
    fresnel = {"DielectricFresnel": {"ar_residual": {"Constant": 1.0}}}
    return {"default": {"from_outside": fresnel, "from_inside": fresnel}, "overrides": []}


def _conic(vertex_x: float, c: float, k: float, ha: float) -> dict[str, Any]:
    return {"vertex": [vertex_x, 0.0], "axis": [1.0, 0.0], "c": c, "k": k, "half_ap": ha}


def _sag_ck(sag: SagModel) -> tuple[float, float]:
    return (0.0, 0.0) if sag.kind == "plane" else (sag.curvature_per_mm, sag.conic)


def _conic_sag(c: float, k: float, r: float) -> float:
    if c == 0.0:
        return 0.0
    rr = r * r
    disc = 1.0 - (1.0 + k) * c * c * rr
    if disc < 0.0:
        disc = 0.0
    return c * rr / (1.0 + sqrt(disc))
