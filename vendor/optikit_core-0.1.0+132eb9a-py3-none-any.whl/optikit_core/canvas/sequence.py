"""Trace-derived beam sequences: extract, then resolve to document identity.

The inversion of the compile lane's chain-walk (ADR 0002 in optiland-canvas):
instead of *predicting* which surfaces a path's beam meets, the kernel traces
the scene's axial ray and reports the chain it actually threads (the ``oc-seq3``
prescription). This module runs that extraction against a materialized scene
and translates the prescription's scene-object identities back into document
identities — ``(component, fragment surface index)`` — via the materializer's
:class:`~.materialize.SceneProvenance`.

The resolved sequence is engine-free: whoever traced (the oc-py wheel here, the
oc-wasm kernel in the browser) is irrelevant downstream. The folded emitter
(:mod:`..compile.folded`) consumes it without ever seeing a scene id.

The kernel binding (``optiland_canvas``) is an optional dependency: without it,
:func:`extract_prescription` raises :class:`SequenceUnavailable` with a stable
code instead of an ImportError mid-request.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .materialize import MaterializedScene, SceneProvenance


class SequenceUnavailable(Exception):
    """Typed sequence-extraction failure; ``code`` is stable API."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code


@dataclass(frozen=True)
class ResolvedHit:
    """One prescription hit, translated to document identity."""

    component: str
    #: Index into the component's ``optics.fragment.surfaces``.
    fragment_index: int
    #: "body" | "mirror" | "thin_lens" — the materialized object kind.
    kind: str
    #: "transmit" | "reflect" | "tir" | "thin_lens" — what the chain did here.
    action: str
    #: The interaction spawned more than one followed branch (splitter).
    split: bool
    n_before: float
    n_after: float
    #: World-space hit geometry (diagnostics; poses are re-derived from the
    #: document by the emitter, so a frozen sequence survives DOF changes).
    point: list[float]
    normal: list[float]
    arc_mm: float
    cum_arc_mm: float
    opl_mm: float


@dataclass(frozen=True)
class ResolvedSequence:
    """A prescription resolved against the document: the portable sequence."""

    path_name: str
    source: tuple[str, str]
    detector: tuple[str, str]
    lambda_um: float
    launch_point: list[float]
    launch_dir: list[float]
    hits: list[ResolvedHit]
    terminal_point: list[float]
    terminal_uv_mm: list[float]
    cum_arc_mm: float
    opl_mm: float
    notes: list[str]


def extract_prescription(mat: MaterializedScene, path_name: str) -> dict[str, Any]:
    """Run kernel sequence extraction for one materialized path.

    Raises :class:`SequenceUnavailable` with ``E_KERNEL_UNAVAILABLE`` when the
    ``optiland_canvas`` wheel is not installed, ``E_SEQ_NO_PATH`` when the
    materialized scene carries no intent for ``path_name``, and ``E_SEQ`` when
    the kernel refuses (never reached / ambiguous — the message carries the
    kernel's branch-fate diagnosis verbatim).
    """
    try:
        import optiland_canvas as oc
    except ImportError as exc:  # pragma: no cover - environment-dependent
        raise SequenceUnavailable(
            "E_KERNEL_UNAVAILABLE",
            "sequence extraction needs the optiland_canvas wheel (oc-py)",
        ) from exc
    if mat.provenance is None or path_name not in mat.provenance.intents:
        raise SequenceUnavailable(
            "E_SEQ_NO_PATH",
            f"materialized scene declares no intent for path {path_name!r} "
            f"(known: {sorted(mat.provenance.intents) if mat.provenance else []})",
        )
    try:
        return oc.scene3_sequence_for_intent(
            mat.scene, mat.provenance.intents[path_name]
        )
    except ValueError as exc:
        raise SequenceUnavailable("E_SEQ", str(exc)) from exc


def resolve_sequence(
    prescription: dict[str, Any],
    provenance: SceneProvenance,
    path_name: str,
) -> ResolvedSequence:
    """Translate a prescription's scene ids into document identity.

    Consecutive hits that resolve to the same ``(component, fragment_index)``
    collapse into one (a cemented interface is two coincident body caps in the
    scene but one authored surface); the collapse keeps the first hit's entry
    medium and the second's exit medium, and is reported in ``notes``.

    Raises :class:`SequenceUnavailable` (``E_SEQ_RESOLVE``) when a hit names an
    object or patch the provenance cannot place — a rim strike, a hit on an
    object the materializer did not emit. That is a diagnosis of the design,
    not a fallback point.
    """
    notes = [str(n) for n in prescription.get("notes", [])]
    hits: list[ResolvedHit] = []
    for h in prescription.get("hits", []):
        obj = provenance.objects.get(int(h["object"]))
        if obj is None:
            raise SequenceUnavailable(
                "E_SEQ_RESOLVE",
                f"hit on scene object {h['object']} which maps to no document "
                f"surface (patch {h['patch']}, at {h['point']})",
            )
        if obj.surface_index is not None:
            frag = obj.surface_index
        else:
            frag_maybe = obj.patches.get(int(h["patch"]))
            if frag_maybe is None:
                raise SequenceUnavailable(
                    "E_SEQ_RESOLVE",
                    f"axial ray strikes a non-optical patch of {obj.component!r} "
                    f"(object {h['object']}, patch {h['patch']}) — a rim/edge hit "
                    "is a mis-aimed beam, not a sequence",
                )
            frag = frag_maybe
        hit = ResolvedHit(
            component=obj.component,
            fragment_index=frag,
            kind=obj.kind,
            action=str(h["action"]),
            split=bool(h["split"]),
            n_before=float(h["n_before"]),
            n_after=float(h["n_after"]),
            point=[float(v) for v in h["point"]],
            normal=[float(v) for v in h["normal"]],
            arc_mm=float(h["arc_mm"]),
            cum_arc_mm=float(h["cum_arc_mm"]),
            opl_mm=float(h["opl_mm"]),
        )
        prev = hits[-1] if hits else None
        if (
            prev is not None
            and prev.component == hit.component
            and prev.fragment_index == hit.fragment_index
        ):
            # A cemented interface: coincident caps of two bodies, one authored
            # surface. Keep entry medium from the first crossing, exit medium
            # from the second.
            hits[-1] = ResolvedHit(
                **{
                    **prev.__dict__,
                    "n_after": hit.n_after,
                    "opl_mm": hit.opl_mm,
                }
            )
            notes.append(
                f"cemented interface at {hit.component!r} surface "
                f"[{hit.fragment_index}]: coincident scene caps collapsed"
            )
            continue
        hits.append(hit)

    src = provenance.sources.get(int(prescription["source"]))
    det = provenance.detectors.get(int(prescription["detector"]))
    if src is None or det is None:
        raise SequenceUnavailable(
            "E_SEQ_RESOLVE",
            f"prescription terminals (source {prescription['source']}, detector "
            f"{prescription['detector']}) are unknown to the provenance",
        )
    terminal = prescription["terminal"]
    launch = prescription["launch"]
    return ResolvedSequence(
        path_name=path_name,
        source=src,
        detector=det,
        lambda_um=float(launch["lambda_um"]),
        launch_point=[float(v) for v in launch["point"]],
        launch_dir=[float(v) for v in launch["dir"]],
        hits=hits,
        terminal_point=[float(v) for v in terminal["point"]],
        terminal_uv_mm=[float(v) for v in terminal["uv_mm"]],
        cum_arc_mm=float(terminal["cum_arc_mm"]),
        opl_mm=float(terminal["opl_mm"]),
        notes=notes,
    )


def sequence_for_path(mat: MaterializedScene, path_name: str) -> ResolvedSequence:
    """Extract + resolve in one step (the common server-side call)."""
    assert mat.provenance is not None
    return resolve_sequence(
        extract_prescription(mat, path_name), mat.provenance, path_name
    )
