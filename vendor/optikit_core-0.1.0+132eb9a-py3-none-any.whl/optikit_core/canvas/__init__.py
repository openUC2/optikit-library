"""Canvas integration: materialize optikit-core designs into Scene3 (.ocanvas v2).

This package is the tap point of SPEC-OPTIKIT-CORE-CANVAS-INTEGRATION. It reads
world poses (from ``flatten``) plus module-local Optiland fragments and emits the
``.ocanvas`` v2 documents the Canvas Rust kernel traces in the browser. Optiland
propagates no rays on this path.

Modules land in PR order: ``dialect`` (KIT-00, the sole fragment reader),
``materials`` (KIT-01), ``materialize`` (KIT-02+).
"""

from .dialect import (
    FRAGMENT_DIALECT,
    DialectFragment,
    DialectSurface,
    SagModel,
    parse_fragment,
)
from .materialize import MaterializedScene, materialize
from .materials import (
    GlassCatalogBuilder,
    ResolvedGlass,
    catalog_material,
    is_ambient,
    resolve_glass,
)

__all__ = [
    "FRAGMENT_DIALECT",
    "DialectFragment",
    "DialectSurface",
    "GlassCatalogBuilder",
    "MaterializedScene",
    "ResolvedGlass",
    "SagModel",
    "catalog_material",
    "is_ambient",
    "materialize",
    "parse_fragment",
    "resolve_glass",
]
