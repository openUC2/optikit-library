"""Path discovery: ask the tracer which beams exist, instead of being told.

WP-165 / part2r Phase A. This is the **single source of truth for what optical
paths a design has**. The authored ``paths:`` block becomes a lockfile it is
diffed against, never an input it reads.

The insight that keeps this cheap and leaves the Rust kernel untouched: the
kernel already answers "does light get from THIS source to THAT detector, and
how" (``oc.scene3_sequence``), and a materialized scene already knows every
source and detector it emitted (:class:`~.materialize.SceneProvenance`).
Discovery is the product of the two — one axial ray per pair,
``N_sources × N_detectors`` single-ray traces. A fluorescence scope is 2 × 2.
No kernel API was missing; enumeration simply had to live somewhere, and this
is where it lives.

**One extraction, two entry points.** :func:`~.sequence.extract_prescription`
and :func:`~.sequence.resolve_sequence` are the primitives; this module and
:func:`~.sequence.sequence_for_path` are both thin callers of them, differing
only in *how the terminals are chosen* — declared intent there, enumeration
here. Neither re-implements tracing or resolution, so the two cannot drift.

Where the answer is a diagnosis rather than a path, it is kept: a pair that
carries no light reports the kernel's own branch-fate list ("surface 0 → body 5
→ escaped"), which is the sentence that tells a user why their beam misses. An
empty discovery is not an error, it is a finding.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..schema.design import DesignDecl, parse_chain_entry
from .materialize import MaterializedScene
from .sequence import ResolvedSequence, SequenceUnavailable, resolve_sequence

#: Why a (source, detector) pair produced no sequence. Stable API, and the
#: distinctions carry weight: NO_LIGHT is a statement about the design,
#: AMBIGUOUS is a request for the author to disambiguate, DEGENERATE is a
#: broken source record, UNRESOLVED is the kernel hitting something the
#: materializer cannot name back.
REASON_NO_LIGHT = "NO_LIGHT"
REASON_AMBIGUOUS = "AMBIGUOUS"
REASON_DEGENERATE = "DEGENERATE_SOURCE"
REASON_UNRESOLVED = "UNRESOLVED"


@dataclass(frozen=True)
class DiscoveredPath:
    """One beam the tracer actually found, in document identity."""

    #: The authored path name when one declares these terminals, else
    #: synthesized from them. Inheriting the name is what lets a pinned
    #: sequence and a discovered one line up without a rename step.
    name: str
    source: tuple[str, str]
    detector: tuple[str, str]
    sequence: ResolvedSequence
    authored_as: str | None = None


@dataclass(frozen=True)
class RejectedPair:
    """A (source, detector) pair the tracer could not turn into a sequence."""

    source: tuple[str, str]
    detector: tuple[str, str]
    reason: str
    #: The kernel's verbatim diagnosis — branch fates, or the competing chains.
    #: Kept whole: "objective → dichroic → escaped" is the answer to "why does
    #: my beam miss", and paraphrasing it would throw that away.
    message: str


@dataclass
class Discovery:
    """Everything one discovery pass learned about a materialized scene."""

    found: list[DiscoveredPath] = field(default_factory=list)
    rejected: list[RejectedPair] = field(default_factory=list)
    #: Pairs traced, i.e. single-ray kernel calls made. Diagnostics/tests.
    pairs_traced: int = 0

    @property
    def names(self) -> list[str]:
        return [p.name for p in self.found]

    def by_name(self, name: str) -> DiscoveredPath | None:
        return next((p for p in self.found if p.name == name), None)


def band_hint(prescription: dict) -> str:
    """The traced wavelength as a short label, for disambiguating a name.

    Two beams between the same terminals at different wavelengths are the
    ordinary case a dichroic creates, so the band is the qualifier that most
    often separates them meaningfully.
    """
    lam = (prescription.get("launch") or {}).get("lambda_um")
    return f"{float(lam) * 1000:.0f}nm" if isinstance(lam, (int, float)) else ""


def _classify(message: str) -> str:
    """Map the kernel's ``SequenceError`` text onto a stable reason code.

    The binding raises a bare ``ValueError`` carrying Rust's ``Display`` output,
    so the message is the discriminator. Matched on the fixed lead-in each
    variant writes (``oc-trace/src/sequence3.rs``), never on the variable tail;
    anything unrecognized stays NO_LIGHT, because a pair that produced no
    sequence produced no sequence whatever the reason.
    """
    if "distinct chains" in message:
        return REASON_AMBIGUOUS
    if "cannot launch an axial ray" in message:
        return REASON_DEGENERATE
    return REASON_NO_LIGHT


def _authored_terminals(
    decl: DesignDecl,
) -> tuple[dict[tuple[str, str, str, str], str], dict[tuple[str, str], list[str]]]:
    """Authored path names, indexed twice: exactly, and by component pair.

    The exact index is ``(src comp, src port, det comp, det port) → name`` and
    is what a discovered beam matches on first. The loose index is
    ``(src comp, det comp) → [names]`` and is the fallback, because a chain's
    terminal entry may name a different port than the record's emitter port —
    the materializer already allows for that when it resolves a source id.

    The loose index is a **list**, not a single name. Keyed on components alone,
    two authored routes between the same pair (a splitter's two arms, a
    dual-output source) collapse onto one key, and a `setdefault` there silently
    discarded every route but the first — so one of them could never be matched
    and its discovered twin inherited the other's name.
    """
    exact: dict[tuple[str, str, str, str], str] = {}
    loose: dict[tuple[str, str], list[str]] = {}
    for name in sorted(decl.paths):
        chain = decl.paths[name].chain
        if len(chain) < 2:
            continue
        src, src_in, src_out = parse_chain_entry(chain[0])
        det, det_in, _ = parse_chain_entry(chain[-1])
        exact[(src, src_out or src_in or "", det, det_in or "")] = name
        loose.setdefault((src, det), []).append(name)
    return exact, loose


def _unique(name: str, taken: set[str], *qualifiers: str) -> str:
    """A name not already in `taken`, qualified rather than numbered.

    Tries the bare name, then appends each qualifier in turn — the source port,
    then the band — because "laser.out2-to-camera" tells a reader which beam
    they are looking at and "relay#2" does not. A numeric suffix is the last
    resort, and reaching it means two beams agreed on every qualifier.
    """
    if name not in taken:
        return name
    candidate = name
    for q in qualifiers:
        if not q:
            continue
        candidate = f"{candidate}·{q}"
        if candidate not in taken:
            return candidate
    n = 2
    while f"{candidate}#{n}" in taken:
        n += 1
    return f"{candidate}#{n}"


def discover(mat: MaterializedScene, decl: DesignDecl | None = None) -> Discovery:
    """Trace every (source, detector) pair; keep the ones that carry light.

    ``decl`` is optional and used only for naming: when an authored path
    declares the same terminal pair, the discovered path inherits its name.

    Raises :class:`SequenceUnavailable` (``E_KERNEL_UNAVAILABLE``) when the
    oc-py wheel is absent — the same failure the single-path extractor reports,
    since without a kernel there is nothing to discover.
    """
    try:
        import optiland_canvas as oc
    except ImportError as exc:  # pragma: no cover - environment-dependent
        raise SequenceUnavailable(
            "E_KERNEL_UNAVAILABLE",
            "path discovery needs the optiland_canvas wheel (uv sync --extra kernel)",
        ) from exc

    prov = mat.provenance
    if prov is None:
        raise SequenceUnavailable(
            "E_SEQ_NO_SCENE", "materialized scene carries no provenance to enumerate")

    exact, loose = _authored_terminals(decl) if decl is not None else ({}, {})
    claimed: dict[str, str] = {}   # authored name → the beam that took it
    used: set[str] = set()         # every name handed out, for uniqueness
    result = Discovery()

    # Sorted on both axes, so the output order is a property of the scene
    # rather than of dict iteration — the determinism rule the materializer
    # already follows, extended to the thing built on top of it.
    for src_id, src in sorted(prov.sources.items()):
        for det_id, det in sorted(prov.detectors.items()):
            result.pairs_traced += 1
            try:
                prescription = oc.scene3_sequence(mat.scene, src_id, det_id)
            except ValueError as exc:
                result.rejected.append(RejectedPair(
                    source=src, detector=det,
                    reason=_classify(str(exc)), message=str(exc)))
                continue

            # Match the authored path exactly where the ports agree, and fall
            # back to the component pair — taking each loose candidate at most
            # once, so two beams between the same pair cannot both claim it.
            authored_as = exact.get((src[0], src[1], det[0], det[1]))
            if authored_as is None:
                for candidate in loose.get((src[0], det[0]), []):
                    if candidate not in claimed:
                        authored_as = candidate
                        break
            name = _unique(
                authored_as or f"{src[0]}-to-{det[0]}", used,
                f"{src[1]}" if src[1] else "", band_hint(prescription),
            )
            used.add(name)
            if authored_as is not None:
                claimed.setdefault(authored_as, name)
            try:
                sequence = resolve_sequence(prescription, prov, name)
            except SequenceUnavailable as exc:
                # The ray reached the detector but struck something the
                # materializer cannot name back — a lens rim, a mount annulus.
                # That is a diagnosis of the design (the beam is clipping), so
                # it is reported rather than dropped.
                result.rejected.append(RejectedPair(
                    source=src, detector=det,
                    reason=REASON_UNRESOLVED, message=str(exc)))
                continue
            result.found.append(DiscoveredPath(
                name=name, source=src, detector=det,
                sequence=sequence, authored_as=authored_as))

    return result


# ---------------------------------------------------------------------------
# Diffing discovery against the authored lockfile (part2r §0.6)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ChangedPath:
    """A path whose traced traversal differs from what was declared."""

    name: str
    declared: list[str]
    traced: list[str]
    #: Declared hops the scene holds no optical object for — a passthrough or
    #: fragment-less component. Reported, never counted as disagreement: a beam
    #: cannot hit what was never emitted, so this names a record that still
    #: owes a fragment or a response block rather than a real divergence.
    unmodelled: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class PathDiff:
    """How the traced set compares to the authored ``paths:`` block.

    The direction of travel (part2r §0.6): the stored chain stays — as a
    lockfile for regressions, stable table rows and CI snapshots — but nobody
    types one. This comparison is what turns it from an input into a lockfile.
    """

    #: Traced and authored, agreeing on every hop the scene models.
    confirmed: list[str] = field(default_factory=list)
    #: Traced and authored, but the light meets different components.
    changed: list[ChangedPath] = field(default_factory=list)
    #: Traced, never authored — the tracer found a beam nobody declared.
    unauthored: list[str] = field(default_factory=list)
    #: Authored, never traced — a declared beam that does not exist.
    missing: list[str] = field(default_factory=list)
    #: Confirmed, but only after excusing hops the scene does not model. The
    #: honest middle state: nothing contradicts the netlist, and part of it was
    #: unverifiable. Does not count against `clean`; counted loudly here.
    unverified_hops: dict[str, list[str]] = field(default_factory=dict)

    @property
    def clean(self) -> bool:
        return not (self.changed or self.unauthored or self.missing)


def _unmodelled(decl: DesignDecl, comp_id: str) -> bool:
    """Does this component contribute no optical object to the scene?

    Mirrors the materializer's own skip conditions (§9.1: a passthrough or
    fragment-less component appears only in the manifest), so the diff excuses
    exactly the hops the scene could not have produced — no more.
    """
    comp = decl.components.get(comp_id)
    if comp is None or comp.optics is None:
        return True
    return bool(comp.optics.passthrough) or comp.optics.fragment is None


def diff_authored(discovery: Discovery, decl: DesignDecl) -> PathDiff:
    """Compare a discovery pass against the design's declared paths.

    Compares the ORDERED COMPONENT sequence — not ports and not surface
    indices. Ports are vocabulary (part2r §0.4) and surface indices renumber on
    any prescription edit, so neither is a stable thing to diff on.
    """
    diff = PathDiff()
    traced_names = {p.name for p in discovery.found}

    for path in discovery.found:
        if path.authored_as is None:
            diff.unauthored.append(path.name)
            continue
        chain = decl.paths[path.authored_as].chain
        # The chain's interior is what the beam should meet; its terminals are
        # the source and detector, which by construction already agree.
        declared = [_component_of(entry) for entry in chain[1:-1]]
        traced = _dedupe([hit.component for hit in path.sequence.hits])
        unmodelled = [c for c in declared if _unmodelled(decl, c)]
        verifiable = [c for c in declared if c not in unmodelled]
        if verifiable == traced:
            diff.confirmed.append(path.name)
            if unmodelled:
                diff.unverified_hops[path.name] = unmodelled
        else:
            diff.changed.append(ChangedPath(
                name=path.name, declared=declared, traced=traced,
                unmodelled=unmodelled))

    diff.missing.extend(sorted(set(decl.paths) - traced_names))
    return diff


def _component_of(chain_entry: str) -> str:
    comp, _, _ = parse_chain_entry(chain_entry)
    return comp


def _dedupe(components: list[str]) -> list[str]:
    """Collapse consecutive hits on one component into a single entry.

    A singlet is two body caps and one authored chain hop; an achromat is
    three. part2r §0.4 calls this the port collapse and wants it driven by
    ``after-surface``; until that field is populated the component boundary is
    the honest approximation, and it is exact for every record whose surfaces
    are contiguous — which is all of them today.
    """
    out: list[str] = []
    for comp in components:
        if not out or out[-1] != comp:
            out.append(comp)
    return out
