"""Photon budget (WP-74): how much light actually reaches the sensor.

The direct analogue of the WP-50 live BOM — where the BOM answers "what does
this cost", the photon budget answers "how much of the source power survives
the optical path to the detector". It walks a declared path and multiplies the
per-surface surviving fraction (a dichroic in-band passes 1.0, a 50:50
beamsplitter arm passes 0.5, a filter out of band passes 0.0), starting from
the source's declared ``power_mw``.

It is deliberately first-order: coating efficiencies and absorption are not
modeled (a surviving surface passes its full power unless it carries a
``transmit_ratio``). That is enough to answer the question every microscope
builder asks and no configurator has answered — and to flag a filter stack that
passes no light at all (``W_FILTER_STACK``, in ``checks.py``).
"""

from __future__ import annotations

from typing import Any

from .schema.design import CompSpec, DesignDecl
from .schema.merge import instantiate
from .schema.response import response_of_surface, transmitted_fraction


def _path_wavelength_um(path: Any) -> float | None:
    """The path's primary simulation line in µm, if declared."""
    sim = getattr(path, "simulation", None) or {}
    lines = ((sim.get("wavelengths") or {}).get("wavelengths")) or []
    primary = next((w for w in lines if w.get("is_primary")), lines[0] if lines else None)
    return float(primary["value"]) if primary and "value" in primary else None


def _source_power_mw(comp: CompSpec) -> float | None:
    source = getattr(comp, "source", None)
    p = source.get("power_mw") if isinstance(source, dict) else getattr(source, "power_mw", None)
    return float(p) if isinstance(p, int | float) else None


def _traversal_fraction(
    comp: CompSpec, exit_name: str, wl_um: float | None
) -> tuple[float, str | None]:
    """Surviving fraction through one ``entry>exit`` traversal, + the response
    kind that governed it (for reporting)."""
    if not comp.optics or not comp.optics.fragment:
        return 1.0, None
    port = comp.optics.ports.get(exit_name)
    if port is None or port.after_surface is None:
        return 1.0, None
    surfaces = comp.optics.fragment.surfaces
    if not 0 <= port.after_surface < len(surfaces):
        return 1.0, None
    response = response_of_surface(surfaces[port.after_surface])
    frac = transmitted_fraction(response, exit_name, wl_um)
    return frac, (response.kind if response else None)


def photon_budget(decl: DesignDecl, path_name: str) -> dict[str, Any]:
    """Fraction (and mW, if the source declares power) reaching the path's end.

    Raises ``KeyError`` for an unknown path. Each element in ``per_element``
    is one traversal with the fraction it passed and the response kind that
    governed it.
    """
    path = decl.paths[path_name]
    components = instantiate(decl)
    wl_um = _path_wavelength_um(path)

    fraction = 1.0
    per_element: list[dict[str, Any]] = []
    source_power: float | None = None
    for entry in path.chain:
        comp_id = entry.split(".", 1)[0]
        comp = components.get(comp_id)
        if comp is None:
            continue
        if source_power is None:
            source_power = _source_power_mw(comp)
        if ">" not in entry:
            continue  # a terminal stop (source exit / detector entry)
        exit_name = entry.split(">", 1)[1]
        frac, kind = _traversal_fraction(comp, exit_name, wl_um)
        fraction *= frac
        per_element.append(
            {"element": comp_id, "exit": exit_name, "kind": kind, "fraction": round(frac, 4)}
        )

    return {
        "path": path_name,
        "wavelength_um": wl_um,
        "source_power_mw": source_power,
        "transmitted_fraction": round(fraction, 6),
        "power_mw": round(source_power * fraction, 6) if source_power is not None else None,
        "per_element": per_element,
    }
