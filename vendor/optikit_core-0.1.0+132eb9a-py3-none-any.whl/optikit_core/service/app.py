"""HTTP service: the optikit-core engine for the React editor (WP-6).

Stateless: every request carries the .dsn directory as a JSON file tree
``{"files": {"optikit-design.yml": "<yaml>"}}``; nothing is stored server-side.
Typed engine errors surface as HTTP 422 ``{code, message, context}``.

Simulation/optimization endpoints run Optiland in-process and answer 501 when
the ``sim`` extra (``pip install optikit-core[sim]``) is not installed. Ray
polylines are returned in WORLD coordinates, re-folded through the compile
manifest's per-surface fold maps, so the frontend can overlay them in 3D.
"""

from __future__ import annotations

import json
import math
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any, Literal

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field, ValidationError

from .. import __version__
from ..annotate import AnnotateError, apply_to_document, back_annotate
from ..chain import ChainError, infer_paths
from ..compile import CompileError, CompileResult, compile_path
from ..geometry import FlattenError, cubify, flat_report
from ..io.yamlio import dump_document, load_document_text, load_document_text_fast
from ..schema import DESIGN_DECL_FILE, DesignDecl, check
from ..schema.merge import instantiate

SCHEMA_DIST = __import__("pathlib").Path(__file__).resolve().parents[3] / "schema" / "dist"

#: Where the record library this service serves and writes actually lives.
#:
#: R1 of DOCS/LIBRARY-REGISTRY.md. This used to be hardcoded as the `library/`
#: next to the service's own source, which quietly made "the library" and "this
#: repo" the same thing — so moving the library out meant moving the service
#: with it. Point `OPTIKIT_LIBRARY_ROOT` at a checkout of the library repo (or
#: a mounted volume) and `/v1/library/index`, `/v1/library/assets/**` and
#: `/v1/library/save` all follow it, with no other change.
#:
#: Read per call rather than captured at import: a test (and an operator
#: restarting under a new mount) can change it without reimporting the module,
#: and the cost is one `os.environ` lookup on endpoints that already touch
#: the filesystem.
LIBRARY_ROOT_ENV = "OPTIKIT_LIBRARY_ROOT"


def library_root_path() -> Path:
    """The record library root, honouring :data:`LIBRARY_ROOT_ENV`.

    Falls back to the `library/` beside this source tree, which is what a dev
    checkout wants and what every deployment did before R1.
    """
    configured = os.environ.get(LIBRARY_ROOT_ENV)
    if configured:
        return Path(configured).expanduser().resolve()
    return (SCHEMA_DIST.parents[1] / "library").resolve()


class FiniteJSONResponse(JSONResponse):
    """JSON with non-finite floats made strict-JSON safe: ±inf → ±1e999 (which
    JSON.parse overflows back to ±Infinity), NaN → null."""

    def render(self, content: Any) -> bytes:
        text = json.dumps(content, allow_nan=True, separators=(",", ":"))
        text = text.replace("Infinity", "1e999").replace("NaN", "null")
        return text.encode("utf-8")


def _normalize_optic(optic: dict[str, Any]) -> dict[str, Any]:
    """Undo JavaScript's lossy Infinity handling on incoming optic dicts.

    ``JSON.stringify(Infinity)`` is ``null``, so a browser sending back an
    optimized optic delivers flat radii as null (and huge overflow floats for
    1e999-encoded values). Restore them to ±inf so diffs against the compiled
    baseline stay meaningful.
    """
    for surface in (optic.get("surface_group") or {}).get("surfaces") or []:
        geometry = surface.get("geometry")
        if not isinstance(geometry, dict):
            continue
        radius = geometry.get("radius")
        if radius is None:
            geometry["radius"] = math.inf
        elif isinstance(radius, int | float) and abs(radius) >= 1e308:
            geometry["radius"] = math.copysign(math.inf, radius)
    return optic


# --- request models ---------------------------------------------------------------------


class DesignBody(BaseModel):
    files: dict[str, str]


class PathBody(DesignBody):
    path: str | None = None


class TraceQualityBody(BaseModel):
    """Numerical sampling override for /v1/scene3 (§9.5) — rendering policy,
    never part of the physical emission model."""

    spatial_samples: int = 64
    angular_samples: int = 1
    seed: int = 0
    #: Kernel sampling sequence (§6.10): Grid = centered strata, Stratified =
    #: jittered strata (seeded), Sobol = low-discrepancy van der Corput.
    sequence: Literal["Grid", "Stratified", "Sobol"] = "Grid"


class Scene3Body(PathBody):
    trace_quality: TraceQualityBody | None = None


class SimulateBody(DesignBody):
    path: str
    actions: list[str] = Field(default_factory=lambda: ["trace", "paraxial"])
    # Hexapolar counts RINGS: 6 rings ≈ 127 rays — sane overlay payloads.
    num_rays: int = 6
    distribution: str = "hexapolar"


class SequenceBody(DesignBody):
    """WP-165 producer: trace-derived sequences.

    ``path`` names one declared path and answers for it alone. **Omit it** and
    the endpoint *discovers* instead: every (source, detector) pair the scene
    holds is traced, the pairs that carry light come back as paths, and the
    result is diffed against the authored ``paths:`` block. Discovery needs no
    declared chain — that is the point of it (part2r Phase A / §0.6).
    """

    path: str = ""
    #: "optic" adds the folded Optiland projection (emit_folded).
    actions: list[str] = Field(default_factory=list)
    trace_quality: TraceQualityBody | None = None
    #: A previously blessed pin (A1c). Discovery mode always returns the pin
    #: for what it just traced; supply the stored one and the response also
    #: carries ``pin_diff`` — held / drifted / appeared / vanished, keyed
    #: ``(variant, path, band)``. Absent = a first trace, which auto-accepts.
    pin: dict[str, Any] | None = None


class ExportStepBody(DesignBody):
    """WP-57: how the beam should appear in the exported CAD assembly."""

    beam: str = "solid"  # solid | wires | off
    beam_radius_mm: float = Field(default=0.5, alias="beam-radius-mm")


class ExportStepPartBody(DesignBody):
    """WP-84: which design component to export, posed w.r.t. its cube frame."""

    component: str


class OptimizeBody(DesignBody):
    path: str
    dofs: list[str] | None = None  # default: every ranged DOF
    num_rays: int = 12
    max_iter: int = 40


class AnnotateBody(DesignBody):
    path: str
    optimized: dict[str, Any]
    apply: bool = False
    optimized_by: str = "optiland"


class CalibrateBody(DesignBody):
    """WP-86: measured axis positions from a RUNNING instrument.

    ``measurements`` maps ``"<component>.<dof>"`` → the absolute measured
    position in the DOF's unit (mm / degrees) — what a motor controller
    reports over the WP-26 UC2-REST link.
    """

    measurements: dict[str, float]
    apply: bool = False
    instrument: str = ""
    note: str = ""


class StepBody(BaseModel):
    """A STEP file for conversion, base64-encoded (no multipart dependency)."""

    filename: str = "part.step"
    data_b64: str


class SeedPoseBody(BaseModel):
    """A stored pose in the contract spelling (grid + offset-deg + offset-mm)."""

    grid: tuple[str, str] = ("+z", "+x")
    offset_deg: tuple[float, float, float] = (0.0, 0.0, 0.0)
    offset_mm: tuple[float, float, float] = (0.0, 0.0, 0.0)


class InventorSeedBody(BaseModel):
    """WP-156: the housed-device road's outbound Inventor leg — reference
    cube halves + the housing at its recorded pose + the PLN/AXIS optical
    datum, as one STEP inside a zip with the round-trip README."""

    name: str
    step_filename: str = "housing.step"
    step_b64: str
    mesh_pose: SeedPoseBody = SeedPoseBody()
    insert_pose: SeedPoseBody = SeedPoseBody()
    optic_position_mm: tuple[float, float, float] = (0.0, 0.0, 0.0)
    beam_dir: tuple[float, float, float] = (0.0, 0.0, 1.0)
    optic_frame: str = "optical"
    aperture_mm: float | None = None
    component_id: str = ""
    template_id: str = ""


class ImportZmxBody(BaseModel):
    """WP-82: a vendor .zmx prescription for review — nothing is written."""

    filename: str = "lens.zmx"
    data_b64: str
    mpn: str = ""
    namespace: str = "thorlabs"
    vendor_name: str = "Thorlabs"


class ImportGlbBody(BaseModel):
    """WP-82: a marker-stamped Inventor GLB for review — nothing is written."""

    filename: str = "cube.glb"
    data_b64: str
    namespace: str = "openuc2"


class ImportOptilandBody(BaseModel):
    """WP-87: a serialized Optiland system (``optic.to_dict()`` JSON) for review."""

    filename: str = "setup.json"
    data_b64: str
    namespace: str = "user"


class DrawBody(DesignBody):
    """WP-82: the compiled optic's 2D layout drawing (optiland's own viewer)."""

    path: str
    num_rays: int = 8


class GenerateBody(BaseModel):
    """A T3 generator run (WP-61): an existing generative template by id, or
    an ad-hoc boolean holder around a bare optical component. With ``files``
    + ``component`` the design component's placed pose folds into the params
    (the cavity lands where the optic actually sits)."""

    template_id: str | None = None
    component_id: str | None = None
    params: dict[str, Any] = Field(default_factory=dict)
    files: dict[str, str] | None = None
    component: str | None = None


class LibrarySaveBody(BaseModel):
    """Records to write into the repo library (developer mode, env-gated).

    ``records`` maps YAML text by record; optional binary assets (GLB/STEP)
    ride along base64-encoded, stored next to their record.
    """

    records: list[str]
    assets: dict[str, str] = Field(default_factory=dict)  # "<id>/<file>" → b64


class VerifyT1Body(BaseModel):
    """A PROPOSED record trio to verify (WP-113) — YAML texts, not published
    ids: the wizard has not written anything yet. The on-disk library is
    still loaded underneath so refs to already-published records resolve;
    proposed records shadow published ones of the same id."""

    records: list[str]
    #: The cube_module to verify; empty = the single module among ``records``.
    module_id: str = ""


# --- app ----------------------------------------------------------------------------------


#: Comma-separated allowed browser origins; "*" allows any (public read-only
#: deployments). Default covers local dev; LAN/Tailscale-served frontends set
#: e.g. OPTIKIT_CORS_ORIGINS=http://100.100.43.118:5173.
DEFAULT_CORS_ORIGINS = "*"


def _cors_origins() -> list[str]:

    raw = os.environ.get("OPTIKIT_CORS_ORIGINS", DEFAULT_CORS_ORIGINS)
    return [origin.strip() for origin in raw.split(",") if origin.strip()]


def create_app() -> FastAPI:
    app = FastAPI(
        title="optikit-core",
        version=__version__,
        default_response_class=FiniteJSONResponse,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins(),
        allow_methods=["*"],
        allow_headers=["*"],
    )

    def parse_design(body: DesignBody) -> DesignDecl:
        entry = body.files.get(DESIGN_DECL_FILE) or next(
            (v for k, v in body.files.items() if k.endswith("/" + DESIGN_DECL_FILE)), None
        )
        if entry is None:
            raise HTTPException(422, {"code": "E_STRUCTURE",
                                      "message": f"no {DESIGN_DECL_FILE} in files",
                                      "context": sorted(body.files)})
        try:
            # Fast plain-data load: the tree goes straight into Pydantic and is
            # discarded, so comment preservation buys nothing here — and this
            # parse is the largest single cost of the live /v1/scene3 loop.
            return DesignDecl.model_validate(load_document_text_fast(entry) or {})
        except ValidationError as exc:
            raise HTTPException(422, {
                "code": "E_STRUCTURE",
                "message": "design failed structural validation",
                "context": [
                    {"loc": ".".join(map(str, e["loc"])), "msg": e["msg"]}
                    for e in exc.errors()
                ],
            }) from exc

    def engine_422(exc: Exception) -> HTTPException:
        code = getattr(exc, "code", "E_INTERNAL")
        where = getattr(exc, "where", getattr(exc, "comp_id", ""))
        detail: dict[str, Any] = {"code": code, "message": str(exc), "context": where}
        escapes = getattr(exc, "escapes", None)
        if escapes:
            # WP-52: structured escape points so the editor can draw the
            # escaping ray and name where it left the system.
            detail["escapes"] = [
                {
                    "source": e.source,
                    "from_comp": e.from_comp,
                    "from_port": e.from_port,
                    "origin_mm": e.origin_mm,
                    "direction": e.direction,
                    "reason": e.reason,
                }
                for e in escapes
            ]
        return HTTPException(422, detail)

    # --- structural / geometric endpoints --------------------------------------------

    @app.post("/v1/validate")
    def validate(body: DesignBody) -> dict[str, Any]:
        decl = parse_design(body)
        findings = check(decl)
        return {
            "ok": not any(f.severity == "error" for f in findings),
            "findings": [
                {"code": f.code, "severity": f.severity, "where": f.where, "message": f.message}
                for f in findings
            ],
        }

    @app.post("/v1/flatten")
    def flatten_endpoint(body: DesignBody) -> dict[str, Any]:
        decl = parse_design(body)
        try:
            report = flat_report(instantiate(decl))
        except (FlattenError, KeyError) as exc:
            raise engine_422(exc) from exc
        return {"report": [e.dump() for e in report]}

    @app.post("/v1/cubify")
    def cubify_endpoint(body: DesignBody) -> dict[str, Any]:
        decl = parse_design(body)
        try:
            result = cubify(
                instantiate(decl),
                dof_values={
                    k: v for k, v in decl.instantiation.dof_values.items()
                    if isinstance(v, int | float)
                },
            )
        except FlattenError as exc:
            raise engine_422(exc) from exc
        return {
            "poses": {cid: pose.pose_dict() for cid, pose in result.poses.items()},
            "findings": [f.__dict__ for f in result.findings],
        }

    @app.post("/v1/drc")
    def drc_endpoint(body: DesignBody) -> dict[str, Any]:
        return {"findings": cubify_endpoint(body)["findings"]}

    @app.post("/v1/chain/infer")
    def chain_infer(body: DesignBody) -> dict[str, Any]:
        decl = parse_design(body)
        try:
            result = infer_paths(decl)
        except (ChainError, FlattenError, CompileError) as exc:
            raise engine_422(exc) from exc
        return {
            "paths": result.paths,
            "warnings": result.warnings,
            "escapes": [
                {
                    "source": e.source,
                    "from_comp": e.from_comp,
                    "from_port": e.from_port,
                    "origin_mm": e.origin_mm,
                    "direction": e.direction,
                    "reason": e.reason,
                }
                for e in result.escapes
            ],
        }

    @app.post("/v1/export/step")
    def export_step_endpoint(body: ExportStepBody) -> Response:
        """WP-57: the design as one grouped STEP assembly, streamed back.

        The file is built in a temp dir and returned as bytes — the service
        keeps no state, so nothing is left behind for the caller to clean up.
        """
        import tempfile

        from ..export import ExportError as _ExportError
        from ..export import export_step

        decl = parse_design(body)
        library_root = library_root_path()
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / f"{decl.design.name or 'design'}.step"
            try:
                export_step(
                    decl,
                    out,
                    library_root=library_root if library_root.is_dir() else None,
                    beam=body.beam,
                    beam_radius_mm=body.beam_radius_mm,
                )
            except (_ExportError, FlattenError) as exc:
                raise engine_422(exc) from exc
            payload = out.read_bytes()
        return Response(
            payload,
            media_type="model/step",
            headers={
                "Content-Disposition":
                    f'attachment; filename="{decl.design.name or "design"}.step"'
            },
        )

    @app.post("/v1/export/step/part")
    def export_step_part_endpoint(body: ExportStepPartBody) -> Response:
        """WP-84: ONE component as a STEP posed w.r.t. its CUBE frame — the
        Inventor round-trip's outbound leg ("design the module around it").

        The return leg needs no endpoint of its own: attaching the resulting
        Inventor STP/GLB back onto the SAME record is a plain
        ``/v1/library/save`` write into the existing template directory.
        """
        import tempfile

        from ..export import ExportError as _ExportError
        from ..export import export_step_part

        decl = parse_design(body)
        library_root = library_root_path()
        safe = body.component.replace("/", "_")
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / f"{safe}-in-cube.step"
            try:
                export_step_part(
                    decl,
                    body.component,
                    out,
                    library_root=library_root if library_root.is_dir() else None,
                )
            except (_ExportError, FlattenError) as exc:
                raise engine_422(exc) from exc
            payload = out.read_bytes()
        return Response(
            payload,
            media_type="model/step",
            headers={
                "Content-Disposition": f'attachment; filename="{safe}-in-cube.step"'
            },
        )

    @app.post("/v1/compile")
    def compile_endpoint(body: PathBody) -> dict[str, Any]:
        decl = parse_design(body)
        names = [body.path] if body.path else sorted(decl.paths)
        if not names:
            raise HTTPException(422, {"code": "E_BAD_PATH",
                                      "message": "design declares no paths", "context": ""})
        out: dict[str, Any] = {}
        for name in names:
            try:
                result = compile_path(decl, name)
            except (CompileError, FlattenError) as exc:
                raise engine_422(exc) from exc
            out[name] = {
                "optic": result.optic,
                "manifest": [m.dump() for m in result.manifest],
                "warnings": result.warnings,
            }
        # Return the Response directly: FastAPI's jsonable_encoder would null
        # the ±Infinity radii before FiniteJSONResponse could encode them.
        return FiniteJSONResponse({"paths": out})

    @app.post("/v1/scene3")
    def scene3_endpoint(body: Scene3Body) -> Response:
        decl = parse_design(body)   # parse the incoming model to the dsn specificiation
        if body.path:
            if body.path not in decl.paths:
                raise HTTPException(422, {"code": "E_BAD_PATH",
                                          "message": f"design declares no path {body.path!r}",
                                          "context": ""})
            decl.paths = {body.path: decl.paths[body.path]}
        from ..canvas import materialize

        # WP-169: chain inference used to run here for a design with no
        # `paths:`, to fabricate some. It no longer does, because everything it
        # was for is gone:
        #
        #  - Terminals no longer need a path to be FOUND (WP-166: ports declare
        #    `roles:`), so the scene is physically complete without it — every
        #    source emits and every detector receives.
        #  - The intents it produced have no consumer on this endpoint. The
        #    editor's kernel lane never reads `manifest.paths` or `scene.intent`
        #    (it loads the scene and traces), and the only reader,
        #    `scene3_sequence_for_intent`, is reached through `/v1/sequence`'s
        #    NAMED-path mode — which requires an authored path by definition.
        #  - Asking "which beams exist" is now `POST /v1/sequence` with no
        #    `path`, and that answers from the trace rather than from a
        #    geometric walk that could disagree with it.
        #
        # So a pathless design gets a complete scene and an empty `paths` map,
        # and the inference walk stops running on the endpoint the editor calls
        # on every settled edit. `/v1/chain/infer` still exposes it standalone
        # (part2r §0.3: the walk demotes to a pre-pass before it retires).
        findings: list[dict[str, Any]] = []
        tq = body.trace_quality.model_dump() if body.trace_quality else None
        result = materialize(decl, trace_quality=tq)
        # Decision 6.14: only *physical* materialization errors reject.
        errors = [f for f in result.findings if f.severity == "error"]
        if errors:
            f = errors[0]
            raise HTTPException(422, {"code": f.code, "message": f.message, "context": f.where})
        # The scene is finite by construction (agent rule 9), so the ±1e999
        # non-finite encoding never triggers; FiniteJSONResponse keeps the
        # response consistent with the other endpoints.
        return FiniteJSONResponse({
            "scene": result.scene,
            "manifest": result.manifest,
            "warnings": [str(w) for w in result.findings if w.severity == "warning"],
            "findings": findings,
        })

    @app.post("/v1/sequence")
    def sequence_endpoint(body: SequenceBody) -> Response:
        """WP-165, producer half: materialize, let the kernel trace, resolve the
        hits to document identity.

        Two modes, one extractor. **Named** ``path`` → that path's declared
        intent alone, plus the folded Optiland projection under
        ``actions=["optic"]`` (``emit_folded``, merged with PR #7). **No path**
        → discovery: every (source, detector) pair is traced and the ones
        carrying light come back as paths, diffed against the authored
        ``paths:`` block. Discovery reads no chain, which is what lets the
        editor stop asking a human to wire ports (part2r Phase A / §0.6).
        """
        decl = parse_design(body)
        if body.path and body.path not in decl.paths:
            raise HTTPException(422, {"code": "E_BAD_PATH",
                                      "message": f"design declares no path {body.path!r}",
                                      "context": ""})
        from ..canvas import materialize
        from ..canvas.sequence import SequenceUnavailable, sequence_for_path

        tq = body.trace_quality.model_dump() if body.trace_quality else None
        result = materialize(decl, trace_quality=tq)
        errors = [f for f in result.findings if f.severity == "error"]
        if errors:
            f = errors[0]
            raise HTTPException(422, {"code": f.code, "message": f.message, "context": f.where})

        if not body.path:
            from ..canvas.discover import diff_authored, discover

            try:
                found = discover(result, decl)
            except SequenceUnavailable as exc:
                status = 501 if exc.code == "E_KERNEL_UNAVAILABLE" else 422
                raise HTTPException(status, {"code": exc.code, "message": str(exc),
                                             "context": ""}) from exc
            from ..canvas.pin import SequencePin, diff_pin, pin_from

            out: dict[str, Any] = {
                "paths": {p.name: asdict(p.sequence) for p in found.found},
                "terminals": {p.name: {"source": list(p.source),
                                       "detector": list(p.detector),
                                       "authored_as": p.authored_as}
                              for p in found.found},
                "rejected": [asdict(r) for r in found.rejected],
                "diff": asdict(diff_authored(found, decl)),
                "pairs_traced": found.pairs_traced,
                # A1c: always returned, so a FIRST trace auto-accepts the whole
                # set simply by the client storing what came back (§0.2).
                "pin": pin_from(found, decl).to_dict(),
            }
            if body.pin is not None:
                try:
                    stored = SequencePin.from_dict(body.pin)
                except (ValueError, KeyError, TypeError) as exc:
                    raise HTTPException(422, {
                        "code": "E_PIN_MALFORMED", "message": str(exc),
                        "context": "pin"}) from exc
                drift = diff_pin(stored, found, decl)
                out["pin_diff"] = {
                    "held": [str(k) for k in drift.held],
                    "drifted": [{"key": str(d.key), "summary": d.summary(),
                                 "pinned": asdict(d.pinned),
                                 "traced": asdict(d.traced)}
                                for d in drift.drifted],
                    "appeared": [str(k) for k in drift.appeared],
                    "vanished": [str(k) for k in drift.vanished],
                    "held_fast": drift.held_fast,
                }
            return FiniteJSONResponse(out)

        try:
            seq = sequence_for_path(result, body.path)
        except SequenceUnavailable as exc:
            status = 501 if exc.code == "E_KERNEL_UNAVAILABLE" else 422
            raise HTTPException(status, {"code": exc.code, "message": str(exc),
                                         "context": body.path}) from exc
        out: dict[str, Any] = {"path": body.path, "sequence": asdict(seq)}
        if "optic" in body.actions:
            from ..compile.folded import emit_folded

            try:
                folded = emit_folded(decl, seq)
            except (CompileError, FlattenError) as exc:
                raise engine_422(exc) from exc
            out["optic"] = folded.optic
            out["manifest"] = [m.dump() for m in folded.manifest]
            out["notes"] = [
                *folded.notes,
                "optic is emitted untraced: tracing it rides the upstream optiland "
                "paraxial entry fix. This response carries geometry, not ray results.",
            ]
        return FiniteJSONResponse(out)

    @app.post("/v1/back-annotate")
    def back_annotate_endpoint(body: AnnotateBody) -> dict[str, Any]:
        decl = parse_design(body)
        try:
            result = back_annotate(decl, body.path, _normalize_optic(body.optimized))
        except (AnnotateError, CompileError, FlattenError) as exc:
            raise engine_422(exc) from exc
        response: dict[str, Any] = {
            "deltas": [d.__dict__ for d in result.deltas],
            "findings": [f.__dict__ for f in result.findings],
            "dof_updates": result.dof_updates,
            "updated_design": None,
        }
        if body.apply and result.dof_updates:
            import datetime

            entry_name = DESIGN_DECL_FILE if DESIGN_DECL_FILE in body.files else next(
                k for k in body.files if k.endswith("/" + DESIGN_DECL_FILE)
            )
            doc = load_document_text(body.files[entry_name])
            apply_to_document(
                doc, result,
                optimized_by=body.optimized_by,
                run=datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds"),
                merit={},
            )
            response["updated_design"] = dump_document(doc)
        return FiniteJSONResponse(response)

    @app.post("/v1/calibrate")
    def calibrate_endpoint(body: CalibrateBody) -> dict[str, Any]:
        """WP-86: measured instrument axes → classified dof_value updates.

        The hardware leg of the round trip, through the SAME reviewed table
        the optimizer leg uses. Applying stamps ``provenance.source:
        instrument`` so a calibrated design is distinguishable from an
        optimized one; needs no optiland (nothing is traced — the
        instrument already measured it).
        """
        from ..annotate import apply_calibration_to_document, calibrate_from_instrument

        decl = parse_design(body)
        try:
            result = calibrate_from_instrument(
                decl, body.measurements, instrument=body.instrument
            )
        except (AnnotateError, FlattenError) as exc:
            raise engine_422(exc) from exc
        response: dict[str, Any] = {
            "deltas": [d.__dict__ for d in result.deltas],
            "findings": [f.__dict__ for f in result.findings],
            "dof_updates": result.dof_updates,
            "updated_design": None,
        }
        if body.apply and result.dof_updates:
            import datetime

            entry_name = DESIGN_DECL_FILE if DESIGN_DECL_FILE in body.files else next(
                k for k in body.files if k.endswith("/" + DESIGN_DECL_FILE)
            )
            doc = load_document_text(body.files[entry_name])
            apply_calibration_to_document(
                doc, result,
                instrument=body.instrument,
                run=datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds"),
                note=body.note,
            )
            response["updated_design"] = dump_document(doc)
        return FiniteJSONResponse(response)

    # --- optiland-backed endpoints -----------------------------------------------------

    @app.post("/v1/simulate")
    def simulate(body: SimulateBody) -> dict[str, Any]:
        decl = parse_design(body)
        from optiland import optic as optic_mod
        try:
            compiled = compile_path(decl, body.path)
        except (CompileError, FlattenError) as exc:
            raise engine_422(exc) from exc
        # A path may compile to NOTHING but the object/image planes (every
        # chain component passthrough or terminal). Optiland's ray aimer then
        # dies on a zero-size array — answer with the diagnosis instead.
        if not any(e.fragment_surface_index is not None for e in compiled.manifest):
            raise HTTPException(422, {
                "code": "E_EMPTY_SYSTEM",
                "message": (
                    f"path '{body.path}' contains no optical surfaces — every chain "
                    "component compiled without a fragment (passthrough or terminal). "
                    "Give the components real `optics.fragment` surfaces, or place "
                    "library parts whose records carry a prescription."
                ),
                "context": body.path,
            }) # optic_mod is the imported library
        optic = _optic_from_dict_422(optic_mod, compiled.optic)
        out: dict[str, Any] = {"path": body.path, "warnings": compiled.warnings}
        wavelength = compiled.optic["wavelengths"]["wavelengths"][0]["value"]
        if "trace" in body.actions or "spot" in body.actions:
            optic.trace(
                Hx=0.0, Hy=0.0, wavelength=wavelength,
                num_rays=body.num_rays, distribution=body.distribution,
            )
        if "trace" in body.actions:
            out["rays_world"] = _world_polylines(optic, compiled)
        if "spot" in body.actions:
            sg = optic.surface_group
            out["spot"] = {
                "x": np.asarray(sg.x[-1]).ravel().tolist(),
                "y": np.asarray(sg.y[-1]).ravel().tolist(),
            }
        if "paraxial" in body.actions:
            out["paraxial"] = _paraxial(optic)
        # WP-74: how much light reaches the sensor — the BOM analogue. Best
        # effort: a path with no spectral data reports a fraction of 1.0.
        if "budget" in body.actions or "paraxial" in body.actions:
            import contextlib

            from ..budget import photon_budget

            with contextlib.suppress(KeyError, ValueError):
                out["photon_budget"] = photon_budget(decl, body.path)
        return FiniteJSONResponse(out)

    def _optic_from_dict_422(optic_mod, optic_dict: dict[str, Any]):  # noqa: ANN202
        """WP-63 hardening: an optic optiland's registry rejects is a typed
        422 naming the surface, never an ASGI traceback."""
        try:
            return optic_mod.Optic.from_dict(optic_dict)
        except (ValueError, KeyError, TypeError) as exc:
            surfaces = (optic_dict.get("surface_group") or {}).get("surfaces") or []
            offending = [
                f"surface {i} ({s.get('comment', '?')}): "
                f"material_post type {(s.get('material_post') or {}).get('type')!r}"
                for i, s in enumerate(surfaces)
                if isinstance(s.get("material_post"), dict)
                and (s["material_post"].get("type") or "")
                not in ("Material", "IdealMaterial", "AbbeMaterial", "MaterialFile")
            ]
            raise HTTPException(422, {
                "code": "E_OPTIC_INVALID",
                "message": f"optiland rejected the compiled optic: {exc}",
                "context": offending or [str(exc)],
            }) from exc

    @app.post("/v1/optimize")
    def optimize(body: OptimizeBody) -> dict[str, Any]:
        decl = parse_design(body)
        from optiland import optic as optic_mod
        keys, bounds = _free_dofs(decl, body.dofs)
        if not keys:
            raise HTTPException(422, {"code": "E_NO_DOF",
                                      "message": "no ranged DOFs to optimize",
                                      "context": body.dofs or []})

        def merit(values: np.ndarray) -> float:
            trial = decl.model_copy(deep=True)
            for key, value in zip(keys, values, strict=True):
                trial.instantiation.dof_values[key] = float(value)
            try:
                compiled = compile_path(trial, body.path)
                optic = optic_mod.Optic.from_dict(compiled.optic)
                wl = compiled.optic["wavelengths"]["wavelengths"][0]["value"]
                optic.trace(Hx=0.0, Hy=0.0, wavelength=wl, num_rays=body.num_rays)
                sg = optic.surface_group
                x = np.asarray(sg.x[-1]).ravel()
                y = np.asarray(sg.y[-1]).ravel()
                return float(np.sqrt(np.nanmean((x - np.nanmean(x)) ** 2 +
                                                (y - np.nanmean(y)) ** 2)))
            except Exception:  # noqa: BLE001 — infeasible trial point
                return 1e9

        from scipy import optimize as sopt

        x0 = np.array([
            float(decl.instantiation.dof_values.get(k, 0.0) or 0.0) for k in keys
        ])
        # WP-63: validate the BASELINE optic once, loudly — merit() swallows
        # per-trial failures (infeasible points), which would otherwise turn a
        # broken material into a silent all-1e9 "optimization".
        try:
            baseline = compile_path(decl, body.path)
        except (CompileError, FlattenError) as exc:
            raise engine_422(exc) from exc
        _optic_from_dict_422(optic_mod, baseline.optic)
        rms_before = merit(x0)
        res = sopt.minimize(
            merit, x0, method="Nelder-Mead", bounds=bounds,
            options={"maxiter": body.max_iter, "xatol": 1e-3, "fatol": 1e-9},
        )
        best = {k: float(v) for k, v in zip(keys, res.x, strict=True)}

        optimized_decl = decl.model_copy(deep=True)
        optimized_decl.instantiation.dof_values.update(best)
        compiled = compile_path(optimized_decl, body.path)
        annotate_result = back_annotate(decl, body.path, compiled.optic)

        # WP-35 T2: the Inventor-side changeset for the optimized dof values
        # (fx user-parameter name == dof name; groove-lattice decomposition
        # where the template declares grooves). Best-effort — no library tree
        # next to this service just omits the block.
        fx: dict[str, Any] | None = None
        library_root = library_root_path()
        if library_root.is_dir():
            try:
                from ..annotate.fx import fx_changeset
                from ..library.build import load_library

                fx = fx_changeset(optimized_decl, load_library(library_root))
            except Exception:  # noqa: BLE001 — advisory block only
                fx = None

        return FiniteJSONResponse({
            "dof_values": best,
            "merit": {"rms_spot_before_mm": rms_before, "rms_spot_after_mm": float(res.fun),
                      "iterations": int(res.nit)},
            "optic": compiled.optic,
            "deltas": [d.__dict__ for d in annotate_result.deltas],
            "findings": [f.__dict__ for f in annotate_result.findings],
            **({"fx": fx} if fx is not None else {}),
        })

    # --- mechanical conversion (WP-19 part-binding workbench) --------------------------

    @app.post("/v1/export/inventor-seed")
    def inventor_seed(body: InventorSeedBody) -> Response:
        """WP-156: the housed-device road's Inventor seed — see
        export/inventor_seed.py for what lands in the tree and why."""
        import base64
        import binascii

        from ..export.inventor_seed import SeedPose, build_inventor_seed
        from ..export.step_assembly import ExportError as _ExportError

        try:
            step_bytes = base64.b64decode(body.step_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"step_b64 is not valid base64: {exc}",
                                      "context": body.step_filename}) from exc
        safe = body.name.replace("/", "_") or "part"
        try:
            payload = build_inventor_seed(
                name=safe,
                housing_step=step_bytes,
                housing_filename=body.step_filename,
                mesh_pose=SeedPose(
                    grid=body.mesh_pose.grid,
                    offset_deg=body.mesh_pose.offset_deg,
                    offset_mm=body.mesh_pose.offset_mm,
                ),
                insert_pose=SeedPose(
                    grid=body.insert_pose.grid,
                    offset_deg=body.insert_pose.offset_deg,
                    offset_mm=body.insert_pose.offset_mm,
                ),
                optic_position_mm=body.optic_position_mm,
                beam_dir=body.beam_dir,
                optic_frame=body.optic_frame,
                aperture_mm=body.aperture_mm,
                component_id=body.component_id,
                template_id=body.template_id,
            )
        except _ExportError as exc:
            status = 501 if exc.code == "E_NO_CADQUERY" else 422
            raise HTTPException(
                status, {"code": exc.code, "message": str(exc), "context": body.name},
            ) from exc
        return Response(
            payload,
            media_type="application/zip",
            headers={
                "Content-Disposition": f'attachment; filename="{safe}-inventor-seed.zip"'
            },
        )

    @app.post("/v1/convert/step-to-glb")
    def step_to_glb(body: StepBody) -> Response:
        """STEP → GLB via the cadquery/OCP stack, mm units preserved.

        GLB is a render-only exchange format; the STEP stays the mechanical
        source of truth referenced by the record (ARCHITECTURE.md).
        """
        import base64
        import binascii
        import tempfile
        from pathlib import Path as _Path

        try:
            import cadquery as cq
        except ImportError as exc:
            raise HTTPException(
                501,
                {"code": "E_NO_CADQUERY",
                 "message": "install the generate extra: pip install optikit-core[generate]",
                 "context": str(exc)},
            ) from exc

        try:
            step_bytes = base64.b64decode(body.data_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"data_b64 is not valid base64: {exc}",
                                      "context": body.filename}) from exc
        with tempfile.TemporaryDirectory() as tmp:
            step_path = _Path(tmp) / "part.step"
            step_path.write_bytes(step_bytes)
            try:
                shape = cq.importers.importStep(str(step_path))
            except Exception as exc:  # noqa: BLE001 — OCC raises plain Exceptions
                raise HTTPException(422, {"code": "E_BAD_STEP",
                                          "message": f"cadquery could not read the STEP: {exc}",
                                          "context": body.filename}) from exc
            glb_path = _Path(tmp) / "part.glb"
            assembly = cq.Assembly(shape, name=_Path(body.filename).stem or "part")
            exporter = getattr(assembly, "export", None) or assembly.save  # save: cq<=2.8
            exporter(str(glb_path))
            return Response(glb_path.read_bytes(), media_type="model/gltf-binary")

    # --- importers for review (WP-82: CLI ↔ frontend parity) ---------------------------
    # The CLI importers auto-write into library/; these endpoints run the SAME
    # importers but return the PROPOSED records for review — the frontend's
    # drop-zone previews them and the user accepts through the ordinary
    # dev-write / zip exits. Nothing here touches the library tree.

    @app.post("/v1/import/zmx")
    def import_zmx(body: ImportZmxBody) -> dict[str, Any]:
        """A vendor .zmx prescription → the proposed component record."""
        import base64
        import binascii
        import tempfile
        from pathlib import Path as _Path

        try:
            import optiland  # noqa: F401

            from ..importers.thorlabs import ZmxImportError, zmx_to_component
        except ImportError as exc:
            raise HTTPException(
                501,
                {"code": "E_NO_OPTILAND",
                 "message": "install the sim extra: pip install optikit-core[sim]",
                 "context": str(exc)},
            ) from exc
        from ..io.yamlio import dump_document

        try:
            zmx_bytes = base64.b64decode(body.data_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"data_b64 is not valid base64: {exc}",
                                      "context": body.filename}) from exc
        with tempfile.TemporaryDirectory() as tmp:
            zmx_path = _Path(tmp) / (_Path(body.filename).name or "lens.zmx")
            zmx_path.write_bytes(zmx_bytes)
            try:
                result = zmx_to_component(
                    zmx_path, mpn=body.mpn,
                    namespace=body.namespace, vendor_name=body.vendor_name,
                )
            except ZmxImportError as exc:
                raise HTTPException(422, {"code": "E_BAD_ZMX",
                                          "message": str(exc),
                                          "context": body.filename}) from exc
        component_id = str(result.component["id"])
        return {
            "component": result.component,
            "review": result.review,
            "efl_mm": result.efl_mm,
            "mpn": result.mpn,
            # Ready for the two accept exits, in the library-PR layout.
            "records": {
                f"components/{component_id}/component.yml": dump_document(result.component),
            },
        }

    @app.post("/v1/import/optiland")
    def import_optiland(body: ImportOptilandBody) -> dict[str, Any]:
        """A whole Optiland setup → unbound components + a placement plan (WP-87)."""
        import base64
        import binascii
        from pathlib import Path as _Path

        from ..importers.optiland_setup import (
            OptilandSetupError,
            name_prefix_from_filename,
            setup_to_components,
        )

        try:
            setup_bytes = base64.b64decode(body.data_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"data_b64 is not valid base64: {exc}",
                                      "context": body.filename}) from exc
        try:
            optic_json = json.loads(setup_bytes.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_OPTILAND",
                                      "message": f"not a JSON document: {exc}",
                                      "context": body.filename}) from exc
        if isinstance(optic_json, dict):
            # A browser round-trip flattens ±Infinity radii — restore them.
            optic_json = _normalize_optic(optic_json)
        try:
            result = setup_to_components(
                optic_json,
                namespace=body.namespace,
                name_prefix=name_prefix_from_filename(_Path(body.filename).name),
            )
        except OptilandSetupError as exc:
            raise HTTPException(422, {"code": "E_BAD_OPTILAND",
                                      "message": str(exc),
                                      "context": body.filename}) from exc
        return {
            "components": result.components,
            "placements": result.placements,
            "review": result.review,
            # Ready for the two accept exits, in the library-PR layout.
            "records": result.records,
            "wavelengths_um": result.wavelengths_um,
        }

    @app.post("/v1/import/glb")
    def import_glb(body: ImportGlbBody) -> dict[str, Any]:
        """A marker-stamped Inventor GLB → the proposed record trio."""
        import base64
        import binascii
        import tempfile
        from pathlib import Path as _Path

        try:
            import pygltflib  # noqa: F401

            from ..importers import import_glb_file
        except ImportError as exc:
            raise HTTPException(
                501,
                {"code": "E_NO_PYGLTFLIB",
                 "message": "install the importers extra: pip install optikit-core[importers]",
                 "context": str(exc)},
            ) from exc
        from ..importers.glb2template import bbox_thumbnail_svg
        from ..io.yamlio import dump_document

        try:
            glb_bytes = base64.b64decode(body.data_b64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                      "message": f"data_b64 is not valid base64: {exc}",
                                      "context": body.filename}) from exc
        glb_name = _Path(body.filename).name or "cube.glb"
        with tempfile.TemporaryDirectory() as tmp:
            glb_path = _Path(tmp) / glb_name
            glb_path.write_bytes(glb_bytes)
            try:
                result = import_glb_file(glb_path, namespace=body.namespace)
            except Exception as exc:  # noqa: BLE001 — pygltflib raises plain errors
                raise HTTPException(422, {"code": "E_BAD_GLB",
                                          "message": f"could not parse the GLB: {exc}",
                                          "context": body.filename}) from exc

        # The mesh the user just dropped IS the template asset — reference it
        # so the accepting client (which holds the bytes) ships it alongside,
        # and the honesty rule (assets only advertised when present) holds.
        template = dict(result.template)
        template["glb"] = glb_name
        module = dict(result.module)
        module["thumbnail"] = "thumbnail.svg"
        component_id = str(result.component["id"])
        template_id = str(template["id"])
        module_id = str(module["id"])
        return {
            "component": result.component,
            "template": template,
            "module": module,
            "review": result.review,
            "envelope_mm": list(result.envelope_mm),
            "glb_asset_path": f"templates/{template_id}/{glb_name}",
            "records": {
                f"components/{component_id}/component.yml": dump_document(result.component),
                f"templates/{template_id}/template.yml": dump_document(template),
                f"modules/{module_id}/module.yml": dump_document(module),
                f"modules/{module_id}/thumbnail.svg": bbox_thumbnail_svg(
                    result.envelope_mm, module_id.rsplit(".", 1)[-1]
                ),
            },
        }

    @app.post("/v1/draw")
    def draw_layout(body: DrawBody) -> Response:
        """WP-82: the compiled path as optiland's 2D layout drawing (PNG).

        The engine has always been able to draw this (`main.py --only draw`);
        now the editor can at least view it. Headless: matplotlib Agg, no
        window, the bytes stream back.
        """
        import io

        try:
            import matplotlib
            from optiland.optic import Optic
        except ImportError as exc:
            raise HTTPException(
                501,
                {"code": "E_NO_OPTILAND",
                 "message": "install the sim extra: pip install optikit-core[sim]",
                 "context": str(exc)},
            ) from exc
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        decl = parse_design(body)
        try:
            result = compile_path(decl, body.path)
        except (CompileError, FlattenError) as exc:
            raise engine_422(exc) from exc
        optic = Optic.from_dict(result.optic)
        try:
            optic.draw(num_rays=max(1, min(64, body.num_rays)), figsize=(10, 4))
            buffer = io.BytesIO()
            plt.savefig(buffer, format="png", dpi=110, bbox_inches="tight")
        finally:
            plt.close("all")
        return Response(buffer.getvalue(), media_type="image/png")

    # --- T3 generation (WP-61: the harness becomes service-reachable) ------------------

    def _generate_t2(record: Any, body: GenerateBody, repo_root: Path) -> dict[str, Any]:
        """WP-85: the T2 branch — parameterize the Inventor master insert.

        The design supplies everything: the component's inline fragment is
        the prescription (`pocket_params` → fx, the wiring that had no
        caller), and `instantiation.dof_values` supply the placement (`dz`).
        The bridge on the Inventor machine does the CAD work; no bridge is a
        TYPED 503 so the editor can fall back to "download the fx changeset".
        """
        import base64

        from ..generate.inventor import (
            E_BRIDGE,
            InventorBridgeError,
            generate_t2,
        )
        from ..schema.design import parse_dof_key

        if not body.files or not body.component:
            raise HTTPException(422, {
                "code": "E_BAD_REQUEST",
                "message": "a T2 run needs files + component — the design carries "
                           "the prescription and the dof values the insert is "
                           "parameterized from",
                "context": record.id,
            })
        decl = parse_design(DesignBody(files=body.files))
        comp = decl.components.get(body.component)
        if comp is None:
            raise HTTPException(422, {
                "code": "E_BAD_REQUEST",
                "message": f"no component {body.component!r} in the design",
                "context": sorted(decl.components),
            })
        fragment = comp.optics.fragment if comp.optics else None
        if fragment is None or not fragment.surfaces:
            raise HTTPException(422, {
                "code": "E_NO_OPTICS",
                "message": f"component {body.component!r} has no fragment surfaces — "
                           "a T2 insert is parameterized from the prescription",
                "context": record.id,
            })
        dof_values: dict[str, float] = {}
        for dotted, value in decl.instantiation.dof_values.items():
            try:
                comp_key, dof_name = parse_dof_key(dotted)
            except ValueError:
                continue
            if comp_key == body.component and isinstance(value, int | float):
                dof_values[dof_name] = float(value)

        try:
            result = generate_t2(
                record,
                [dict(s) for s in fragment.surfaces],
                dof_values,
                component_key=body.component,
                out_root=repo_root / "out",
            )
        except InventorBridgeError as exc:
            raise HTTPException(
                502 if exc.code == E_BRIDGE else 503,
                {"code": exc.code, "message": str(exc), "context": record.id},
            ) from exc
        except ValueError as exc:  # pocket derivation (no semi_aperture, …)
            raise HTTPException(422, {"code": "E_BAD_PRESCRIPTION",
                                      "message": str(exc),
                                      "context": record.id}) from exc

        artifacts = {
            p.name: base64.b64encode(p.read_bytes()).decode("ascii")
            for p in sorted(result.out_dir.iterdir())
            if p.suffix in {".stp", ".step", ".glb", ".png"}
        }
        return {
            "template_id": result.template_id,
            "generator": "inventor-bridge",
            "key": result.key,
            "out_dir": str(result.out_dir.relative_to(repo_root)),
            "regenerated": result.regenerated,
            "meta": result.meta,
            "artifacts": artifacts,
        }

    @app.post("/v1/generate")
    def generate_t3(body: GenerateBody) -> dict[str, Any]:
        """Run a T3 generator: an existing generative template by id, OR an
        ad-hoc boolean holder around a bare optical component (WP-60's
        unbound primitives — the "put it in a cube" verb).

        Honours the sha256 params key: an identical request is a cache hit
        (``regenerated: false``), not a rebuild. With ``files`` + ``component``
        the design component's placed intra-cube δ/ΔR folds into the params
        (``pose_params_from_component``) so the cavity is carved where the
        optic ACTUALLY sits. Artifacts return base64-inline — they live under
        the repo's ``out/``, which is not a served asset tree.
        """
        import base64

        from ..generate import GenerateError, generate, pose_params_from_component
        from ..library import load_library
        from ..schema.library import TemplateRecord

        if bool(body.template_id) == bool(body.component_id):
            raise HTTPException(422, {
                "code": "E_BAD_REQUEST",
                "message": "give exactly one of template_id | component_id",
                "context": {"template_id": body.template_id,
                            "component_id": body.component_id},
            })

        # `repo_root` is a DIFFERENT thing from the library root and stays
        # tied to this source tree: it is where generated CAD lands (`out/`),
        # which belongs to the service, not to the record library.
        repo_root = SCHEMA_DIST.parents[1]
        library_root = library_root_path()
        if not library_root.is_dir():
            raise HTTPException(404, {"code": "E_NOT_FOUND",
                                      "message": f"no record library at {library_root}",
                                      "context": str(library_root)})
        library = load_library(library_root)

        if body.template_id:
            record = next(
                (e.record for e in library.records
                 if isinstance(e.record, TemplateRecord) and e.record.id == body.template_id),
                None,
            )
            if record is None:
                raise HTTPException(404, {"code": "E_NOT_FOUND",
                                          "message": f"no template {body.template_id!r}",
                                          "context": str(library_root)})
            # WP-85: an ADAPTIVE template is the T2 road — parameterize the
            # real Inventor master insert via the bridge instead of running
            # CadQuery. The design supplies the prescription and dof values.
            if record.class_ == "adaptive":
                return _generate_t2(record, body, repo_root)
        else:
            # Ad-hoc holder around a bare component. Prefer the vendor STEP
            # when the record ships one; otherwise the cut body is derived
            # from the prescription (WP-62). The synthesized id matches what
            # the editor materializes on accept, so the accepted template's
            # first regenerate is a cache hit on this very run.
            slug = (body.component_id or "").split(".")[-1].replace("-", "_")
            comp_step = library_root / "components" / str(body.component_id) / "model.step"
            if "part_step" in body.params or "part_prescription" in body.params:
                # The request names its own cut body — exactly-one is enforced
                # by the params schema, so the record must not add a default.
                cut_body: dict[str, Any] = {}
            elif comp_step.is_file():
                cut_body = {"part_step": f"library/components/{body.component_id}/model.step"}
            else:
                cut_body = {"part_prescription": {"component": body.component_id}}
            record = TemplateRecord.model_validate({
                "kind": "mechanical_template",
                "id": f"user.tpl.holder_{slug}",
                "version": "0.1.0",
                "class": "generative",
                "description": f"boolean holder around {body.component_id}",
                "envelope": {"x-mm": 50, "y-mm": 50, "z-mm": 50},
                "generator": {
                    "script": "generators/boolean_holder_1x1.py",
                    "params": {**cut_body, "clearance_mm": 0.15,
                               "split_plane": "xz", "body_height_mm": 30},
                },
            })

        # The T3 road runs CadQuery in-process; gate here so a T2 run above
        # never needed the generate extra at all.
        try:
            import cadquery  # noqa: F401
        except ImportError as exc:
            # The harness could shell out via uv, but a service that quietly
            # spawns subprocess builds per request is a foot-gun — mirror
            # /v1/convert/step-to-glb and ask for the extra instead.
            raise HTTPException(
                501,
                {"code": "E_NO_CADQUERY",
                 "message": "install the generate extra: pip install optikit-core[generate]",
                 "context": str(exc)},
            ) from exc

        overrides: dict[str, Any] = {}
        if body.files and body.component:
            decl = parse_design(DesignBody(files=body.files))
            comp = decl.components.get(body.component)
            if comp is None:
                raise HTTPException(422, {
                    "code": "E_BAD_REQUEST",
                    "message": f"no component {body.component!r} in the design",
                    "context": sorted(decl.components),
                })
            overrides.update(pose_params_from_component(
                comp, record.generator.params if record.generator else {}
            ))
        overrides.update(body.params)

        try:
            result = generate(
                record,
                params_override=overrides,
                out_root=repo_root / "out",
                repo_root=repo_root,
            )
        except GenerateError as exc:
            raise engine_422(exc) from exc

        artifacts = {
            p.name: base64.b64encode(p.read_bytes()).decode("ascii")
            for p in sorted(result.out_dir.glob("model*"))
            if p.suffix in {".step", ".stl", ".glb"}
        }
        return {
            "template_id": result.template_id,
            "generator": record.generator.script if record.generator else "",
            "key": result.key,
            "out_dir": str(result.out_dir.relative_to(repo_root)),
            "regenerated": result.regenerated,
            "meta": result.meta,
            "artifacts": artifacts,
        }

    @app.post("/v1/library/save")
    def library_save(body: LibrarySaveBody) -> dict[str, Any]:
        """Developer fast path: write records straight into the repo library.

        WP-31: enabled BY DEFAULT when the service runs from a git checkout
        (the "we are the developers" case); OPTIKIT_ALLOW_LIBRARY_WRITE=0
        forces it off (the prod compose pins that), =1 forces it on. Container
        images carry no .git, so deployments stay read-only even without the
        env var. The normal road for contributions is the PR flow (WP-22).
        """
        import base64

        from ..io.yamlio import load_document_text
        from ..schema.library import (
            COMPONENT_FILE,
            MODULE_FILE,
            TEMPLATE_FILE,
            load_record,
        )

        # WP-102: this used to `setdefault(..., "1")` FIRST, which made `env`
        # never None and the checkout probe below dead code — so writes were
        # enabled unconditionally, in containers too, contradicting the
        # docstring. With DEFAULT_CORS_ORIGINS="*" and no auth, that let any
        # page a user visits POST arbitrary YAML into their library while the
        # service is running. Let the probe do its job.
        env = os.environ.get("OPTIKIT_ALLOW_LIBRARY_WRITE")
        dev_checkout = (SCHEMA_DIST.parents[1] / ".git").exists()
        enabled = env != "0" if env is not None else dev_checkout
        if not enabled:
            raise HTTPException(403, {
                "code": "E_WRITE_DISABLED",
                "message": "library writes are disabled — they are on by default only "
                           "when the service runs from a git checkout; set "
                           "OPTIKIT_ALLOW_LIBRARY_WRITE=1 to force-enable "
                           "(the PR flow is the normal contribution road)",
                "context": "",
            })

        library_root = library_root_path()
        kind_files = {
            "optical_component": ("components", COMPONENT_FILE),
            "mechanical_template": ("templates", TEMPLATE_FILE),
            "cube_module": ("modules", MODULE_FILE),
        }
        written: list[str] = []
        for text in body.records:
            try:
                record = load_record(load_document_text(text) or {})
            except Exception as exc:  # noqa: BLE001 — reported as a typed 422
                raise HTTPException(422, {"code": "E_BAD_RECORD",
                                          "message": str(exc), "context": ""}) from exc
            folder, filename = kind_files[record.kind]
            rec_dir = library_root / folder / record.id
            rec_dir.mkdir(parents=True, exist_ok=True)
            (rec_dir / filename).write_text(text, encoding="utf-8")
            written.append(f"{folder}/{record.id}/{filename}")
        for rel, data_b64 in body.assets.items():
            target = (library_root / rel).resolve()
            if library_root.resolve() not in target.parents:
                raise HTTPException(422, {"code": "E_BAD_UPLOAD",
                                          "message": f"asset path escapes the library: {rel}",
                                          "context": rel})
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(base64.b64decode(data_b64))
            written.append(rel)
        return {"written": written}

    @app.post("/v1/library/verify-t1")
    def library_verify_t1(body: VerifyT1Body) -> dict[str, Any]:
        """verify-t1 over a PROPOSED trio (WP-113): do the optical model and
        the mechanics agree, before anything is published?

        The check existed only as a CLI command; the wizard's last step runs
        it here. Findings come back verbatim ({code, level, message}) —
        including ``W_NO_INSERT_FRAME``, which the caller must surface: a
        template with no ``frames:`` makes the OK VACUOUS (it passes without
        ever comparing a pose, which is precisely how a wrong record ships).
        """
        from ..io.yamlio import load_document_text
        from ..library.build import Library, LoadedRecord, load_library
        from ..library.verify import verify_t1, verify_t1_ok
        from ..schema.library import load_record

        proposed: list[LoadedRecord] = []
        for i, text in enumerate(body.records):
            try:
                record = load_record(load_document_text(text) or {})
            except Exception as exc:  # noqa: BLE001 — reported as a typed 422
                raise HTTPException(422, {"code": "E_BAD_RECORD",
                                          "message": str(exc), "context": ""}) from exc
            proposed.append(LoadedRecord(record=record, path=Path(f"proposed-{i}")))

        module_id = body.module_id or next(
            (r.record.id for r in proposed if r.record.kind == "cube_module"), "")
        if not module_id:
            raise HTTPException(422, {
                "code": "E_BAD_REQUEST",
                "message": "no cube_module among the proposed records and no module_id "
                           "given — verify-t1 checks a module's bound pair",
                "context": "",
            })

        # Proposed records FIRST so a same-id@higher-version proposal wins
        # resolution; the published library underneath resolves refs to
        # records the proposal does not carry.
        library_root = library_root_path()
        published = load_library(library_root) if library_root.is_dir() else Library()
        library = Library(records=[*proposed, *published.records], root=published.root)

        findings = verify_t1(library, module_id)
        return {
            "ok": verify_t1_ok(findings),
            "module_id": module_id,
            "findings": [
                {"code": f.code, "level": f.level, "message": f.message} for f in findings
            ],
        }

    # --- library registry (WP-22) --------------------------------------------------------
    # The service IS the registry: the frontend's default index URL points
    # here; the static /configurator/optikit-library/index.json bundled with
    # the frontend is the offline fallback only.

    # WP-51: the index is cached against the library tree's state key
    # (max mtime + file count from a cheap os.scandir walk), so dev writes
    # still appear instantly — they touch the tree, the key changes, the
    # cache misses. `?fresh=1` bypasses the cache outright.
    index_cache: dict[str, Any] = {"key": None, "body": None}

    def _library_state_key(root: Path) -> tuple[float, int]:
        """(max mtime, entry count) over the tree — changes on any write."""

        latest = 0.0
        count = 0
        stack = [str(root)]
        while stack:
            with os.scandir(stack.pop()) as entries:
                for entry in entries:
                    count += 1
                    stat = entry.stat(follow_symlinks=False)
                    if stat.st_mtime > latest:
                        latest = stat.st_mtime
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(entry.path)
        return latest, count

    @app.get("/v1/library/index")
    def library_index(fresh: bool = False) -> Response:
        from ..library.build import build_index, load_library

        library_root = library_root_path()
        if not library_root.is_dir():
            raise HTTPException(404, {"code": "E_NOT_FOUND",
                                      "message": "no library/ next to this service",
                                      "context": ""})

        key = _library_state_key(library_root)
        if not fresh and index_cache["key"] == key and index_cache["body"] is not None:
            return Response(index_cache["body"], media_type="application/json")
        # Build from the tree (the WP-22 freshness contract), then cache
        # against the tree state we just built from. dump_index_json keeps
        # .inf fragment radii strict-JSON safe (WP-60).
        from ..library.build import dump_index_json

        body = dump_index_json(build_index(load_library(library_root), library_root))
        index_cache["key"] = key
        index_cache["body"] = body
        return Response(body, media_type="application/json")

    @app.get("/v1/library/assets/{kind}/{record_id}/{filename}")
    def library_asset(kind: str, record_id: str, filename: str) -> Response:
        import mimetypes

        if kind not in ("components", "templates", "modules"):
            raise HTTPException(404, {"code": "E_NOT_FOUND", "message": kind, "context": ""})
        library_root = library_root_path()
        target = (library_root / kind / record_id / filename).resolve()
        # No traversal: the resolved file must stay under library/.
        if library_root not in target.parents or not target.is_file():
            raise HTTPException(404, {"code": "E_NOT_FOUND",
                                      "message": f"{kind}/{record_id}/{filename}",
                                      "context": ""})
        media = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if target.suffix == ".glb":
            media = "model/gltf-binary"
        return Response(target.read_bytes(), media_type=media)

    # --- schema ------------------------------------------------------------------------

    @app.get("/v1/schema")
    def schema_index() -> dict[str, Any]:
        return {"schemas": sorted(p.name for p in SCHEMA_DIST.glob("*.schema.json"))}

    @app.get("/v1/schema/{name}")
    def schema_file(name: str) -> Response:
        file = SCHEMA_DIST / name
        if not file.is_file() or file.suffix != ".json":
            raise HTTPException(404, {"code": "E_NOT_FOUND", "message": name, "context": ""})
        return Response(file.read_text(encoding="utf-8"), media_type="application/json")

    return app


# --- optiland helpers -----------------------------------------------------------------------



def _paraxial(optic: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for name in ("f1", "f2", "F1", "F2", "P1", "P2", "EPD", "EPL", "FNO", "magnification"):
        try:
            out[name] = float(getattr(optic.paraxial, name)())
        except Exception:  # noqa: BLE001 — metric not defined for this system
            continue
    return out


def _world_polylines(optic: Any, compiled: CompileResult) -> list[list[list[float]]]:
    """Re-fold traced per-surface intersections into world-coordinate polylines."""
    sg = optic.surface_group
    xs, ys, zs = np.asarray(sg.x), np.asarray(sg.y), np.asarray(sg.z)
    n_rays = xs.shape[1] if xs.ndim == 2 else 1
    polylines: list[list[list[float]]] = []
    for ray in range(n_rays):
        points: list[list[float]] = []
        for entry in compiled.manifest:
            world = entry.world
            if world is None:
                continue
            i = entry.surface_index
            x = float(xs[i][ray]) if xs.ndim == 2 else float(xs[i])
            y = float(ys[i][ray]) if ys.ndim == 2 else float(ys[i])
            z = float(zs[i][ray]) if zs.ndim == 2 else float(zs[i])
            if not all(map(math.isfinite, (x, y, z))):
                continue
            p = (
                np.array(world["axis_point"])
                + x * np.array(world["u"])
                + y * np.array(world["v"])
                + (z - world["cs_z"]) * np.array(world["direction"])
            )
            points.append([round(float(v), 6) for v in p])
        if len(points) >= 2:
            polylines.append(points)
    return polylines


def _free_dofs(
    decl: DesignDecl, requested: list[str] | None
) -> tuple[list[str], list[tuple[float, float]]]:
    keys: list[str] = []
    bounds: list[tuple[float, float]] = []
    for comp_id, comp in instantiate(decl).items():
        for dof in comp.dof:
            if dof.range is None:
                continue
            lo, hi = dof.range
            if isinstance(lo, str) or isinstance(hi, str):
                continue
            key = f"{comp_id}.{dof.name}"
            if requested is not None and key not in requested:
                continue
            keys.append(key)
            bounds.append((float(lo), float(hi)))
    return keys, bounds


app = create_app()
