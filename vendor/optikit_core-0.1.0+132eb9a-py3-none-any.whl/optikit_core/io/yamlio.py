"""Lossless YAML I/O for design documents.

Two layers with distinct guarantees:

- **Document layer** (ruamel.yaml round-trip mode): preserves comments, key order,
  and node styles, so a load→dump cycle of a hand-authored file is stable. This is
  what editors and converters must use when rewriting files a human owns.
- **Model layer** (Pydantic): ``load_design`` / ``dump_design`` go through the
  schema models for validation; unknown keys survive via ``extra="allow"`` but
  comments do not. Tools that generate files from scratch use this.
"""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from ..schema.design import DESIGN_DECL_FILE, DesignDecl


def _yaml() -> YAML:
    y = YAML(typ="rt")  # round-trip: preserves comments, order, anchors
    y.preserve_quotes = True
    y.width = 100
    y.indent(mapping=2, sequence=4, offset=2)
    return y


def load_document(path: Path) -> Any:
    """Load a YAML file as a comment-preserving document tree."""
    return _yaml().load(path.read_text(encoding="utf-8"))


def load_document_text(text: str) -> Any:
    """Load YAML text as a comment-preserving document tree."""
    return _yaml().load(text)


def load_document_text_fast(text: str) -> Any:
    """Load YAML text as plain data, without comment preservation.

    For hot paths that immediately validate into Pydantic and discard the
    tree (the service's per-request design bodies): PyYAML's libyaml loader
    is ~15x faster than ruamel round-trip mode. PyYAML resolves scalars per
    YAML 1.1 (unquoted ``yes``/``no`` become booleans, ``2024-01-01`` a
    date) where ruamel follows 1.2 — machine-generated design bodies never
    author those forms unquoted, and hand-owned files keep going through
    ``load_document_text``. Falls back to the pure-Python SafeLoader when
    libyaml is absent.
    """
    import yaml as pyyaml

    loader = getattr(pyyaml, "CSafeLoader", pyyaml.SafeLoader)
    return pyyaml.load(text, Loader=loader)


def dump_document(doc: Any) -> str:
    """Serialize a document tree (or plain data) back to YAML text."""
    buf = io.StringIO()
    _yaml().dump(doc, buf)
    return buf.getvalue()


def resolve_design_file(path: Path) -> Path:
    """Accept either a design directory (``*.dsn``) or the design file itself."""
    if path.is_dir():
        return path / DESIGN_DECL_FILE
    return path


def load_design(path: Path) -> DesignDecl:
    """Load and structurally validate a design file or design directory."""
    file = resolve_design_file(path)
    data = _yaml().load(file.read_text(encoding="utf-8"))
    if data is None:
        data = {}
    return DesignDecl.model_validate(_to_plain(data))


def dump_design(decl: DesignDecl) -> str:
    """Serialize a DesignDecl to YAML (declared-field order, unset fields omitted)."""
    return dump_document(decl.dump())


def design_dir_loader(design_dir: Path):
    """Subassembly loader rooted at ``design_dir`` (WP-36) — the io-side plug
    for :func:`optikit_core.geometry.flat_design_report`.

    Resolves each component's ``design:`` path relative to the design's own
    directory (symlinks welcome — the Go examples use them), instantiates the
    requested variant, and hands back a loader scoped to the subdesign so
    nesting recurses like the Go reference's ``FSDesign.LoadFSDesign``.
    """
    from ..schema.design import InstSpec
    from ..schema.merge import instantiate

    def load(design_path: str, variant: str):
        subdir = (design_dir / design_path).resolve()
        decl = load_design(subdir)
        components = instantiate(decl, InstSpec(variant=variant))
        return components, design_dir_loader(subdir)

    return load


def _to_plain(node: Any) -> Any:
    """Convert ruamel container types to plain dict/list/scalars for Pydantic."""
    if isinstance(node, dict):
        return {str(k): _to_plain(v) for k, v in node.items()}
    if isinstance(node, list):
        return [_to_plain(v) for v in node]
    if isinstance(node, bytes):
        return node.decode("utf-8")
    if node is not None and not isinstance(node, str | int | float | bool):
        # ruamel scalar wrappers (ScalarFloat, ScalarInt, folded strings, ...)
        for typ in (bool, int, float):
            if isinstance(node, typ):
                return typ(node)
        return str(node)
    return node
