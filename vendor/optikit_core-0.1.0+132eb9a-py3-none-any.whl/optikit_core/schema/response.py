"""Per-surface spectral & polarization response (WP-74).

Every filter and dichroic in the library was a physics stub: a dichroic was a
bare reflective flat with no cut-on — structurally identical to a beamsplitter —
so chain inference was wavelength-blind and proposed the dichroic's bleed-through
arm as a legitimate path. This module adds the *response* half of the physics
(the source half, ``SourceSpec.wavelengths_um``, already exists) as a small
declarative block on a fragment surface:

    response:
      kind: dichroic                 # mirror | sampler | polarizing | dichroic | absorptive
      reflect-bands-um: [[null, 0.505]]   # null = open-ended (PyOpticL's convention)
      transmit-bands-um: null             # absorptive filters use this
      transmit-ratio: null                # sampler / beamsplitter, for the photon budget
      polarization-deg: null              # PBS reflect axis — DECLARED, not yet projected

The block lives ON THE SURFACE (decision: a cut-on is a property of the coated
surface, not the port) inside the Optiland-serialized fragment, where
``extra="allow"`` already carries it losslessly. Wavelength gating is
implemented; the Jones projection for ``polarization_deg`` is deferred until a
BB84-class design needs it.

Consumed by ``chain/infer.py`` (prune an arm whose band excludes the
propagating wavelength), ``schema/checks.py`` (a filter-stack compatibility
check), and ``budget.py`` (the photon budget — how much light reaches the
sensor).
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import field_validator

from .common import SchemaModel
from .design import _dashed

#: A wavelength band [lo, hi] in µm; ``None`` on either side is open-ended.
Band = tuple[float | None, float | None]

ResponseKind = Literal["mirror", "sampler", "polarizing", "dichroic", "absorptive"]


class SurfaceResponse(SchemaModel):
    """Spectral/polarization gating of a single coated surface (WP-74)."""

    model_config = SchemaModel.model_config | {"alias_generator": _dashed}

    kind: ResponseKind = "mirror"
    #: Wavelength ranges (µm) this surface REFLECTS; the rest transmits. A
    #: mirror leaves this null (reflects everything); a dichroic names its
    #: reflect band; a beamsplitter leaves it null (reflects all, ratio splits
    #: the power). Empty list == "all wavelengths", same as null.
    reflect_bands_um: list[Band] | None = None
    #: Wavelength ranges (µm) this surface PASSES — for an absorptive filter,
    #: which is a straight-through element with no reflect arm.
    transmit_bands_um: list[Band] | None = None
    #: Reflected power fraction of a sampler/beamsplitter (0–1); feeds the
    #: photon budget, not the topology.
    transmit_ratio: float | None = None
    #: PBS reflect axis in degrees — declared so BB84 designs can record it;
    #: the Jones projection is not implemented (decision 2).
    polarization_deg: float | None = None

    @field_validator("reflect_bands_um", "transmit_bands_um")
    @classmethod
    def _valid_bands(cls, v: list[Band] | None) -> list[Band] | None:
        if v is None:
            return v
        for lo, hi in v:
            if lo is not None and hi is not None and float(lo) > float(hi):
                raise ValueError(f"band [{lo}, {hi}] has lo > hi")
        return v

    @field_validator("transmit_ratio")
    @classmethod
    def _valid_ratio(cls, v: float | None) -> float | None:
        if v is not None and not 0.0 <= float(v) <= 1.0:
            raise ValueError(f"transmit-ratio must be in [0, 1], got {v}")
        return v


def response_of_surface(surface: dict[str, Any] | None) -> SurfaceResponse | None:
    """Parse the ``response`` block off an opaque Optiland surface dict, or None."""
    if not isinstance(surface, dict):
        return None
    block = surface.get("response")
    if block is None:
        return None
    return SurfaceResponse.model_validate(block)


def _band_contains(bands: list[Band] | None, wl_um: float, *, default: bool) -> bool:
    """Is ``wl_um`` inside any band? ``None``/empty means "all" → ``default``."""
    if not bands:
        return default
    return any(
        (lo is None or wl_um >= float(lo)) and (hi is None or wl_um <= float(hi))
        for lo, hi in bands
    )


def exit_role(port_name: str) -> Literal["reflect", "transmit"] | None:
    """Which arm an exit port is, from the name the record already uses.

    A 45° dichroic makes BOTH exits perpendicular to the incoming beam, so the
    reflect/transmit split cannot be read from geometry — but the record author
    always names them (``reflected`` / ``transmitted``, ``…-refl`` / ``…-back``).
    That naming IS the physics contract, the same way PyOpticL's definition
    author labels a ``Reflection``. An unrecognized name is not gated.
    """
    n = port_name.lower()
    if "refl" in n:
        return "reflect"
    if "trans" in n:
        return "transmit"
    return None


def exit_survives(
    response: SurfaceResponse | None, exit_name: str, wl_um: float | None
) -> bool:
    """Does the beam at ``wl_um`` survive leaving through ``exit_name``?

    ``None`` response or ``None`` wavelength ⇒ no gating (the wavelength-blind
    behavior every pre-WP-74 design keeps). Otherwise the surface kind decides:

    - ``mirror``   — reflects; kept iff the wavelength is in its (open) band.
    - ``absorptive`` — a filter; the straight-through arm passes iff the
      wavelength is in a transmit band.
    - ``dichroic`` / ``sampler`` / ``polarizing`` — split by port role: a
      reflect arm survives inside the reflect band, a transmit arm survives
      outside it (and inside any transmit band).
    """
    if response is None or wl_um is None:
        return True
    if response.kind == "mirror":
        return _band_contains(response.reflect_bands_um, wl_um, default=True)
    if response.kind == "absorptive":
        return _band_contains(response.transmit_bands_um, wl_um, default=True)
    role = exit_role(exit_name)
    if role == "reflect":
        return _band_contains(response.reflect_bands_um, wl_um, default=True)
    if role == "transmit":
        blocked = _band_contains(response.reflect_bands_um, wl_um, default=False)
        return (not blocked) and _band_contains(
            response.transmit_bands_um, wl_um, default=True
        )
    return True  # unrecognized role: do not gate


def transmitted_fraction(
    response: SurfaceResponse | None, exit_name: str, wl_um: float | None
) -> float:
    """Power fraction that survives this traversal (WP-74 photon budget).

    Topology-survival is 0/1 from :func:`exit_survives`; a sampler additionally
    splits by ``transmit_ratio`` (reflect arm keeps the ratio, transmit arm the
    complement). Everything else that survives keeps its full power (coating
    efficiency is not modeled yet).
    """
    if not exit_survives(response, exit_name, wl_um):
        return 0.0
    if response is not None and response.kind == "sampler" and response.transmit_ratio is not None:
        r = float(response.transmit_ratio)
        return r if exit_role(exit_name) == "reflect" else (1.0 - r)
    return 1.0
