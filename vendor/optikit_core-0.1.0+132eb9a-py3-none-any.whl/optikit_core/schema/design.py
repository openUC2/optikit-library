"""Pydantic models for the ``optikit-design.yml`` format, schema v0.

Superset of the Go reference ``DesignDecl``
(github.com/openUC2/optikit, exp/designs/designs-decl.go): every field and
semantic of the Go struct is kept, so all designs in that repo's
``examples/designs/**`` remain valid. Extensions over the Go struct
(ratification pending, see Ethan TODO E2):

- ``components.<id>.optics``    — verbatim Optiland surface fragment + frames + ports
- ``components.<id>.template``  — mechanical template class T1/T2/T3, envelope, generator
- ``components.<id>.dof``       — declared degrees of freedom (the load-bearing block)
- ``pose.rotation.offset-deg``  — extrinsic-ZXY residual rotation on top of the 24-rotation
- top-level ``paths``           — the optical netlist (port traversals + simulation context)
- ``instantiation.dof_values``  — per-instance resolved DOF values
- top-level ``provenance``      — optimization/build provenance

Draft syntax already present in the example corpus (top-level ``inputs``,
component-level ``instantiation``, ``computed-primitive`` components,
``rotation.type: z-spherical``, ``relations``) is modeled loosely and preserved.
"""

from __future__ import annotations

import math
from typing import Any, Literal

from pydantic import Field, field_validator

from .common import (
    ContinuousXYZ,
    DiscreteXYZ,
    SchemaModel,
    TemplatedFloat,
)

DESIGN_DECL_FILE = "optikit-design.yml"

# Component / primitive / rotation type vocabularies. Kept as plain strings in the
# models (forward compatibility); membership is enforced by checks.check().
KNOWN_COMP_TYPES = ("location", "primitive", "design", "computed-primitive")
KNOWN_PRIM_TYPES = ("optiland", "gltf", "glb", "step", "computed")
#: WP-140: `quaternion` is accepted (Go @21dc193 made it first-class) and
#: normalized to grid + offset-deg by `RotSpec.normalized()` — never emitted.
KNOWN_ROT_TYPES = ("", "uc2", "grid", "z-spherical", "quaternion")

ROT_TYPE_UC2 = "uc2"
ROT_TYPE_GRID = "grid"


def _dashed(name: str) -> str:
    return name.replace("_", "-")


class DesignSpec(SchemaModel):
    """Basic metadata for a design (Go: DesignSpec, plus optional name/version)."""

    path: str = ""
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    # v0 extensions: human-readable name and a semver for library-published designs.
    name: str = ""
    version: str = ""


class InstSpec(SchemaModel):
    """Top-level instantiation parameters (Go: InstSpec, plus dof_values).

    ``dof_values`` maps ``"<component>.<dof-name>"`` to the resolved value for this
    instance. Instance data only — never library data.
    """

    variant: str = ""
    dof_values: dict[str, TemplatedFloat] = Field(default_factory=dict)


class PrimSpec(SchemaModel):
    """Model primitive reference (Go: CompPrimSpec, plus draft `computed` fields)."""

    type: str = ""
    model: str = ""
    # Draft syntax (lens-parametric example): procedurally computed geometry.
    function: str = ""
    inputs: dict[str, Any] = Field(default_factory=dict)


class RotGridSpec(SchemaModel):
    """Axis-naming rotation: which design axis local +z / +x point along."""

    z: str = ""  # zero value means "+z"
    x: str = ""  # zero value means "+x"


class RotSpec(SchemaModel):
    """Component orientation (Go: CompPoseRotSpec, plus offset-deg residual).

    ``offset_deg`` is the v0 extension: an extrinsic-ZXY Euler residual rotation
    (degrees) applied on top of the discrete 24-rotation, e.g. written back by
    optimization (TILT_UPDATE) or by cubify's R = R24·ΔR decomposition.
    """

    type: str = ""
    grid: RotGridSpec = Field(default_factory=RotGridSpec)
    offset_deg: ContinuousXYZ = Field(default_factory=ContinuousXYZ, alias="offset-deg")
    # Draft syntax (lens-parametric example): spherical-coordinate orientation.
    z_spherical: dict[str, Any] = Field(default_factory=dict, alias="z-spherical")
    #: WP-140: the Go reference (openUC2/optikit@21dc193) added a first-class
    #: ``quaternion`` rotation type. We ACCEPT it — the wire has one meaning —
    #: but never EMIT it: a bare quaternion has thrown away the grid
    #: membership that the T-rule, the yaw ring, DRC-on-residuals and the 24
    #: insert poses all read. `normalized()` below converts it losslessly to
    #: the equivalent ``grid`` + ``offset-deg``, which says strictly more.
    quaternion: list[float] = Field(default_factory=list)

    @field_validator("quaternion")
    @classmethod
    def _unit_quaternion(cls, v: list[float]) -> list[float]:
        if not v:
            return v
        if len(v) != 4:
            raise ValueError(f"quaternion must be [x, y, z, w], got {len(v)} values")
        norm = math.sqrt(sum(float(c) * float(c) for c in v))
        if abs(norm - 1.0) > 1e-6:
            raise ValueError(f"quaternion is not a unit quaternion (norm {norm:.6f})")
        return [float(c) for c in v]

    def normalized(self) -> RotSpec:
        """This rotation as ``grid`` + ``offset-deg`` — the spelling we emit.

        A ``quaternion`` rotation is decomposed into the nearest of the 24
        grid orientations plus the extrinsic-ZXY residual that remains, which
        is exactly the ``R = R24 · ΔR`` the contract already defines (§3).
        Any other type passes through untouched.
        """
        if self.type != "quaternion" or not self.quaternion:
            return self
        # Local import: geometry pulls in numpy, schema must stay importable
        # without it for the JSON-Schema export.
        from ..geometry.rotations import decompose, quaternion_to_matrix

        decomposition = decompose(quaternion_to_matrix(self.quaternion))
        return RotSpec(
            type="grid",
            grid=RotGridSpec(z=decomposition.z, x=decomposition.x),
            **{"offset-deg": ContinuousXYZ(**decomposition.offset_deg)},
        )


class TranslSpec(SchemaModel):
    """Component position relative to an anchor component (Go: CompPoseTranslSpec)."""

    anchor: str = ""
    offset_grid: DiscreteXYZ = Field(default_factory=DiscreteXYZ, alias="offset-grid")
    offset_mm: ContinuousXYZ = Field(default_factory=ContinuousXYZ, alias="offset-mm")


class PoseSpec(SchemaModel):
    """Component pose (Go: CompPoseSpec). A zero value means no spatial geometry."""

    rotation: RotSpec = Field(default_factory=RotSpec)
    translation: TranslSpec = Field(default_factory=TranslSpec)

    @field_validator("rotation", "translation", mode="before")
    @classmethod
    def _null_is_empty(cls, v: Any) -> Any:
        # The corpus contains empty nodes like `translation:` — treat as zero value.
        return {} if v is None else v


class FrameSpec(SchemaModel):
    """Named datum frame: a fixed transform in the component's local coordinates.

    Position (``x-mm``/``y-mm``/``z-mm``) is the frame origin. ``rotation`` is an
    ``[x, y, z, w]`` quaternion taking the component's axes to the frame's, and is
    omitted (identity) for the axis-aligned majority — a port's ``direction``
    literal is resolved *in its frame*, so a tilted frame tilts the beam. Both
    are populated from a ``PLN`` datum marker (``DOCS/inventor-naming-contract.md``);
    ``clear-aperture-mm`` is the diameter of the marker disc that defined it.
    """

    model_config = SchemaModel.model_config | {"alias_generator": _dashed}

    x_mm: TemplatedFloat = 0.0
    y_mm: TemplatedFloat = 0.0
    z_mm: TemplatedFloat = 0.0
    #: [x, y, z, w] quaternion; None means identity (frame aligned to the component).
    rotation: list[float] | None = None
    #: Clear-aperture diameter at this frame, mm (from the datum disc).
    clear_aperture_mm: TemplatedFloat | None = None

    @field_validator("rotation")
    @classmethod
    def _quat_len(cls, v: list[float] | None) -> list[float] | None:
        if v is not None and len(v) != 4:
            raise ValueError(f"rotation must be an [x, y, z, w] quaternion, got {len(v)} values")
        return v


class PortSpec(SchemaModel):
    """Optical entry/exit port: a named frame plus a beam direction.

    ``direction`` is an axis literal (``+x`` … ``-z``) or — WP-39, pending E2
    ratification (ask #8) — a continuous ``[x, y, z]`` unit vector for
    record-internal geometry no cube axis can express (a 30° galvo mirror, an
    off-axis parabola). ``checks.check()`` warns on vectors until schema v0.1.
    """

    frame: str = ""
    direction: str | list[float] = ""  # axis literal or [x, y, z] unit vector
    # Index into optics.fragment.surfaces after which this port sits (exit ports).
    after_surface: int | None = Field(default=None, alias="after-surface")
    #: What the light DOES at this boundary (WP-166) — the terminal-discovery
    #: key. `emitter` launches a beam, `sensor` receives one; the tracer finds
    #: both without any declared path, which is what lets `paths:` become a
    #: lockfile instead of an input.
    #:
    #: A LIST, not a scalar, because a fluorescent sample is genuinely both at
    #: the same boundary: it absorbs the excitation arriving at `plane` and
    #: re-emits from that same plane. Forcing one role per port would have made
    #: it two ports naming one physical surface, and every chain that says
    #: `sample.plane` would have had to pick a side.
    #:
    #: Empty = undeclared; discovery then falls back to `category` with
    #: `W_ROLE_INFERRED`. `pass`/`fold` are vocabulary for the netlist and the
    #: table (part2r §0.4); they are not discovery keys.
    roles: list[Literal["emitter", "sensor", "pass", "fold"]] = Field(
        default_factory=list)
    #: How light enters/leaves this port (WP-46). "" = free space (the default:
    #: the beam propagates geometrically to the next element); "fiber" = a
    #: fiber connector (FC/PC, SMA) that only couples through a declared
    #: ``fibers:`` link. Routing a fiber into a free-space port warns.
    coupling: Literal["", "fiber"] = ""

    @field_validator("direction")
    @classmethod
    def _unit_vector(cls, v: str | list[float]) -> str | list[float]:
        if isinstance(v, list):
            if len(v) != 3:
                raise ValueError(f"direction vector needs 3 components, got {len(v)}")
            norm = sum(float(c) * float(c) for c in v) ** 0.5
            if abs(norm - 1.0) > 1e-3:
                raise ValueError(f"direction vector must be unit length, |v| = {norm:.4f}")
        return v


class SourceSpec(SchemaModel):
    """What a `category: source` component emits (WP-47).

    ``wavelengths_um`` is the source's LINE LIST — a multi-line laser declares
    every line it can emit; a design picks the active one per placement
    (``CompSpec.wavelength_um``). ``divergence_deg`` is the full-angle beam
    divergence of the bare emitter.
    """

    wavelengths_um: list[float] = Field(default_factory=list)
    divergence_deg: float = 0.0
    #: Emitted optical power in mW (WP-74 photon budget); None reports the
    #: budget as a transmitted fraction only.
    power_mw: float | None = None
    #: 1/e² beam diameter at the emission aperture, mm (WP-112: the housed-
    #: device wizard authors this; declared here so it is typed rather than
    #: folklore riding on extra="allow"). None = undeclared.
    beam_diameter_mm: float | None = None

    @field_validator("beam_diameter_mm", "power_mw")
    @classmethod
    def _positive_or_none(cls, v: float | None) -> float | None:
        if v is not None and float(v) <= 0:
            raise ValueError(f"must be positive when set, got {v}")
        return v

    @field_validator("wavelengths_um")
    @classmethod
    def _positive(cls, v: list[float]) -> list[float]:
        for w in v:
            if float(w) <= 0:
                raise ValueError(f"wavelength must be positive, got {w}")
        return v


class ProgrammableSpec(SchemaModel):
    """A pixel-addressable surface: DMD, LCoS, LC panel, display (WP-47).

    The PATTERN is not simulated — the surface traces as a plane mirror
    (reflective) or a flat window (transmissive), so it still folds the beam
    and participates in DRC. What the record carries is the hardware fact
    sheet: pixel pitch, resolution, fill factor.
    """

    model_config = SchemaModel.model_config | {"alias_generator": _dashed}

    mode: Literal["reflective", "transmissive"] = "reflective"
    pixel_pitch_um: float | None = None
    #: [width, height] in pixels.
    resolution: tuple[int, int] | None = None
    #: Active area fraction (0–1); DMDs are ~0.92.
    fill_factor: float | None = None

    def active_area_mm(self) -> tuple[float, float] | None:
        """Physical active area, when pitch and resolution are both known."""
        if self.pixel_pitch_um is None or self.resolution is None:
            return None
        w, h = self.resolution
        return (w * self.pixel_pitch_um / 1000.0, h * self.pixel_pitch_um / 1000.0)


class FragmentSpec(SchemaModel):
    """Verbatim Optiland surface fragment.

    The surface dicts use Optiland's own serialization schema and are opaque to
    optikit-core except for their count and order, which are preserved exactly —
    with one WP-74 exception: a ``response`` block on a surface is validated
    (so a typo is an error, not silently swallowed by ``extra="allow"``) while
    still stored verbatim.
    """

    surfaces: list[dict[str, Any]] = Field(min_length=1)

    @field_validator("surfaces")
    @classmethod
    def _valid_responses(cls, v: list[dict[str, Any]]) -> list[dict[str, Any]]:
        from .response import SurfaceResponse

        for i, surface in enumerate(v):
            if isinstance(surface, dict) and surface.get("response") is not None:
                try:
                    SurfaceResponse.model_validate(surface["response"])
                except ValueError as exc:
                    raise ValueError(f"surface {i} response: {exc}") from exc
        return v


class EmissionLine(SchemaModel):
    """One spectral line of a source's emission: wavelength (µm) and weight."""

    wavelength_um: float
    weight: float = 1.0


class EmissionSpatial(SchemaModel):
    """Spatial extent of the emitted beam. ``type`` is ``point`` or ``disc``
    (dialect v0); ``disc`` requires ``radius_mm``. The materializer rejects
    anything else with ``E_SIM_UNSUPPORTED`` — the schema stays permissive so
    newer records degrade gracefully in older tools."""

    type: str = "point"
    radius_mm: TemplatedFloat | None = None


class EmissionAngular(SchemaModel):
    """Angular emission model. The dialect supports ``collimated`` (a beam) and
    ``cone`` (uniform in solid angle within ``half_angle_deg`` about the port
    direction — a fluorophore emitting into an objective's acceptance cone)."""

    type: str = "collimated"
    half_angle_deg: float | None = None


class EmissionSpec(SchemaModel):
    """Physical emission model of a source component (canvas spec §9.5).

    Beam radius, divergence, spectrum, and flux are properties of the module —
    unlike ray counts (numerical ``trace_quality`` policy) and unlike a
    sequential path's EPD (analysis configuration). A record with this block
    emits exactly one ``Source3`` at ``port``, however many paths reference it.
    """

    port: str = ""
    spectrum: list[EmissionLine] = Field(default_factory=list)
    spatial: EmissionSpatial = Field(default_factory=EmissionSpatial)
    angular: EmissionAngular = Field(default_factory=EmissionAngular)
    flux: float = 1.0


class OpticsSpec(SchemaModel):
    """Optical description of a component: fragment + datum frames + ports."""

    fragment: FragmentSpec | None = None
    frames: dict[str, FrameSpec] = Field(default_factory=dict)
    ports: dict[str, PortSpec] = Field(default_factory=dict)
    # Component sits in a beam path but contributes no surfaces (window/aperture).
    passthrough: bool = False
    # Physical emission model; present marks the component as a source (§9.5).
    emission: EmissionSpec | None = None


class EnvelopeSpec(SchemaModel):
    """Bounding box of a mechanical template, in mm."""

    model_config = SchemaModel.model_config | {"alias_generator": _dashed}

    x_mm: TemplatedFloat = 0.0
    y_mm: TemplatedFloat = 0.0
    z_mm: TemplatedFloat = 0.0


class GeneratorSpec(SchemaModel):
    """Generative (T3) geometry source: a CadQuery script plus its parameters."""

    script: str = ""
    params: dict[str, Any] = Field(default_factory=dict)


TemplateClass = Literal["fixed", "adaptive", "generative"]


class TemplateSpec(SchemaModel):
    """Mechanical template classification (T1 fixed / T2 adaptive / T3 generative)."""

    class_: TemplateClass = Field(alias="class")
    envelope: EnvelopeSpec = Field(default_factory=EnvelopeSpec)
    generator: GeneratorSpec | None = None


DofKind = Literal["translation", "rotation", "parameter"]


class DofSpec(SchemaModel):
    """A declared degree of freedom — the load-bearing block of the whole system.

    The same entry is consumed by optimization (bounds), CAD (offset/regeneration),
    firmware (``actuatable`` + axis binding), and calibration (design / optimized /
    measured values).
    """

    name: str
    kind: DofKind = "translation"
    axis: str = ""  # x|y|z for translation/rotation kinds
    range: tuple[TemplatedFloat, TemplatedFloat] | None = None
    resolution: TemplatedFloat | None = None
    unit: str = "mm"
    actuatable: bool = False
    #: WP-42 (E2 ask #9): what the DOF actually moves. ``pivot_frame`` names the
    #: frame the DOF rotates/translates about (a galvo mirror's pivot, a stage's
    #: reference); ``surface`` is the fragment surface index it drives (which
    #: mirror of a dual-axis galvo). Both optional — an unbound DOF still means
    #: "the whole component moves along ``axis``", the pre-WP-42 default.
    pivot_frame: str = Field(default="", alias="pivot-frame")
    surface: int | None = None


#: Optical role vocabulary shared with library component records. On design
#: components it is optional; chain inference (WP-4) uses `source` (and
#: `sample`, a secondary emitter) as walk starts and `detector`/`sample` as
#: walk terminals.
KNOWN_CATEGORIES = (
    "lens",
    "mirror",
    "filter",
    "beamsplitter",
    "dichroic",
    "source",
    "detector",
    "sample",
    "stage",
    # WP-47: programmable/structured-light parts. `slm` covers DMD and LCoS
    # (reflective) and LC panels (transmissive); `display` covers screens and
    # diffusers. Both trace as a plane for now — the pattern is NOT simulated,
    # but the record carries pitch/resolution and the surface folds geometry.
    "slm",
    "display",
    # Non-optical first-class parts (WP-30): BOM identity, no optics block.
    # Chain inference skips them naturally (no ports, not start/terminal).
    "electronics",
    "mechanics",
    "other",
)


class CompSpec(SchemaModel):
    """A component of a design (Go: CompSpec, plus optics/template/dof extensions)."""

    type: str = ""
    category: str = ""
    design: str = ""
    primitive: PrimSpec = Field(default_factory=PrimSpec)
    pose: PoseSpec = Field(default_factory=PoseSpec)
    # v0 extensions:
    optics: OpticsSpec | None = None
    template: TemplateSpec | None = None
    dof: list[DofSpec] = Field(default_factory=list)
    #: WP-47 runtime state of a source placement: whether it is emitting, and
    #: which of its record's lines is active. Chain inference skips a source
    #: that is off, so the drawing matches what the bench is actually doing.
    enabled: bool = True
    wavelength_um: float | None = Field(default=None, alias="wavelength-um")
    #: WP-145: what this placement EMITS — the record's source block, carried
    #: onto the design so the trace and the canvas read one number. Typed
    #: here rather than riding `extra="allow"`, which is how the entrance
    #: pupil came to be a hardcoded 10 mm.
    source: SourceSpec | None = None
    #: Programmable surface facts (SLM/display placements, WP-47).
    programmable: ProgrammableSpec | None = None
    # Draft syntax from the corpus: per-component instantiation of a sub-design
    # (variant selection and/or input bindings), and computed-primitive descriptors.
    instantiation: dict[str, Any] = Field(default_factory=dict)
    computation: dict[str, Any] = Field(default_factory=dict)

    @field_validator("pose", "primitive", "instantiation", "computation", mode="before")
    @classmethod
    def _null_is_empty(cls, v: Any) -> Any:
        return {} if v is None else v


class VariantSpec(SchemaModel):
    """A design variant: overlay merged onto the design's components (Go: VariantSpec)."""

    description: str = ""
    components: dict[str, CompSpec] = Field(default_factory=dict)
    # Draft syntax: variant-scoped input declarations.
    inputs: dict[str, Any] = Field(default_factory=dict)

    @field_validator("components", mode="before")
    @classmethod
    def _null_members_are_empty(cls, v: Any) -> Any:
        # Variant overlays may name a component with no body (`mounted-lens:`).
        if isinstance(v, dict):
            return {k: ({} if m is None else m) for k, m in v.items()}
        return {} if v is None else v


class PathSpec(SchemaModel):
    """A named optical path — the netlist entry.

    ``chain`` is an ordered list of port traversals:
    ``"<component>.<port>"`` for terminal stops (source exit, detector entry) or
    ``"<component>.<port-in>><port-out>"`` for pass-through traversals. The same
    component may appear more than once (double-pass systems).

    ``simulation`` holds the path's Optiland global sections (aperture, fields,
    wavelengths) verbatim.
    """

    simulation: dict[str, Any] = Field(default_factory=dict)
    chain: list[str] = Field(default_factory=list)


class FiberSpec(SchemaModel):
    """A fiber link between two ports (WP-46).

    A fiber carries light from ``from_port`` to ``to_port`` WITHOUT a geometric
    constraint: the two components may sit anywhere, at any angle. The optical
    path length is the fiber's own ``length_m``, not the distance between the
    connectors — the compiler advances the unfolded axis by that length and
    resumes at the far port's frame.

    ``core_um``/``na`` describe the guided mode: a multimode fiber re-emits at
    the NA-derived cone half-angle, a single-mode one diffraction-limited.
    """

    model_config = SchemaModel.model_config | {"alias_generator": _dashed}

    #: ``"<component>.<port>"`` at each end (order = propagation direction).
    from_port: str = Field(default="", alias="from")
    to_port: str = Field(default="", alias="to")
    core_um: float | None = None
    na: float | None = None
    length_m: float = 1.0
    #: ``SM`` (single-mode) or ``MM`` (multimode).
    type: Literal["SM", "MM"] = "MM"

    @field_validator("from_port", "to_port")
    @classmethod
    def _port_ref(cls, v: str) -> str:
        if v and "." not in v:
            raise ValueError(f"fiber endpoint {v!r} must be '<component>.<port>'")
        return v

    def divergence_deg(self) -> float:
        """Half-angle the fiber re-emits into (0 for an unspecified SM fiber)."""
        if self.type == "SM" or self.na is None:
            return 0.0
        return math.degrees(math.asin(min(1.0, max(0.0, float(self.na)))))


class ProvenanceSpec(SchemaModel):
    """Optimization/build provenance stamped by tools, never hand-authored."""

    optimized_by: str = ""
    run: str = ""
    merit: dict[str, Any] = Field(default_factory=dict)

    @field_validator("run", mode="before")
    @classmethod
    def _timestamp_as_string(cls, v: Any) -> Any:
        # An unquoted ISO timestamp (`run: 2026-07-14T12:00:00`) is a datetime
        # to ruamel; tools writing plain YAML must not be rejected for it.
        return v.isoformat() if hasattr(v, "isoformat") else v


class DesignDecl(SchemaModel):
    """The root document of ``optikit-design.yml`` (Go: DesignDecl, extended).

    DesignDecl stands for the whole design — components, variants, and
    instantiation; "decl" is short for declaration (the Go struct is called
    DesignDecl, and the YAML file is optikit-design.yml).
    """

    optikit_version: str = Field(default="", alias="optikit-version")
    design: DesignSpec = Field(default_factory=DesignSpec)
    instantiation: InstSpec = Field(default_factory=InstSpec)
    components: dict[str, CompSpec] = Field(default_factory=dict)
    variants: dict[str, VariantSpec] = Field(default_factory=dict)
    # v0 extensions:
    paths: dict[str, PathSpec] = Field(default_factory=dict)
    #: Named fiber links (WP-46) — connections that carry light between two
    #: ports without a geometric constraint.
    fibers: dict[str, FiberSpec] = Field(default_factory=dict)
    provenance: ProvenanceSpec = Field(default_factory=ProvenanceSpec)
    # Draft syntax from the corpus, preserved but not yet interpreted:
    inputs: dict[str, Any] = Field(default_factory=dict)
    relations: dict[str, Any] = Field(default_factory=dict)

    @field_validator("components", mode="before")
    @classmethod
    def _null_members_are_empty(cls, v: Any) -> Any:
        if isinstance(v, dict):
            return {k: ({} if m is None else m) for k, m in v.items()}
        return {} if v is None else v

    @field_validator("relations", "inputs", mode="before")
    @classmethod
    def _null_is_empty(cls, v: Any) -> Any:
        return {} if v is None else v


def parse_chain_entry(entry: str) -> tuple[str, str, str | None]:
    """Split a chain entry into (component, port_in, port_out or None).

    Raises ValueError on malformed entries.
    """
    comp, sep, ports = entry.rpartition(".")
    if not sep or not comp or not ports:
        raise ValueError(f"chain entry {entry!r} is not of the form '<component>.<port>'")
    if ">" in ports:
        port_in, _, port_out = ports.partition(">")
        if not port_in or not port_out:
            raise ValueError(f"chain entry {entry!r} has a malformed '<in>><out>' traversal")
        return comp, port_in, port_out
    return comp, ports, None


def parse_dof_key(key: str) -> tuple[str, str]:
    """Split a dof_values key into (component, dof-name)."""
    comp, sep, dof = key.rpartition(".")
    if not sep or not comp or not dof:
        raise ValueError(f"dof_values key {key!r} is not of the form '<component>.<dof>'")
    return comp, dof
