"""Semantic validation of a DesignDecl, producing typed findings.

Structural validity (types, required fields, non-empty surface lists) is enforced
by the Pydantic models; everything cross-referential or rule-based lives here so
that a structurally parseable document can be diagnosed exhaustively instead of
failing on the first problem. Mirrors and extends the Go reference's ``Check()``
methods.

Error codes are stable API — the CLI, the HTTP service (WP-6), and the frontend
marker panel (WP-15) all key off them.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .common import AXES, AXIS_DIRS, is_template
from .design import (
    KNOWN_COMP_TYPES,
    KNOWN_PRIM_TYPES,
    KNOWN_ROT_TYPES,
    ROT_TYPE_GRID,
    ROT_TYPE_UC2,
    CompSpec,
    DesignDecl,
    RotSpec,
    parse_chain_entry,
    parse_dof_key,
)
from .merge import merged_components

Severity = Literal["error", "warning"]


@dataclass(frozen=True)
class Finding:
    code: str
    severity: Severity
    where: str  # dotted document location, e.g. "components.objective.pose.rotation"
    message: str

    def __str__(self) -> str:
        return f"{self.severity.upper()} {self.code} at {self.where}: {self.message}"


def check(decl: DesignDecl) -> list[Finding]:
    """Run all semantic checks; returns findings sorted by severity then location."""
    findings: list[Finding] = []
    findings += _check_components(decl.components, where="components")
    findings += _check_variants(decl)
    findings += _check_instantiation(decl)
    findings += _check_paths(decl)
    findings += _check_fibers(decl)
    findings += _check_programmable(decl)
    findings.sort(key=lambda f: (f.severity != "error", f.where, f.code))
    return findings


def errors(findings: list[Finding]) -> list[Finding]:
    return [f for f in findings if f.severity == "error"]


# --- components ---------------------------------------------------------------


def _check_components(comps: dict[str, CompSpec], where: str) -> list[Finding]:
    findings: list[Finding] = []
    for comp_id, comp in comps.items():
        w = f"{where}.{comp_id}"
        findings += _check_comp(comp_id, comp, w)
        anchor = comp.pose.translation.anchor
        if anchor and anchor not in comps:
            findings.append(
                Finding(
                    "E_ANCHOR_MISSING",
                    "error",
                    f"{w}.pose.translation",
                    f"component depends on nonexistent translation anchor {anchor!r}",
                )
            )
    findings += _check_anchor_cycles(comps, where)
    return findings


def _check_comp(comp_id: str, comp: CompSpec, w: str) -> list[Finding]:
    findings: list[Finding] = []
    if comp.type and comp.type not in KNOWN_COMP_TYPES:
        findings.append(
            Finding("W_COMP_TYPE", "warning", f"{w}.type", f"unknown component type {comp.type!r}")
        )
    if comp.primitive.type and comp.primitive.type not in KNOWN_PRIM_TYPES:
        findings.append(
            Finding(
                "W_PRIM_TYPE",
                "warning",
                f"{w}.primitive.type",
                f"unknown primitive type {comp.primitive.type!r}",
            )
        )
    findings += _check_rotation(comp.pose.rotation, f"{w}.pose.rotation")
    findings += _check_template(comp, w)
    findings += _check_ports(comp, w)
    return findings


def _check_rotation(rot: RotSpec, w: str) -> list[Finding]:
    findings: list[Finding] = []
    if rot.type not in KNOWN_ROT_TYPES:
        return [Finding("E_ROT_TYPE", "error", w, f"invalid rotation type: {rot.type!r}")]
    if rot.type not in (ROT_TYPE_UC2, ROT_TYPE_GRID):
        return findings
    z = rot.grid.z or "+z"
    x = rot.grid.x or "+x"
    for name, value in (("z", z), ("x", x)):
        if value not in AXIS_DIRS:
            findings.append(
                Finding(
                    "E_ROT_AXIS",
                    "error",
                    f"{w}.grid",
                    f"invalid value for component's {name}-axis: {value!r}",
                )
            )
    if z in AXIS_DIRS and x in AXIS_DIRS and z[1] == x[1]:
        findings.append(
            Finding(
                "E_ROT_COAXIAL",
                "error",
                f"{w}.grid",
                f"component's z and x axes are coaxial: z={z}, x={x}",
            )
        )
    if rot.type == ROT_TYPE_UC2:
        # UC2 cubes stand upright: z may only flip, x must stay horizontal.
        if z not in ("+z", "-z"):
            findings.append(
                Finding(
                    "E_ROT_UC2_Z",
                    "error",
                    f"{w}.grid",
                    f"uc2 rotation requires z in (+z, -z), got {z!r}",
                )
            )
        if x in ("+z", "-z"):
            findings.append(
                Finding(
                    "E_ROT_UC2_X",
                    "error",
                    f"{w}.grid",
                    f"uc2 rotation forbids x in (+z, -z), got {x!r}",
                )
            )
    return findings


def _check_anchor_cycles(comps: dict[str, CompSpec], where: str) -> list[Finding]:
    """The translation digraph must be a forest rooted at the design origin."""
    findings: list[Finding] = []
    state: dict[str, int] = {}  # 0 visiting, 1 done

    def visit(comp_id: str, trail: list[str]) -> None:
        if comp_id not in comps or state.get(comp_id) == 1:
            return
        if state.get(comp_id) == 0:
            cycle = " -> ".join([*trail[trail.index(comp_id) :], comp_id])
            findings.append(
                Finding(
                    "E_ANCHOR_CYCLE",
                    "error",
                    f"{where}.{comp_id}.pose.translation",
                    f"translation anchors form a cycle: {cycle}",
                )
            )
            state[comp_id] = 1
            return
        state[comp_id] = 0
        anchor = comps[comp_id].pose.translation.anchor
        if anchor:
            visit(anchor, [*trail, comp_id])
        state[comp_id] = 1

    for comp_id in comps:
        visit(comp_id, [])
    return findings


# --- template / DOF (T1, T2, T3) ----------------------------------------------


def _check_template(comp: CompSpec, w: str) -> list[Finding]:
    findings: list[Finding] = []
    tpl = comp.template
    if tpl is None:
        return findings
    if tpl.class_ == "fixed" and comp.dof:
        findings.append(
            Finding(
                "E_T1_HAS_DOF",
                "error",
                f"{w}.dof",
                f"template class 'fixed' (T1) must declare zero DOFs, got {len(comp.dof)}",
            )
        )
    if tpl.class_ == "generative" and (tpl.generator is None or not tpl.generator.script):
        findings.append(
            Finding(
                "E_T3_NO_GENERATOR",
                "error",
                f"{w}.template",
                "template class 'generative' (T3) requires template.generator.script",
            )
        )
    if tpl.class_ == "adaptive":
        findings += _check_t2_ranges(comp, w)
    return findings


def _check_t2_ranges(comp: CompSpec, w: str) -> list[Finding]:
    """T2: translation DOF ranges must fit inside the template envelope (± half-extent)."""
    findings: list[Finding] = []
    assert comp.template is not None
    env = comp.template.envelope
    extents = {"x": env.x_mm, "y": env.y_mm, "z": env.z_mm}
    for i, dof in enumerate(comp.dof):
        if dof.kind != "translation" or dof.range is None or dof.axis not in AXES:
            continue
        extent = extents[dof.axis]
        lo, hi = dof.range
        if is_template(extent) or is_template(lo) or is_template(hi) or not extent:
            continue  # unresolved template values / unspecified envelope: checked later
        half = float(extent) / 2.0
        if float(lo) < -half or float(hi) > half:
            findings.append(
                Finding(
                    "E_T2_RANGE_ENVELOPE",
                    "error",
                    f"{w}.dof[{i}]",
                    f"DOF {dof.name!r} range [{lo}, {hi}] mm exceeds the template envelope "
                    f"±{half} mm along {dof.axis}",
                )
            )
    return findings


def _check_ports(comp: CompSpec, w: str) -> list[Finding]:
    findings: list[Finding] = []
    if comp.optics is None:
        return findings
    n_surfaces = len(comp.optics.fragment.surfaces) if comp.optics.fragment else 0
    for name, port in comp.optics.ports.items():
        pw = f"{w}.optics.ports.{name}"
        if isinstance(port.direction, list):
            # WP-39: continuous unit vector — engine-supported, but the schema
            # extension is pending ratification (E2 ask #8).
            findings.append(
                Finding(
                    "W_PORT_DIRECTION_VECTOR", "warning", pw,
                    f"continuous direction {port.direction} needs schema-v0.1 "
                    "ratification (E2 ask #8) — axis literals stay the portable form",
                )
            )
        elif port.direction and port.direction not in AXIS_DIRS:
            findings.append(
                Finding("E_PORT_DIRECTION", "error", pw, f"invalid direction {port.direction!r}")
            )
        if port.frame and port.frame not in comp.optics.frames:
            findings.append(
                Finding(
                    "E_PORT_FRAME", "error", pw, f"port references unknown frame {port.frame!r}"
                )
            )
        if port.after_surface is not None and not 0 <= port.after_surface < max(n_surfaces, 1):
            findings.append(
                Finding(
                    "E_PORT_SURFACE",
                    "error",
                    pw,
                    f"after-surface {port.after_surface} out of range for "
                    f"{n_surfaces} fragment surface(s)",
                )
            )
    return findings


# --- variants / instantiation ---------------------------------------------------


def _check_variants(decl: DesignDecl) -> list[Finding]:
    """Each variant must merge into a components spec that itself passes checks."""
    findings: list[Finding] = []
    for variant_id, variant in decl.variants.items():
        merged = merged_components(decl.components, variant.components)
        findings += _check_components(merged, where=f"variants.{variant_id}(merged).components")
    return findings


def _check_instantiation(decl: DesignDecl) -> list[Finding]:
    findings: list[Finding] = []
    inst = decl.instantiation
    if inst.variant and inst.variant not in decl.variants:
        findings.append(
            Finding(
                "E_VARIANT_UNKNOWN",
                "error",
                "instantiation.variant",
                f"requested variant not found: {inst.variant!r}",
            )
        )
    comps = decl.components
    for key, value in inst.dof_values.items():
        w = f"instantiation.dof_values.{key}"
        try:
            comp_id, dof_name = parse_dof_key(key)
        except ValueError as exc:
            findings.append(Finding("E_DOF_KEY_SYNTAX", "error", w, str(exc)))
            continue
        comp = comps.get(comp_id)
        if comp is None:
            findings.append(
                Finding("E_DOF_UNKNOWN", "error", w, f"unknown component {comp_id!r}")
            )
            continue
        dof = next((d for d in comp.dof if d.name == dof_name), None)
        if dof is None:
            findings.append(
                Finding(
                    "E_DOF_UNKNOWN",
                    "error",
                    w,
                    f"component {comp_id!r} declares no DOF named {dof_name!r}",
                )
            )
            continue
        if dof.range is not None and not is_template(value):
            lo, hi = dof.range
            if not (is_template(lo) or is_template(hi)) and not (
                float(lo) <= float(value) <= float(hi)
            ):
                findings.append(
                    Finding(
                        "E_DOF_VALUE_RANGE",
                        "error",
                        w,
                        f"value {value} outside declared range [{lo}, {hi}] {dof.unit}",
                    )
                )
    return findings


# --- paths ----------------------------------------------------------------------


def _check_paths(decl: DesignDecl) -> list[Finding]:
    findings: list[Finding] = []
    for path_name, path in decl.paths.items():
        for i, entry in enumerate(path.chain):
            w = f"paths.{path_name}.chain[{i}]"
            try:
                comp_id, port_in, port_out = parse_chain_entry(entry)
            except ValueError as exc:
                findings.append(Finding("E_CHAIN_SYNTAX", "error", w, str(exc)))
                continue
            comp = decl.components.get(comp_id)
            if comp is None:
                findings.append(
                    Finding("E_CHAIN_COMPONENT", "error", w, f"unknown component {comp_id!r}")
                )
                continue
            ports = comp.optics.ports if comp.optics else {}
            for port in (port_in, port_out):
                if port is not None and port not in ports:
                    findings.append(
                        Finding(
                            "E_PORT_UNKNOWN",
                            "error",
                            w,
                            f"component {comp_id!r} declares no port {port!r}",
                        )
                    )
        findings += _check_filter_stack(decl, path_name)
    return findings


def _check_filter_stack(decl: DesignDecl, path_name: str) -> list[Finding]:
    """WP-74: does the declared path actually pass light at its wavelength?

    A path whose wavelength is blocked by a filter or lands on the wrong side of
    a dichroic's cut-on carries no light — a real design error the wavelength-
    blind tracer could never catch. Reported once per dead traversal, naming the
    element and the wavelength, so an emission filter fighting the dichroic is a
    finding, not a silently dark image.
    """
    from ..budget import _path_wavelength_um, _traversal_fraction

    path = decl.paths[path_name]
    wl_um = _path_wavelength_um(path)
    if wl_um is None:
        return []  # no declared wavelength → nothing to gate against
    findings: list[Finding] = []
    for i, entry in enumerate(path.chain):
        if ">" not in entry:
            continue
        comp_id = entry.split(".", 1)[0]
        exit_name = entry.split(">", 1)[1]
        comp = decl.components.get(comp_id)
        if comp is None:
            continue
        frac, kind = _traversal_fraction(comp, exit_name, wl_um)
        if frac == 0.0:
            findings.append(
                Finding(
                    "W_FILTER_STACK",
                    "warning",
                    f"paths.{path_name}.chain[{i}]",
                    f"{comp_id}.{exit_name} ({kind or 'surface'}) blocks "
                    f"{wl_um * 1000:.0f} nm — this path carries no light at its wavelength",
                )
            )
    return findings


# --- fibers (WP-46) -------------------------------------------------------------


def _check_fibers(decl: DesignDecl) -> list[Finding]:
    """Fiber endpoints resolve, and both ends are fiber-coupled ports."""
    findings: list[Finding] = []
    for name, fiber in decl.fibers.items():
        where = f"fibers.{name}"
        for side, ref in (("from", fiber.from_port), ("to", fiber.to_port)):
            if not ref:
                findings.append(
                    Finding("E_FIBER_ENDPOINT", "error", where, f"{side!r} endpoint is empty")
                )
                continue
            comp_id, _, port_name = ref.partition(".")
            comp = decl.components.get(comp_id)
            if comp is None:
                findings.append(
                    Finding(
                        "E_FIBER_ENDPOINT",
                        "error",
                        where,
                        f"{side} endpoint {ref!r}: unknown component {comp_id!r}",
                    )
                )
                continue
            ports = comp.optics.ports if comp.optics else {}
            port = ports.get(port_name)
            if port is None:
                findings.append(
                    Finding(
                        "E_FIBER_ENDPOINT",
                        "error",
                        where,
                        f"{side} endpoint {ref!r}: component declares no port {port_name!r}",
                    )
                )
                continue
            if port.coupling != "fiber":
                findings.append(
                    Finding(
                        "W_FIBER_FREE_SPACE_PORT",
                        "warning",
                        where,
                        f"{side} endpoint {ref!r} is a free-space port — declare "
                        "`coupling: fiber` on it if it really takes a connector",
                    )
                )
        if fiber.length_m <= 0:
            findings.append(
                Finding(
                    "E_FIBER_LENGTH",
                    "error",
                    where,
                    f"length-m must be positive, got {fiber.length_m}",
                )
            )
        if fiber.type == "MM" and fiber.na is None:
            findings.append(
                Finding(
                    "W_FIBER_NO_NA",
                    "warning",
                    where,
                    "a multimode fiber without `na` re-emits collimated — declare its NA",
                )
            )
    return findings


# --- programmable surfaces (WP-47) ----------------------------------------------


def _check_programmable(decl: DesignDecl) -> list[Finding]:
    """A programmable block on a PLACEMENT must be internally consistent.

    Note what is NOT checked here: whether an ``slm``/``display`` placement
    carries a block at all. Pixel pitch and resolution are facts of the
    *record*, not of each placement — a design references the record and must
    not duplicate it. ``library validate`` enforces that records carry them
    (E_RECORD_PROGRAMMABLE_MISSING); a design may override selectively.
    """
    findings: list[Finding] = []
    for comp_id, comp in decl.components.items():
        where = f"components.{comp_id}.programmable"
        prog = comp.programmable
        if prog is None:
            continue
        if prog.pixel_pitch_um is None or prog.pixel_pitch_um <= 0:
            findings.append(
                Finding(
                    "E_PROGRAMMABLE_PITCH",
                    "error",
                    where,
                    "pixel-pitch-um must be a positive number",
                )
            )
        if prog.resolution is None or any(int(n) <= 0 for n in prog.resolution):
            findings.append(
                Finding(
                    "E_PROGRAMMABLE_RESOLUTION",
                    "error",
                    where,
                    "resolution must be [width, height] in positive pixels",
                )
            )
        if prog.fill_factor is not None and not 0 < prog.fill_factor <= 1:
            findings.append(
                Finding(
                    "W_PROGRAMMABLE_FILL",
                    "warning",
                    where,
                    f"fill-factor {prog.fill_factor} is outside (0, 1]",
                )
            )
    return findings
