"""Shared scalar and vector types for the design schema.

Semantics mirror the Go reference (github.com/openUC2/optikit,
exp/designs/geometry.go + designs-decl.go); this package is the normative
implementation and the Go repo conforms to it (see kicad-for-optics-execution.md).

Any numeric leaf may instead hold a Go-template interpolation string like
``'{{get inputs "lens-offset-x"}}'`` — the parametric-design draft syntax used in
the example corpus. Such values are preserved verbatim and skipped by numeric
semantic checks until instantiation resolves them.
"""

from __future__ import annotations

import re
from typing import Annotated, Any

from pydantic import BaseModel, ConfigDict, field_validator
from pydantic.functional_validators import AfterValidator

TEMPLATE_RE = re.compile(r"\{\{.*\}\}", re.DOTALL)


def is_template(value: Any) -> bool:
    """True if the value is a template-interpolation string rather than a literal."""
    return isinstance(value, str) and TEMPLATE_RE.search(value) is not None


def _check_templated_str(v: str) -> str:
    if not TEMPLATE_RE.search(v):
        raise ValueError(
            f"string {v!r} is not a template interpolation (expected '{{{{ ... }}}}')"
        )
    return v


TemplateStr = Annotated[str, AfterValidator(_check_templated_str)]

# Numeric leaves: literal number, or a template string resolved at instantiation time.
TemplatedFloat = float | int | TemplateStr
TemplatedInt = int | TemplateStr

# Axis direction names, exactly the six used by the Go reference.
AXIS_DIRS = ("+x", "-x", "+y", "-y", "+z", "-z")
AXES = ("x", "y", "z")


class SchemaModel(BaseModel):
    """Base for all schema models.

    ``extra="allow"`` keeps unknown keys so that (a) draft syntax in existing designs
    survives a load→dump round trip losslessly and (b) newer documents degrade
    gracefully in older tools. Semantic errors are reported by ``checks.check()``,
    not by structural parsing.
    """

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
        validate_assignment=True,
        # Keep infinities (flat surfaces use radius: .inf) instead of nulling them.
        ser_json_inf_nan="constants",
    )

    def dump(self) -> dict[str, Any]:
        """Dump to plain data using YAML key aliases, omitting unset fields."""
        return self.model_dump(mode="json", by_alias=True, exclude_unset=True)


class DiscreteXYZ(SchemaModel):
    """Integer vector, e.g. ``offset-grid: {x: 1, y: 0, z: -2}`` (units: grid cells)."""

    x: TemplatedInt = 0
    y: TemplatedInt = 0
    z: TemplatedInt = 0

    @field_validator("x", "y", "z", mode="before")
    @classmethod
    def _no_float_cells(cls, v: Any) -> Any:
        if isinstance(v, float) and not v.is_integer():
            raise ValueError(f"grid offsets must be integers, got {v}")
        return int(v) if isinstance(v, float) else v


class ContinuousXYZ(SchemaModel):
    """Float vector, e.g. ``offset-mm: {x: -80}`` (units given by the field name)."""

    x: TemplatedFloat = 0.0
    y: TemplatedFloat = 0.0
    z: TemplatedFloat = 0.0
