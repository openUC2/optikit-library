"""Variant overlay merging, mirroring the Go reference's ``Merged`` semantics.

Go uses ``cmp.Or(overlay, base)`` per field: the overlay value wins iff it is
non-zero. The same rule is applied here field-by-field, including its known quirk
that an overlay cannot reset a field back to its zero value (e.g. an offset of 0
never overrides a non-zero base offset).
"""

from __future__ import annotations

from typing import TypeVar

from .common import ContinuousXYZ, DiscreteXYZ
from .design import (
    CompSpec,
    DesignDecl,
    InstSpec,
    PoseSpec,
    PrimSpec,
    RotGridSpec,
    RotSpec,
    TranslSpec,
)

T = TypeVar("T")


def _or(overlay: T, base: T) -> T:
    """Go's cmp.Or: overlay if it is non-zero-valued, else base."""
    return overlay if overlay else base


def merged_xyz_int(base: DiscreteXYZ, overlay: DiscreteXYZ) -> DiscreteXYZ:
    return DiscreteXYZ(
        x=_or(overlay.x, base.x), y=_or(overlay.y, base.y), z=_or(overlay.z, base.z)
    )


def merged_xyz_float(base: ContinuousXYZ, overlay: ContinuousXYZ) -> ContinuousXYZ:
    return ContinuousXYZ(
        x=_or(overlay.x, base.x), y=_or(overlay.y, base.y), z=_or(overlay.z, base.z)
    )


def merged_rot(base: RotSpec, overlay: RotSpec) -> RotSpec:
    return RotSpec(
        type=_or(overlay.type, base.type),
        grid=RotGridSpec(
            z=_or(overlay.grid.z, base.grid.z),
            x=_or(overlay.grid.x, base.grid.x),
        ),
        **{"offset-deg": merged_xyz_float(base.offset_deg, overlay.offset_deg)},
        **{"z-spherical": _or(overlay.z_spherical, base.z_spherical)},
    )


def merged_transl(base: TranslSpec, overlay: TranslSpec) -> TranslSpec:
    return TranslSpec(
        anchor=_or(overlay.anchor, base.anchor),
        **{"offset-grid": merged_xyz_int(base.offset_grid, overlay.offset_grid)},
        **{"offset-mm": merged_xyz_float(base.offset_mm, overlay.offset_mm)},
    )


def merged_pose(base: PoseSpec, overlay: PoseSpec) -> PoseSpec:
    return PoseSpec(
        rotation=merged_rot(base.rotation, overlay.rotation),
        translation=merged_transl(base.translation, overlay.translation),
    )


def merged_prim(base: PrimSpec, overlay: PrimSpec) -> PrimSpec:
    return PrimSpec(
        type=_or(overlay.type, base.type),
        model=_or(overlay.model, base.model),
        function=_or(overlay.function, base.function),
        inputs=_or(overlay.inputs, base.inputs),
    )


def merged_comp(base: CompSpec, overlay: CompSpec) -> CompSpec:
    """Merge one component overlay onto a base component (Go: CompSpec.Merged)."""
    return CompSpec(
        type=_or(overlay.type, base.type),
        design=_or(overlay.design, base.design),
        primitive=merged_prim(base.primitive, overlay.primitive),
        pose=merged_pose(base.pose, overlay.pose),
        # v0 extension fields overlay wholesale (they are authored, not diffed):
        optics=overlay.optics if overlay.optics is not None else base.optics,
        template=overlay.template if overlay.template is not None else base.template,
        dof=overlay.dof or base.dof,
        instantiation=_or(overlay.instantiation, base.instantiation),
        computation=_or(overlay.computation, base.computation),
    )


def merged_components(
    base: dict[str, CompSpec], overlay: dict[str, CompSpec]
) -> dict[str, CompSpec]:
    """Apply a variant's component overlay (Go: CompsSpec.Merged)."""
    merged = dict(base)
    for comp_id, over in overlay.items():
        if comp_id in merged:
            merged[comp_id] = merged_comp(merged[comp_id], over)
        else:
            merged[comp_id] = over
    return merged


def instantiate(decl: DesignDecl, instantiation: InstSpec | None = None) -> dict[str, CompSpec]:
    """Return the components with the requested variant applied (Go: Instantiate).

    With no variants declared, or an empty variant selection, the base components
    are returned. Requesting a variant that does not exist raises KeyError.
    """
    inst = instantiation if instantiation is not None else decl.instantiation
    if not inst.variant:
        return dict(decl.components)
    if inst.variant not in decl.variants:
        raise KeyError(f"requested variant not found: {inst.variant}")
    return merged_components(decl.components, decl.variants[inst.variant].components)
