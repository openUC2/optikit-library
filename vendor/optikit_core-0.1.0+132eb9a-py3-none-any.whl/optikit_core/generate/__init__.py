"""Generative (T3) template harness: CadQuery generators → STEP/STL/GLB artifacts."""

from .beam import bores_from_ports, derive_beam_params
from .harness import (
    GenerateError,
    GenerateResult,
    canonicalize,
    generate,
    generate_all,
    params_key,
    pose_params_from_component,
    resolve_generator,
    validate_params,
)

__all__ = [
    "GenerateError",
    "GenerateResult",
    "bores_from_ports",
    "canonicalize",
    "derive_beam_params",
    "generate",
    "generate_all",
    "params_key",
    "pose_params_from_component",
    "resolve_generator",
    "validate_params",
]
