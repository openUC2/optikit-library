"""Headless generator runner — executed inside the CadQuery environment.

Deliberately dependency-free apart from cadquery itself (stdlib + cadquery),
because the harness may run it as a standalone script in a *separate*
interpreter (``uv run --no-project --with cadquery``) when cadquery has no
wheel for the interpreter optikit-core runs on.

Usage (as a script):

    python _runner.py <generator.py> <params.json> <out-dir>

Writes into ``<out-dir>``: ``model.step``, ``model.stl``, ``model.glb``,
``meta.json`` (bounding box + envelope verdict). The exit code is non-zero on
any failure, with the error on stderr.
"""

from __future__ import annotations

import importlib.util
import json
import math
import sys
from pathlib import Path

#: The UC2 1x1 cube envelope every generated insert must fit (mm).
ENVELOPE_MM = (50.0, 50.0, 50.0)

STL_LINEAR_TOL = 0.05
STL_ANGULAR_TOL_DEG = 5.0


def _load_module(generator_path: Path):  # noqa: ANN202
    spec = importlib.util.spec_from_file_location(generator_path.stem, generator_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load generator module {generator_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not callable(getattr(module, "build", None)):
        raise RuntimeError(
            f"{generator_path.name} does not expose build(params) -> cq.Workplane"
        )
    return module


def _bbox_of(part) -> dict:  # noqa: ANN001
    bb = part.val().BoundingBox()
    return {
        "min": [bb.xmin, bb.ymin, bb.zmin],
        "max": [bb.xmax, bb.ymax, bb.zmax],
        "size": [bb.xmax - bb.xmin, bb.ymax - bb.ymin, bb.zmax - bb.zmin],
    }


def _export_part(part, out_dir: Path, basename: str, label: str) -> None:  # noqa: ANN001
    import cadquery as cq

    cq.exporters.export(part, str(out_dir / f"{basename}.step"))
    cq.exporters.export(
        part,
        str(out_dir / f"{basename}.stl"),
        tolerance=STL_LINEAR_TOL,
        angularTolerance=math.radians(STL_ANGULAR_TOL_DEG),
    )
    assembly = cq.Assembly(part, name=label)
    exporter = getattr(assembly, "export", None) or assembly.save  # save: cq<=2.8
    exporter(str(out_dir / f"{basename}.glb"))


def run(
    generator_path: Path,
    params: dict,
    out_dir: Path,
    envelope_mm: tuple[float, float, float] | None = None,
) -> dict:
    """Build and export STEP + STL + GLB + meta.json into ``out_dir``.

    Generators exposing ``build_parts(params) -> dict[str, Workplane]`` (e.g.
    the two halves of a printable holder) get one artifact set per part
    (``model.<name>.step`` …); the envelope check runs on the union bbox.
    ``envelope_mm`` is the template's declared envelope — a multi-cell carrier
    (a 3x4 sandwich plate, WP-53) is bigger than one cube on purpose. Default:
    the 1x1 cube.
    """
    envelope = tuple(envelope_mm) if envelope_mm else ENVELOPE_MM
    module = _load_module(generator_path)
    out_dir.mkdir(parents=True, exist_ok=True)

    build_parts = getattr(module, "build_parts", None)
    if callable(build_parts):
        parts: dict = build_parts(params)
    else:
        parts = {"": module.build(params)}

    part_meta: dict[str, dict] = {}
    lo = [float("inf")] * 3
    hi = [float("-inf")] * 3
    for name, part in parts.items():
        basename = f"model.{name}" if name else "model"
        # bbox BEFORE export: STL tessellation attaches a triangulation that
        # OCC's bound computation then prefers, inflating the box by the mesh
        # deflection (several mm on a coarse spherical face, WP-62).
        bbox = _bbox_of(part)
        _export_part(part, out_dir, basename, name or generator_path.stem)
        part_meta[name or "model"] = bbox
        lo = [min(a, b) for a, b in zip(lo, bbox["min"], strict=True)]
        hi = [max(a, b) for a, b in zip(hi, bbox["max"], strict=True)]

    # WP-61: multi-part generators additionally export the UNION as the plain
    # model.{step,glb} pair — the render mesh + mechanical source a
    # materialized template ships (the per-half files stay the print files).
    if callable(build_parts) and len(parts) > 1:
        it = iter(parts.values())
        union = next(it)
        for part in it:
            union = union.union(part)
        import cadquery as cq

        cq.exporters.export(union, str(out_dir / "model.step"))
        assembly = cq.Assembly(union, name=generator_path.stem)
        exporter = getattr(assembly, "export", None) or assembly.save  # save: cq<=2.8
        exporter(str(out_dir / "model.glb"))

    size = [b - a for a, b in zip(lo, hi, strict=True)]
    meta = {
        "generator": generator_path.name,
        "params": params,
        "parts": part_meta,
        "bbox_mm": {"min": lo, "max": hi, "size": size},
        "envelope_mm": list(envelope),
        # 10 µm slop: OCC bounding boxes of filleted shapes overshoot the
        # nominal size by ~1 µm-scale artifacts; mechanically meaningless.
        "fits_envelope": all(s <= e + 1e-2 for s, e in zip(size, envelope, strict=True)),
    }
    (out_dir / "meta.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    return meta


def main(argv: list[str]) -> int:
    if len(argv) not in (3, 4):
        print(
            "usage: _runner.py <generator.py> <params.json> <out-dir> [envelope-json]",
            file=sys.stderr,
        )
        return 2
    generator_path = Path(argv[0])
    params = json.loads(Path(argv[1]).read_text(encoding="utf-8"))
    envelope = tuple(json.loads(argv[3])) if len(argv) == 4 else None
    try:
        meta = run(generator_path, params, Path(argv[2]), envelope_mm=envelope)
    except Exception as exc:  # noqa: BLE001 — boundary: report and fail the process
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(meta))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
