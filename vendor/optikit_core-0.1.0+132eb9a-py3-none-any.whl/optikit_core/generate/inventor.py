"""WP-85: the T2 parametric-insert loop — optikit-core's Inventor-bridge client.

The T3 road generates mechanics with CadQuery; the T2 road PARAMETERIZES a
real Inventor master insert. The scripts on the Inventor machine
(``PyInventor/apply_fx_params.py`` + ``batch_iam_to_stp_glb.py``) close that
loop by hand — verified by the WP-85 human test
(``DOCS/INVENTOR-T2-BRIDGE.md``) — and ``PyInventor/inventor_bridge.py``
makes them callable over HTTP. This module is the optikit side:

1. **fx derivation** — the ``pocket_params`` → fx wiring that existed with no
   caller becomes the input: a lens's own prescription derives the insert's
   fx user parameters (``lens_diameter`` · ``radius`` · ``thickness`` ·
   ``edge_thickness``), and the placement's dof values (``dz`` …) ride along
   under their own names (the fx name IS the dof name — the WP-35 contract).
2. **the changeset** — everything travels as a standard ``optikit-fx/v0``
   changeset, the exact format ``apply_fx_params.py`` already consumes, so
   the bridge is a thin wrapper around the human-verified path.
3. **the run** — POST to the bridge (``OPTIKIT_INVENTOR_BRIDGE``), store the
   returned STP/GLB trio under ``out/<template-id>/<key>/`` exactly like a
   T3 generator run (sha256-keyed canonical params → identical parameters
   are a cache hit, no Inventor round trip).

No bridge configured (or unreachable) is a TYPED error naming the fallback —
the editor then offers "download the fx changeset", which already works.
"""

from __future__ import annotations

import base64
import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from ..annotate.fx import FX_SCHEMA
from ..library.pocket import pocket_params_from_surfaces
from ..library.sag import surface_radius
from ..schema.library import TemplateRecord
from .harness import GenerateResult, canonicalize, params_key

#: The bridge's base URL, e.g. ``http://192.168.1.50:8020`` (the FastAPI
#: service on the Inventor/Windows machine).
BRIDGE_ENV = "OPTIKIT_INVENTOR_BRIDGE"

E_NO_BRIDGE = "E_NO_BRIDGE"
E_BRIDGE_UNREACHABLE = "E_BRIDGE_UNREACHABLE"
E_BRIDGE = "E_BRIDGE"

#: The artifact names a bridge run is expected to return (b64-encoded).
ARTIFACT_NAMES = ("model.stp", "model.glb", "thumbnail.png")


class InventorBridgeError(Exception):
    """Typed bridge failure; ``code`` is stable API (the editor's fallback
    trigger)."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code


def bridge_url() -> str | None:
    """The configured bridge, or None (the editor falls back to fx download)."""
    url = os.environ.get(BRIDGE_ENV, "").strip().rstrip("/")
    return url or None


def fx_parameters(
    surfaces: list[dict[str, Any]],
    dof_values: dict[str, float] | None = None,
) -> dict[str, float]:
    """The master insert's fx user parameters from a prescription + DOFs.

    Names follow the naming contract (the Inventor USER PARAMETER NAME is the
    parameter name here): the pocket numbers become ``lens_diameter`` /
    ``thickness`` / ``edge_thickness``, the front-surface ``radius`` rides
    along (0 for plano — a flat pocket seat), and every dof value keeps its
    own name (``dz`` …).
    """
    pocket = pocket_params_from_surfaces(surfaces)
    front_radius = surface_radius(surfaces[0])
    fx: dict[str, float] = {
        "lens_diameter": pocket["lens-diameter-mm"],
        "thickness": pocket["center-thickness-mm"],
        "edge_thickness": pocket["edge-thickness-mm"],
        "radius": 0.0 if front_radius == float("inf") else round(front_radius, 6),
    }
    for name, value in (dof_values or {}).items():
        fx[name] = float(value)
    return fx


def fx_changeset(
    template_id: str, component_key: str, fx: dict[str, float]
) -> dict[str, Any]:
    """The fx parameters as a standard ``optikit-fx/v0`` changeset — the
    exact shape ``apply_fx_params.py`` consumes (parameter name == user
    parameter name, values in mm)."""
    return {
        "schema": FX_SCHEMA,
        "changes": [
            {
                "component": component_key,
                "template-id": template_id,
                "parameter": name,
                "value-mm": float(value),
            }
            for name, value in sorted(fx.items())
        ],
    }


def _post_json(url: str, payload: dict[str, Any], timeout: float) -> dict[str, Any]:
    """POST JSON → JSON; split out so tests can monkeypatch the transport."""
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310
        return json.loads(response.read().decode("utf-8"))


def generate_t2(
    record: TemplateRecord,
    surfaces: list[dict[str, Any]],
    dof_values: dict[str, float] | None = None,
    *,
    component_key: str = "part",
    out_root: str | Path = "out",
    timeout_s: float = 180.0,
) -> GenerateResult:
    """Parameterize the record's Inventor master insert and fetch the trio.

    Mirrors the T3 harness contract: canonical params → sha256 key →
    ``out/<template-id>/<key12>/`` with ``params.json`` + ``meta.json`` +
    the artifacts; an identical request is a cache hit (``regenerated:
    False``) and never touches Inventor.
    """
    if record.class_ != "adaptive":
        raise InventorBridgeError(
            E_BRIDGE, f"{record.id} is class {record.class_!r}, not adaptive (T2)"
        )
    fx = fx_parameters(surfaces, dof_values)
    params = canonicalize({
        "assembly": record.inventor or record.id,
        "fx": fx,
    })
    key = params_key(params)
    out_dir = Path(out_root) / record.id / key
    meta_file = out_dir / "meta.json"
    if meta_file.is_file():
        return GenerateResult(
            record.id, key, out_dir, json.loads(meta_file.read_text("utf-8")), False
        )

    url = bridge_url()
    if url is None:
        raise InventorBridgeError(
            E_NO_BRIDGE,
            f"no Inventor bridge configured — set {BRIDGE_ENV} to the bridge URL "
            "(PyInventor/inventor_bridge.py on the Inventor machine), or download "
            "the fx changeset and apply it there by hand",
        )
    changeset = fx_changeset(record.id, component_key, fx)
    try:
        response = _post_json(
            f"{url}/inventor/apply-fx",
            {
                "assembly": record.inventor or record.id,
                "changeset": changeset,
                "export": True,
            },
            timeout_s,
        )
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        raise InventorBridgeError(
            E_BRIDGE_UNREACHABLE,
            f"Inventor bridge at {url} is unreachable ({exc}) — download the fx "
            "changeset instead and apply it on the Inventor machine",
        ) from exc

    artifacts: dict[str, bytes] = {}
    for name, encoded in (response.get("artifacts") or {}).items():
        if name in ARTIFACT_NAMES and isinstance(encoded, str):
            artifacts[name] = base64.b64decode(encoded)
    if "model.stp" not in artifacts:
        raise InventorBridgeError(
            E_BRIDGE,
            f"bridge returned no model.stp (got: {sorted(response.get('artifacts') or {})}) — "
            f"log: {response.get('log', '')[:400]}",
        )

    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "params.json").write_text(
        json.dumps(params, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    for name, content in artifacts.items():
        (out_dir / name).write_bytes(content)
    meta = {
        "source": "inventor-bridge",
        "assembly": record.inventor or record.id,
        "fx": fx,
        "applied": response.get("applied"),
        "artifacts": sorted(artifacts),
        # The bridge exports a real Inventor assembly — the envelope claim is
        # the record's own; nothing here re-measures it.
        "fits_envelope": True,
    }
    meta_file.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    return GenerateResult(record.id, key, out_dir, meta, True)


__all__ = [
    "ARTIFACT_NAMES",
    "BRIDGE_ENV",
    "E_BRIDGE",
    "E_BRIDGE_UNREACHABLE",
    "E_NO_BRIDGE",
    "InventorBridgeError",
    "bridge_url",
    "fx_changeset",
    "fx_parameters",
    "generate_t2",
]
