"""The 24 axis-aligned rotations and the extrinsic-ZXY Euler convention.

Normative conventions (Go repo and TS frontend conform to these):

- ``rotation.grid`` names which design axis the component's local +z / +x point
  along; the y-axis follows from the right-hand rule (y = z × x). This yields
  exactly 24 proper rotations (Go reference: exp/designs/geometry.go
  ``GridRotMats``, columns = component x/y/z axes in design coordinates).

- ``offset-deg`` / report angles are **extrinsic Z-X-Y** Euler angles in
  degrees: ``R = Rz(θz) · Rx(θx) · Ry(θy)`` — rotations applied about the
  *fixed* design axes in the order y, then x, then z. This matches go3d's
  ``mat4.ExtractEulerAngles`` used by the Go ``PrimReport``
  (internal/optikit/report.go) and the generated ``_primitives:*.yml``
  artifacts, which serve as cross-implementation test fixtures.

- A full component rotation composes as ``R = R24 · ΔR`` with the residual ΔR
  applied in the component's local frame.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

AXIS_DIRS = ("+x", "-x", "+y", "-y", "+z", "-z")

_BASIS: dict[str, np.ndarray] = {
    "+x": np.array([1.0, 0.0, 0.0]),
    "-x": np.array([-1.0, 0.0, 0.0]),
    "+y": np.array([0.0, 1.0, 0.0]),
    "-y": np.array([0.0, -1.0, 0.0]),
    "+z": np.array([0.0, 0.0, 1.0]),
    "-z": np.array([0.0, 0.0, -1.0]),
}


def _build_rot24() -> dict[tuple[str, str], np.ndarray]:
    table: dict[tuple[str, str], np.ndarray] = {}
    for z in AXIS_DIRS:
        for x in AXIS_DIRS:
            if z[1] == x[1]:  # coaxial — invalid
                continue
            zv, xv = _BASIS[z], _BASIS[x]
            yv = np.cross(zv, xv)  # right-hand rule
            table[(z, x)] = np.column_stack([xv, yv, zv])
    return table


#: All 24 valid (z, x) → rotation matrix (3×3, columns = component x/y/z axes).
ROT24: dict[tuple[str, str], np.ndarray] = _build_rot24()


def direction_vector(direction: str | list[float]) -> np.ndarray | None:
    """Resolve a port direction — axis literal OR ``[x, y, z]`` unit vector
    (WP-39) — to a unit ndarray; None when it is neither. The one shared
    resolver: compile, chain inference and checks all speak through it."""
    if isinstance(direction, list) and len(direction) == 3:
        arr = np.asarray(direction, dtype=float)
        n = float(np.linalg.norm(arr))
        return arr / n if n > 1e-9 else None
    if isinstance(direction, str) and len(direction) == 2 and direction in AXIS_DIRS:
        sign = 1.0 if direction[0] == "+" else -1.0
        vec = np.zeros(3)
        vec["xyz".index(direction[1])] = sign
        return vec
    return None


def rot24_matrix(z: str = "+z", x: str = "+x") -> np.ndarray:
    """Rotation matrix for a ``rotation.grid`` naming (empty strings = defaults)."""
    key = (z or "+z", x or "+x")
    if key not in ROT24:
        raise ValueError(f"invalid rot24: z={key[0]!r}, x={key[1]!r}")
    return ROT24[key].copy()


# --- extrinsic-ZXY Euler ---------------------------------------------------------


def euler_zxy_to_matrix(x_deg: float, y_deg: float, z_deg: float) -> np.ndarray:
    """R = Rz(z)·Rx(x)·Ry(y), angles in degrees (extrinsic: y, then x, then z)."""
    x, y, z = map(math.radians, (x_deg, y_deg, z_deg))
    cx, sx = math.cos(x), math.sin(x)
    cy, sy = math.cos(y), math.sin(y)
    cz, sz = math.cos(z), math.sin(z)
    rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return rz @ rx @ ry


def matrix_to_euler_zxy(r: np.ndarray) -> tuple[float, float, float]:
    """Inverse of :func:`euler_zxy_to_matrix`; returns (x, y, z) in degrees.

    Mirrors go3d ``mat4.ExtractEulerAngles`` (including its gimbal-lock branch)
    so reports are bit-comparable with the Go implementation.
    """
    m21 = float(np.clip(r[2, 1], -1.0, 1.0))
    x = math.asin(m21)
    if abs(m21) > 1.0 - 1e-9:  # gimbal lock: y and z axes coincide
        y = 0.0
        z = math.atan2(float(r[1, 0]), float(r[0, 0]))
    else:
        y = math.atan2(-float(r[2, 0]), float(r[2, 2]))
        z = math.atan2(-float(r[0, 1]), float(r[1, 1]))
    return math.degrees(x), math.degrees(y), math.degrees(z)


# --- compose / decompose -----------------------------------------------------------


def compose(z: str, x: str, offset_deg: dict[str, float] | None = None) -> np.ndarray:
    """Full rotation R = R24 · ΔR(offset-deg), the schema's rotation semantics."""
    r24 = rot24_matrix(z, x)
    if not offset_deg:
        return r24
    delta = euler_zxy_to_matrix(
        float(offset_deg.get("x", 0.0)),
        float(offset_deg.get("y", 0.0)),
        float(offset_deg.get("z", 0.0)),
    )
    return r24 @ delta


@dataclass(frozen=True)
class Rot24Decomposition:
    z: str
    x: str
    #: Residual ΔR such that R = R24 · ΔR (in the component's local frame).
    residual: np.ndarray
    #: Residual as extrinsic-ZXY degrees, ready for ``rotation.offset-deg``.
    offset_deg: dict[str, float]

    @property
    def residual_angle_deg(self) -> float:
        """Total rotation angle of the residual (0 = exactly on a grid rotation)."""
        trace = float(np.trace(self.residual))
        return math.degrees(math.acos(np.clip((trace - 1.0) / 2.0, -1.0, 1.0)))


def decompose(r: np.ndarray) -> Rot24Decomposition:
    """Split an arbitrary rotation into the nearest of the 24 plus a residual.

    "Nearest" minimizes the residual rotation angle, i.e. maximizes
    trace(R24ᵀ·R).
    """
    best_key: tuple[str, str] | None = None
    best_trace = -np.inf
    for key, r24 in ROT24.items():
        t = float(np.trace(r24.T @ r))
        if t > best_trace:
            best_trace = t
            best_key = key
    assert best_key is not None
    z, x = best_key
    residual = ROT24[best_key].T @ r
    ex, ey, ez = matrix_to_euler_zxy(residual)
    return Rot24Decomposition(
        z=z, x=x, residual=residual, offset_deg={"x": ex, "y": ey, "z": ez}
    )


def quaternion_to_matrix(q: list[float] | tuple[float, float, float, float]) -> np.ndarray:
    """[x, y, z, w] → a 3×3 rotation matrix.

    WP-140: the Go reference gained a first-class ``quaternion`` rotation
    type. We accept it on the wire and decompose it back into the grid +
    residual spelling the editors read.
    """
    x, y, z, w = (float(c) for c in q)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def rotation_angle_deg(r: np.ndarray) -> float:
    """Total rotation angle of a rotation matrix, degrees."""
    return math.degrees(math.acos(np.clip((float(np.trace(r)) - 1.0) / 2.0, -1.0, 1.0)))
