"""Geometry engine: 24-rotations, anchor flattening, cubify + DRC."""

from .cubify import (
    CubifiedPose,
    CubifyResult,
    DrcFinding,
    cubify,
    cubify_pose,
    drc,
)
from .flatten import (
    FlatEntry,
    FlatPose,
    FlattenError,
    SubdesignLoader,
    flat_design_report,
    flat_report,
    flatten,
)
from .rotations import (
    AXIS_DIRS,
    ROT24,
    Rot24Decomposition,
    compose,
    decompose,
    euler_zxy_to_matrix,
    matrix_to_euler_zxy,
    rot24_matrix,
    rotation_angle_deg,
)

__all__ = [
    "AXIS_DIRS",
    "ROT24",
    "CubifiedPose",
    "CubifyResult",
    "DrcFinding",
    "FlatEntry",
    "FlatPose",
    "FlattenError",
    "Rot24Decomposition",
    "compose",
    "cubify",
    "cubify_pose",
    "decompose",
    "drc",
    "euler_zxy_to_matrix",
    "SubdesignLoader",
    "flat_design_report",
    "flat_report",
    "flatten",
    "matrix_to_euler_zxy",
    "rot24_matrix",
    "rotation_angle_deg",
]
