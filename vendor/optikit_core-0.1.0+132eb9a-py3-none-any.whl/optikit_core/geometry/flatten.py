"""Resolve the translation anchor digraph to absolute world poses.

Mirrors the semantics of the Go reference (exp/designs/designs-.go, as of
``origin/subassemblies``, synced 2026-07-17 — WP-36):

- **anchor chains** (``CompsSpec.TranslFlattened()``): translations accumulate
  along the chain with grid and mm offsets kept separate; **rotations do not
  compose along the chain** — a component's rotation is always relative to its
  own design's frame. Ethan's rename ``Flattened → TranslFlattened`` codifies
  exactly this contract.
- **subassembly boundaries** (``FSDesign.Flattened()``, new on the branch):
  the FULL 4×4 transform composes — a subassembly's rotation rotates its
  children: ``M_world = M_parent · M_child``. Component ids join with ``/``
  and primitive model paths are prefixed with the subdesign path
  (:func:`flat_design_report`).

Deviation from Go, deliberate: a component with rotation type ``""`` (no
spatial geometry) reports the identity rotation rather than Go's degenerate
zero matrix. The grid-pitch constant (E1) is fixed on Ethan's branch — both
implementations now use (50, 50, 55) mm.
"""

from __future__ import annotations

import math
import posixpath
from dataclasses import dataclass, field
from typing import Any, Protocol

import numpy as np

from ..constants import UC2_GRID_MM
from ..schema.common import is_template
from ..schema.design import KNOWN_ROT_TYPES, CompSpec, parse_dof_key
from .rotations import compose, matrix_to_euler_zxy


class FlattenError(Exception):
    """Typed flattening failure; ``code`` is stable API."""

    def __init__(self, code: str, comp_id: str, message: str) -> None:
        super().__init__(f"{code} at component {comp_id!r}: {message}")
        self.code = code
        self.comp_id = comp_id


@dataclass
class FlatPose:
    """Absolute pose of one component in the design frame."""

    #: Accumulated integer grid offset (kept separate, as in Go).
    offset_grid: tuple[int, int, int]
    #: Accumulated continuous offset, mm.
    offset_mm: tuple[float, float, float]
    #: 3×3 rotation matrix (R24 · ΔR from offset-deg).
    rotation: np.ndarray

    @property
    def position_mm(self) -> tuple[float, float, float]:
        g, mm, s = self.offset_grid, self.offset_mm, UC2_GRID_MM
        return (g[0] * s[0] + mm[0], g[1] * s[1] + mm[1], g[2] * s[2] + mm[2])


def _numeric(value: Any, comp_id: str, what: str) -> float:
    if isinstance(value, bool) or not isinstance(value, int | float):
        if is_template(value):
            raise FlattenError(
                "E_TEMPLATED",
                comp_id,
                f"{what} holds unresolved template {value!r}; instantiate first",
            )
        raise FlattenError("E_BAD_VALUE", comp_id, f"{what} is not a number: {value!r}")
    return float(value)


def _rotation_matrix(comp_id: str, comp: CompSpec) -> np.ndarray:
    # WP-140: a `quaternion` rotation (Go @21dc193) is normalized to the
    # equivalent grid + offset-deg on the way in — one resolver, and the
    # discrete state the editors read is recovered rather than lost.
    rot = comp.pose.rotation.normalized()
    if rot.type not in KNOWN_ROT_TYPES or rot.type == "z-spherical":
        if rot.type == "z-spherical":
            raise FlattenError(
                "E_ROT_UNSUPPORTED", comp_id, "z-spherical rotations are not resolved yet"
            )
        raise FlattenError("E_ROT_UNSUPPORTED", comp_id, f"rotation type {rot.type!r}")
    offset_deg = {
        "x": _numeric(rot.offset_deg.x, comp_id, "offset-deg.x"),
        "y": _numeric(rot.offset_deg.y, comp_id, "offset-deg.y"),
        "z": _numeric(rot.offset_deg.z, comp_id, "offset-deg.z"),
    }
    # type "" = no spatial geometry: identity keeps the report well-defined.
    return compose(rot.grid.z, rot.grid.x, offset_deg)


def flatten(components: dict[str, CompSpec]) -> dict[str, FlatPose]:
    """Anchor-resolve every component to an absolute pose.

    Raises :class:`FlattenError` with code ``E_ANCHOR_MISSING`` or
    ``E_ANCHOR_CYCLE`` (or ``E_TEMPLATED`` for unresolved parametric values).
    """
    poses: dict[str, FlatPose] = {}

    Vec3i = tuple[int, int, int]
    Vec3f = tuple[float, float, float]

    def resolve(comp_id: str, trail: tuple[str, ...]) -> tuple[Vec3i, Vec3f]:
        if comp_id in trail:
            cycle = " -> ".join([*trail[trail.index(comp_id):], comp_id])
            raise FlattenError(
                "E_ANCHOR_CYCLE", comp_id, f"translation anchors form a cycle: {cycle}"
            )
        comp = components.get(comp_id)
        if comp is None:
            raise FlattenError("E_ANCHOR_MISSING", trail[-1] if trail else comp_id,
                               f"nonexistent translation anchor {comp_id!r}")
        t = comp.pose.translation
        gx = int(_numeric(t.offset_grid.x, comp_id, "offset-grid.x"))
        gy = int(_numeric(t.offset_grid.y, comp_id, "offset-grid.y"))
        gz = int(_numeric(t.offset_grid.z, comp_id, "offset-grid.z"))
        mx = _numeric(t.offset_mm.x, comp_id, "offset-mm.x")
        my = _numeric(t.offset_mm.y, comp_id, "offset-mm.y")
        mz = _numeric(t.offset_mm.z, comp_id, "offset-mm.z")
        if t.anchor:
            (ax, ay, az), (amx, amy, amz) = resolve(t.anchor, (*trail, comp_id))
            return (gx + ax, gy + ay, gz + az), (mx + amx, my + amy, mz + amz)
        return (gx, gy, gz), (mx, my, mz)

    for comp_id, comp in components.items():
        grid, mm = resolve(comp_id, ())
        poses[comp_id] = FlatPose(
            offset_grid=grid, offset_mm=mm, rotation=_rotation_matrix(comp_id, comp)
        )
    return poses


# --- DOF application (shared by compile and canvas materialize) --------------------

_DOF_AXIS_VEC = {
    "x": np.array([1.0, 0.0, 0.0]),
    "y": np.array([0.0, 1.0, 0.0]),
    "z": np.array([0.0, 0.0, 1.0]),
}


def axis_rotation(axis: str, angle_rad: float) -> np.ndarray:
    """3×3 rotation about a local +x/+y/+z axis (WP-80 rotation DOFs)."""
    c, s = math.cos(angle_rad), math.sin(angle_rad)
    if axis == "x":
        return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
    if axis == "y":
        return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def apply_dof_values(
    components: dict[str, CompSpec],
    poses: dict[str, FlatPose],
    dof_values: dict[str, Any],
    warnings: list[str],
) -> None:
    """Apply DOF values to poses: a translation displaces the component along
    its local axis; a rotation (WP-80) tilts it about a local axis.

    One implementation for BOTH engines: compile's sequential unfolding and
    the canvas Scene3 materializer must move a dragged insert identically, or
    the kernel preview and ``/v1/simulate`` disagree about where the glass is.
    """
    for key, value in dof_values.items():
        if is_template(value):
            continue
        try:
            comp_id, dof_name = parse_dof_key(key)
        except ValueError:
            continue  # schema checks report these
        comp = components.get(comp_id)
        pose = poses.get(comp_id)
        if comp is None or pose is None:
            continue
        dof = next((d for d in comp.dof if d.name == dof_name), None)
        if dof is None:
            continue
        if dof.axis not in ("x", "y", "z"):
            warnings.append(f"dof_values {key}: DOF axis {dof.axis!r} is not x/y/z — ignored")
            continue
        if dof.kind == "translation":
            axis = pose.rotation @ _DOF_AXIS_VEC[dof.axis]
            shifted = np.array(pose.position_mm) + axis * float(value)
            grid = pose.offset_grid
            poses[comp_id] = FlatPose(
                offset_grid=grid,
                offset_mm=tuple(
                    shifted[i] - grid[i] * UC2_GRID_MM[i] for i in range(3)
                ),  # type: ignore[arg-type]
                rotation=pose.rotation,
            )
        elif dof.kind == "rotation":
            # WP-80: a rotation DOF tilts the component in its LOCAL frame — the
            # ports and datum frames swing rigidly with it, so the downstream
            # geometry follows (a kinematic mount, a tip/tilt platform, a
            # rotation stage). NOTE: this is a rigid θ rotation of the element;
            # a FOLD mirror's 2θ reflection-law doubling is not applied, because
            # the compiler unfolds folds using authored port directions rather
            # than computed surface normals — tracked as a follow-on. The
            # per-surface `dof.surface` case (a dual-axis galvo) rides the same
            # limitation and rotates the whole component today.
            r_local = axis_rotation(dof.axis, math.radians(float(value)))
            poses[comp_id] = FlatPose(
                offset_grid=pose.offset_grid,
                offset_mm=pose.offset_mm,
                rotation=pose.rotation @ r_local,
            )
        else:
            warnings.append(f"dof_values {key}: DOF kind {dof.kind!r} does not move a pose")


# --- FlatReport (the Go PrimReport analogue) ---------------------------------------


@dataclass
class FlatEntry:
    """One primitive in the report. Field names match the Go ``PrimReport``
    (type/model/position/rotation{type,order,angles}); ``id`` is additive."""

    id: str
    type: str
    model: str
    position: tuple[float, float, float]
    rotation: dict[str, Any] = field(default_factory=dict)

    def dump(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type,
            "model": self.model,
            "position": list(self.position),
            "rotation": self.rotation,
        }


def flat_report(components: dict[str, CompSpec]) -> list[FlatEntry]:
    """World pose per primitive component, sorted by id (Go: ReportPrimitives)."""
    poses = flatten(components)
    entries: list[FlatEntry] = []
    for comp_id in sorted(components):
        comp = components[comp_id]
        if comp.type != "primitive":
            continue
        pose = poses[comp_id]
        ex, ey, ez = matrix_to_euler_zxy(pose.rotation)
        angles: dict[str, float] = {}
        if abs(ex) > 1e-12:
            angles["x"] = ex
        if abs(ey) > 1e-12:
            angles["y"] = ey
        if abs(ez) > 1e-12:
            angles["z"] = ez
        entries.append(
            FlatEntry(
                id=comp_id,
                type=comp.primitive.type,
                model=comp.primitive.model,
                position=pose.position_mm,
                rotation={"type": "extrinsic", "order": "zxy", "angles": angles},
            )
        )
    return entries


# --- recursive subassembly flattening (WP-36, Go: FSDesign.Flattened) ---------------


class SubdesignLoader(Protocol):
    """Loads a subassembly's components; scoped to one design directory.

    Called with the ``design:`` path (relative to the current design's
    directory) and the requested variant (``""`` = base). Returns the
    variant-instantiated components plus a loader scoped to the SUBDESIGN's
    own directory, so nesting resolves like the Go reference's
    ``FSDesign.LoadFSDesign`` (each design sees paths relative to itself).
    """

    def __call__(
        self, design_path: str, variant: str
    ) -> tuple[dict[str, CompSpec], SubdesignLoader]: ...


def _euler_angles(rotation: np.ndarray) -> dict[str, float]:
    ex, ey, ez = matrix_to_euler_zxy(rotation)
    return {k: v for k, v in (("x", ex), ("y", ey), ("z", ez)) if abs(v) > 1e-12}


def flat_design_report(
    components: dict[str, CompSpec],
    load_subdesign: SubdesignLoader | None = None,
) -> list[FlatEntry]:
    """World pose per primitive, recursing into ``type: design`` components.

    Anchor chains still compose translations only (:func:`flatten`), but at a
    subassembly boundary the parent's FULL transform applies to the children —
    ``R_world = R_parent · R_sub``, ``t_world = R_parent · t_sub + t_parent``
    (Go: ``FSDesign.Flattened``, ``flattenedSubmat = mat · submat``). Ids join
    with ``/``; model paths are prefixed with the subdesign path. Without a
    loader, ``design`` components are skipped (the WP-2 behavior).
    """
    entries: list[FlatEntry] = []

    def collect(
        comps: dict[str, CompSpec],
        loader: SubdesignLoader | None,
        id_prefix: str,
        model_prefix: str,
        parent_r: np.ndarray,
        parent_t: np.ndarray,
    ) -> None:
        poses = flatten(comps)
        for comp_id in sorted(comps):
            comp = comps[comp_id]
            pose = poses[comp_id]
            world_r = parent_r @ pose.rotation
            world_t = parent_r @ np.asarray(pose.position_mm) + parent_t
            joined = posixpath.join(id_prefix, comp_id) if id_prefix else comp_id
            if comp.type == "primitive":
                model = (
                    posixpath.join(model_prefix, comp.primitive.model)
                    if model_prefix
                    else comp.primitive.model
                )
                entries.append(
                    FlatEntry(
                        id=joined,
                        type=comp.primitive.type,
                        model=model,
                        position=(float(world_t[0]), float(world_t[1]), float(world_t[2])),
                        rotation={
                            "type": "extrinsic",
                            "order": "zxy",
                            "angles": _euler_angles(world_r),
                        },
                    )
                )
            elif comp.type == "design" and loader is not None:
                variant = str(comp.instantiation.get("variant", "") or "")
                sub_comps, sub_loader = loader(comp.design, variant)
                collect(
                    sub_comps,
                    sub_loader,
                    joined,
                    posixpath.join(model_prefix, comp.design) if model_prefix else comp.design,
                    world_r,
                    world_t,
                )

    collect(components, load_subdesign, "", "", np.eye(3), np.zeros(3))
    return sorted(entries, key=lambda e: e.id)
