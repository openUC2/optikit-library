"""T2 fx-parameter changeset: optikit → Inventor (WP-35).

After ``/v1/optimize`` (or hand-editing) writes ``instantiation.dof_values``,
this exporter turns them into ``optikit-fx.json`` — the small file the
Windows/Inventor side consumes with PyInventor's ``apply_fx_params.py``:

.. code-block:: json

    {"schema": "optikit-fx/v0",
     "changes": [{"component": "objective", "template-id": "openuc2.tpl.lens_insert_25mm",
                  "parameter": "dz", "value-mm": 3.2,
                  "groove": {"pair": [0, 1], "midpoint-mm": 2.5, "delta-mm": 0.7}}]}

Naming contract: **the Inventor fx user-parameter name IS the dof name**
(``dz`` in the record ⇒ user parameter ``dz`` on the master-insert part).
See ``openUC2-OptiKit/DOCS/inventor-naming-contract.md`` §fx parameters.

Groove lattice (mechanical-templates doc): when the template declares
``grooves:``, a dz value decomposes into the nearest clampable groove PAIR
(the holder's origin sits at the pair midpoint) plus the bounded continuous
lens offset δ inside the pocket — the discrete part is realized by which
grooves the holder clamps, only δ goes into the fx parameter set.
"""

from __future__ import annotations

import json
from typing import Any

from ..library.build import Library, resolve
from ..schema.design import DesignDecl
from ..schema.library import GroovesSpec, ModuleRecord, TemplateRecord

FX_SCHEMA = "optikit-fx/v0"


def decompose_on_lattice(
    value_mm: float, grooves: GroovesSpec
) -> dict[str, Any]:
    """Nearest clampable groove pair + continuous residual for a dz value.

    Considers every pair (i < j) of the lattice ``g_n = center + n·pitch``;
    the holder origin sits at the pair midpoint. Picks the pair whose midpoint
    is closest to ``value_mm`` (ties → narrowest span, then lowest pair).
    """
    half = (grooves.count - 1) // 2
    indices = list(range(-half, half + 1))
    best: tuple[float, int, tuple[int, int], float] | None = None
    for a_pos, i in zip(grooves.positions_mm(), indices, strict=True):
        for b_pos, j in zip(grooves.positions_mm(), indices, strict=True):
            if j <= i:
                continue
            midpoint = (a_pos + b_pos) / 2.0
            candidate = (abs(value_mm - midpoint), j - i, (i, j), midpoint)
            if best is None or candidate[:2] < best[:2]:
                best = candidate
    assert best is not None  # count >= 2 by schema intent
    _, _, pair, midpoint = best
    return {
        "pair": list(pair),
        "midpoint-mm": round(midpoint, 6),
        "delta-mm": round(value_mm - midpoint, 6),
    }


def _template_of(decl: DesignDecl, comp_key: str, library: Library) -> TemplateRecord | None:
    """Resolve the library template for a design component.

    Frontend exports carry the placed part's library MODULE id in
    ``primitive.model`` (WP-32/34 bare exports); a raw ``module``/``template``
    ref on the component (draft syntax, kept by ``extra="allow"``) also works.
    """
    comp = decl.components.get(comp_key)
    if comp is None:
        return None
    extra = getattr(comp, "__pydantic_extra__", None) or {}
    candidates = [
        str(extra.get("template") or ""),
        str(extra.get("module") or ""),
        comp.primitive.model,
    ]
    for ref in candidates:
        if not ref:
            continue
        if "@" not in ref:
            ref = f"{ref}@*"
        try:
            hit = resolve(library, ref)
        except ValueError:
            continue  # not a record reference (e.g. a raw STEP filename)
        if hit is None:
            continue
        record = hit.record
        if isinstance(record, TemplateRecord):
            return record
        if isinstance(record, ModuleRecord):
            tpl_hit = resolve(library, record.template)
            if tpl_hit is not None and isinstance(tpl_hit.record, TemplateRecord):
                return tpl_hit.record
    return None


def fx_changeset(decl: DesignDecl, library: Library) -> dict[str, Any]:
    """The ``optikit-fx.json`` document for a design's resolved dof values.

    Only ADAPTIVE (T2) templates emit changes — T1 has no parameters and T3
    regenerates instead. Unresolvable templates still emit an entry (with
    ``template-id: null``) so nothing is silently dropped; the Inventor side
    skips those with a warning.
    """
    changes: list[dict[str, Any]] = []
    for key in sorted(decl.instantiation.dof_values):
        value = decl.instantiation.dof_values[key]
        if not isinstance(value, int | float):
            continue
        comp_key, _, dof_name = key.rpartition(".")
        if not comp_key:
            continue
        template = _template_of(decl, comp_key, library)
        if template is not None and template.class_ != "adaptive":
            continue  # T1 fixed / T3 generative — not an fx parameter
        # WP-80: a rotation DOF is a degree, not a millimetre — the fx key must
        # say so or the Inventor side sets an angle parameter from a mm value.
        dof = None
        if template is not None:
            dof = next((d for d in template.dof if d.name == dof_name), None)
        if dof is None:
            comp = decl.components.get(comp_key)
            dof = next((d for d in (comp.dof if comp else []) if d.name == dof_name), None)
        is_rotation = dof is not None and dof.kind == "rotation"
        entry: dict[str, Any] = {
            "component": comp_key,
            "template-id": template.id if template else None,
            "parameter": dof_name,  # fx user-parameter name == dof name
            ("value-deg" if is_rotation else "value-mm"): float(value),
        }
        if template is not None and template.grooves is not None and not is_rotation:
            entry["groove"] = decompose_on_lattice(float(value), template.grooves)
        changes.append(entry)
    return {"schema": FX_SCHEMA, "changes": changes}


def dump_fx(changeset: dict[str, Any]) -> str:
    return json.dumps(changeset, indent=2) + "\n"
