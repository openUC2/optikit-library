"""WP-86: calibration write-back — derive a design's dof values from a RUNNING
instrument.

Back-annotation (``back_annotate.py``) closes the loop for the *simulator*: an
optimizer result becomes a ``dof_value``. This module closes the other one —
the leg that makes OptiKit different from a pure CAD/EDA tool. A focus found
by turning a real motor, an axis position read back over the WP-26 UC2-REST
link, is a **measurement of the instrument that was built from this design**,
and it belongs in the design:

    design → CAD → printed/assembled → running instrument → measured axis
       ↑                                                          │
       └────────────────── calibrate_from_instrument ─────────────┘

Deliberately the SAME classified-delta path the optimizer leg uses — same
``Delta``, same ``AnnotateResult``, same range gate, same
``DRC_RANGE`` findings, so both legs land in ``instantiation.dof_values``
through one reviewed table. What differs is only the *source of truth* and
therefore the provenance: ``{source: instrument, instrument: …, run: …}``
instead of ``optimized_by``.

Measurements are **absolute axis positions in the DOF's own unit** (mm for a
translation, degrees for a rotation) — what a motor controller reports. The
old value is whatever the design currently declares, so the table reads as
"the design said 1.85, the instrument is at 2.10".

Nothing is merged blindly:

| The instrument reported…                        | Result                     |
|-------------------------------------------------|----------------------------|
| an axis the design declares, value in range      | applied (POSE/TILT_UPDATE) |
| a value outside the declared range               | reported, NOT applied      |
| a DOF the component does not declare             | ``E_UNKNOWN_DOF`` finding  |
| a component the design does not have             | ``E_UNKNOWN_DOF`` finding  |
| an axis nobody declared ``actuatable``           | applied + a W finding      |
"""

from __future__ import annotations

import math
from typing import Any

from ..geometry.cubify import DrcFinding
from ..schema.design import CompSpec, DesignDecl, parse_dof_key
from ..schema.merge import instantiate
from .back_annotate import AnnotateResult, Delta

#: Below this the reading agrees with the design — no delta worth writing.
MEASURE_TOL = 1e-9

#: A measured axis whose kind has no pose meaning (a `parameter` DOF) is
#: reported rather than applied: the design's geometry does not move with it.
_KIND_CLASSIFICATION = {"translation": "POSE_UPDATE", "rotation": "TILT_UPDATE"}


def _find_dof(comp: CompSpec | None, dof_name: str) -> Any | None:
    if comp is None:
        return None
    return next((d for d in comp.dof if d.name == dof_name), None)


def calibrate_from_instrument(
    decl: DesignDecl,
    measurements: dict[str, float],
    *,
    instrument: str = "",
) -> AnnotateResult:
    """Classify measured instrument axis positions against the design.

    ``measurements`` maps ``"<component>.<dof>"`` → the ABSOLUTE measured
    position in the DOF's unit. Returns the same reviewed table the optimizer
    leg produces; ``result.dof_updates`` are the values ready to merge.
    """
    components = instantiate(decl)
    result = AnnotateResult(path_name=instrument or "instrument")

    for key in sorted(measurements):
        raw = measurements[key]
        try:
            value = float(raw)
        except (TypeError, ValueError):
            result.findings.append(DrcFinding(
                "E_BAD_MEASUREMENT", key, "",
                f"measured value {raw!r} is not a number",
            ))
            continue
        if not math.isfinite(value):
            result.findings.append(DrcFinding(
                "E_BAD_MEASUREMENT", key, "",
                f"measured value {value} is not finite",
            ))
            continue

        try:
            comp_id, dof_name = parse_dof_key(key)
        except ValueError:
            result.findings.append(DrcFinding(
                "E_UNKNOWN_DOF", key, "",
                "measurement key is not '<component>.<dof>'",
            ))
            continue

        comp = components.get(comp_id)
        if comp is None:
            result.findings.append(DrcFinding(
                "E_UNKNOWN_DOF", comp_id, "",
                f"the design has no component {comp_id!r} — the instrument "
                "reported an axis this design does not contain",
            ))
            continue

        dof = _find_dof(comp, dof_name)
        if dof is None:
            declared = ", ".join(d.name for d in comp.dof) or "none"
            result.findings.append(DrcFinding(
                "E_UNKNOWN_DOF", comp_id, "",
                f"{comp_id} declares no DOF {dof_name!r} (declared: {declared})",
            ))
            continue

        classification = _KIND_CLASSIFICATION.get(dof.kind)
        old = float(decl.instantiation.dof_values.get(key, 0.0) or 0.0)
        if classification is None:
            result.deltas.append(Delta(
                comp_id, "PART_PARAM", key, old, value, False,
                f"DOF kind {dof.kind!r} does not move a pose — review by hand",
            ))
            continue

        if abs(value - old) <= MEASURE_TOL:
            result.deltas.append(Delta(
                comp_id, classification, key, old, value, False,
                "instrument agrees with the design",
            ))
            continue

        in_range = dof.range is None or (
            float(dof.range[0]) <= value <= float(dof.range[1])
        )
        note = ""
        if not in_range:
            note = f"outside range {list(dof.range)} {dof.unit}"
            result.findings.append(DrcFinding(
                "DRC_RANGE", comp_id, dof.axis,
                f"measured {key} = {value:.4g} {dof.unit} outside declared range "
                f"[{dof.range[0]}, {dof.range[1]}] — the instrument moved further "
                "than the mechanics declare",
            ))
        elif not dof.actuatable:
            # A reading for an axis nobody said was motorized: real, but the
            # design's actuation contract (WP-42) is incomplete.
            note = "axis is not declared actuatable — check the template's dof block"
            result.findings.append(DrcFinding(
                "W_NOT_ACTUATABLE", comp_id, dof.axis,
                f"the instrument reports {key} but the template does not declare "
                "it actuatable (WP-42 axis-map)",
            ))
        result.deltas.append(
            Delta(comp_id, classification, key, old, value, in_range, note)
        )

    return result


def apply_calibration_to_document(
    doc: Any,
    result: AnnotateResult,
    *,
    instrument: str,
    run: str,
    note: str = "",
) -> int:
    """Write measured dof values + instrument provenance into a ruamel tree.

    Instance data only, exactly like the optimizer leg — but the provenance
    says where the numbers came from: ``source: instrument`` is what makes a
    calibrated design distinguishable from an optimized one.
    """
    updates = result.dof_updates
    if updates:
        inst = doc.setdefault("instantiation", {})
        dof_values = inst.setdefault("dof_values", {})
        for key, value in updates.items():
            dof_values[key] = round(value, 9)
    prov = doc.setdefault("provenance", {})
    prov["source"] = "instrument"
    prov["instrument"] = instrument
    prov["run"] = run
    if note:
        prov["note"] = note
    return len(updates)


__all__ = ["apply_calibration_to_document", "calibrate_from_instrument"]
