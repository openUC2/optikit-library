"""Back-annotation: classify an optimized optic.json against the design record.

The narrow, typed reverse direction of the round trip (unification doc §6.2):
every diff between the freshly-compiled baseline and the optimizer's output is
classified — nothing is merged blindly, and only instance data
(``instantiation.dof_values``, ``provenance``) is ever written.

| Optimizer changed…                       | Classification      |
|------------------------------------------|---------------------|
| rigid part position (cs z/x/y together)  | ``POSE_UPDATE``     |
| part tilt (cs rx/ry)                     | ``TILT_UPDATE``     |
| intra-part spacing, radius/conic         | ``PART_PARAM``      |
| material, param without a matching DOF   | ``PART_SUBSTITUTION`` (report only) |
| surface count / type / order             | ``E_TOPOLOGY`` — whole file rejected |

``POSE_UPDATE`` deltas are projected onto the component's declared translation
DOFs (in its local frame); a delta with no DOF to carry it, or one that pushes
a DOF outside its declared range, is reported as a ``DRC_RANGE`` finding
instead of applied — the optimizer does not get to move what the mechanics
cannot.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..compile import CompileResult, compile_path
from ..geometry.cubify import DrcFinding
from ..geometry.flatten import flatten
from ..geometry.rotations import AXIS_DIRS  # noqa: F401  (re-exported convention)
from ..schema.design import CompSpec, DesignDecl
from ..schema.merge import instantiate

POS_TOL_MM = 1e-6
TILT_TOL_RAD = 1e-9
PARAM_TOL = 1e-9

_LOCAL_AXES = {"x": np.array([1.0, 0, 0]), "y": np.array([0, 1.0, 0]), "z": np.array([0, 0, 1.0])}


class AnnotateError(Exception):
    """Typed back-annotation failure; ``code`` is stable API."""

    def __init__(self, code: str, where: str, message: str) -> None:
        super().__init__(f"{code} at {where}: {message}")
        self.code = code
        self.where = where


@dataclass
class Delta:
    component: str
    classification: str  # POSE_UPDATE | TILT_UPDATE | PART_PARAM | PART_SUBSTITUTION
    param: str  # dof key ("comp.dz"), or a description ("radius[1]", "offset-deg")
    old: Any
    new: Any
    applied: bool
    note: str = ""

    def row(self) -> str:
        mark = "✓" if self.applied else "·"
        return (
            f"{mark} {self.component:<18} {self.classification:<18} {self.param:<22} "
            f"{_fmt(self.old):>12} → {_fmt(self.new):<12} {self.note}"
        )


def _fmt(v: Any) -> str:
    if isinstance(v, float):
        return f"{v:.4g}"
    return str(v)


@dataclass
class AnnotateResult:
    path_name: str
    deltas: list[Delta] = field(default_factory=list)
    findings: list[DrcFinding] = field(default_factory=list)

    @property
    def dof_updates(self) -> dict[str, float]:
        """The applied dof_values (absolute new values), ready to merge."""
        return {
            d.param: float(d.new)
            for d in self.deltas
            if d.applied and d.classification in ("POSE_UPDATE", "TILT_UPDATE")
        }

    def table(self) -> str:
        header = (
            f"  {'component':<18} {'classification':<18} {'param':<22} "
            f"{'old':>12}   {'new':<12}"
        )
        lines = [header, "  " + "-" * len(header)]
        lines += [d.row() for d in self.deltas] or ["  (no differences)"]
        lines += [f"  ! {f}" for f in self.findings]
        return "\n".join(lines)


# --- topology guard ---------------------------------------------------------------------


def _check_topology(base: list[dict], opt: list[dict], where: str) -> None:
    if len(base) != len(opt):
        raise AnnotateError(
            "E_TOPOLOGY", where,
            f"surface count changed ({len(base)} → {len(opt)}) — topology belongs to the "
            "design, not the optimizer",
        )
    for i, (b, o) in enumerate(zip(base, opt, strict=True)):
        if b.get("type") != o.get("type") or (
            (b.get("geometry") or {}).get("type") != (o.get("geometry") or {}).get("type")
        ):
            raise AnnotateError(
                "E_TOPOLOGY", where, f"surface {i} changed type — rejected"
            )

    def order(surfaces: list[dict]) -> list[int]:
        zs = [
            (s.get("geometry", {}).get("cs", {}).get("z", 0.0) or 0.0, i)
            for i, s in enumerate(surfaces)
            if not math.isinf(s.get("geometry", {}).get("cs", {}).get("z", 0.0) or 0.0)
        ]
        return [i for _, i in sorted(zs, key=lambda t: t[0])]

    if order(base) != order(opt):
        raise AnnotateError(
            "E_TOPOLOGY", where,
            "surface order along the axis changed (elements moved past each other) — rejected",
        )


# --- classification -----------------------------------------------------------------------


def back_annotate(
    decl: DesignDecl, path_name: str, optimized_optic: dict[str, Any]
) -> AnnotateResult:
    """Classify every surface diff of ``optimized_optic`` against a fresh compile."""
    baseline: CompileResult = compile_path(decl, path_name)
    base_surfaces = baseline.optic["surface_group"]["surfaces"]
    opt_surfaces = (optimized_optic.get("surface_group") or {}).get("surfaces")
    if not isinstance(opt_surfaces, list):
        raise AnnotateError("E_TOPOLOGY", path_name, "optimized file has no surface_group")
    _check_topology(base_surfaces, opt_surfaces, path_name)

    components = instantiate(decl)
    poses = flatten(components)
    result = AnnotateResult(path_name=path_name)

    # Group manifest entries into per-traversal blocks (a part may appear twice).
    blocks: list[list[int]] = []
    for i, entry in enumerate(baseline.manifest):
        if blocks and (
            baseline.manifest[i - 1].port_traversal == entry.port_traversal
        ):
            blocks[-1].append(i)
        else:
            blocks.append([i])

    for block in blocks:
        entries = [baseline.manifest[i] for i in block]
        comp_id = entries[0].component_id
        comp = components.get(comp_id)
        world = entries[0].world
        if world is None:
            continue  # infinite-conjugate object plane — nothing to annotate

        dz_list, dx_list, dy_list, drx_list, dry_list = [], [], [], [], []
        for entry in entries:
            b = base_surfaces[entry.surface_index]["geometry"]["cs"]
            o = opt_surfaces[entry.surface_index]["geometry"]["cs"]
            dz_list.append(float(o.get("z", 0) - b.get("z", 0)))
            dx_list.append(float(o.get("x", 0) - b.get("x", 0)))
            dy_list.append(float(o.get("y", 0) - b.get("y", 0)))
            drx_list.append(float(o.get("rx", 0) - b.get("rx", 0)))
            dry_list.append(float(o.get("ry", 0) - b.get("ry", 0)))
            _classify_params(
                result, comp, comp_id, entry,
                base_surfaces[entry.surface_index], opt_surfaces[entry.surface_index],
            )

        # Intra-part spacing change = a part parameter, not a pose.
        if max(dz_list) - min(dz_list) > POS_TOL_MM:
            result.deltas.append(
                Delta(comp_id, "PART_PARAM", "spacing", 0.0,
                      round(max(dz_list) - min(dz_list), 9), False,
                      "intra-part surface spacing changed"))
        rigid = np.array([np.mean(dx_list), np.mean(dy_list), np.mean(dz_list)])
        if float(np.linalg.norm(rigid)) > POS_TOL_MM:
            _classify_pose(result, decl, comp, comp_id, poses, world, rigid)

        tilt = np.array([float(np.mean(drx_list)), float(np.mean(dry_list))])
        if float(np.linalg.norm(tilt)) > TILT_TOL_RAD:
            _classify_tilt(result, decl, comp, comp_id, poses, world, tilt)

    return result


def _classify_params(
    result: AnnotateResult,
    comp: CompSpec | None,
    comp_id: str,
    entry: Any,
    base: dict[str, Any],
    opt: dict[str, Any],
) -> None:
    bg, og = base.get("geometry") or {}, opt.get("geometry") or {}
    frag = entry.fragment_surface_index
    for key in ("radius", "conic"):
        old, new = float(bg.get(key, 0) or 0), float(og.get(key, 0) or 0)
        if math.isinf(old) and math.isinf(new):
            continue
        if abs(new - old) > PARAM_TOL:
            dof_name = _matching_param_dof(comp, key, frag)
            if dof_name:
                result.deltas.append(
                    Delta(comp_id, "PART_PARAM", f"{comp_id}.{dof_name}", old, new, True))
            else:
                result.deltas.append(
                    Delta(comp_id, "PART_SUBSTITUTION", f"{key}[{frag}]", old, new, False,
                          "no parameter DOF — propose closest catalog part instead"))
    b_mat = (base.get("material_post") or {}).get("name") or (
        base.get("material_post") or {}).get("index")
    o_mat = (opt.get("material_post") or {}).get("name") or (
        opt.get("material_post") or {}).get("index")
    if b_mat != o_mat:
        result.deltas.append(
            Delta(comp_id, "PART_SUBSTITUTION", f"material[{frag}]", b_mat, o_mat, False,
                  "material changes are library substitutions"))


def _matching_param_dof(comp: CompSpec | None, key: str, frag: int | None) -> str | None:
    """Convention: a parameter-kind DOF named `<key>` or `<key><frag_index>`."""
    if comp is None:
        return None
    names = {key, f"{key}{frag}" if frag is not None else key}
    for dof in comp.dof:
        if dof.kind == "parameter" and dof.name in names:
            return dof.name
    return None


def _classify_pose(
    result: AnnotateResult,
    decl: DesignDecl,
    comp: CompSpec | None,
    comp_id: str,
    poses: dict[str, Any],
    world: dict[str, Any],
    rigid: np.ndarray,
) -> None:
    """Rigid (dx, dy, dz in path coords) → world delta → translation DOFs."""
    world_delta = (
        rigid[0] * np.array(world["u"])
        + rigid[1] * np.array(world["v"])
        + rigid[2] * np.array(world["direction"])
    )
    if comp is None or comp_id not in poses:
        result.findings.append(DrcFinding(
            "DRC_RANGE", comp_id, "", f"pose delta {world_delta.round(4).tolist()} mm on an "
            "unknown component"))
        return
    rotation = poses[comp_id].rotation
    residual = world_delta.copy()
    for dof in comp.dof:
        if dof.kind != "translation" or dof.axis not in _LOCAL_AXES:
            continue
        axis_world = rotation @ _LOCAL_AXES[dof.axis]
        coeff = float(world_delta @ axis_world)
        if abs(coeff) < POS_TOL_MM:
            continue
        residual -= coeff * axis_world
        key = f"{comp_id}.{dof.name}"
        old = float(decl.instantiation.dof_values.get(key, 0.0) or 0.0)
        new = old + coeff
        if dof.range is not None and not (
            float(dof.range[0]) <= new <= float(dof.range[1])
        ):
            result.deltas.append(Delta(comp_id, "POSE_UPDATE", key, old, new, False,
                                       f"outside range {list(dof.range)} {dof.unit}"))
            result.findings.append(DrcFinding(
                "DRC_RANGE", comp_id, dof.axis,
                f"optimized {key} = {new:.4g} outside declared range "
                f"[{dof.range[0]}, {dof.range[1]}] {dof.unit}"))
        else:
            result.deltas.append(Delta(comp_id, "POSE_UPDATE", key, old, new, True))
    if float(np.linalg.norm(residual)) > POS_TOL_MM:
        axis = "xyz"[int(np.argmax(np.abs(residual)))]
        result.deltas.append(Delta(
            comp_id, "POSE_UPDATE", f"offset-mm.{axis}", 0.0,
            round(float(residual[int(np.argmax(np.abs(residual)))]), 9), False,
            "no translation DOF covers this direction"))
        result.findings.append(DrcFinding(
            "DRC_RANGE", comp_id, axis,
            f"pose delta {residual.round(4).tolist()} mm has no translation DOF to carry it"))


def _classify_tilt(
    result: AnnotateResult,
    decl: DesignDecl,
    comp: CompSpec | None,
    comp_id: str,
    poses: dict[str, Any],
    world: dict[str, Any],
    tilt_rad: np.ndarray,
) -> None:
    """Part tilt (rx about u, ry about v) → rotation DOF or offset-deg proposal."""
    tilt_world = tilt_rad[0] * np.array(world["u"]) + tilt_rad[1] * np.array(world["v"])
    tilt_deg = math.degrees(float(np.linalg.norm(tilt_world)))
    if comp is not None and comp_id in poses:
        rotation = poses[comp_id].rotation
        for dof in comp.dof:
            if dof.kind != "rotation" or dof.axis not in _LOCAL_AXES:
                continue
            axis_world = rotation @ _LOCAL_AXES[dof.axis]
            coeff_deg = math.degrees(float(tilt_world @ axis_world))
            if abs(coeff_deg) < 1e-9:
                continue
            key = f"{comp_id}.{dof.name}"
            old = float(decl.instantiation.dof_values.get(key, 0.0) or 0.0)
            new = old + coeff_deg
            in_range = dof.range is None or (
                float(dof.range[0]) <= new <= float(dof.range[1])
            )
            result.deltas.append(Delta(
                comp_id, "TILT_UPDATE", key, old, new, in_range,
                "" if in_range else f"outside range {list(dof.range)} {dof.unit}"))
            if not in_range:
                result.findings.append(DrcFinding(
                    "DRC_RANGE", comp_id, dof.axis,
                    f"optimized {key} = {new:.4g}° outside declared range"))
            return
    result.deltas.append(Delta(
        comp_id, "TILT_UPDATE", "rotation.offset-deg", 0.0, round(tilt_deg, 6), False,
        "no rotation DOF — apply manually as pose.rotation.offset-deg"))


# --- apply ---------------------------------------------------------------------------------


def apply_to_document(
    doc: Any, result: AnnotateResult, *, optimized_by: str, run: str, merit: dict[str, Any]
) -> int:
    """Write applied deltas + provenance into a ruamel document tree (instance
    data only: ``instantiation.dof_values`` and ``provenance``)."""
    updates = result.dof_updates
    if updates:
        inst = doc.setdefault("instantiation", {})
        dof_values = inst.setdefault("dof_values", {})
        for key, value in updates.items():
            dof_values[key] = round(value, 9)
    prov = doc.setdefault("provenance", {})
    prov["optimized_by"] = optimized_by
    prov["run"] = run
    prov["merit"] = merit
    return len(updates)
