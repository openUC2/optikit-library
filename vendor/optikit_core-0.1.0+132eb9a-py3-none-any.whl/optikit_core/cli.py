"""Command-line interface: ``optikit-core validate <design-dir-or-file> ...``"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from pydantic import ValidationError

from . import __version__
from .io import load_design, resolve_design_file
from .schema import DESIGN_DECL_FILE, check


def _iter_design_files(paths: list[Path]) -> list[Path]:
    """Expand arguments: design files, design dirs, or trees containing designs."""
    files: list[Path] = []
    for path in paths:
        if path.is_file():
            files.append(path)
        elif (path / DESIGN_DECL_FILE).is_file():
            files.append(path / DESIGN_DECL_FILE)
        elif path.is_dir():
            files.extend(sorted(path.rglob(DESIGN_DECL_FILE)))
        else:
            raise FileNotFoundError(f"no design found at {path}")
    return files


def cmd_validate(args: argparse.Namespace) -> int:
    files = _iter_design_files([Path(p) for p in args.paths])
    if not files:
        print("no optikit-design.yml files found", file=sys.stderr)
        return 2

    n_errors = 0
    for file in files:
        try:
            decl = load_design(file)
        except ValidationError as exc:
            n_errors += exc.error_count()
            print(f"{file}: STRUCTURAL ERRORS")
            for err in exc.errors():
                loc = ".".join(str(part) for part in err["loc"])
                print(f"  ERROR E_STRUCTURE at {loc}: {err['msg']}")
            continue
        findings = check(decl)
        errors = [f for f in findings if f.severity == "error"]
        warnings = [f for f in findings if f.severity == "warning"]
        n_errors += len(errors)
        status = "FAIL" if errors else "OK"
        suffix = f" ({len(warnings)} warning(s))" if warnings else ""
        print(f"{file}: {status}{suffix}")
        shown = findings if args.warnings else errors
        for finding in shown:
            print(f"  {finding}")
    return 1 if n_errors else 0


def cmd_flatten(args: argparse.Namespace) -> int:
    import json

    from .geometry import FlattenError, flat_report
    from .io.yamlio import dump_document
    from .schema.merge import instantiate

    decl = load_design(Path(args.path))
    try:
        entries = [e.dump() for e in flat_report(instantiate(decl))]
    except FlattenError as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1
    if args.format == "json":
        print(json.dumps(entries, indent=2))
    else:
        print(dump_document(entries), end="")
    return 0


def cmd_cubify(args: argparse.Namespace) -> int:
    from .geometry import FlattenError, cubify
    from .io.yamlio import dump_document
    from .schema.merge import instantiate

    decl = load_design(Path(args.path))
    dof_values = {
        k: v for k, v in decl.instantiation.dof_values.items() if isinstance(v, int | float)
    }
    try:
        result = cubify(instantiate(decl), dof_values=dof_values)
    except FlattenError as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1
    out = {comp_id: pose.pose_dict() for comp_id, pose in sorted(result.poses.items())}
    print(dump_document({"poses": out}), end="")
    for finding in result.findings:
        print(f"  {finding}")
    return 1 if result.findings else 0


def cmd_chain(args: argparse.Namespace) -> int:
    from .chain import ChainError, infer_paths
    from .geometry import FlattenError
    from .io.yamlio import dump_document, load_document

    file = resolve_design_file(Path(args.design))
    decl = load_design(file)
    try:
        result = infer_paths(decl)
    except (ChainError, FlattenError) as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1

    existing_chains = {tuple(p.chain) for p in decl.paths.values()}
    new_paths = {
        name: spec
        for name, spec in result.paths.items()
        if tuple(spec["chain"]) not in existing_chains
    }

    print(dump_document({"paths": result.paths}), end="")
    for warning in result.warnings:
        print(f"  note: {warning}")

    if args.write:
        if not new_paths:
            print("nothing to write: every inferred chain is already declared")
            return 0
        doc = load_document(file)
        doc.setdefault("paths", {})
        for name, spec in new_paths.items():
            key = name
            while key in doc["paths"]:
                key += "-inferred"
            doc["paths"][key] = spec
        file.write_text(dump_document(doc), encoding="utf-8")
        print(f"wrote {len(new_paths)} path(s) into {file}")
    return 0


def cmd_compile(args: argparse.Namespace) -> int:
    import json

    from .compile import CompileError, compile_path
    from .geometry import FlattenError
    from .io.yamlio import dump_document

    decl = load_design(Path(args.design))
    path_names = [args.path_name] if args.path_name else sorted(decl.paths)
    if not path_names:
        print("design declares no paths", file=sys.stderr)
        return 2
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    summaries: list[dict] = []
    for path_name in path_names:
        try:
            result = compile_path(decl, path_name)
        except (CompileError, FlattenError) as exc:
            print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
            return 1
        optic_file = out_dir / f"optic.{path_name}.json"
        optic_file.write_text(json.dumps(result.optic, indent=2) + "\n", encoding="utf-8")
        manifest_file = out_dir / f"optic.{path_name}.manifest.yml"
        manifest_file.write_text(
            dump_document([m.dump() for m in result.manifest]), encoding="utf-8"
        )
        print(f"wrote {optic_file} + {manifest_file.name}")
        for warning in result.warnings:
            print(f"  note: {warning}")
        if args.summary:
            summaries.append(_paraxial_summary(result))

    if args.summary:
        summary_file = out_dir / "summary.json"
        summary_file.write_text(json.dumps(summaries, indent=2) + "\n", encoding="utf-8")
        print(f"wrote {summary_file}")
    return 0


def cmd_export_scene3(args: argparse.Namespace) -> int:
    import json

    from .canvas import materialize

    decl = load_design(Path(args.design))
    if args.path_name:
        if args.path_name not in decl.paths:
            print(f"design declares no path {args.path_name!r}", file=sys.stderr)
            return 2
        decl.paths = {args.path_name: decl.paths[args.path_name]}

    result = materialize(decl)
    errors = [f for f in result.findings if f.severity == "error"]
    if errors:
        for f in errors:
            print(f"ERROR {f}", file=sys.stderr)
        return 1

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    indent = 2 if args.pretty else None
    scene_file = out_dir / "scene3.ocanvas"
    manifest_file = out_dir / "scene3-manifest.json"
    scene_file.write_text(json.dumps(result.scene, indent=indent) + "\n", encoding="utf-8")
    manifest_file.write_text(json.dumps(result.manifest, indent=indent) + "\n", encoding="utf-8")
    print(f"wrote {scene_file} + {manifest_file.name}")
    for f in result.findings:
        if f.severity == "warning":
            print(f"  note: {f}")
    return 0


def _paraxial_summary(result) -> dict:  # noqa: ANN001
    """Paraxial report per compiled path (optiland required, like the old
    exporter's summary.json)."""
    info: dict = {
        "path": result.path_name,
        "n_surfaces": len(result.optic["surface_group"]["surfaces"]),
        "wavelengths_um": [
            w["value"] for w in result.optic["wavelengths"]["wavelengths"]
        ],
        "warnings": list(result.warnings),
    }
    try:
        from optiland.optic import Optic

        optic = Optic.from_dict(result.optic)
        info["efl_mm"] = float(optic.paraxial.f2())
    except ImportError:
        info["paraxial_error"] = "optiland not installed"
    except Exception as exc:  # noqa: BLE001 — diagnostic only
        info["paraxial_error"] = str(exc)
    return info


def cmd_back_annotate(args: argparse.Namespace) -> int:
    import datetime
    import json

    from .annotate import AnnotateError, apply_to_document, back_annotate
    from .compile import CompileError
    from .geometry import FlattenError
    from .io.yamlio import dump_document, load_document

    file = resolve_design_file(Path(args.design))
    decl = load_design(file)
    optimized = json.loads(Path(args.optimized).read_text(encoding="utf-8"))
    try:
        result = back_annotate(decl, args.path_name, optimized)
    except (AnnotateError, CompileError, FlattenError) as exc:
        print(f"ERROR {exc.code}: {exc}", file=sys.stderr)
        return 1

    print(result.table())
    if not args.apply:
        return 1 if result.findings else 0

    doc = load_document(file)
    n = apply_to_document(
        doc,
        result,
        optimized_by=args.optimized_by,
        run=datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds"),
        merit={},
    )
    file.write_text(dump_document(doc), encoding="utf-8")
    print(f"applied {n} dof value(s) to {file}")
    return 1 if result.findings else 0


def cmd_calibrate(args: argparse.Namespace) -> int:
    """WP-86: measured instrument axes → classified dof_value updates."""
    import datetime
    import json

    from .annotate import apply_calibration_to_document, calibrate_from_instrument
    from .io.yamlio import dump_document, load_document

    file = resolve_design_file(Path(args.design))
    decl = load_design(file)
    raw = json.loads(Path(args.measurements).read_text(encoding="utf-8"))
    # Accept both the bare mapping and the {"measurements": {...}} envelope a
    # device-side script may wrap it in.
    measurements = raw.get("measurements", raw) if isinstance(raw, dict) else {}
    if not isinstance(measurements, dict) or not measurements:
        print(
            "no measurements: expected {'<component>.<dof>': <value>, …} "
            "(optionally under a 'measurements' key)",
            file=sys.stderr,
        )
        return 2
    instrument = args.instrument or (
        raw.get("instrument", "") if isinstance(raw, dict) else ""
    )

    result = calibrate_from_instrument(decl, measurements, instrument=instrument)
    print(result.table())
    if not args.apply:
        return 1 if result.findings else 0

    doc = load_document(file)
    n = apply_calibration_to_document(
        doc,
        result,
        instrument=instrument,
        run=datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds"),
        note=args.note,
    )
    file.write_text(dump_document(doc), encoding="utf-8")
    print(f"applied {n} measured dof value(s) to {file} (provenance: instrument)")
    return 1 if result.findings else 0


def cmd_serve(args: argparse.Namespace) -> int:
    import uvicorn

    uvicorn.run("optikit_core.service:app", host=args.host, port=args.port)
    return 0


def _repo_library_root() -> Path:
    return Path(__file__).resolve().parents[2] / "library"


def cmd_import_glb(args: argparse.Namespace) -> int:
    from .importers import import_glb_file
    from .importers.glb2template import bbox_thumbnail_svg
    from .io.yamlio import dump_document

    try:
        result = import_glb_file(Path(args.glb), namespace=args.namespace)
    except ImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    root = Path(args.out) if args.out else _repo_library_root()
    written: list[Path] = []
    kinds = {
        "optical_component": ("components", result.component),
        "mechanical_template": ("templates", result.template),
        "cube_module": ("modules", result.module),
    }
    for kind, (folder, record) in kinds.items():
        rec_dir = root / folder / record["id"]
        rec_dir.mkdir(parents=True, exist_ok=True)
        file = rec_dir / {"optical_component": "component.yml",
                          "mechanical_template": "template.yml",
                          "cube_module": "module.yml"}[kind]
        if record.get("review"):
            record["thumbnail"] = "thumbnail.svg" if kind == "cube_module" else record.get(
                "thumbnail", "")
        if kind == "cube_module":
            thumb = rec_dir / "thumbnail.svg"
            thumb.write_text(
                bbox_thumbnail_svg(result.envelope_mm, record["id"].rsplit(".", 1)[-1]),
                encoding="utf-8",
            )
            record["thumbnail"] = "thumbnail.svg"
        file.write_text(dump_document(record), encoding="utf-8")
        written.append(file)

    for file in written:
        print(f"wrote {file}")
    if result.review:
        print(f"\n⚠ {len(result.review)} item(s) need review:", file=sys.stderr)
        for item in result.review:
            print(f"  - {item}", file=sys.stderr)
    return 0


def cmd_actuate(args: argparse.Namespace) -> int:
    import json

    from .library import load_library
    from .library.actuate import ActuationError, firmware_command

    if "=" not in args.assignment:
        print("assignment must be <dof>=<value>", file=sys.stderr)
        return 2
    dof, raw = args.assignment.split("=", 1)
    try:
        value = float(raw)
    except ValueError:
        print(f"not a number: {raw!r}", file=sys.stderr)
        return 2

    root = Path(args.root) if args.root else _repo_library_root()
    try:
        command = firmware_command(load_library(root), args.module_id, dof.strip(), value)
    except ActuationError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(command, indent=2))
    return 0


def cmd_import_csv(args: argparse.Namespace) -> int:
    from .importers.csv_palette import import_csv
    from .io.yamlio import dump_document

    result = import_csv(Path(args.csv), namespace=args.namespace)
    root = Path(args.out) if args.out else _repo_library_root()

    counts: dict[str, int] = {}
    for rr in result.rows:
        counts[rr.category] = counts.get(rr.category, 0) + 1
        for folder, fname, record in (
            ("components", "component.yml", rr.component),
            ("templates", "template.yml", rr.template),
            ("modules", "module.yml", rr.module),
        ):
            if record is None:
                continue
            rec_dir = root / folder / record["id"]
            rec_dir.mkdir(parents=True, exist_ok=True)
            (rec_dir / fname).write_text(dump_document(record), encoding="utf-8")

    print(f"migrated {len(result.rows)} row(s) → record trios in {root}")
    for cat, n in sorted(counts.items()):
        print(f"  {cat}: {n}")
    for skip in result.skipped:
        print(f"  skipped {skip}", file=sys.stderr)
    print("\n⚠ every migrated record is review-flagged — run `library validate` and confirm")
    return 0


def _write_component_record(record: dict, root: Path) -> Path:
    from .io.yamlio import dump_document

    rec_dir = root / "components" / record["id"]
    rec_dir.mkdir(parents=True, exist_ok=True)
    file = rec_dir / "component.yml"
    file.write_text(dump_document(record), encoding="utf-8")
    return file


def _report_zmx_results(results: list, root: Path) -> int:  # noqa: ANN001
    n_review = 0
    for result in results:
        file = _write_component_record(result.component, root)
        efl = f"  EFL {result.efl_mm:.2f} mm" if result.efl_mm is not None else ""
        print(f"wrote {file}{efl}")
        if result.review:
            n_review += 1
            print(f"  ⚠ {len(result.review)} item(s) need review:", file=sys.stderr)
            for item in result.review:
                print(f"    - {item}", file=sys.stderr)
    return 0


def cmd_import_zmx(args: argparse.Namespace) -> int:
    from .importers.thorlabs import ZmxImportError, zmx_to_component

    try:
        result = zmx_to_component(
            Path(args.zmx), mpn=args.mpn, namespace=args.namespace, vendor_name=args.vendor
        )
    except ImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except ZmxImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    root = Path(args.out) if args.out else _repo_library_root()
    return _report_zmx_results([result], root)


def cmd_import_thorlabs(args: argparse.Namespace) -> int:
    from .importers.thorlabs import ZmxImportError, import_thorlabs_mpns

    try:
        results = import_thorlabs_mpns(args.mpns, args.zmx_dir, namespace=args.namespace)
    except ImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except ZmxImportError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    root = Path(args.out) if args.out else _repo_library_root()
    return _report_zmx_results(results, root)


def _parse_param_overrides(pairs: list[str]) -> dict:
    overrides = {}
    for pair in pairs:
        key, sep, raw = pair.partition("=")
        if not sep or not key:
            raise SystemExit(f"--param expects key=value, got {pair!r}")
        try:
            overrides[key] = float(raw)
        except ValueError:
            overrides[key] = raw
    return overrides


def cmd_generate(args: argparse.Namespace) -> int:
    import json

    from .generate import GenerateError, generate, generate_all, pose_params_from_component
    from .library import load_library
    from .schema.library import TemplateRecord

    root = Path(args.library) if args.library else _repo_library_root()
    repo_root = root.parent

    try:
        if args.all:
            results = generate_all(
                root, out_root=args.out, repo_root=repo_root, force=args.force
            )
        else:
            if not args.template_id:
                print("give a <template-id> or --all", file=sys.stderr)
                return 2
            library = load_library(root)
            candidates = [
                e.record
                for e in library.records
                if isinstance(e.record, TemplateRecord) and e.record.id == args.template_id
            ]
            if not candidates:
                print(f"no template {args.template_id!r} in {root}", file=sys.stderr)
                return 2
            overrides = _parse_param_overrides(args.param)
            if args.params_json:
                overrides.update(
                    json.loads(Path(args.params_json).read_text(encoding="utf-8"))
                )
            if args.design and args.component:
                # WP-35 T3: regenerate around the part's ACTUAL placed pose —
                # the design component's intra-cube δ shifts the cavity.
                from .io import load_design

                decl = load_design(Path(args.design))
                comp = decl.components.get(args.component)
                if comp is None:
                    print(f"no component {args.component!r} in {args.design}", file=sys.stderr)
                    return 2
                overrides.update(
                    pose_params_from_component(comp, candidates[0].generator.params
                                               if candidates[0].generator else {})
                )
            elif args.design or args.component:
                print("--design and --component go together", file=sys.stderr)
                return 2
            results = [
                generate(
                    candidates[0],
                    params_override=overrides,
                    out_root=args.out,
                    repo_root=repo_root,
                    force=args.force,
                )
            ]
    except GenerateError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    for result in results:
        verb = "generated" if result.regenerated else "up-to-date"
        size = result.meta.get("bbox_mm", {}).get("size", [])
        dims = "x".join(f"{s:.1f}" for s in size)
        print(f"{verb} {result.template_id}@{result.key} -> {result.out_dir} ({dims} mm)")
    return 0


def cmd_rebuild(args: argparse.Namespace) -> int:
    from .release import RebuildError, rebuild

    try:
        report = rebuild(Path(args.bundle))
    except RebuildError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(report.table())
    print(f"\nresult: {'REPRODUCIBLE' if report.ok else 'MISMATCH'}")
    return 0 if report.ok else 1


def cmd_fx(args: argparse.Namespace) -> int:
    """Emit the optikit-fx.json changeset for a design's dof values (WP-35 T2)."""
    from .annotate.fx import dump_fx, fx_changeset
    from .io import load_design
    from .library import load_library

    root = Path(args.library) if args.library else _repo_library_root()
    if not root.is_dir():
        print(f"no library directory at {root}", file=sys.stderr)
        return 2
    decl = load_design(Path(args.design))
    changeset = fx_changeset(decl, load_library(root))
    text = dump_fx(changeset)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"wrote {args.out} ({len(changeset['changes'])} change(s))")
    else:
        print(text, end="")
    return 0


def cmd_export_step(args: argparse.Namespace) -> int:
    """WP-57: a design → one grouped STEP assembly.
    WP-84 (``--component``): ONE part, posed w.r.t. its CUBE frame — the
    Inventor round-trip's outbound leg."""
    from .export import ExportError, export_step, export_step_part
    from .io import load_design

    design_path = Path(args.design)
    if not design_path.exists():
        print(f"no design at {design_path}", file=sys.stderr)
        return 2
    component = getattr(args, "component", None)
    default_name = (
        design_path.with_suffix(".step")
        if component is None
        else design_path.parent / f"{component}-in-cube.step"
    )
    out = Path(args.out) if args.out else default_name
    library_root = Path(args.library) if args.library else _repo_library_root()

    try:
        decl = load_design(design_path)
        if component is not None:
            report = export_step_part(
                decl,
                component,
                out,
                library_root=library_root if library_root.is_dir() else None,
            )
        else:
            report = export_step(
                decl,
                out,
                library_root=library_root if library_root.is_dir() else None,
                beam=args.beam,
                **({"beam_radius_mm": args.beam_radius} if args.beam_radius else {}),
            )
    except ExportError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    for warning in report.warnings:
        print(f"warning: {warning}", file=sys.stderr)
    print(
        f"wrote {out} — {len(report.modules)} module STEP(s), "
        f"{len(report.optics)} optic(s), {report.beam_segments} beam segment(s)"
    )
    return 0


def _library_restore(root: Path, record_id: str) -> int:
    """WP-68: move an archived record trio back into the live library.

    Restores the directory whose record carries ``record_id``; when that
    record is a cube module, the component and template it references are
    pulled out of the archive with it (if they are archived).
    """
    import shutil

    from .io.yamlio import (
        _to_plain,  # noqa: PLC2701 — internal helper reuse
        load_document,
    )
    from .library.build import RECORD_FILES

    archive = root / "archive"
    if not archive.is_dir():
        print(f"no archive directory at {archive}", file=sys.stderr)
        return 2

    def find(rid: str) -> tuple[Path, dict] | None:
        for file in sorted(archive.rglob("*.yml")):
            if file.name not in RECORD_FILES:
                continue
            try:
                data = _to_plain(load_document(file)) or {}
            except Exception:  # noqa: BLE001 — skip unreadable archived files
                continue
            if data.get("id") == rid:
                return file, data
        return None

    restored: list[str] = []

    def restore(rid: str) -> None:
        hit = find(rid)
        if hit is None:
            return
        file, data = hit
        src_dir = file.parent
        target = root / src_dir.relative_to(archive)
        if target.exists():
            print(f"skip {rid}: {target.relative_to(root)} already exists "
                  "in the live library", file=sys.stderr)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src_dir), str(target))
            restored.append(rid)
            print(f"restored {rid} -> {target.relative_to(root)}")
        # A module drags the component + template it references back out too.
        for ref in (data.get("component"), data.get("template")):
            if isinstance(ref, str) and "@" in ref:
                dep = ref.split("@", 1)[0]
                if dep not in restored and not any(
                    (root / kind / dep).is_dir()
                    for kind in ("components", "templates", "modules", "groups")
                ):
                    restore(dep)

    if find(record_id) is None:
        live = any(
            (root / kind / record_id).is_dir()
            for kind in ("components", "templates", "modules", "groups")
        )
        hint = " (it is already in the live library)" if live else ""
        print(f"{record_id} is not in the archive{hint}", file=sys.stderr)
        return 1

    restore(record_id)
    print(f"{len(restored)} record(s) restored — run `optikit-core library build` "
          "to refresh the index")
    return 0


#: Stamped onto every record that survives a `library reset`. It rides the
#: EXISTING `review:` machinery on purpose rather than inventing a second flag:
#: `review` already propagates module → component → template in the index, and
#: already badges the part in the palette, the library browser, the BOM and the
#: cubify dialog. So a carried-over part is visibly unconfirmed everywhere it
#: appears, and the only way to clear it is to open the record and delete the
#: note — which is exactly the "you must re-author this through the editor"
#: gate R0 asks for. A parallel flag would have needed all five surfaces
#: taught about it, and would have let someone clear one without the other.
CARRY_OVER_NOTE = (
    "carried over from the pre-reset library — the prescription has NOT been "
    "confirmed against a real part. Verify it in the component editor and "
    "delete this note before using it in a design you intend to build."
)

#: The one set the carry-over stamp does NOT touch.
#:
#: `test_the_seed_records_are_flag_free` enforces "WP-68: the starter set is
#: the quality bar — no review flags, ever", and it is right to. The starters
#: are the exemplar trio somebody copies when authoring their own part, so a
#: review flag on them would mean the thing being copied is itself unconfirmed.
#: Stamping them would also destroy what the flag MEANS: if every record is
#: flagged, "flagged" stops distinguishing importer-drafted from curated and
#: starts meaning "exists".
STARTER_TAG = "starter"


def _norm_note(text: str) -> str:
    """Collapse whitespace, so a line-wrapped YAML note compares equal.

    The carry-over note is long enough that the round-trip writer folds it
    across lines; YAML folds it back to single spaces on read, but the raw
    text differs. Every comparison of a note goes through here.
    """
    return " ".join(str(text).split())


def _library_archive(root: Path, record_id: str) -> int:
    """Move a live record into `archive/`. The mirror of :func:`_library_restore`.

    A module takes the component and template it references with it, unless
    another live module still needs them — archiving a component out from under
    a module that still points at it is how a library starts failing reference
    integrity.
    """
    import shutil

    from .io.yamlio import (
        _to_plain,  # noqa: PLC2701 — internal helper reuse
        load_document,
    )
    from .library.build import RECORD_FILES

    kinds = ("components", "templates", "modules", "groups")

    def find_live(rid: str) -> tuple[Path, dict] | None:
        for kind in kinds:
            for file in sorted((root / kind).glob("*/*.yml")):
                if file.name not in RECORD_FILES:
                    continue
                try:
                    data = _to_plain(load_document(file)) or {}
                except Exception:  # noqa: BLE001 — skip unreadable records
                    continue
                if data.get("id") == rid:
                    return file, data
        return None

    def referenced_elsewhere(dep: str, ignoring: set[str]) -> bool:
        """Does any live module still name `dep`, other than the ones going away?"""
        for file in sorted((root / "modules").glob("*/*.yml")):
            try:
                data = _to_plain(load_document(file)) or {}
            except Exception:  # noqa: BLE001
                continue
            if data.get("id") in ignoring:
                continue
            for ref in (data.get("component"), data.get("template")):
                if isinstance(ref, str) and ref.split("@", 1)[0] == dep:
                    return True
        return False

    hit = find_live(record_id)
    if hit is None:
        print(f"{record_id} is not in the live library", file=sys.stderr)
        return 1

    archived: list[str] = []
    going = {record_id}

    def archive_one(rid: str) -> None:
        found = find_live(rid)
        if found is None:
            return
        file, data = found
        src_dir = file.parent
        target = root / "archive" / src_dir.relative_to(root)
        if target.exists():
            print(f"skip {rid}: already archived at "
                  f"{target.relative_to(root)}", file=sys.stderr)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src_dir), str(target))
            archived.append(rid)
            print(f"archived {rid} -> {target.relative_to(root)}")
        for ref in (data.get("component"), data.get("template")):
            if isinstance(ref, str) and "@" in ref:
                dep = ref.split("@", 1)[0]
                if dep not in archived and not referenced_elsewhere(dep, going):
                    archive_one(dep)

    archive_one(record_id)
    print(f"{len(archived)} record(s) archived — run `optikit-core library build` "
          "to refresh the index")
    return 0


def _library_reset(root: Path, apply: bool) -> int:
    """R0 curated carry-over: archive what an importer guessed, flag what stays.

    The rule is one line — **a record carrying a `review:` block was drafted by
    an importer and nobody confirmed it, so it does not survive the reset** —
    and the interesting part is what happens to the survivors: they are stamped
    with :data:`CARRY_OVER_NOTE`, which makes them badge as unreviewed
    everywhere the palette shows them until a human opens the record and
    deletes the note.

    Archiving is trio-aware (a module drags its component and template unless
    another module still needs them), so reference integrity holds afterwards
    — which `library validate` will confirm.

    Dry run by default. This moves directories and rewrites records; it should
    be read before it is run.
    """
    from .io.yamlio import (
        _to_plain,  # noqa: PLC2701 — internal helper reuse
        dump_document,
        load_document,
    )
    from .library.build import RECORD_FILES

    doomed: list[tuple[str, str, int]] = []          # (kind, id, note count)
    survivors: list[tuple[Path, str, bool]] = []      # (file, id, is_starter)
    for kind in ("components", "templates", "modules", "groups"):
        for file in sorted((root / kind).glob("*/*.yml")):
            if file.name not in RECORD_FILES:
                continue
            try:
                data = _to_plain(load_document(file)) or {}
            except Exception:  # noqa: BLE001
                continue
            rid = data.get("id") or file.parent.name
            # A record's OWN carry-over stamp is not an importer's guess. Left
            # uncounted, the second run of a reset archives everything the
            # first one carried over — the stamp would be a slow delete.
            notes = [n for n in (data.get("review") or [])
                     if _norm_note(n) != _norm_note(CARRY_OVER_NOTE)]
            if notes:
                doomed.append((kind, rid, len(notes)))
            else:
                survivors.append((file, rid, STARTER_TAG in (data.get("tags") or [])))

    print(f"{len(doomed)} record(s) carry a review: block and will be ARCHIVED")
    for kind, rid, n in doomed:
        print(f"  archive  {kind:11} {rid}  ({n} note(s))")
    print()
    starters = [rid for _f, rid, is_starter in survivors if is_starter]
    print(f"{len(survivors)} record(s) are clean and will be CARRIED OVER "
          f"({len(survivors) - len(starters)} stamped unreviewed, "
          f"{len(starters)} starter record(s) left untouched)")
    for _file, rid, is_starter in survivors:
        print(f"  {'starter ' if is_starter else 'carry   '} {rid}")

    if not apply:
        print()
        print("dry run — nothing moved. Re-run with --apply to perform the reset.")
        return 0

    for _kind, rid, _n in doomed:
        _library_archive(root, rid)

    stamped = 0
    for file, rid, is_starter in survivors:
        if is_starter:
            continue  # the quality bar keeps its meaning (see STARTER_TAG)
        if not file.is_file():
            continue  # archived as a trio dependency in the loop above
        doc = load_document(file)
        existing = list(_to_plain(doc).get("review") or [])
        # Compared on normalized whitespace: the YAML writer line-wraps a note
        # this long, and a re-read gives back the folded form. Comparing raw
        # would stack a duplicate stamp on every run.
        if any(_norm_note(n) == _norm_note(CARRY_OVER_NOTE) for n in existing):
            continue
        doc["review"] = [*existing, CARRY_OVER_NOTE]
        file.write_text(dump_document(doc), encoding="utf-8", newline="\n")
        stamped += 1
        print(f"flagged  {rid}")

    print()
    print(f"reset applied: {len(doomed)} archived, {stamped} carried over and "
          f"flagged, {len(starters)} starter record(s) untouched.")
    print("Every carried-over part now badges as unreviewed in the palette until "
          "someone confirms it in the component editor and removes the note.")
    print("Run `optikit-core library validate` then `library build`.")
    return 0


def cmd_library(args: argparse.Namespace) -> int:
    from .library import (
        LibraryError,
        build_index,
        check_references,
        load_library,
        write_index,
    )

    root = Path(args.root) if args.root else _repo_library_root()
    if not root.is_dir():
        print(f"no library directory at {root}", file=sys.stderr)
        return 2

    if args.subcommand == "archive":
        if not args.module_id:
            print("archive needs a <record-id>", file=sys.stderr)
            return 2
        return _library_archive(root, args.module_id)

    if args.subcommand == "reset":
        return _library_reset(root, apply=bool(getattr(args, "apply", False)))

    if args.subcommand == "restore":
        # WP-68: move an archived record trio back into the live library.
        if not args.module_id:
            print("restore needs a <record-id>", file=sys.stderr)
            return 2
        return _library_restore(root, args.module_id)

    library = load_library(root)

    if args.subcommand == "vendor-assets":
        # WP-58: pull remotely-referenced meshes next to their record so the
        # ONE library has ONE asset home (the WP-43 migration left 64 records
        # naming a local file they never shipped).
        from .library.vendor import plan, vendor_all

        pending = plan(library)
        if not pending:
            print("nothing to vendor — every referenced asset is already local")
            return 0
        if args.dry_run:
            for item in pending:
                print(f"WOULD FETCH  {item.record_id}\n             {item.url}\n"
                      f"          -> {item.target}")
            print(f"\n{len(pending)} asset(s) would be downloaded")
            return 0
        fetched, failed = vendor_all(library)
        for item, size in fetched:
            print(f"OK   {item.record_id}: {size / 1024:.0f} KiB -> {item.target.name}")
        for item, error in failed:
            print(f"FAIL {item.record_id}: {error}", file=sys.stderr)
        print(f"\nvendored {len(fetched)}, failed {len(failed)}")
        return 1 if failed else 0

    if args.subcommand == "migrate-materials":
        # WP-63: one-shot repair of the WP-43 migration's invented material
        # tag — {type: "ideal"} → optiland's registry vocabulary. A purely
        # mechanical edit through the ruamel round-trip (comments and review
        # flags untouched).
        from .io.yamlio import dump_document, load_document

        changed = 0
        for path in sorted(root.glob("**/component.yml")):
            if "dist" in path.parts:
                continue
            doc = load_document(path)
            surfaces = ((((doc or {}).get("optics") or {}).get("fragment") or {})
                        .get("surfaces") or [])
            touched = False
            for surface in surfaces:
                for key in ("material_post", "material_pre"):
                    material = surface.get(key)
                    if not (isinstance(material, dict) and material.get("type") == "ideal"):
                        continue
                    if material.get("name"):
                        material["type"] = "Material"
                    elif "index" in material:
                        material["type"] = "IdealMaterial"
                    else:
                        print(f"SKIP {path}: bare {{type: ideal}} with neither "
                              "name nor index", file=sys.stderr)
                        continue
                    touched = True
            if touched:
                path.write_text(dump_document(doc), encoding="utf-8")
                changed += 1
                print(f"migrated {path.relative_to(root)}")
        print(f"\n{changed} record(s) rewritten onto optiland's registry vocabulary")
        return 0

    if args.subcommand == "verify-t1":
        from .library.verify import verify_t1, verify_t1_ok

        if not args.module_id:
            print("verify-t1 needs a <module-id>", file=sys.stderr)
            return 2
        findings = verify_t1(library, args.module_id)
        for finding in findings:
            print(finding, file=sys.stderr if finding.level == "error" else sys.stdout)
        if not verify_t1_ok(findings):
            return 1
        print(f"OK  {args.module_id}: optics and mechanics agree (T1)")
        return 0

    errors = list(library.errors)
    errors += check_references(library)

    # WP-40: surfaces are the truth — warn where a component's authored port
    # directions disagree with what its fragment + frame rotations imply.
    from .library.actuation import check_actuation
    from .library.derive import check_port_directions
    from .schema.library import ComponentRecord as _CompRec

    direction_warnings: list[str] = []
    for record in library.records:
        if isinstance(record.record, _CompRec):
            direction_warnings += [
                f"{record.record.id}: {w}" for w in check_port_directions(record.record)
            ]

    # WP-42: the actuation contract — template DOFs ↔ module firmware axis-map.
    actuation_warnings: list[str] = []
    for level, code, message in check_actuation(library):
        if level == "error":
            errors.append(LibraryError("", f"{code}: {message}"))
        else:
            actuation_warnings.append(f"{code}: {message}")

    # KIT-00: read every fragment through the canvas dialect and surface its
    # findings informationally. Dialect errors do not fail `library validate`
    # yet — they become blocking when the materializer (KIT-02+) consumes them.
    from .canvas import parse_fragment

    dialect_findings: list[str] = []
    for record in library.records:
        rec = record.record
        if not isinstance(rec, _CompRec) or rec.optics.fragment is None:
            continue
        where = f"{rec.id}.optics.fragment.surfaces"
        for finding in parse_fragment(rec.optics.fragment.surfaces, where).findings:
            dialect_findings.append(str(finding))

    # WP-48: authored schematic symbols — present, scalable, themable.
    # WP-47: slm/display records carry their pixel facts.
    from .library.symbols import check_programmable_records, check_symbols

    symbol_warnings: list[str] = []
    for level, code, message in check_symbols(library) + check_programmable_records(library):
        if level == "error":
            errors.append(LibraryError("", f"{code}: {message}"))
        else:
            symbol_warnings.append(f"{code}: {message}")

    # WP-109: a cube template's MESH must measure the cell it claims. The
    # library carries two undeclared glTF frame conventions (one ships an
    # Rx(-90°) wrapper node, one does not), and the way that fails is a cube
    # rendering on its side. Checking the bounding box catches a lost wrapper,
    # wrong units and the wrong file at once — no new schema field needed.
    from .library.mesh import check_template_mesh
    from .schema.library import TemplateRecord as _TplRec

    mesh_warnings: list[str] = []
    for record in library.records:
        tpl = record.record
        if not isinstance(tpl, _TplRec) or not tpl.glb:
            continue
        glb_path = record.path.parent / tpl.glb
        if not glb_path.is_file():
            continue
        env = tpl.envelope
        envelope = (
            (float(env.x_mm), float(env.y_mm), float(env.z_mm)) if env else None
        )
        pose = getattr(tpl, "mesh_pose", None)
        pose_grid = (
            (pose.rotation.grid.z or "+z", pose.rotation.grid.x or "+x")
            if pose is not None
            else None
        )
        # WP-156: a residual tilt (housings only — the schema rejects it on
        # cube-mounted templates) switches the mesh checks to their
        # orientation-tolerant readings.
        pose_off = pose.rotation.offset_deg if pose is not None else None
        pose_tilted = pose_off is not None and any(
            abs(float(v or 0.0)) > 1e-9 for v in (pose_off.x, pose_off.y, pose_off.z)
        )
        for level, code, message in check_template_mesh(
            tpl.id, envelope, tpl.footprint_grid, tpl.provenance, glb_path,
            mesh_frame=getattr(tpl, "mesh_frame", ""),
            # WP-137: the file->cube correction, when declared.
            mesh_pose_grid=pose_grid,
            mesh_pose_tilted=pose_tilted,
            # WP-134: the AS-MOUNTED ports (cube frame) are what the glass has
            # to agree with — the record's own F2 ports describe an unmounted
            # optic and say nothing about which way the mirror ended up facing.
            optical_ports={
                name: str(port.direction)
                for name, port in (tpl.optical_ports or {}).items()
                if isinstance(port.direction, str)
            },
        ):
            if level == "error":
                errors.append(LibraryError("", f"{code}: {message}"))
            else:
                mesh_warnings.append(f"{code}: {message}")

    # WP-53: group structure — envelope, overlaps, sandwich plates, joints.
    from .library.groups import check_groups

    group_warnings: list[str] = []
    for finding in check_groups(library):
        if finding.level == "error":
            errors.append(LibraryError("", f"{finding.code}: {finding.message}"))
        else:
            group_warnings.append(f"{finding.code}: {finding.message}")

    for record in sorted(library.records, key=lambda r: (r.record.kind, r.record.id)):
        flag = " [review]" if record.record.review else ""
        print(f"OK  {record.record.kind:<20} {record.record.id}@{record.record.version}{flag}")
    for warning in (
        direction_warnings + actuation_warnings + symbol_warnings + group_warnings
        + mesh_warnings
    ):
        print(f"WARN {warning}")
    for finding in dialect_findings:
        print(f"DIALECT {finding}")
    for error in errors:
        print(f"ERR {error}", file=sys.stderr)

    if errors:
        return 1
    if args.subcommand == "build":
        out = write_index(library, root)
        index = build_index(library, root)
        print(f"wrote {out} ({index['count']} module(s))")
    return 0


def cmd_import_layout_json(args: argparse.Namespace) -> int:
    from .importers.layout_json import import_layout_json
    from .library import load_library

    root = Path(args.library) if args.library else _repo_library_root()
    library = load_library(root)
    source = Path(args.layout)
    result = import_layout_json(source, library, name=args.name)

    out_dir = Path(args.out) if args.out else source.with_suffix(".dsn")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / "optikit-design.yml"
    out_file.write_text(result.design_yaml, encoding="utf-8")

    print(f"wrote {out_file} ({result.components} component(s))")
    for warning in result.warnings:
        print(f"WARN {warning}")
    if result.unresolved:
        print(f"⚠ {len(result.unresolved)} unresolved module reference(s) — "
              f"review before publishing")
    return 0


def cmd_group(args: argparse.Namespace) -> int:
    import json

    from .library import load_library
    from .library.groups import suggest_structure
    from .schema.library import GroupRecord

    root = Path(args.root) if args.root else _repo_library_root()
    library = load_library(root)
    hit = next(
        (
            e for e in library.by_kind("cube_group")
            if isinstance(e.record, GroupRecord) and e.record.id == args.group_id
        ),
        None,
    )
    if hit is None:
        print(f"no group {args.group_id!r} in {root}", file=sys.stderr)
        return 2
    assert isinstance(hit.record, GroupRecord)
    suggestion = suggest_structure(hit.record, library)
    print(json.dumps(suggestion, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="optikit-core",
        description="Normative datamodel tools for the openUC2 Optikit toolchain",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    validate = sub.add_parser(
        "validate",
        help="validate design files (a .dsn dir, an optikit-design.yml, or a tree of them)",
    )
    validate.add_argument("paths", nargs="+", help="design dirs/files or trees to scan")
    validate.add_argument(
        "-W", "--warnings", action="store_true", help="also print warning-level findings"
    )
    validate.set_defaults(func=cmd_validate)

    flatten_p = sub.add_parser(
        "flatten",
        help="anchor-resolve a design and report primitive world poses (Go: report primitives)",
    )
    flatten_p.add_argument("path", help="design dir or optikit-design.yml")
    flatten_p.add_argument("--format", choices=["yaml", "json"], default="yaml")
    flatten_p.set_defaults(func=cmd_flatten)

    cubify_p = sub.add_parser(
        "cubify",
        help="decompose world poses into grid poses (p = S·g + δ, R = R24·ΔR) and run DRC",
    )
    cubify_p.add_argument("path", help="design dir or optikit-design.yml")
    cubify_p.set_defaults(func=cmd_cubify)

    chain_p = sub.add_parser(
        "chain",
        help="infer paths: blocks by chief-ray propagation over world poses",
    )
    chain_p.add_argument("design", help="design dir or optikit-design.yml")
    chain_p.add_argument("--infer", action="store_true", required=True,
                         help="run inference (explicit by design)")
    chain_p.add_argument("--write", action="store_true",
                         help="merge proposed paths into the design file")
    chain_p.set_defaults(func=cmd_chain)

    compile_p = sub.add_parser(
        "compile",
        help="compile a design path to a native Optiland optic.json + trace manifest",
    )
    compile_p.add_argument("design", help="design dir or optikit-design.yml")
    compile_p.add_argument(
        "--path", dest="path_name", default=None,
        help="path name to compile (default: every declared path)",
    )
    compile_p.add_argument("--out", default=".", help="output directory (default: cwd)")
    compile_p.add_argument(
        "--summary", action="store_true",
        help="also write summary.json with paraxial properties (requires optiland)",
    )
    compile_p.set_defaults(func=cmd_compile)

    annotate_p = sub.add_parser(
        "back-annotate",
        help="classify an optimized optic.json against the design (dry run by default)",
    )
    annotate_p.add_argument("design", help="design dir or optikit-design.yml")
    annotate_p.add_argument("optimized", help="optimized optic.json from Optiland")
    annotate_p.add_argument("--path", dest="path_name", required=True, help="path name")
    annotate_p.add_argument(
        "--apply", action="store_true",
        help="write accepted deltas into instantiation.dof_values + provenance",
    )
    annotate_p.add_argument("--optimized-by", default="optiland", help="provenance tool tag")
    annotate_p.set_defaults(func=cmd_back_annotate)

    # WP-86: the OTHER return leg — a running instrument's measured axes.
    calib_p = sub.add_parser(
        "calibrate",
        help="classify measured instrument axis positions against the design "
             "(dry run by default) — the hardware return leg",
    )
    calib_p.add_argument("design", help="design dir or optikit-design.yml")
    calib_p.add_argument(
        "measurements",
        help="JSON: {'<component>.<dof>': <measured value in the dof's unit>, …}",
    )
    calib_p.add_argument(
        "--apply", action="store_true",
        help="write measured values into instantiation.dof_values + "
             "provenance {source: instrument}",
    )
    calib_p.add_argument("--instrument", default="", help="instrument id / device URL")
    calib_p.add_argument("--note", default="", help="free-text provenance note")
    calib_p.set_defaults(func=cmd_calibrate)

    fx_p = sub.add_parser(
        "fx",
        help="emit the optikit-fx.json changeset (dof values → Inventor fx parameters, WP-35)",
    )
    fx_p.add_argument("design", help="design dir or optikit-design.yml")
    fx_p.add_argument("-o", "--out", default=None, help="output file (default: stdout)")
    fx_p.add_argument("--library", default=None, help="library dir (default: repo library/)")
    fx_p.set_defaults(func=cmd_fx)

    serve_p = sub.add_parser("serve", help="run the HTTP service (FastAPI/uvicorn)")
    serve_p.add_argument("--host", default="0.0.0.0")
    serve_p.add_argument("--port", type=int, default=8000)
    serve_p.set_defaults(func=cmd_serve)

    library_p = sub.add_parser("library", help="validate and index the record library")
    library_p.add_argument(
        "subcommand",
        choices=["validate", "build", "verify-t1", "vendor-assets", "migrate-materials",
                 "archive", "reset", "restore"],
        help="validate: check records only; build: also write library/dist/index.json; "
             "verify-t1: cross-check a fixed module's optics against its mechanics (WP-35); "
             "vendor-assets: download remotely-referenced meshes next to their record (WP-58); "
             "migrate-materials: rewrite legacy {type: ideal} materials onto "
             "optiland's registry vocabulary (WP-63, one-shot); "
             "archive: move a live record trio OUT to archive/ (the mirror of restore); "
             "reset: R0 curated carry-over — archive every record carrying a review: "
             "block and flag the survivors as unconfirmed (dry run unless --apply); "
             "restore: move an archived record trio back into the library (WP-68)",
    )
    library_p.add_argument(
        "--apply", action="store_true",
        help="reset: actually move and rewrite records (default is a dry run)",
    )
    library_p.add_argument(
        "--dry-run", action="store_true",
        help="vendor-assets: list what WOULD be downloaded, fetch nothing",
    )
    library_p.add_argument(
        "module_id", nargs="?", default=None,
        help="record id for verify-t1 / restore (e.g. openuc2.cube.mirror_45)",
    )
    library_p.add_argument("--root", default=None, help="library dir (default: repo library/)")
    library_p.set_defaults(func=cmd_library)

    group_p = sub.add_parser("group", help="cube-group tools (WP-53): the OPM arrangement")
    group_p.add_argument(
        "subcommand", choices=["suggest"],
        help="suggest: derive the minimal plates + puzzle joints for a group",
    )
    group_p.add_argument("group_id", help="group id, e.g. openuc2.group.miniframe_brightfield")
    group_p.add_argument("--root", default=None, help="library dir (default: repo library/)")
    group_p.set_defaults(func=cmd_group)

    export_p = sub.add_parser("export", help="export a design to a downstream format")
    export_sub = export_p.add_subparsers(dest="format", required=True)
    step_p = export_sub.add_parser(
        "step", help="one grouped STEP assembly: modules, lathed optics, the beam (WP-57)"
    )
    step_p.add_argument("design", help="path to the .dsn design directory")
    step_p.add_argument("-o", "--out", default=None, help="output .step (default: <design>.step)")
    step_p.add_argument(
        "--beam", choices=["solid", "wires", "off"], default="solid",
        help="how the traced beam is emitted (default: solid swept cylinders)",
    )
    step_p.add_argument(
        "--beam-radius", type=float, default=None,
        help="radius of a beam solid in mm (default: 0.5)",
    )
    step_p.add_argument(
        "--component", default=None, metavar="KEY",
        help="WP-84: export ONE design component, posed w.r.t. its cube frame "
             "(for designing the cube module around it in Inventor)",
    )
    step_p.add_argument("--library", default=None, help="library dir (default: repo library/)")
    step_p.set_defaults(func=cmd_export_step)

    scene3_p = export_sub.add_parser(
        "scene3",
        help="materialize a design into a Scene3 (.ocanvas v2) + manifest for the Canvas kernel",
    )
    scene3_p.add_argument("design", help="design dir or optikit-design.yml")
    scene3_p.add_argument(
        "--path", dest="path_name", default=None,
        help="single path to materialize (default: all paths in one scene)",
    )
    scene3_p.add_argument("--out", default=".", help="output directory (default: cwd)")
    scene3_p.add_argument("--pretty", action="store_true", help="indent the emitted JSON")
    scene3_p.set_defaults(func=cmd_export_scene3)

    import_p = sub.add_parser("import", help="import external CAD/vendor formats into the library")
    import_sub = import_p.add_subparsers(dest="format", required=True)
    glb_p = import_sub.add_parser("glb", help="an openUC2 Inventor GLB export → library records")
    glb_p.add_argument("glb", help="path to the .glb file")
    glb_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    glb_p.add_argument("--namespace", default="openuc2", help="id namespace (default: openuc2)")
    glb_p.set_defaults(func=cmd_import_glb)

    zmx_p = import_sub.add_parser(
        "zmx", help="a vendor Zemax prescription → optical component record"
    )
    zmx_p.add_argument("zmx", help="path to the .zmx file")
    zmx_p.add_argument("--mpn", default="", help="manufacturer part number (default: filename)")
    zmx_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    zmx_p.add_argument("--namespace", default="thorlabs", help="id namespace (default: thorlabs)")
    zmx_p.add_argument("--vendor", default="Thorlabs", help="vendor name (default: Thorlabs)")
    zmx_p.set_defaults(func=cmd_import_zmx)

    thorlabs_p = import_sub.add_parser(
        "thorlabs",
        help="batch: Thorlabs MPNs → component records, from local .zmx files",
        description="Downloads are out of scope: fetch each part's Zemax file from "
        "its thorlabs.com product page and drop it into --zmx-dir.",
    )
    thorlabs_p.add_argument("mpns", nargs="+", help="manufacturer part numbers, e.g. AC254-050-A")
    thorlabs_p.add_argument("--zmx-dir", required=True, help="directory with the .zmx files")
    thorlabs_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    thorlabs_p.add_argument("--namespace", default="thorlabs", help="id namespace")
    thorlabs_p.set_defaults(func=cmd_import_thorlabs)

    actuate_p = sub.add_parser(
        "actuate",
        help="resolve an actuatable DOF value → a firmware command (WP-26)",
        description="Prints the CAN/UC2-REST command that drives a module's DOF "
        "to a value, via its axis-map binding. Does not talk to hardware.",
    )
    actuate_p.add_argument("module_id", help="cube module id, e.g. openuc2.cube.galvo")
    actuate_p.add_argument("assignment", help="<dof>=<value>, e.g. tilt_x=7.5")
    actuate_p.add_argument("--root", default=None, help="library dir (default: repo library/)")
    actuate_p.set_defaults(func=cmd_actuate)

    layout_p = import_sub.add_parser(
        "layout-json", help="a legacy grid-builder layout JSON → .dsn design (WP-54)"
    )
    layout_p.add_argument("layout", help="path to the legacy layout .json")
    layout_p.add_argument(
        "--out", default=None,
        help="output .dsn directory (default: <layout-name>.dsn/ next to the input)",
    )
    layout_p.add_argument("--name", default="", help="design name (default: from filename)")
    layout_p.add_argument("--library", default=None, help="library dir (default: repo library/)")
    layout_p.set_defaults(func=cmd_import_layout_json)

    csv_p = import_sub.add_parser(
        "csv", help="the legacy CSV palette → library record trios (WP-43)"
    )
    csv_p.add_argument("csv", help="path to modules_updated.csv (';'-delimited)")
    csv_p.add_argument("--out", default=None, help="library dir (default: repo library/)")
    csv_p.add_argument("--namespace", default="openuc2", help="id namespace (default: openuc2)")
    csv_p.set_defaults(func=cmd_import_csv)

    generate_p = sub.add_parser(
        "generate",
        help="run a T3 (generative) template's CadQuery generator headlessly",
        description="Artifacts land in out/<template-id>/<sha256[:12] of canonical "
        "params>/ as model.step + model.stl + model.glb + meta.json.",
    )
    generate_p.add_argument("template_id", nargs="?", default=None, help="library template id")
    generate_p.add_argument(
        "--all", action="store_true", help="regenerate every T3 template in the library"
    )
    generate_p.add_argument(
        "--param", action="append", default=[], metavar="KEY=VALUE",
        help="override one generator parameter (repeatable)",
    )
    generate_p.add_argument("--params-json", default=None, help="JSON file with overrides")
    generate_p.add_argument(
        "--design", default=None,
        help="design dir: with --component, regenerate around the placed pose (WP-35 T3)",
    )
    generate_p.add_argument(
        "--component", default=None, help="design component key whose pose drives the cavity",
    )
    generate_p.add_argument("--out", default="out", help="artifact root (default: out/)")
    generate_p.add_argument("--library", default=None, help="library dir (default: repo library/)")
    generate_p.add_argument(
        "--force", action="store_true", help="regenerate even if the key already exists"
    )
    generate_p.set_defaults(func=cmd_generate)

    rebuild_p = sub.add_parser(
        "rebuild",
        help="verify a release bundle: check lockfile pins + recompile all paths",
        description="The reproducibility check for bundles exported by the editor "
        "(File → Export Release Bundle): every pinned file must hash to its pin, "
        "and every locked path must recompile to a bit-identical optic.",
    )
    rebuild_p.add_argument("bundle", help="path to the release .zip")
    rebuild_p.set_defaults(func=cmd_rebuild)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    # Debug entry: a bare `python cli.py` starts the API with defaults (the
    # serve command); any explicit arguments dispatch through the full CLI.
    if len(sys.argv) > 1:
        sys.exit(main())
    cmd_serve(argparse.Namespace(host="0.0.0.0", port=8000))


# Re-exported for tests / callers that want the resolution rule without the CLI.
__all__ = ["main", "resolve_design_file"]
