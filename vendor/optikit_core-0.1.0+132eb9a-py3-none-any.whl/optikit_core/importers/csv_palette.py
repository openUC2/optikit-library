"""Migrate the legacy CSV palette into library record trios (WP-43).

The React app's schematic palette historically came from a spreadsheet
(``modules_updated.csv`` + the Store's ``parts.csv``): one row per placeable
part, with optical params, a GLB reference, group/colour, price and docs. This
importer converts each row into the three git-versioned records the library
speaks — component (the optical symbol), template (the mechanical footprint +
GLB), module (the binding) — so the palette can read ONE database.

Category comes from the row's group + ``opticalKind`` (mapped to the schema's
``KNOWN_CATEGORIES``); optical params (focal length, wavelength, sensor size)
become the component; the GLB reference and footprint become the template;
price/docs/vendor ride along as record fields. Rows with no optical role
(cubes, stages, holders) become ``mechanics`` records; ``electronics`` rows
become ``electronics`` records (WP-30 non-optical categories). **Everything is
review-flagged** — an auto-conversion is a draft until a human confirms it.

Ports follow the library ±z convention (optical axis = local z, WP-29/WP-34):
placement rotates the entry beam onto the document +x, so migrated parts route
exactly like the hand-authored records.
"""

from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# --- category derivation -----------------------------------------------------------------

#: N-BK7 index at 587.6 nm — the thin-lens radius approximation (WP-32 parity).
_N_BK7 = 1.5168

_LENS_KINDS = {"thin_lens", "objective", "cylindrical", "achromat", "lens"}
_FILTER_KINDS = {"filter", "ndfilter", "polarizer", "waveplate"}
_APERTURE_KINDS = {"pinhole", "aperture", "iris", "slit"}


def derive_category(row: dict[str, str]) -> str:
    """The schema category for a CSV row (group + opticalKind + id patterns)."""
    group = (row.get("group") or "").lower()
    kind = (row.get("opticalKind") or "").lower()
    rid = (row.get("id") or "").lower()

    if "dichroic" in rid or "dichroic" in kind:
        return "dichroic"
    if any(s in rid for s in ("beamsplitter", "splitter")):
        return "beamsplitter"
    if group in ("mirror", "mirrors") or "mirror" in rid or "galvo" in rid:
        return "mirror"
    if group == "electronics":
        return "electronics"
    if group in ("cameras", "detector") or any(s in rid for s in ("camera", "sensor", "detector")):
        return "detector"
    if group == "illumination" or any(s in rid for s in ("led", "laser", "torch", "dmd", "slm")):
        return "source"
    if group in ("lenses",) or kind in _LENS_KINDS:
        return "lens"
    if kind in _FILTER_KINDS or "filter" in rid:
        return "filter"
    if kind in _APERTURE_KINDS:
        return "filter"
    if group in ("fluorescence", "samples") or "sample" in rid:
        return "sample"
    # cubes, stages, frames, passive holders, wildcards → non-optical mechanics.
    return "mechanics"


# Ports per category, ±z record convention (openuc2.mirror.flat_45 etc.).
_PORTS: dict[str, dict[str, dict[str, Any]]] = {
    "lens": {"front": {"frame": "optical", "direction": "-z"},
             "back": {"frame": "optical", "direction": "+z", "after-surface": 1}},
    "filter": {"front": {"frame": "optical", "direction": "-z"},
               "back": {"frame": "optical", "direction": "+z"}},
    "mirror": {"front": {"frame": "optical", "direction": "-z"},
               "reflected": {"frame": "optical", "direction": "+x", "after-surface": 0}},
    "beamsplitter": {"front": {"frame": "optical", "direction": "-z"},
                     "transmitted": {"frame": "optical", "direction": "+z", "after-surface": 0},
                     "reflected": {"frame": "optical", "direction": "+x", "after-surface": 0}},
    "dichroic": {"front": {"frame": "optical", "direction": "-z"},
                 "transmitted": {"frame": "optical", "direction": "+z", "after-surface": 0},
                 "reflected": {"frame": "optical", "direction": "+x", "after-surface": 0}},
    "source": {"out": {"frame": "optical", "direction": "+z"}},
    "detector": {"sensor": {"frame": "optical", "direction": "-z"}},
    "sample": {"front": {"frame": "optical", "direction": "-z"}},
}


def _num(row: dict[str, str], key: str) -> float | None:
    raw = (row.get(key) or "").strip()
    if not raw:
        return None
    try:
        return float(raw)
    except ValueError:
        return None


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_") or "part"


def _optics_for(category: str, row: dict[str, str], review: list[str]) -> dict[str, Any] | None:
    """The component's optics block (fragment + frames + ports) for a category."""
    if category in ("electronics", "mechanics"):
        return None  # non-optical: no optics block (WP-30)

    frames = {"optical": {"z-mm": 0.0}}
    ports = _PORTS.get(category, {"front": {"frame": "optical", "direction": "-z"}})
    optics: dict[str, Any] = {"frames": frames, "ports": ports}

    if category == "lens":
        f = _num(row, "focalLength_mm") or 100.0
        dia = _num(row, "diameter_mm") or 25.0
        thick = _num(row, "thickness_mm") or 3.0
        r = abs(2 * f * (_N_BK7 - 1))
        sign = 1.0 if f >= 0 else -1.0
        semi = dia / 2.0
        # WP-63: optiland's registry keys on class names — a named glass is
        # {type: Material}; the invented "ideal" tag broke Optic.from_dict.
        material = {"type": "Material", "name": row.get("material") or "N-BK7"}
        optics["fragment"] = {"surfaces": [
            {"type": "standard",
             "geometry": {"type": "StandardGeometry", "radius": round(sign * r, 4), "conic": 0.0},
             "thickness": thick, "material_post": material, "semi_aperture": semi},
            {"type": "standard",
             "geometry": {"type": "StandardGeometry", "radius": round(-sign * r, 4), "conic": 0.0},
             "semi_aperture": semi},
        ]}
        review.append(
            "lens surfaces are a thin biconvex approximation from focalLength — verify the trace"
        )
    elif category in ("mirror", "beamsplitter", "dichroic"):
        optics["fragment"] = {"surfaces": [
            {"type": "standard",
             "geometry": {"type": "StandardGeometry", "radius": ".inf"},
             "interaction_model": {"type": "refractive_reflective", "is_reflective": True}},
        ]}
    elif category in ("filter", "sample"):
        optics["passthrough"] = True
    return optics


# --- record assembly ---------------------------------------------------------------------


@dataclass
class RowResult:
    row_id: str
    category: str
    component: dict[str, Any] | None
    template: dict[str, Any]
    module: dict[str, Any]
    review: list[str] = field(default_factory=list)


@dataclass
class CsvImportResult:
    rows: list[RowResult] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)


def row_to_records(row: dict[str, str], namespace: str = "openuc2") -> RowResult:
    """One CSV row → a component/template/module trio (review-flagged)."""
    review: list[str] = ["auto-migrated from the legacy CSV palette (WP-43) — confirm the record"]
    category = derive_category(row)
    slug = _slug(row.get("id") or row.get("name") or "part")
    name = row.get("name") or slug
    description = row.get("description") or ""
    docs = [row.get("docsUrl")] if row.get("docsUrl") else []
    glb_url = row.get("glbUrl") or ""
    glb_name = Path(glb_url).name if glb_url else ""
    width = int(_num(row, "width") or 1)
    height = int(_num(row, "height") or 1)
    group = row.get("group") or ""

    component_id = f"{namespace}.{category}.{slug}"
    template_id = f"{namespace}.tpl.{slug}"
    module_id = f"{namespace}.cube.{slug}"

    optics = _optics_for(category, row, review)
    component: dict[str, Any] | None = None
    if optics is not None or category in ("electronics", "mechanics"):
        component = {
            "kind": "optical_component", "id": component_id, "version": "0.1.0",
            "category": category, "description": description,
            "tags": [t for t in ("migrated", group) if t], "docs": docs,
            "review": list(review),
        }
        if optics is not None:
            component["optics"] = optics
        efl = _num(row, "focalLength_mm")
        if category == "lens" and efl is not None:
            component["effective_focal_length_mm"] = efl
        vendor = row.get("vendor") or ""
        if vendor:
            component["vendor"] = {"name": vendor, "mpn": row.get("sku") or "", "url": ""}

    template: dict[str, Any] = {
        "kind": "mechanical_template", "id": template_id, "version": "0.1.0",
        "class": "fixed",
        "description": f"{name} mount (migrated)",
        "tags": [t for t in ("migrated", group) if t],
        "envelope": {"x-mm": 50.0 * width, "y-mm": 50.0 * height, "z-mm": 50.0},
        "footprint_grid": [width, height, 1],
        "review": list(review),
    }
    if glb_name:
        template["glb"] = glb_name
        template["glb-url"] = glb_url  # provenance for a later fetch (extra=allow)

    module: dict[str, Any] = {
        "kind": "cube_module", "id": module_id, "version": "0.1.0",
        "description": description or name,
        "tags": [t for t in ("migrated", "cube", f"cube/{category}", group) if t],
        "docs": docs,
        "component": f"{component_id}@^0.1",
        "template": f"{template_id}@^0.1",
        "footprint_grid": [width, height, 1],
        "review": list(review),
    }
    price = _num(row, "price")
    if price is not None:
        module["price"] = price

    return RowResult(row.get("id") or slug, category, component, template, module, review)


def import_csv(path: str | Path, namespace: str = "openuc2") -> CsvImportResult:
    """Parse a ``;``-delimited palette CSV into record trios."""
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    reader = csv.DictReader(io.StringIO(text), delimiter=";")
    result = CsvImportResult()
    seen: set[str] = set()
    for row in reader:
        rid = (row.get("id") or "").strip()
        if not rid:
            continue
        if rid in seen:
            result.skipped.append(f"{rid} (duplicate id)")
            continue
        seen.add(rid)
        result.rows.append(row_to_records(row, namespace))
    return result
