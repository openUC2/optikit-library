"""Optiland setup import: a serialized SYSTEM → component records + placement plan.

WP-87, the third import road beside ``.zmx`` (one vendor lens) and GLB (one
mechanical cube): a whole Optiland setup — the JSON of ``optic.to_dict()`` —
becomes a ROW of unbound free primitives. Interior surfaces are split into
contiguous-glass elements (the WP-62/WP-75 grouping rule), each element
becoming one :class:`~optikit_core.schema.library.ComponentRecord` whose
``optics.fragment`` carries its surfaces verbatim, and the air gaps between
elements become a placement plan (axial ``z-mm`` per component) that belongs
to the LAYOUT, not to any record — the same thickness split
:func:`~optikit_core.importers.thorlabs.zmx_to_component` applies to its
trailing back-focal gap.

Deliberately NO template / T-class anywhere: the imported primitives are
unbound by design — mechanics arrive later through cubify / WP-67 housings /
WP-84 attach. A source (carrying the system's wavelength line list) and a
detector bracket the plan so chain inference has its walk start and terminal.

Everything here is pure dict processing — optiland itself is NOT required:
the serialized system is self-describing.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..schema.library import ComponentRecord
from .thorlabs import INITIAL_VERSION, _normalize_material

#: Object distance assumed when the object surface sits at infinity (mm).
DEFAULT_SOURCE_GAP_MM = 50.0

#: ZMX-style fallback clear semi-aperture (Ø25.4 mm optic) when the setup
#: declares none — flagged for review, never silent.
DEFAULT_SEMI_APERTURE_MM = 12.7


class OptilandSetupError(Exception):
    """A serialized Optiland system could not be imported (wrong shape)."""


@dataclass
class OptilandSetupResult:
    """One imported setup: the component records plus the placement plan."""

    components: list[dict[str, Any]] = field(default_factory=list)
    #: Axial order: ``{"component": <id>, "z-mm": <float>, "kind": ...}``.
    placements: list[dict[str, Any]] = field(default_factory=list)
    review: list[str] = field(default_factory=list)
    wavelengths_um: list[float] = field(default_factory=list)

    @property
    def records(self) -> dict[str, str]:
        """The PROPOSED records in the library-PR layout, ready to accept."""
        from ..io.yamlio import dump_document

        return {
            f"components/{component['id']}/component.yml": dump_document(component)
            for component in self.components
        }


def name_prefix_from_filename(filename: str) -> str:
    """Slugify an upload name into a record-id-safe prefix (``setup`` fallback)."""
    stem = Path(filename).stem
    slug = re.sub(r"[^a-z0-9_-]+", "-", stem.lower()).strip("-")
    if not slug or not slug[0].isalnum():
        return "setup"
    return slug


# --- shape helpers -----------------------------------------------------------------------


def _normalize_radius(geometry: dict[str, Any]) -> None:
    """Undo JavaScript's lossy Infinity handling on one geometry dict.

    Same spelling as the service's ``_normalize_optic``: ``null`` and
    1e999-overflow floats are flat radii, restored to ±inf.
    """
    radius = geometry.get("radius")
    if radius is None:
        geometry["radius"] = math.inf
    elif isinstance(radius, int | float) and abs(radius) >= 1e308:
        geometry["radius"] = math.copysign(math.inf, radius)


def _glass_groups(
    surfaces: list[dict[str, Any]], materials: list[dict | None]
) -> list[tuple[int, int, float]]:
    """Contiguous glass groups ``(first, last, z_offset_mm)`` of the stack.

    Mirrors ``generators/optic_solid.py::glass_groups`` (pure math), which is
    not importable here: the generators tree is not a package and pulls in
    cadquery at module top. One difference: serialized systems spell air as a
    truthy ``IdealMaterial`` dict (fragments omit it), so grouping runs on the
    NORMALIZED materials — a surface with glass continues the element; one
    with ``None`` (air follows) ends it, its air-gap thickness advancing the
    axis but belonging to the layout.
    """
    groups: list[tuple[int, int, float]] = []
    start: int | None = None
    z = 0.0
    z_start = 0.0
    for i, surface in enumerate(surfaces):
        if start is None:
            start = i
            z_start = z
        z += float(surface.get("thickness") or 0.0)
        if materials[i] is None or i == len(surfaces) - 1:
            groups.append((start, i, z_start))
            start = None
    return groups


def _is_reflective(surface: dict[str, Any]) -> bool:
    return bool((surface.get("interaction_model") or {}).get("is_reflective"))


def _wavelengths_um(optic_json: dict[str, Any], review: list[str]) -> list[float]:
    entries = (optic_json.get("wavelengths") or {}).get("wavelengths") or []
    values: list[float] = []
    for entry in entries:
        unit = str(entry.get("unit", "um"))
        if unit != "um":
            review.append(f"wavelength {entry.get('value')} declared in {unit!r}, kept as-is")
        values.append(float(entry["value"]))
    if not values:
        review.append("setup declares no wavelengths — source imported with an empty line list")
    return values


def _source_z_mm(object_surface: dict[str, Any]) -> float:
    """Source placement: the finite object distance, else 50 mm before element 1."""
    cs_z = ((object_surface.get("geometry") or {}).get("cs") or {}).get("z")
    if isinstance(cs_z, int | float) and math.isfinite(cs_z):
        return float(cs_z)
    thickness = object_surface.get("thickness")
    if isinstance(thickness, int | float) and math.isfinite(thickness):
        return -float(thickness)
    return -DEFAULT_SOURCE_GAP_MM


# --- the importer ------------------------------------------------------------------------


def _element_component(
    surfs: list[dict[str, Any]],
    materials: list[dict | None],
    n: int,
    namespace: str,
    name_prefix: str,
    review: list[str],
) -> tuple[dict[str, Any], str, float]:
    """One glass group → ``(component, kind, center_thickness_mm)``."""
    kind = "mirror" if len(surfs) == 1 and _is_reflective(surfs[0]) else "lens"
    fragment: list[dict[str, Any]] = []
    aperture_known = False
    for i, surf in enumerate(surfs):
        where = f"element {n} surface {i}"
        geometry = {k: v for k, v in (surf.get("geometry") or {}).items() if k != "cs"}
        _normalize_radius(geometry)
        gtype = geometry.get("type", "StandardGeometry")
        if gtype not in ("StandardGeometry", "Plane"):
            review.append(
                f"{where}: geometry {gtype!r} is beyond what the path compiler "
                "supports today — record kept, compilation will fail"
            )
        out: dict[str, Any] = {"type": "standard", "geometry": geometry}
        material = materials[i]
        if material is not None:
            out["material_post"] = material
        if kind == "lens" and _is_reflective(surf):
            review.append(f"{where}: reflective surface inside a glass group — verify")
        # The trailing thickness is the air gap to the NEXT element — layout,
        # not record (same convention as the zmx importer).
        if i < len(surfs) - 1:
            out["thickness"] = float(surf.get("thickness", 0.0))
        if surf.get("is_stop"):
            out["is_stop"] = True
        if _is_reflective(surf):
            out["interaction_model"] = {
                "type": "refractive_reflective",
                "is_reflective": True,
            }
        aperture = surf.get("aperture")
        atype = (aperture or {}).get("type", "")
        if atype == "RadialAperture" and float(aperture.get("r_max") or 0.0) > 0:
            out["semi_aperture"] = float(aperture["r_max"])
            aperture_known = True
        elif aperture is not None:
            out["aperture"] = aperture  # RectangularAperture et al., verbatim
            aperture_known = True
        fragment.append(out)

    if not aperture_known:
        for out in fragment:
            out["semi_aperture"] = DEFAULT_SEMI_APERTURE_MM
        review.append(
            f"element {n}: clear aperture unknown — defaulted to "
            f"{DEFAULT_SEMI_APERTURE_MM} mm semi-aperture, verify"
        )

    center_thickness = sum(s.get("thickness", 0.0) for s in fragment)
    if kind == "mirror":
        ports: dict[str, Any] = {
            "front": {"frame": "optical", "direction": "-z"},
            "reflected": {"frame": "optical", "direction": "-x", "after-surface": 0},
        }
    else:
        ports = {
            "front": {"frame": "optical", "direction": "-z"},
            "back": {
                "frame": "exit",
                "direction": "+z",
                "after-surface": len(fragment) - 1,
            },
        }
    component = {
        "kind": "optical_component",
        "id": f"{namespace}.{kind}.{name_prefix}-el{n}",
        "version": INITIAL_VERSION,
        "category": kind,
        "description": f"Optiland setup {name_prefix!r}, element {n}",
        "tags": ["imported", "optiland"],
        "optics": {
            "fragment": {"surfaces": fragment},
            "frames": {
                "optical": {"z-mm": 0.0},
                "exit": {"z-mm": round(center_thickness, 9)},
                "mount": {"z-mm": round(center_thickness / 2.0, 9)},
            },
            "ports": ports,
        },
    }
    return component, kind, center_thickness


def setup_to_components(
    optic_json: dict[str, Any],
    namespace: str = "user",
    name_prefix: str = "setup",
) -> OptilandSetupResult:
    """Import one serialized Optiland system (``optic.to_dict()`` JSON)."""
    if not isinstance(optic_json, dict):
        raise OptilandSetupError("not a serialized Optiland system (expected an object)")
    surfaces = (optic_json.get("surface_group") or {}).get("surfaces")
    if not isinstance(surfaces, list) or len(surfaces) < 3:
        raise OptilandSetupError(
            "not a serialized Optiland system: need surface_group.surfaces with "
            "at least one surface between object and image"
        )

    review: list[str] = []
    wavelengths_um = _wavelengths_um(optic_json, review)

    # Interior surfaces are the setup; index 0 is the object, the last the image
    # (the same unmarked-image convention the zmx importer relies on).
    interior = surfaces[1:-1]
    components: list[dict[str, Any]] = []
    placements: list[dict[str, Any]] = []

    # Source: the system's line list, placed at the object distance.
    source_id = f"{namespace}.source.{name_prefix}-source"
    components.append({
        "kind": "optical_component",
        "id": source_id,
        "version": INITIAL_VERSION,
        "category": "source",
        "description": f"Optiland setup {name_prefix!r}, source",
        "tags": ["imported", "optiland"],
        "source": {"wavelengths_um": wavelengths_um},
        "optics": {
            "frames": {"optical": {"z-mm": 0.0}},
            "ports": {"out": {"frame": "optical", "direction": "+z"}},
        },
    })
    placements.append({
        "component": source_id,
        "z-mm": _source_z_mm(surfaces[0]),
        "kind": "source",
    })

    # Normalize materials ONCE (air → None) — both the grouping and the
    # fragments run on the normalized view; labels use absolute surface indices.
    materials = [
        _normalize_material(surf, f"surface {i + 1}", review)
        for i, surf in enumerate(interior)
    ]

    last_exit_z = 0.0
    for n, (start, end, z_offset) in enumerate(_glass_groups(interior, materials), start=1):
        component, kind, center_thickness = _element_component(
            interior[start : end + 1],
            materials[start : end + 1],
            n,
            namespace,
            name_prefix,
            review,
        )
        if kind == "mirror":
            review.append(
                f"element {n}: mirror folds the axis — placements keep the "
                "unfolded signed z, re-fold on the canvas"
            )
        components.append(component)
        placements.append({"component": component["id"], "z-mm": z_offset, "kind": kind})
        last_exit_z = z_offset + center_thickness

    if len(components) == 1:
        raise OptilandSetupError("no optical elements between object and image")

    # Detector at the image plane: last exit + the back-focal air gap.
    bfd = float(interior[-1].get("thickness") or 0.0)
    detector_id = f"{namespace}.detector.{name_prefix}-detector"
    components.append({
        "kind": "optical_component",
        "id": detector_id,
        "version": INITIAL_VERSION,
        "category": "detector",
        "description": f"Optiland setup {name_prefix!r}, detector",
        "tags": ["imported", "optiland"],
        "optics": {
            "frames": {"optical": {"z-mm": 0.0}},
            "ports": {"sensor": {"frame": "optical", "direction": "-z"}},
        },
    })
    placements.append({
        "component": detector_id,
        "z-mm": last_exit_z + bfd,
        "kind": "detector",
    })

    result = OptilandSetupResult(
        components=components,
        placements=placements,
        review=review,
        wavelengths_um=wavelengths_um,
    )
    for component in components:
        # Validate eagerly — an unwritable record should fail here, not on accept.
        ComponentRecord.model_validate(component)
    return result
