"""Legacy layout JSON → schema-v0 design (WP-54).

The old grid builder (and PyInventor's exporter) stored setups as
``{uc2_components: [{moduleId, grid_pos: [x, y, layer], rotation: [rx, yaw,
rz], …}]}``. This importer turns that corpus into ``.dsn`` designs that BOTH
sides read: optikit-core validates them, and the frontend resolves each
component back to its palette module via ``primitive.model`` (the WP-43
migrated record ids).

Two conventions bridged here (see openUC2-OptiKit src/document/mapping.ts):

- store grid ``[x, y, layer]`` → document cell ``(x, -y, layer)`` (store y
  grows "south", document y is north);
- store yaw (degrees, CW, index 1 of the rotation triple) → document yaw =
  ``-storeYaw``;
- record optics are authored along ±z (schema convention); the placement
  rotation maps the entry beam onto document +x and any fold arm onto -y —
  the same ``defaultRotationFor`` the palette applies (WP-34) — THEN the yaw
  turns the part in the plane. The emitted ``rotation.grid`` basis is the
  composition.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from ..library.build import Library, resolve
from ..schema.library import ComponentRecord, ModuleRecord

_INPUT_PORT_RE = re.compile(r"^(front|sensor|in|plane)$")

_AXIS_VEC = {
    "+x": np.array([1.0, 0, 0]), "-x": np.array([-1.0, 0, 0]),
    "+y": np.array([0, 1.0, 0]), "-y": np.array([0, -1.0, 0]),
    "+z": np.array([0, 0, 1.0]), "-z": np.array([0, 0, -1.0]),
}


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_") or "part"


def _beam_dir(name: str, direction: Any) -> np.ndarray:
    """Beam TRAVEL direction of a port (entry ports face against the beam)."""
    if isinstance(direction, (list, tuple)):
        v = np.array([float(x) for x in direction])
        v = v / (np.linalg.norm(v) or 1.0)
    else:
        v = _AXIS_VEC.get(str(direction), _AXIS_VEC["+z"]).copy()
    return -v if _INPUT_PORT_RE.match(name) else v


def _default_rotation(component: ComponentRecord) -> np.ndarray:
    """The palette's default placement rotation, from the record's own ports.

    Mirror of the frontend's ``defaultRotationFor`` (libraryPalette.ts):
    entry beam → document +x; a fold arm additionally → -y (right-handed
    completion); no ports → identity.
    """
    ports = [(n, p.direction) for n, p in component.optics.ports.items()]
    if not ports:
        return np.eye(3)
    by_name = dict(ports)
    entry = (
        "front" if "front" in by_name
        else next((n for n, _ in ports if _INPUT_PORT_RE.match(n)), None)
        or ("out" if "out" in by_name else ports[0][0])
    )
    b = _beam_dir(entry, by_name[entry])
    fold = next(
        (d for d in (_beam_dir(n, dirn) for n, dirn in ports) if abs(d @ b) < 0.5),
        None,
    )
    if fold is not None:
        s3 = np.cross(b, fold)
        source = np.column_stack([b, fold, s3])
        t1, t2 = _AXIS_VEC["+x"], _AXIS_VEC["-y"]
        target = np.column_stack([t1, t2, np.cross(t1, t2)])
        return target @ source.T
    # Minimal rotation taking the beam onto +x (Rodrigues via quaternion-free path).
    t = _AXIS_VEC["+x"]
    v = np.cross(b, t)
    c = float(b @ t)
    if np.linalg.norm(v) < 1e-9:
        return np.eye(3) if c > 0 else np.diag([1.0, -1.0, -1.0])  # 180° about x
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + vx + vx @ vx * (1.0 / (1.0 + c))


def _axis_label(v: np.ndarray) -> str:
    i = int(np.argmax(np.abs(v)))
    return f"{'+' if v[i] > 0 else '-'}{'xyz'[i]}"


def _grid_spec(m: np.ndarray) -> dict[str, str] | None:
    """The ``rotation.grid`` block ({z, x} images), None for identity."""
    z_img = _axis_label(m @ np.array([0.0, 0, 1]))
    x_img = _axis_label(m @ np.array([1.0, 0, 0]))
    spec: dict[str, str] = {}
    if z_img != "+z":
        spec["z"] = z_img
    if x_img != "+x":
        spec["x"] = x_img
    return spec or None


def _yaw_matrix(doc_yaw_deg: float) -> np.ndarray:
    a = np.radians(doc_yaw_deg)
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.0]])


@dataclass
class LayoutImportResult:
    design_yaml: str
    components: int
    unresolved: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def import_layout_json(
    path: str | Path, library: Library, name: str = ""
) -> LayoutImportResult:
    """Convert one legacy layout JSON into an ``optikit-design.yml`` text."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    raw_components = data.get("uc2_components") or []
    meta = data.get("metadata") or {}
    design_name = name or _slug(Path(path).stem)

    unresolved: list[str] = []
    warnings: list[str] = []
    components: dict[str, Any] = {}
    used: set[str] = set()

    for entry in raw_components:
        module_id = f"openuc2.cube.{_slug(str(entry.get('moduleId') or 'part'))}"
        hit = resolve(library, f"{module_id}@*")
        category = ""
        rotation_m = np.eye(3)
        if hit is not None and isinstance(hit.record, ModuleRecord):
            comp_hit = resolve(library, hit.record.component)
            if comp_hit is not None and isinstance(comp_hit.record, ComponentRecord):
                category = comp_hit.record.category
                rotation_m = _default_rotation(comp_hit.record)
        else:
            unresolved.append(module_id)
            warnings.append(
                f"{entry.get('moduleId')}: no record {module_id!r} in the library — "
                f"kept as an unresolved reference"
            )

        gx, gy, gz = (list(entry.get("grid_pos") or [0, 0, 0]) + [0, 0, 0])[:3]
        rot = (list(entry.get("rotation") or [0, 0, 0]) + [0, 0, 0])[:3]
        store_yaw = float(rot[1])
        doc_yaw = -store_yaw
        total = _yaw_matrix(doc_yaw) @ rotation_m

        key_base = _slug(str(entry.get("name") or entry.get("moduleId") or "part"))
        key = key_base
        n = 1
        while key in used:
            n += 1
            key = f"{key_base}-{n}"
        used.add(key)

        rotation_block: dict[str, Any] = {"type": "grid"}
        grid = _grid_spec(total)
        if grid:
            rotation_block["grid"] = grid
        translation: dict[str, Any] = {}
        cell = {"x": int(gx), "y": int(-gy), "z": int(gz)}
        cell = {k: v for k, v in cell.items() if v}
        if cell:
            translation["offset-grid"] = cell

        comp: dict[str, Any] = {
            "type": "primitive",
            "primitive": {"type": "glb", "model": module_id},
            "pose": {"rotation": rotation_block, "translation": translation},
        }
        if category:
            comp["category"] = category
        components[key] = comp

    design: dict[str, Any] = {
        "optikit-version": "v0.0.0-alpha.1",
        "design": {
            "name": design_name,
            "version": "0.1.0",
            "description": (
                f"converted from legacy layout JSON ({Path(path).name}, "
                f"exported {meta.get('created', 'unknown date')}) — WP-54"
            ),
            "tags": ["converted", "legacy-layout"],
        },
        "components": components,
    }

    import yaml

    text = yaml.safe_dump(design, sort_keys=False, allow_unicode=True)
    return LayoutImportResult(
        design_yaml=text,
        components=len(components),
        unresolved=unresolved,
        warnings=warnings,
    )
