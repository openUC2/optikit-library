"""Thorlabs / Zemax vendor import: ``.zmx`` prescription → optical component record.

Extends the seeded vendor-catalog approach of the legacy ``optikit_exporter``
(``vendor_catalog.py``): instead of resolving SKUs into live Optiland optics at
export time, a ``.zmx`` file is imported **once** into a git-versioned
:class:`~optikit_core.schema.library.ComponentRecord` whose ``optics.fragment``
carries the surface list verbatim.

Zemax parsing is optiland's, not ours (WP-9 rule: do not hand-parse ZMX beyond
what optiland lacks):

- :func:`optiland.fileio.load_zemax_file` builds the ``Optic`` whose serialized
  surfaces become the fragment (and whose paraxial solve gives the EFL);
- ``optiland.fileio.zemax.reader.parser.ZemaxDataParser`` supplies the one
  thing the converter drops on the floor: the per-surface ``DIAM`` records.
  In ``.zmx`` files DIAM stores the **semi**-diameter (a Ø25.4 mm achromat
  carries ``DIAM 1.27E+1``), which is exactly our ``semi_aperture``.

Materials are normalized to names optiland's material database resolves
*without* fuzzy search — the canonical name is the database file stem (e.g.
the file's ``SF10`` becomes ``N-SF10``). Glass that only resolved to an
index/Abbe fallback is kept verbatim and flagged ``review`` — no guessing.

Every imported component gets datum frames:

- ``optical`` at the first vertex,
- ``exit`` at the last vertex (first vertex + total center thickness), so
  port-to-port gaps equal physical air gaps (compiler convention),
- ``mount`` at the mid-plane of the edge cylinder, derived from the center
  thickness and the clear semi-diameter via the spherical sag.

Where do the ``.zmx`` files come from? Thorlabs publishes one per lens on the
product page ("Zemax file" under the part-number popup / the red docs icon);
downloading is deliberately out of scope here — drop the files into a local
directory and point ``optikit-core import thorlabs --zmx-dir`` at it.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..schema.library import ComponentRecord

#: Filename suffixes Thorlabs appends to the MPN in their download names.
_FILENAME_NOISE_RE = re.compile(r"[-_](zemax)([-_]zmx)?$", re.IGNORECASE)

INITIAL_VERSION = "0.1.0"


class ZmxImportError(Exception):
    """A ``.zmx`` file could not be imported (missing file, optiland failure)."""


@dataclass
class ZmxImportResult:
    """One imported prescription: the component record plus review flags."""

    component: dict[str, Any]
    review: list[str] = field(default_factory=list)
    efl_mm: float | None = None
    mpn: str = ""

    @property
    def record(self) -> ComponentRecord:
        return ComponentRecord.model_validate(self.component)


def _require_optiland():  # noqa: ANN202
    try:
        import optiland  # noqa: F401
    except ImportError as exc:  # pragma: no cover - exercised via CLI message
        raise ImportError(
            "optiland is required for zmx import: pip install optikit-core[sim]"
        ) from exc


def mpn_from_filename(path: Path) -> str:
    """Derive the manufacturer part number from a Thorlabs download name.

    ``AC254-050-A-ML-Zemax-ZMX.zmx`` → ``AC254-050-A-ML``.
    """
    return _FILENAME_NOISE_RE.sub("", path.stem)


def _slug(mpn: str) -> str:
    slug = re.sub(r"[^a-z0-9_-]+", "-", mpn.lower()).strip("-")
    if not slug or not slug[0].isalnum():
        raise ZmxImportError(f"cannot derive a record id from MPN {mpn!r}")
    return slug


# --- material normalization -----------------------------------------------------------


def _canonical_material(material_post: dict[str, Any], where: str, review: list[str]) -> dict:
    """Normalize a serialized Material to its database-canonical name.

    The canonical name is the stem of the database file optiland resolved —
    deterministic and re-resolvable without ``robust_search``. Anything that
    did not resolve to a database file is kept verbatim and flagged.
    """
    name = material_post.get("name", "")
    filename = material_post.get("filename") or ""
    canonical = Path(filename).stem if filename else ""
    if not canonical:
        review.append(
            f"{where}: glass {name!r} did not resolve in optiland's material "
            "database (kept verbatim) — resolve manually"
        )
        return {k: v for k, v in material_post.items() if k != "filename"}
    if canonical.lower() != name.lower():
        review.append(
            f"{where}: glass {name!r} normalized to database name {canonical!r} "
            "via optiland's search — verify"
        )
    return {"type": "Material", "name": canonical}


def _normalize_material(surf: dict[str, Any], where: str, review: list[str]) -> dict | None:
    """Fragment ``material_post`` for one serialized surface (None = air, omitted)."""
    mat = surf.get("material_post") or {}
    mtype = mat.get("type", "")
    if mtype == "IdealMaterial" and float(mat.get("index", 1.0)) == 1.0:
        return None  # air — fragment convention omits it
    if mtype == "Material":
        return _canonical_material(mat, where, review)
    # AbbeMaterial fallback (unknown glass), ideal non-air, or anything newer:
    # keep verbatim, flag for review — no guessing.
    review.append(
        f"{where}: non-database material {mtype or '?'!s} kept verbatim — verify"
    )
    return {k: v for k, v in mat.items() if k != "filename"}


# --- geometry helpers ------------------------------------------------------------------


def _sag_mm(radius: float, semi_diameter: float) -> float:
    """Spherical sag at height ``semi_diameter`` (signed like the radius; 0 for flat)."""
    if not math.isfinite(radius) or radius == 0.0:
        return 0.0
    ratio = semi_diameter / radius
    if abs(ratio) >= 1.0:
        raise ValueError(f"semi-diameter {semi_diameter} exceeds |radius| {abs(radius)}")
    return (semi_diameter * ratio) / (1.0 + math.sqrt(1.0 - ratio * ratio))


# --- the importer ----------------------------------------------------------------------


def zmx_to_component(
    zmx_path: str | Path,
    mpn: str = "",
    namespace: str = "thorlabs",
    vendor_name: str = "Thorlabs",
) -> ZmxImportResult:
    """Import one ``.zmx`` prescription into an optical component record."""
    _require_optiland()
    from optiland.fileio import load_zemax_file
    from optiland.fileio.zemax.reader.parser import ZemaxDataParser

    path = Path(zmx_path)
    if not path.is_file():
        raise ZmxImportError(f"no such file: {path}")
    mpn = mpn or mpn_from_filename(path)
    review: list[str] = []

    try:
        optic = load_zemax_file(str(path))
        parsed = ZemaxDataParser(str(path)).parse().to_dict()
    except Exception as exc:
        raise ZmxImportError(f"{path.name}: optiland could not read the file: {exc}") from exc

    serialized = optic.to_dict()
    surfaces: list[dict[str, Any]] = serialized["surface_group"]["surfaces"]
    if len(surfaces) < 3:
        raise ZmxImportError(f"{path.name}: no lens surfaces between object and image")

    has_coordinate_break = any(
        s.get("type") == "coordinate_break" for s in parsed.get("surfaces", {}).values()
    )
    if has_coordinate_break:
        review.append(
            "file uses coordinate breaks: surface indices may not line up with "
            "DIAM records — check semi-apertures"
        )

    # Interior surfaces are the lens; index 0 is the object, the last the image.
    fragment: list[dict[str, Any]] = []
    lens = surfaces[1:-1]
    for i, surf in enumerate(lens):
        where = f"surface {i + 1}"
        geometry = {
            k: v for k, v in (surf.get("geometry") or {}).items() if k != "cs"
        }
        gtype = geometry.get("type", "StandardGeometry")
        if gtype not in ("StandardGeometry", "Plane"):
            review.append(
                f"{where}: geometry {gtype!r} is beyond what the path compiler "
                "supports today — record kept, compilation will fail"
            )
        out: dict[str, Any] = {"type": "standard", "geometry": geometry}
        material = _normalize_material(surf, where, review)
        if material is not None:
            out["material_post"] = material
        # The last thickness is the back focal distance to the image plane,
        # not part of the component.
        if i < len(lens) - 1:
            out["thickness"] = float(surf.get("thickness", 0.0))
        if surf.get("is_stop"):
            out["is_stop"] = True
        interaction = surf.get("interaction_model") or {}
        if interaction.get("is_reflective"):
            out["interaction_model"] = {
                "type": "refractive_reflective",
                "is_reflective": True,
            }
        # Semi-aperture from the parser's DIAM records (ZMX stores semi-diameters).
        if not has_coordinate_break:
            diam = (parsed.get("surfaces", {}).get(i + 1) or {}).get("diameter")
            if isinstance(diam, int | float) and diam > 0:
                out["semi_aperture"] = float(diam)
        fragment.append(out)

    if not any("semi_aperture" in s for s in fragment):
        review.append(
            "no DIAM records found: clear aperture unknown, chain inference "
            "will fall back to its default"
        )

    center_thickness = sum(s.get("thickness", 0.0) for s in fragment)
    semi = max((s["semi_aperture"] for s in fragment if "semi_aperture" in s), default=0.0)

    # Mount plane: mid-plane of the edge cylinder (shoulder), from sag at the
    # clear semi-diameter. Fall back to the center-thickness mid-plane.
    mount_z = center_thickness / 2.0
    if semi > 0.0 and fragment:
        try:
            front_sag = _sag_mm(fragment[0]["geometry"].get("radius", math.inf), semi)
            back_sag = _sag_mm(fragment[-1]["geometry"].get("radius", math.inf), semi)
            mount_z = (front_sag + (center_thickness + back_sag)) / 2.0
        except ValueError:
            review.append(
                "edge/shoulder plane not derivable (semi-diameter exceeds a "
                "radius) — mount frame set to the center-thickness mid-plane"
            )
    else:
        review.append("mount frame set to the center-thickness mid-plane (no aperture data)")

    try:
        efl = float(optic.paraxial.f2())
    except Exception as exc:  # noqa: BLE001 — diagnostic only
        efl = None
        review.append(f"paraxial EFL not computable: {exc}")

    component = {
        "kind": "optical_component",
        "id": f"{namespace}.lens.{_slug(mpn)}",
        "version": INITIAL_VERSION,
        "category": "lens",
        "description": parsed.get("name", "") or f"{vendor_name} {mpn}",
        "tags": ["imported", "zmx"],
        "vendor": {"name": vendor_name, "mpn": mpn},
        "optics": {
            "fragment": {"surfaces": fragment},
            "frames": {
                "optical": {"z-mm": 0.0},
                "exit": {"z-mm": round(center_thickness, 9)},
                "mount": {"z-mm": round(mount_z, 6)},
            },
            "ports": {
                "front": {"frame": "optical", "direction": "-z"},
                "back": {
                    "frame": "exit",
                    "direction": "+z",
                    "after-surface": len(fragment) - 1,
                },
            },
        },
    }
    if review:
        component["review"] = review
    if efl is not None:
        component["effective_focal_length_mm"] = round(efl, 6)

    result = ZmxImportResult(component=component, review=review, efl_mm=efl, mpn=mpn)
    _ = result.record  # validate eagerly — an unwritable record should fail here
    return result


# --- batch mode --------------------------------------------------------------------------


def find_zmx_for_mpn(zmx_dir: str | Path, mpn: str) -> Path:
    """Locate the ``.zmx`` file for an MPN in a local directory.

    Matches ``<mpn>.zmx`` and Thorlabs download names like
    ``<mpn>-Zemax-ZMX.zmx``, case-insensitively. Exact-MPN stems win over
    prefix matches (``AC254-050-A`` must not pick up ``AC254-050-A-ML``).
    """
    directory = Path(zmx_dir)
    exact: list[Path] = []
    prefixed: list[Path] = []
    want = mpn.lower()
    for candidate in sorted(directory.glob("*.zmx")):
        stem = mpn_from_filename(candidate).lower()
        if stem == want:
            exact.append(candidate)
        elif stem.startswith(want):
            prefixed.append(candidate)
    matches = exact or prefixed
    if not matches:
        raise ZmxImportError(
            f"no .zmx file for {mpn!r} in {directory} — download the Zemax file "
            "from the thorlabs.com product page and drop it there"
        )
    if len(matches) > 1:
        names = ", ".join(p.name for p in matches)
        raise ZmxImportError(f"ambiguous .zmx files for {mpn!r}: {names}")
    return matches[0]


def import_thorlabs_mpns(
    mpns: list[str], zmx_dir: str | Path, namespace: str = "thorlabs"
) -> list[ZmxImportResult]:
    """Batch import: one component record per MPN, from local ``.zmx`` files."""
    results = []
    for mpn in mpns:
        path = find_zmx_for_mpn(zmx_dir, mpn)
        results.append(zmx_to_component(path, mpn=mpn, namespace=namespace))
    return results
