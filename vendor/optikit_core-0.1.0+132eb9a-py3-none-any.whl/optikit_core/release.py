"""Release-bundle verification (WP-18): ``optikit-core rebuild <bundle.zip>``.

A release bundle (exported by the openUC2-OptiKit editor) is a zip holding
the merged design, a lockfile with sha256 pins, the BOM/notes, and the
compiled ``optic.<path>.json`` files. ``rebuild`` proves reproducibility:

1. **integrity** — every file listed in ``optikit-lock.yml`` hashes to its pin;
2. **reproducibility** — every path in the lock recompiles from the bundled
   design and the canonicalized optic structure matches the bundled one
   byte-for-byte.

Canonicalization: both sides are parsed to Python structures (the bundle's
``±1e999`` literals overflow to ``±inf`` in ``json.loads``) and re-dumped with
sorted keys and fixed separators — so browser vs Python float formatting
cannot cause false mismatches, while any real numeric or structural change
fails the comparison.
"""

from __future__ import annotations

import hashlib
import io
import json
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .compile import CompileError, compile_path
from .geometry import FlattenError
from .io.yamlio import load_document_text
from .schema import DESIGN_DECL_FILE, DesignDecl

LOCK_FILE = "optikit-lock.yml"


class RebuildError(Exception):
    """The bundle is unreadable or structurally incomplete."""


@dataclass
class RebuildReport:
    ok: bool
    checks: list[tuple[str, bool, str]] = field(default_factory=list)

    def add(self, name: str, passed: bool, detail: str = "") -> None:
        self.checks.append((name, passed, detail))
        if not passed:
            self.ok = False

    def table(self) -> str:
        lines = []
        for name, passed, detail in self.checks:
            mark = "OK " if passed else "FAIL"
            lines.append(f"  {mark}  {name}" + (f"  ({detail})" if detail else ""))
        return "\n".join(lines)


def _canon(obj: Any) -> Any:
    """Numbers become floats: JavaScript's JSON round trip erases the
    int/float distinction (1.0 → 1), so a browser-written optic must not
    fail the comparison over it. Real value changes still differ."""
    if isinstance(obj, bool):
        return obj
    if isinstance(obj, int):
        return float(obj)
    if isinstance(obj, dict):
        return {k: _canon(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_canon(v) for v in obj]
    return obj


def canonical_bytes(obj: Any) -> bytes:
    """Deterministic JSON bytes: sorted keys, fixed separators, inf allowed,
    ints folded into floats (see _canon)."""
    return json.dumps(
        _canon(obj), sort_keys=True, separators=(",", ":"), allow_nan=True
    ).encode()


def _read_bundle(path: Path) -> dict[str, bytes]:
    try:
        with zipfile.ZipFile(path) as archive:
            entries = {}
            for info in archive.infolist():
                if info.is_dir():
                    continue
                name = info.filename
                # Tolerate a single wrapping directory ("x-release/…").
                if "/" in name:
                    name = name.split("/", 1)[1]
                if name and not name.startswith("."):
                    entries[name] = archive.read(info)
            return entries
    except (OSError, zipfile.BadZipFile) as exc:
        raise RebuildError(f"cannot read bundle: {exc}") from exc


def rebuild(bundle_path: str | Path) -> RebuildReport:
    """Verify a release bundle; every finding lands in the report."""
    files = _read_bundle(Path(bundle_path))
    if LOCK_FILE not in files:
        raise RebuildError(f"bundle has no {LOCK_FILE}")
    if DESIGN_DECL_FILE not in files:
        raise RebuildError(f"bundle has no {DESIGN_DECL_FILE}")

    lock = load_document_text(files[LOCK_FILE].decode("utf-8")) or {}
    report = RebuildReport(ok=True)

    # 1 — integrity: every pinned file is present and hashes to its pin.
    pins: dict[str, str] = dict(lock.get("sha256") or {})
    for name, expected in pins.items():
        if name not in files:
            report.add(f"integrity {name}", False, "file missing from bundle")
            continue
        actual = hashlib.sha256(files[name]).hexdigest()
        report.add(
            f"integrity {name}",
            actual == expected,
            "" if actual == expected else f"sha256 {actual[:12]}… != pinned {expected[:12]}…",
        )

    # 2 — reproducibility: recompile every locked path and byte-compare the
    #     canonicalized optic structures.
    try:
        decl = DesignDecl.model_validate(
            load_document_text(files[DESIGN_DECL_FILE].decode("utf-8")) or {}
        )
    except Exception as exc:  # noqa: BLE001 — reported, not raised
        report.add("design parses", False, str(exc))
        return report
    report.add("design parses", True)

    for name in lock.get("paths") or []:
        optic_file = f"optic.{name}.json"
        if optic_file not in files:
            report.add(f"recompile {name}", False, f"{optic_file} missing")
            continue
        try:
            bundled = json.loads(files[optic_file])  # ±1e999 → ±inf
        except json.JSONDecodeError as exc:
            report.add(f"recompile {name}", False, f"{optic_file} unparseable: {exc}")
            continue
        try:
            recompiled = compile_path(decl, name).optic
        except (CompileError, FlattenError) as exc:
            report.add(f"recompile {name}", False, f"{exc.code}: {exc}")
            continue
        identical = canonical_bytes(bundled) == canonical_bytes(recompiled)
        report.add(
            f"recompile {name}",
            identical,
            "bit-identical" if identical else "optic differs from a fresh compile",
        )

    return report


def build_bundle_bytes(decl_yaml: str, path_names: list[str]) -> bytes:
    """Construct a bundle the way the frontend does (test/CLI helper).

    Compiles every path, writes optic JSON with the ±1e999 Infinity contract,
    and pins everything in the lockfile.
    """
    decl = DesignDecl.model_validate(load_document_text(decl_yaml) or {})
    files: dict[str, bytes] = {DESIGN_DECL_FILE: decl_yaml.encode()}
    for name in path_names:
        optic = compile_path(decl, name).optic
        text = json.dumps(optic, indent=2, allow_nan=True)
        text = text.replace("Infinity", "1e999")
        files[f"optic.{name}.json"] = (text + "\n").encode()

    pins = {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}
    lock_lines = [
        "schema: optikit-lock/v0",
        f"design: {json.dumps(decl.design.name or 'untitled')}",
        f"paths: [{', '.join(json.dumps(n) for n in path_names)}]",
        "sha256:",
        *(f"  {json.dumps(name)}: {hex_}" for name, hex_ in pins.items()),
        "",
    ]
    files[LOCK_FILE] = "\n".join(lock_lines).encode()

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, data in files.items():
            archive.writestr(name, data)
    return buffer.getvalue()
